;; =========================================================================
;; Map.lsp - Automated Map Vector Data Fetch & Draw
;; Description: Connects to a Python script to fetch OSM roads, buildings,
;;              and parcels based on coordinates, then draws them 1:1 in CAD.
;; =========================================================================

(defun c:map ( / currDir pyScript resultFile wsh cmd f line pts objType commaPos x y )
  (vl-load-com)

  ;; Đường dẫn gốc chứa file script
  (setq currDir "c:\\Users\\longnh\\OneDrive\\02.Libraries\\04.CAD\\02.Tool\\02.MasterW\\MapGG_Lisp\\")
  (setq pyScript (strcat currDir "fetch_map_data.py"))
  (setq resultFile (strcat currDir "map_vectors.txt"))
  
  (princ "\nĐang mở phần mềm Chọn Bản đồ Vệ tinh UI...\nLưu ý: Lần chạy đầu tiên Python sẽ cài thư viện nên có thể mất 15-30 giây.\n")
  
  ;; Xóa file vector cũ đi nếu có
  (if (findfile resultFile)
    (vl-file-delete resultFile)
  )

  ;; Khởi tạo môi trường WScript chạy ngầm Python
  (setq wsh (vlax-create-object "WScript.Shell"))
  ;; Format lệnh cmd để bật giao diện UI Python. Dùng lại "python" nhưng ẩn viền đen
  (setq cmd (strcat "python \"" pyScript "\" \"" resultFile "\""))
  
  ;; Dùng hàm Wscript Run = 0 (vbHide) để ẨN HOÀN TOÀN Cửa sổ đen của CMD, 
  ;; nhưng Giao diện UI giao tiếp của Python vẫn hiển thị do là Windows Form
  (vlax-invoke-method wsh 'Run cmd 0 :vlax-true)
  (vlax-release-object wsh)

  ;; Sau khi chạy xong, tiến hành đọc file Vector Text đầu ra
  (if (setq f (open resultFile "r"))
    (progn
      (setq pts nil)
      (while (setq line (read-line f))
         ;; Xóa các ký tự rác xuống dòng
         (setq line (vl-string-trim "\r\n " line))
         (cond
           ((vl-string-search "START" line)
              (setq pts nil)
              (setq objType (substr line 7)) ; Lấy loại (ROAD/BUILDING...)
           )
           ((vl-string-search "END" line)
              (if (> (length pts) 1)
                (DrawPolyline pts objType)
              )
           )
           (t
              ;; Xử lý đọc dòng "x,y"
              (setq commaPos (vl-string-position (ascii ",") line))
              (if commaPos
                (progn
                   (setq x (atof (substr line 1 commaPos)))
                   (setq y (atof (substr line (+ commaPos 2))))
                   (setq pts (append pts (list (list x y))))
                )
              )
           )
         )
      )
      (close f)
      (princ "\nVẽ hoàn tất với kích thước chính xác 1:1 theo Unit CAD.")
      (command "_.ZOOM" "_E")
    )
    (princ "\nLỗi: Không tìm thấy file dữ liệu vector trả về. Có thể máy chưa cài thư viện chuẩn Python (python -m urllib).")
  )
  (princ)
)

;; Cốt lõi LISP: Vẽ nét siêu tốc qua EntMake thay vì lệnh Command thông thường.
(defun DrawPolyline ( pointList objType / color )
  (setq color 7) ; Màu trắng là mặc định
  
  (cond
    ((vl-string-search "ROAD" objType)     (setq color 1)) ; Màu đỏ (Đường giao thông)
    ((vl-string-search "BUILDING" objType) (setq color 3)) ; Màu xanh lá cây (Tòa nhà / Nhà dân)
    ((vl-string-search "LANDUSE" objType)  (setq color 5)) ; Màu xanh dương (Khu đất ngầm / Ranh giới)
  )
  
  (entmake
    (append
      (list '(0 . "LWPOLYLINE")
            '(100 . "AcDbEntity")
            '(100 . "AcDbPolyline")
            (cons 90 (length pointList))
            (cons 70 0)   ; 0 = Không tự động đóng kín (Open), 1 = Đóng kín (Closed). An toàn nhất cứ mở hết.
            (cons 62 color)
      )
      (mapcar '(lambda (pt) (cons 10 pt)) pointList)
    )
  )
)

(princ "\nĐã tải Giao diện Map Vệ tinh UI Cao Cấp! Lệnh gõ: map")
(princ)
