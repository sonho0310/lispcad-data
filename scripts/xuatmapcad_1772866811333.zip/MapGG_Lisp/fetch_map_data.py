import sys
import os
import subprocess
import urllib.request
import urllib.parse
import math
import threading
import json
import threading

# --- Tự động cài đặt thư viện cần thiết nếu phát hiện thiếu ---
def ensure_packages():
    required = {"customtkinter": "customtkinter", "tkintermapview": "tkintermapview"}
    pending = []
    
    for module_name, pip_name in required.items():
        try:
            __import__(module_name)
        except ImportError:
            pending.append(pip_name)
            
    if pending:
        # Tắt in ra console để tránh xung đột với tiến trình pythonw ngầm
        subprocess.check_call([sys.executable, "-m", "pip", "install", *pending], 
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

ensure_packages()

import customtkinter as ctk
import tkintermapview

# Cấu hình giao diện thẩm mỹ Dark Mode Cao Cấp
ctk.set_appearance_mode("Dark")  
ctk.set_default_color_theme("blue")  

class MapApp(ctk.CTk):
    def __init__(self, output_file):
        super().__init__()
        self.output_file = output_file
        self.title("AutoCAD - Map Vector Extractor Pro")
        self.geometry("1050x700")
        
        # Cấu hình grid phân chia 2 mảng: Left (Menu) và Right (Map)
        self.grid_columnconfigure(0, weight=0)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        
        # ==================== BẢNG ĐIỀU KHIỂN (LEFT) ====================
        self.frame_left = ctk.CTkFrame(master=self, width=300, corner_radius=0)
        self.frame_left.grid(row=0, column=0, sticky="nswe")
        
        self.label_title = ctk.CTkLabel(self.frame_left, text="MAP TO CAD", font=ctk.CTkFont(size=28, weight="bold"))
        self.label_title.grid(row=0, column=0, padx=20, pady=(30, 10))
        
        # 1. Khung tìm kiếm
        self.entry_search = ctk.CTkEntry(self.frame_left, placeholder_text="Nhập địa điểm (vd: Hanoi)")
        self.entry_search.grid(row=1, column=0, padx=20, pady=(10, 0), sticky="we")
        self.entry_search.bind("<Return>", self.search_event)
        
        self.btn_search = ctk.CTkButton(self.frame_left, text="Tìm kiếm địa điểm", command=self.search_event)
        self.btn_search.grid(row=2, column=0, padx=20, pady=(10, 20), sticky="we")
        
        # 2. Khung tinh chỉnh Bán kính (Area Size)
        self.label_radius = ctk.CTkLabel(self.frame_left, text="Bán kính khoanh vùng: 200m")
        self.label_radius.grid(row=3, column=0, padx=20, pady=(10, 0), sticky="w")
        
        self.slider_radius = ctk.CTkSlider(self.frame_left, from_=50, to=2000, command=self.update_radius_label)
        self.slider_radius.set(200)
        self.slider_radius.grid(row=4, column=0, padx=20, pady=(5, 20), sticky="we")
        
        # 3. Checklist Dữ Liệu
        self.label_options = ctk.CTkLabel(self.frame_left, text="Cấu hình Dữ Liệu Vẽ:", font=ctk.CTkFont(weight="bold"))
        self.label_options.grid(row=5, column=0, padx=20, pady=(10, 0), sticky="w")
        
        self.chk_road = ctk.CTkCheckBox(self.frame_left, text="Đường giao thông (Roads)", text_color="#ff9999")
        self.chk_road.select()
        self.chk_road.grid(row=6, column=0, padx=20, pady=5, sticky="w")
        
        self.chk_building = ctk.CTkCheckBox(self.frame_left, text="Nhà dân/Tòa nhà (Buildings)", text_color="#99ff99")
        self.chk_building.select()
        self.chk_building.grid(row=7, column=0, padx=20, pady=5, sticky="w")
        
        self.chk_landuse = ctk.CTkCheckBox(self.frame_left, text="Ranh giới khu đất (Landuse)", text_color="#99ccff")
        self.chk_landuse.select()
        self.chk_landuse.grid(row=8, column=0, padx=20, pady=5, sticky="w")
        
        # 4. Label Trạng thái
        self.label_status = ctk.CTkLabel(self.frame_left, text="Chỉ cần kéo thả Map đến khu đất.\nÔ đỏ là vùng sẽ tải!", text_color="#00E5FF")
        self.label_status.grid(row=9, column=0, padx=20, pady=(30, 0), sticky="w")
        
        # 5. Nút Bấm Thực Thi
        self.btn_render = ctk.CTkButton(self.frame_left, text="TẢI XUỐNG VÀ VẼ CAD", height=50, 
                                        font=ctk.CTkFont(size=14, weight="bold"), 
                                        fg_color="#D84315", hover_color="#BF360C",
                                        command=self.fetch_data)
        self.btn_render.grid(row=10, column=0, padx=20, pady=(20, 20), sticky="we")
        
        # ==================== HIỂN THỊ BẢN ĐỒ (RIGHT) ====================
        self.frame_right = ctk.CTkFrame(master=self, corner_radius=0)
        self.frame_right.grid(row=0, column=1, sticky="nswe")
        self.frame_right.grid_rowconfigure(1, weight=1)
        self.frame_right.grid_columnconfigure(0, weight=1)
        
        # Segment button đổi mode bản đồ
        self.map_type_var = ctk.StringVar(value="Vệ tinh (Google)")
        self.seg_button = ctk.CTkSegmentedButton(self.frame_right, values=["Bản đồ thường (OSM)", "Vệ tinh (Google)"],
                                                 command=self.change_map_type, variable=self.map_type_var)
        self.seg_button.grid(row=0, column=0, padx=20, pady=10, sticky="n")
        
        # Tạo Widget Bản đồ
        self.map_widget = tkintermapview.TkinterMapView(self.frame_right, corner_radius=10)
        self.map_widget.grid(row=1, column=0, sticky="nswe", padx=10, pady=(0, 10))
        # Mặc định mở Google Vệ tinh siêu nét
        self.map_widget.set_tile_server("https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)
        
        # Setup logic vẽ Boundary
        self.polygon = None
        self.last_center = None
        self.last_radius = None
        
        self.config_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "map_config.json")
        self.load_config()
        
        # Bắt đầu vòng lặp tự động neo khu vực vào giữa màn hình
        self.update_bounds_loop()

    def load_config(self):
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, "r") as f:
                    config = json.load(f)
                    self.map_widget.set_position(config.get("lat", 21.0285), config.get("lon", 105.8542))
                    self.map_widget.set_zoom(config.get("zoom", 16))
                    rad = config.get("radius", 200)
                    self.slider_radius.set(rad)
                    self.update_radius_label(rad)
            else:
                self.map_widget.set_position(21.0285, 105.8542)
                self.map_widget.set_zoom(16)
        except Exception:
            self.map_widget.set_position(21.0285, 105.8542)
            self.map_widget.set_zoom(16)
            
    def save_config(self, lat, lon):
        try:
            config = {
                "lat": lat,
                "lon": lon,
                "zoom": self.map_widget.zoom,
                "radius": self.slider_radius.get()
            }
            with open(self.config_path, "w") as f:
                json.dump(config, f)
        except:
            pass

    def change_map_type(self, value):
        if "Vệ tinh" in value:
            self.map_widget.set_tile_server("https://mt0.google.com/vt/lyrs=s&hl=en&x={x}&y={y}&z={z}&s=Ga", max_zoom=22)
        else:
            self.map_widget.set_tile_server("https://a.tile.openstreetmap.org/{z}/{x}/{y}.png")

    def search_event(self, event=None):
        addr = self.entry_search.get()
        if not addr: return
        
        # Sửa lỗi 403 bằng cách tự Request API Tọa độ với User-Agent chuẩn chỉ
        try:
            self.label_status.configure(text="Đang tìm kiếm tọa độ...", text_color="orange")
            url = f"https://nominatim.openstreetmap.org/search?q={urllib.parse.quote(addr)}&format=json&limit=1"
            req = urllib.request.Request(url, headers={'User-Agent': 'AutoCAD-Map-Fetcher-Pro/3.0'})
            response = urllib.request.urlopen(req, timeout=10)
            data = json.loads(response.read().decode('utf-8'))
            
            if data and len(data) > 0:
                lat = float(data[0]['lat'])
                lon = float(data[0]['lon'])
                self.map_widget.set_position(lat, lon)
                self.label_status.configure(text="Đã chuyển tới: " + data[0].get('display_name', addr).split(',')[0], text_color="#00E5FF")
            else:
                self.label_status.configure(text=f"Không tìm thấy dữ liệu cho: {addr}", text_color="red")
        except Exception as e:
            self.label_status.configure(text=f"Lỗi tìm kiếm địa chỉ: {e}", text_color="red")

    def update_radius_label(self, value):
        self.label_radius.configure(text=f"Bán kính khoanh vùng: {int(value)}m")

    def update_bounds_loop(self):
        current_center = self.map_widget.get_position()
        current_radius = self.slider_radius.get()
        if self.last_center != current_center or self.last_radius != current_radius:
            self.last_center = current_center
            self.last_radius = current_radius
            self.draw_bounds()
        self.after(100, self.update_bounds_loop)

    def draw_bounds(self):
        """Vẽ hình chữ nhật bóng mờ giới hạn khoanh vùng khu đất"""
        if not self.last_center: return
        lat, lon = self.last_center
        radius = self.slider_radius.get()
        
        lat_deg_offset = radius / 111320.0
        lon_deg_offset = radius / (111320.0 * math.cos(math.radians(lat)))
        
        s = lat - lat_deg_offset
        n = lat + lat_deg_offset
        w = lon - lon_deg_offset
        e = lon + lon_deg_offset
        
        if self.polygon:
            self.polygon.delete()
            
        # Vẽ đa giác phủ đỏ
        self.polygon = self.map_widget.set_polygon([(n, w), (n, e), (s, e), (s, w)],
                                                   fill_color="#ff4d4d", outline_color="red", border_width=2)

    def latlon_to_meters(self, lat, lon, origin_lat, origin_lon):
        """Hàm quy đổi tọa độ tròn trái đất sang Mặt phẳng CAD hệ Milimét (Tỉ lệ 1:1)"""
        R = 6378137.0
        lat_r = math.radians(lat)
        lon_r = math.radians(lon)
        origin_lat_r = math.radians(origin_lat)
        origin_lon_r = math.radians(origin_lon)
        
        x = R * (lon_r - origin_lon_r) * math.cos(origin_lat_r)
        y = R * (lat_r - origin_lat_r)
        
        factor = 1000.0 # CAD setup chuẩn 1 unit = 1 milimét
        return x * factor, y * factor

    def fetch_data(self):
        # Lấy thẳng tâm của khung nhìn bản đồ
        current_center = self.map_widget.get_position()
        if not current_center:
            return
            
        lat, lon = current_center
        radius = self.slider_radius.get()
        
        b_road = self.chk_road.get()
        b_build = self.chk_building.get()
        b_land = self.chk_landuse.get()
        
        if not (b_road or b_build or b_land):
            self.label_status.configure(text="Lỗi: Bạn cần tick ít nhất 1 loại dữ liệu!", text_color="red")
            return
            
        self.label_status.configure(text="Đang tải API từ vệ tinh... Xin chờ do Server", text_color="orange")
        self.btn_render.configure(state="disabled")
        
        # Lưu lại cấu hình cho lần chạy sau
        self.save_config(lat, lon)
        
        # Chạy tải bằng luồng Thread riêng để UI không bị đơ
        threading.Thread(target=self._download_and_save, args=(lat, lon, radius, b_road, b_build, b_land)).start()

    def _download_and_save(self, lat, lon, radius, b_road, b_build, b_land):
        lat_deg_offset = radius / 111320.0
        lon_deg_offset = radius / (111320.0 * math.cos(math.radians(lat)))
        
        s = lat - lat_deg_offset
        n = lat + lat_deg_offset
        w = lon - lon_deg_offset
        e = lon + lon_deg_offset
        
        # Ghép mã truy vấn (Thêm time out để tránh lỗi Gateway 504)
        query_parts = []
        if b_road: 
            query_parts.append(f'way["highway"]({s},{w},{n},{e});')
            query_parts.append(f'relation["highway"]({s},{w},{n},{e});')
        if b_build: 
            query_parts.append(f'way["building"]({s},{w},{n},{e});')
            query_parts.append(f'relation["building"]({s},{w},{n},{e});')
        if b_land: 
            query_parts.append(f'way["landuse"]({s},{w},{n},{e});')
            query_parts.append(f'relation["landuse"]({s},{w},{n},{e});')
        
        query_body = "\n".join(query_parts)
        # Set timeout 90 giây cho server Overpass tránh bị Timeout 504. 
        # Cập nhật query thành out body; >; out skel qt; để lấy TRỌN VẸN mọi chi tiết của đường lớn (relation)
        query = f"[out:json][timeout:90];\n(\n{query_body}\n);\nout body;\n>;\nout skel qt;"
        data = urllib.parse.urlencode({'data': query}).encode('utf-8')
        
        # Thử liền 3 máy chủ khác nhau trên thế giới để trị dứt điểm tình trạng Server Gateway Timeout
        endpoints = [
            "https://lz4.overpass-api.de/api/interpreter",
            "https://overpass-api.de/api/interpreter",
            "https://overpass.kumi.systems/api/interpreter"
        ]
        
        result = None
        last_error = ""
        for url in endpoints:
            try:
                # Tăng timeout request của urllib lên 90s để chờ tool load 
                req = urllib.request.Request(url, data=data)
                req.add_header('User-Agent', 'AutoCAD-Map-Fetcher-Pro/3.0')
                response = urllib.request.urlopen(req, timeout=90)
                result = json.loads(response.read().decode('utf-8'))
                break  # Nếu thành công -> Thoát vòng lặp ngay
            except Exception as e:
                last_error = str(e)
                continue  # Nếu lỗi, chạy tiếp server thứ 2
                
        if not result:
            self.label_status.configure(text=f"Lỗi toàn bộ mạng Server: {last_error}", text_color="red")
            self.btn_render.configure(state="normal")
            return
            
        try:
            # Lưu Data Point dưới dạng format chuẩn siêu tốc cho LISP CAD đọc
            with open(self.output_file, "w", encoding='utf-8') as f:
                # Bước 1: Tạo từ điển chứa toàn bộ Nodes (tọa độ các đỉnh)
                nodes = {}
                elements = result.get("elements", [])
                for element in elements:
                    if element["type"] == "node":
                        nodes[element["id"]] = (element["lat"], element["lon"])
                        
                # Bước 2: Dò tìm mọi nét vẽ dạng Way (kể cả nó là 1 phần của Relation con đường lớn)
                for element in elements:
                    if element.get("type") == "way":
                        tags = element.get("tags", {})
                        
                        # Có những "Way" không mang Tag vì nó nằm trong "Relation" tổng.
                        # Ta auto gán chúng thành mạng lưới LINE nét đứt để giữ nguyên hình dạng.
                        obj_type = "LINE"
                        if "highway" in tags: obj_type = "ROAD"
                        elif "building" in tags: obj_type = "BUILDING"
                        elif "landuse" in tags: obj_type = "LANDUSE"
                        
                        # Trích xuất list Tọa độ ID đỉnh (Nodes) của đoạn đường đó
                        node_ids = element.get("nodes", [])
                        if not node_ids or len(node_ids) < 2: continue
                            
                        f.write(f"START {obj_type}\n")
                        for n_id in node_ids:
                            if n_id in nodes:
                                pt_lat, pt_lon = nodes[n_id]
                                x, y = self.latlon_to_meters(pt_lat, pt_lon, lat, lon)
                                f.write(f"{x:.3f},{y:.3f}\n")
                        f.write("END\n")
            
            # Thông báo tự tắt Tools
            self.label_status.configure(text="HOÀN TẤT. TOOL TỰ ĐÓNG VÀ Vẽ CAD SAU 1S", text_color="#00FF00")
            self.after(1500, self.destroy)
            
        except Exception as ex:
            self.label_status.configure(text=f"Lỗi truy xuất: {ex}", text_color="red")
            self.btn_render.configure(state="normal")

if __name__ == "__main__":
    out_file = "map_vectors.txt"
    if len(sys.argv) > 1:
        out_file = sys.argv[1]
        
    # Tạo đường dẫn cố định ngăn lỗi ghi khác ổ đĩa
    if not os.path.isabs(out_file):
        out_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), out_file)
        
    app = MapApp(out_file)
    app.mainloop()
