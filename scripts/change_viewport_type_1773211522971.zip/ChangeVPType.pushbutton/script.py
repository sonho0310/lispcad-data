# -*- coding: utf-8 -*-
__title__ = "Change\nViewports Type"
from pyrevit import revit, DB, forms, script
from System.Windows.Data import CollectionViewSource, PropertyGroupDescription
from System.Collections.ObjectModel import ObservableCollection
from System.Windows import Visibility
import clr
try: clr.AddReference("System.Drawing")
except: pass

doc = revit.doc
uidoc = revit.uidoc

VIEW_TYPE_ORDER = {
    "FloorPlan":0,"CeilingPlan":1,"EngineeringPlan":2,"AreaPlan":3,
    "Section":4,"Elevation":5,"Detail":6,"ThreeD":7,"DraftingView":10,"Legend":20,
}
CATEGORY_MAP = {"DraftingView": "DraftingView", "Legend": "Legend"}
FILTER_OPTIONS = [u"All Types", u"Views", u"Drafting Views", u"Legends"]

def get_view_sort_key(view):
    if view is None: return (99, "")
    return (VIEW_TYPE_ORDER.get(view.ViewType.ToString(), 9), view.Name)

def get_view_category(view):
    if view is None: return "Other"
    return CATEGORY_MAP.get(view.ViewType.ToString(), "View")

class ViewportItem(forms.Reactive):
    def __init__(self, viewport, sheet_label, view_name, current_type_name,
                 sort_key, vp_type_names, view_category):
        self._is_checked = True
        self._manual_type = current_type_name
        self.viewport = viewport
        self.sheet_label = sheet_label
        self.view_name = view_name
        self.current_type = current_type_name
        self.sort_key = sort_key
        self.vp_type_names = vp_type_names
        self.view_category = view_category
        self.source_val = ""
        self.dest_val = ""

    @forms.reactive
    def is_checked(self): return self._is_checked
    @is_checked.setter
    def is_checked(self, value): self._is_checked = value

    @forms.reactive
    def manual_type(self): return self._manual_type
    @manual_type.setter
    def manual_type(self, value): self._manual_type = value

# ────────────────── Parameter helpers ──────────────────
def collect_view_params(vp_items):
    """Scan first view + viewport to find all string parameters."""
    source_params = []  # (display_name, element_type, param_name)
    dest_params = []
    if not vp_items: return source_params, dest_params

    first = vp_items[0]
    view = doc.GetElement(first.viewport.ViewId)
    vp = first.viewport
    seen = set()

    # Special: View Name (read-only, source only)
    source_params.append(("View Name", "view_name", None))

    # View parameters
    if view:
        for p in view.Parameters:
            if p.StorageType == DB.StorageType.String:
                name = p.Definition.Name
                if name in seen or name == "View Name": continue
                seen.add(name)
                source_params.append((name, "view", name))
                if not p.IsReadOnly:
                    dest_params.append((name, "view", name))

    # Viewport parameters
    seen_vp = set()
    for p in vp.Parameters:
        if p.StorageType == DB.StorageType.String:
            name = p.Definition.Name
            if name in seen_vp or name in seen: continue
            seen_vp.add(name)
            label = u"[VP] " + name
            source_params.append((label, "viewport", name))
            if not p.IsReadOnly:
                dest_params.append((label, "viewport", name))

    return source_params, dest_params

def read_param(item, param_info):
    """Read a parameter value from a viewport item."""
    _, etype, pname = param_info
    try:
        if etype == "view_name":
            v = doc.GetElement(item.viewport.ViewId)
            return v.Name if v else ""
        elif etype == "view":
            v = doc.GetElement(item.viewport.ViewId)
            if v:
                p = v.LookupParameter(pname)
                if p and p.HasValue: return p.AsString() or ""
        elif etype == "viewport":
            p = item.viewport.LookupParameter(pname)
            if p and p.HasValue: return p.AsString() or ""
    except: pass
    return ""

def write_param(item, param_info, value):
    """Write a parameter value to a viewport item."""
    _, etype, pname = param_info
    try:
        if etype == "view":
            v = doc.GetElement(item.viewport.ViewId)
            if v:
                p = v.LookupParameter(pname)
                if p and not p.IsReadOnly: p.Set(value or "")
        elif etype == "viewport":
            p = item.viewport.LookupParameter(pname)
            if p and not p.IsReadOnly: p.Set(value or "")
    except: pass

# ────────────────── Main Window ──────────────────
class ChangeVPTypeWindow(forms.WPFWindow):
    def __init__(self, vp_items, vp_type_dict):
        forms.WPFWindow.__init__(self, "ChangeVPType.xaml")
        self.vp_type_dict = vp_type_dict
        self.selected_type_name = None
        self.is_manual = False
        self.is_transfer = False
        self.action = "cancel"
        self._set_revit_icon()
        self._all_items = list(vp_items)

        # Collect params for transfer mode
        self._source_params, self._dest_params = collect_view_params(vp_items)
        self._source_map = {}  # display_name -> param_info tuple
        self._dest_map = {}

        # Populate VP type ComboBoxes
        sorted_names = sorted(vp_type_dict.keys())
        for name in sorted_names:
            self.cb_vp_type.Items.Add(name)
            self.cb_batch_type.Items.Add(name)
        if self.cb_vp_type.Items.Count > 0:
            self.cb_vp_type.SelectedIndex = 0
            self.cb_batch_type.SelectedIndex = 0

        # Populate filter
        for opt in FILTER_OPTIONS:
            self.cb_filter.Items.Add(opt)
        self.cb_filter.SelectedIndex = 0

        # Populate transfer param ComboBoxes
        for info in self._source_params:
            self.cb_source_param.Items.Add(info[0])
            self._source_map[info[0]] = info
        for info in self._dest_params:
            self.cb_dest_param.Items.Add(info[0])
            self._dest_map[info[0]] = info

        # Set defaults: View Name → Title on Sheet
        if self.cb_source_param.Items.Count > 0:
            self.cb_source_param.SelectedIndex = 0
        if self.cb_dest_param.Items.Count > 0:
            # Try to default to "Title on Sheet"
            for i in range(self.cb_dest_param.Items.Count):
                if "Title on Sheet" in str(self.cb_dest_param.Items[i]):
                    self.cb_dest_param.SelectedIndex = i
                    break
            else:
                self.cb_dest_param.SelectedIndex = 0

        self._apply_items(self._all_items)
        self._update_status()

    def _set_revit_icon(self):
        try:
            import System.Drawing, System.Windows.Interop, System.Windows
            from System.Windows.Media.Imaging import BitmapSizeOptions
            proc = System.Diagnostics.Process.GetCurrentProcess()
            icon = System.Drawing.Icon.ExtractAssociatedIcon(proc.MainModule.FileName)
            self.Icon = System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle, System.Windows.Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions())
        except: pass

    def _apply_items(self, items):
        oc = ObservableCollection[object](items)
        view = CollectionViewSource.GetDefaultView(oc)
        view.GroupDescriptions.Clear()
        view.GroupDescriptions.Add(PropertyGroupDescription("sheet_label"))
        self.lv_viewports.ItemsSource = view

    def _get_filtered_items(self):
        items = list(self._all_items)
        try:
            f = str(self.cb_filter.SelectedItem) if self.cb_filter.SelectedItem else ""
        except: f = ""
        if f == u"Views":
            items = [i for i in items if i.view_category == "View"]
        elif f == u"Drafting Views":
            items = [i for i in items if i.view_category == "DraftingView"]
        elif f == u"Legends":
            items = [i for i in items if i.view_category == "Legend"]
        try:
            query = self.tb_search.Text.strip().lower() if self.tb_search.Text else ""
        except: query = ""
        if query:
            items = [i for i in items if query in i.view_name.lower()]
        return items

    def _update_status(self):
        c = sum(1 for i in self._all_items if i.is_checked)
        self.tb_status.Text = u"Selected: {} / {} viewport(s)".format(c, len(self._all_items))

    def _update_transfer_preview(self):
        """Update source_val and dest_val on all items for transfer preview."""
        src = self._source_map.get(str(self.cb_source_param.SelectedItem)) if self.cb_source_param.SelectedItem else None
        dst = self._dest_map.get(str(self.cb_dest_param.SelectedItem)) if self.cb_dest_param.SelectedItem else None
        for item in self._all_items:
            item.source_val = read_param(item, src) if src else ""
            item.dest_val = read_param(item, dst) if dst else ""
        self._apply_items(self._get_filtered_items())

    # ─── Events ───
    def button_close(self, sender, e):
        self.action = "cancel"; self.Close()

    def btn_check_all(self, sender, e):
        visible = self._get_filtered_items()
        for i in visible: i.is_checked = True
        self._apply_items(visible); self._update_status()

    def btn_uncheck_all(self, sender, e):
        visible = self._get_filtered_items()
        for i in visible: i.is_checked = False
        self._apply_items(visible); self._update_status()

    def search_changed(self, sender, e):
        self._apply_items(self._get_filtered_items())

    def filter_changed(self, sender, e):
        self._apply_items(self._get_filtered_items())

    def mode_changed(self, sender, e):
        is_target = self.rb_target.IsChecked
        is_manual = self.rb_manual.IsChecked
        is_transfer = self.rb_transfer.IsChecked
        self.is_manual = is_manual
        self.is_transfer = is_transfer

        self.target_section.Visibility = Visibility.Visible if is_target else Visibility.Collapsed
        self.manual_batch_section.Visibility = Visibility.Visible if is_manual else Visibility.Collapsed
        self.transfer_section.Visibility = Visibility.Visible if is_transfer else Visibility.Collapsed

        if is_target:
            self.lv_viewports.ItemTemplate = self.FindResource("TargetRowTemplate")
        elif is_manual:
            self.lv_viewports.ItemTemplate = self.FindResource("ManualRowTemplate")
        elif is_transfer:
            self._update_transfer_preview()
            self.lv_viewports.ItemTemplate = self.FindResource("TransferRowTemplate")

    def transfer_param_changed(self, sender, e):
        if self.is_transfer:
            self._update_transfer_preview()

    def btn_batch_set(self, sender, e):
        if self.cb_batch_type.SelectedItem is None:
            forms.alert(u"Vui lòng chọn Viewport Type!", title=u"Chú ý"); return
        batch_type = str(self.cb_batch_type.SelectedItem)
        for item in self._all_items:
            if item.is_checked: item.manual_type = batch_type
        self._apply_items(self._get_filtered_items())

    def btn_apply_click(self, sender, e):
        if self.is_transfer:
            self.action = "apply_transfer"
        elif self.is_manual:
            self.action = "apply"
        else:
            if self.cb_vp_type.SelectedItem is None:
                forms.alert(u"Vui lòng chọn Viewport Type!", title=u"Chú ý"); return
            self.selected_type_name = str(self.cb_vp_type.SelectedItem)
            self.action = "apply"
        self.Close()

    def btn_new_sheets(self, sender, e):
        self.action = "new_sheets"; self.Close()

# ────────────────── Sheet Picker ──────────────────
class SheetItem(forms.Reactive):
    def __init__(self, sheet):
        self._is_checked = False
        self.sheet = sheet
        self.sheet_number = sheet.SheetNumber
        self.sheet_name = sheet.Name
    @forms.reactive
    def is_checked(self): return self._is_checked
    @is_checked.setter
    def is_checked(self, value): self._is_checked = value

class SelectSheetsWindow(forms.WPFWindow):
    def __init__(self, sheet_items):
        forms.WPFWindow.__init__(self, "SelectSheets.xaml")
        self.result = None
        self._all = list(sheet_items)
        try:
            import System.Drawing, System.Windows.Interop, System.Windows
            from System.Windows.Media.Imaging import BitmapSizeOptions
            proc = System.Diagnostics.Process.GetCurrentProcess()
            icon = System.Drawing.Icon.ExtractAssociatedIcon(proc.MainModule.FileName)
            self.Icon = System.Windows.Interop.Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle, System.Windows.Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions())
        except: pass
        self._refresh(); self._update_status()

    def _refresh(self):
        try: query = self.tb_search.Text.strip().lower() if self.tb_search.Text else ""
        except: query = ""
        items = self._all if not query else [i for i in self._all if query in i.sheet_number.lower() or query in i.sheet_name.lower()]
        self.lv_sheets.ItemsSource = ObservableCollection[object](items)

    def _update_status(self):
        self.tb_status.Text = u"Đã chọn: {} sheet(s)".format(sum(1 for i in self._all if i.is_checked))

    def btn_check_all(self, sender, e):
        for i in self._all: i.is_checked = True
        self._refresh(); self._update_status()
    def btn_uncheck_all(self, sender, e):
        for i in self._all: i.is_checked = False
        self._refresh(); self._update_status()
    def search_changed(self, sender, e): self._refresh()
    def btn_ok(self, sender, e):
        self.result = [i.sheet for i in self._all if i.is_checked]; self.Close()
    def btn_cancel(self, sender, e):
        self.result = None; self.Close()

# ────────────────── Helpers ──────────────────
def get_vp_type_name(vt_el):
    try:
        p = vt_el.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)
        if p and p.AsString(): return p.AsString()
        if hasattr(vt_el, "Name") and vt_el.Name: return vt_el.Name
        return DB.Element.Name.GetValue(vt_el)
    except: return None

def get_vp_type_dict():
    d = {}
    for et in DB.FilteredElementCollector(doc).OfClass(DB.ElementType).ToElements():
        try:
            if hasattr(et, "FamilyName") and et.FamilyName == "Viewport":
                name = get_vp_type_name(et)
                if name: d[name] = et
        except: pass
    return d

def build_vp_items(sheets, vp_type_dict):
    sorted_names = sorted(vp_type_dict.keys())
    vp_items = []
    for sheet in sheets:
        label = u"{} - {}".format(sheet.SheetNumber, sheet.Name)
        svps = []
        try:
            for vid in sheet.GetAllViewports():
                vp = doc.GetElement(vid)
                if not vp: continue
                view = doc.GetElement(vp.ViewId)
                vname = view.Name if view else "Unknown"
                sk = get_view_sort_key(view)
                vc = get_view_category(view)
                vte = doc.GetElement(vp.GetTypeId())
                cn = get_vp_type_name(vte) if vte else "Unknown"
                if not cn: cn = "Unknown"
                svps.append(ViewportItem(vp, label, vname, cn, sk, sorted_names, vc))
        except Exception as e:
            print(u"Lỗi Sheet {}: {}".format(sheet.SheetNumber, e))
        svps.sort(key=lambda x: x.sort_key)
        vp_items.extend(svps)
    return vp_items

def apply_vp_type_changes(window, vp_items, vp_type_dict):
    checked = [i for i in vp_items if i.is_checked]
    if not checked: return 0
    if not window.is_manual and not window.selected_type_name: return 0
    count = 0
    with revit.Transaction(u"Đổi Viewport Type hàng loạt"):
        if window.is_manual:
            for item in checked:
                try:
                    t = vp_type_dict.get(item.manual_type)
                    if t and item.viewport.GetTypeId() != t.Id:
                        item.viewport.ChangeTypeId(t.Id); count += 1
                except: pass
        else:
            t = vp_type_dict[window.selected_type_name]
            for item in checked:
                try:
                    if item.viewport.GetTypeId() != t.Id:
                        item.viewport.ChangeTypeId(t.Id); count += 1
                except: pass
    return count

def apply_transfer(window, vp_items):
    src_name = str(window.cb_source_param.SelectedItem) if window.cb_source_param.SelectedItem else None
    dst_name = str(window.cb_dest_param.SelectedItem) if window.cb_dest_param.SelectedItem else None
    if not src_name or not dst_name:
        forms.alert(u"Vui lòng chọn Source và Destination!", title=u"Chú ý"); return 0
    src_info = window._source_map.get(src_name)
    dst_info = window._dest_map.get(dst_name)
    if not src_info or not dst_info: return 0

    checked = [i for i in vp_items if i.is_checked]
    if not checked: return 0
    count = 0
    with revit.Transaction(u"Transfer Parameter"):
        for item in checked:
            try:
                val = read_param(item, src_info)
                if val:
                    write_param(item, dst_info, val)
                    count += 1
            except: pass
    return count

def pick_sheets():
    all_sheets = DB.FilteredElementCollector(doc)\
        .OfClass(DB.ViewSheet).WhereElementIsNotElementType().ToElements()
    if not all_sheets: return None
    items = [SheetItem(s) for s in sorted(all_sheets, key=lambda x: x.SheetNumber)]
    win = SelectSheetsWindow(items)
    win.ShowDialog()
    return win.result if win.result else None

# ────────────────── Main Loop ──────────────────
def main():
    selection = revit.get_selection()
    selected_sheets = [el for el in selection.elements if isinstance(el, DB.ViewSheet)]
    if not selected_sheets:
        forms.alert(u'Vui lòng chọn các Sheet trên Project Browser trước!', exitscript=True)

    vp_type_dict = get_vp_type_dict()
    if not vp_type_dict:
        forms.alert(u'Không tìm thấy Viewport Type nào!', exitscript=True)

    while True:
        vp_items = build_vp_items(selected_sheets, vp_type_dict)
        if not vp_items:
            forms.alert(u'Không tìm thấy Viewport nào trên các Sheet đã chọn!')
            break

        window = ChangeVPTypeWindow(vp_items, vp_type_dict)
        window.ShowDialog()

        if window.action == "cancel":
            break
        elif window.action == "new_sheets":
            new = pick_sheets()
            if new: selected_sheets = new
            continue
        elif window.action == "apply_transfer":
            count = apply_transfer(window, vp_items)
            if count > 0:
                forms.alert(u"Đã transfer {} parameter(s)!".format(count), title=u"Hoàn tất")
            else:
                forms.alert(u"Không có parameter nào bị thay đổi.", title=u"Báo cáo")
            continue
        elif window.action == "apply":
            count = apply_vp_type_changes(window, vp_items, vp_type_dict)
            if count > 0:
                forms.alert(u"Đã đổi thành công {} Viewport(s)!".format(count), title=u"Hoàn tất")
            else:
                forms.alert(u"Không có Viewport nào bị thay đổi.", title=u"Báo cáo")
            vp_type_dict = get_vp_type_dict()
            continue

if __name__ == '__main__':
    main()
