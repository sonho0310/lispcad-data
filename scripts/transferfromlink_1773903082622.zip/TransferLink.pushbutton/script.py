# -*- coding: utf-8 -*-
"""
Transfer Views & Filters from a source file to the CURRENT active file.
[Superpowers Edition] - Ultra Fast Background Open + Metadata/Image Preview
"""
__title__ = 'Transfer\nViews & Filters'

from pyrevit import revit, DB, UI
from pyrevit import forms
from pyrevit import script
import System
from System import Uri, UriKind
from System.Windows.Media.Imaging import BitmapImage, BitmapCacheOption
from System.Collections.Generic import List
from System.Collections.ObjectModel import ObservableCollection
import os
import stat
import tempfile

doc = revit.doc
app = __revit__.Application

class CopyOptionHandler(DB.IDuplicateTypeNamesHandler):
    def OnDuplicateTypeNamesFound(self, args):
        return DB.DuplicateTypeAction.UseDestinationTypes

class IgnoreWarningsHandler(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning:
                failuresAccessor.DeleteWarning(f)
        return DB.FailureProcessingResult.Continue

class DocItem(object):
    def __init__(self, doc_obj, name):
        self.Doc = doc_obj
        self.Name = name
        self.IsBackground = False
        self._cached_views = None

    def GetViews(self):
        if self._cached_views is not None:
            return self._cached_views
        
        if not self.Doc:
            return []
            
        elements_to_show = []
        
        # 1. Drafting views
        draft_views = DB.FilteredElementCollector(self.Doc)\
                        .OfClass(DB.ViewDrafting)\
                        .WhereElementIsNotElementType()\
                        .ToElements()
        for v in draft_views:
            if not v.IsTemplate:
                elements_to_show.append(ViewItem(v, "[Drafting View] " + v.Name))
                
        # 2. Legends & Templates
        views = DB.FilteredElementCollector(self.Doc)\
                  .OfClass(DB.View)\
                  .WhereElementIsNotElementType()\
                  .ToElements()
        for v in views:
            if v.IsTemplate:
                elements_to_show.append(ViewItem(v, "[Template] " + v.Name))
            elif v.ViewType == DB.ViewType.Legend:
                elements_to_show.append(ViewItem(v, "[Legend] " + v.Name))
                
        # 3. Filters
        filters = DB.FilteredElementCollector(self.Doc)\
                    .OfClass(DB.ParameterFilterElement)\
                    .WhereElementIsNotElementType()\
                    .ToElements()
        for f in filters:
            elements_to_show.append(ViewItem(f, "[Filter] " + f.Name))
            
        elements_to_show.sort(key=lambda x: x.Name)
        self._cached_views = elements_to_show
        return self._cached_views

class ViewItem(object):
    def __init__(self, view, display_name=None):
        self.View = view
        self.Name = display_name if display_name else view.Name
        # [LUẬT YAGNI] - Sửa True thành False để mặc định không tick All
        self._is_selected = False 

    @property
    def IsSelected(self):
        return self._is_selected

    @IsSelected.setter
    def IsSelected(self, value):
        self._is_selected = value

class TransferWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        self.selected_doc_item = None
        self.selected_views = []
        self._current_views_list = []
        self.bg_doc = None
        
    def window_mouse_down(self, sender, e):
        from System.Windows.Input import MouseButtonState
        if e.LeftButton == MouseButtonState.Pressed:
            self.DragMove()
            
    def btn_close_click(self, sender, e):
        self.selected_views = []
        self.Close()
        
    def btn_browse_click(self, sender, e):
        file_path = forms.pick_file(file_ext='rvt', title='Pick Source Revit File (.rvt)')
        if not file_path:
            return
            
        # check if already open
        found_d = None
        for d in app.Documents:
            if d.PathName.lower() == file_path.lower():
                found_d = d
                break
                
        if found_d:
            if found_d.PathName.lower() == doc.PathName.lower():
                forms.alert(u"Không thể copy view từ chính file hiện hành. Vui lòng chọn file khác.")
                return
                
            self.selected_doc_item = DocItem(found_d, found_d.Title)
            self.TxtSourceFile.Text = self.selected_doc_item.Name + " (Open)"
        else:
            # Open background
            if os.path.exists(file_path):
                try: os.chmod(file_path, stat.S_IWRITE)
                except: pass
            
            try:
                model_path = DB.ModelPathUtils.ConvertUserVisiblePathToModelPath(file_path)
                opts = DB.OpenOptions()
                
                # [TỐI ƯU TỐC ĐỘ 1]: Đóng toàn bộ mô hình 3D vật lý (Views/Filters vẫn load bình thường)
                ws_config = DB.WorksetConfiguration(DB.WorksetConfigurationOption.CloseAllWorksets)
                opts.SetOpenWorksetsConfiguration(ws_config)
                
                # [TỐI ƯU TỐC ĐỘ 2]: Bỏ qua Ping mạng/Server (Ngắt kết nối file Central)
                opts.DetachFromCentralOption = DB.DetachFromCentralOption.DetachAndPreserveWorksets
                
                # Close previous bg doc if exists
                if self.bg_doc:
                    try: self.bg_doc.Close(False)
                    except: pass
                    
                self.bg_doc = app.OpenDocumentFile(model_path, opts)
                self.selected_doc_item = DocItem(self.bg_doc, os.path.basename(file_path))
                self.TxtSourceFile.Text = self.selected_doc_item.Name + " (Background)"
                
            except Exception as ex:
                forms.alert(u"Lỗi mở file:\n{}".format(ex))
                return
                
        # Update Views List
        if self.selected_doc_item:
            self._current_views_list = self.selected_doc_item.GetViews()
            self.ListViews.ItemsSource = self._current_views_list

    def txt_search_changed(self, sender, e):
        search_term = self.TxtSearch.Text.lower()
        if not search_term:
            self.ListViews.ItemsSource = self._current_views_list
        else:
            filtered = [item for item in self._current_views_list if search_term in item.Name.lower()]
            self.ListViews.ItemsSource = filtered

    def btn_all_click(self, sender, e):
        displayed_items = self.ListViews.ItemsSource
        if displayed_items:
            for item in displayed_items:
                item.IsSelected = True
            self.ListViews.Items.Refresh()
        
    def btn_none_click(self, sender, e):
        displayed_items = self.ListViews.ItemsSource
        if displayed_items:
            for item in displayed_items:
                item.IsSelected = False
            self.ListViews.Items.Refresh()
    
    # [FIX UX]: Tự động Select dòng khi user bấm vào Checkbox
    def checkbox_clicked(self, sender, e):
        # sender chính là cái CheckBox. DataContext của nó chứa dữ liệu của dòng đó.
        self.ListViews.SelectedItem = sender.DataContext

    # [HÀM DIAGNOSTIC - DÙNG ĐỂ BẮT LỖI NGẦM]
    def list_views_selection_changed(self, sender, e):
        try:
            selected_item = self.ListViews.SelectedItem
            if not selected_item:
                self.PreviewText.Text = "Chọn một Item bên trái để xem trước thông tin..."
                self.PreviewImage.Source = None
                return

            # Cập nhật UI ngay lập tức để biết sự kiện đã kích hoạt
            self.PreviewText.Text = "Đang xử lý dữ liệu..." 
            self.PreviewImage.Source = None 

            v = selected_item.View
            
            # 1. Nếu là FILTER
            if isinstance(v, DB.ParameterFilterElement):
                cat_ids = v.GetCategories()
                cat_names = []
                for cid in cat_ids:
                    try: cat_names.append(DB.Category.GetCategory(self.selected_doc_item.Doc, cid).Name)
                    except: pass
                info = u"LOẠI: FILTER\nSố lượng Category: {}\nBao gồm: {}".format(len(cat_names), ", ".join(cat_names[:10]))
                self.PreviewText.Text = info
                
            # 2. Nếu là VIEW TEMPLATE
            elif isinstance(v, DB.View) and v.IsTemplate:
                info = u"LOẠI: VIEW TEMPLATE\nScale: 1:{}\nDetail Level: {}".format(v.Scale, v.DetailLevel)
                self.PreviewText.Text = info
                
            # 3. Nếu là DRAFTING VIEW / LEGEND
            elif isinstance(v, DB.View):
                info = u"LOẠI: {}\nScale: 1:{}\n".format("DRAFTING VIEW" if v.ViewType == DB.ViewType.DraftingView else "LEGEND", v.Scale)
                
                try:
                    collector = DB.FilteredElementCollector(self.selected_doc_item.Doc, v.Id).WhereElementIsNotElementType()
                    info += u"Tổng số phần tử: {}\n".format(collector.GetElementCount())
                except Exception as ex1:
                    info += u"[Lỗi đếm phần tử: {}]\n".format(str(ex1))
                    
                self.PreviewText.Text = info
                
                # Render Ảnh
                try:
                    import tempfile
                    from System.Collections.Generic import List
                    temp_dir = tempfile.gettempdir()
                    img_prefix = "pv_img_{}".format(v.Id.IntegerValue) 
                    
                    opts = DB.ImageExportOptions()
                    opts.FilePath = os.path.join(temp_dir, img_prefix)
                    opts.ExportRange = DB.ExportRange.SetOfViews
                    opts.SetViewsAndSheets(List[DB.ElementId]([v.Id]))
                    opts.ImageResolution = DB.ImageResolution.DPI_72
                    opts.ZoomType = DB.ZoomFitType.FitToPage
                    opts.PixelSize = 512
                    opts.HLRandWFViewsFileType = DB.ImageFileType.JPEGLossless
                    opts.ShadowViewsFileType = DB.ImageFileType.JPEGLossless
                    
                    self.selected_doc_item.Doc.ExportImage(opts)
                    
                    exported_files = [f for f in os.listdir(temp_dir) if f.startswith(img_prefix) and f.lower().endswith(".jpg")]
                    if exported_files:
                        exported_files.sort(key=lambda x: os.path.getmtime(os.path.join(temp_dir, x)), reverse=True)
                        img_path = os.path.join(temp_dir, exported_files[0])
                        
                        bitmap = BitmapImage()
                        bitmap.BeginInit()
                        bitmap.UriSource = Uri(img_path, UriKind.Absolute)
                        bitmap.CacheOption = BitmapCacheOption.OnLoad 
                        bitmap.EndInit()
                        self.PreviewImage.Source = bitmap
                except Exception as ex_img:
                    self.PreviewText.Text += u"\n[Lỗi Render Ảnh: {}]".format(str(ex_img))
                    
        except Exception as global_ex:
            # Nếu có lỗi ngầm, nó sẽ in thẳng ra đây
            import traceback
            error_msg = traceback.format_exc()
            self.PreviewText.Text = u"CRASH REPORT:\n" + str(error_msg)
        
    def btn_transfer_click(self, sender, e):
        if not self.selected_doc_item:
            forms.alert(u"Vui lòng chọn File Nguồn!")
            return
            
        self.selected_views = [item for item in self._current_views_list if item.IsSelected]
        if not self.selected_views:
            forms.alert(u"Vui lòng chọn ít nhất 1 item!")
            return
            
        self.Close()

def get_elements_to_copy(source_doc, selected_views):
    view_ids_set = set() # O(1) lookup
    for v_item in selected_views:
        v = v_item.View
        view_ids_set.add(v.Id)
            
        if isinstance(v, DB.View) and not v.IsTemplate:
            try:
                collector = DB.FilteredElementCollector(source_doc, v.Id).WhereElementIsNotElementType().ToElementIds()
                for eid in collector:
                    view_ids_set.add(eid)
            except:
                pass
            
    view_ids = List[DB.ElementId]()
    for eid in view_ids_set:
        view_ids.Add(eid)
    return view_ids

def main():
    xaml_path = os.path.join(os.path.dirname(__file__), 'window.xaml')
    window = TransferWindow(xaml_path)
    window.ShowDialog()
    
    if not window.selected_views:
        if window.bg_doc:
            try: window.bg_doc.Close(False)
            except: pass
        return
        
    source_doc_item = window.selected_doc_item
    selected_views = window.selected_views
    source_doc = source_doc_item.Doc
    
    if not source_doc:
        forms.alert(u"Không xác định được file nguồn.", exitscript=True)
        
    copy_ids = get_elements_to_copy(source_doc, selected_views)
    
    copy_options = DB.CopyPasteOptions()
    copy_options.SetDuplicateTypeNamesHandler(CopyOptionHandler())
    
    trans_success = False
    error_msg = ""
    
    try:
        t = DB.Transaction(doc, "Pull Views & Filters")
        t.Start()
        
        failure_opts = t.GetFailureHandlingOptions()
        failure_opts.SetFailuresPreprocessor(IgnoreWarningsHandler())
        t.SetFailureHandlingOptions(failure_opts)
        
        DB.ElementTransformUtils.CopyElements(source_doc, copy_ids, doc, DB.Transform.Identity, copy_options)
        
        t.Commit()
        trans_success = True
    except Exception as e:
        error_msg = str(e)
        if hasattr(t, 'HasStarted') and t.HasStarted():
            t.RollBack()
            
    # Clean up background docs
    if window.bg_doc:
        try: window.bg_doc.Close(False)
        except: pass
            
    if trans_success:
        forms.alert(u"Tuyệt vời! Đã nhận (pull) {} item(s) thành công vào File A của bạn.".format(len(selected_views)))
    else:
        forms.alert(u"Lỗi trong quá trình copy:\n{}".format(error_msg))

if __name__ == '__main__':
    main()