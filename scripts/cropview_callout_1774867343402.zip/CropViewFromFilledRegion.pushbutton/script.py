﻿# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *
from pyrevit import forms
import clr

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
view = doc.ActiveView

# ==========================================
# 0. ĐỊNH NGHĨA XAML GIAO DIỆN WPF BORDERLESS (CHUẨN VIP)
# ==========================================
xaml_source = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        Width="450" Height="220" WindowStartupLocation="CenterScreen"
        MouseLeftButtonDown="window_drag">
    
    <Border BorderBrush="#0078D7" BorderThickness="2" Background="#F9F9F9">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="40"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="50"/>
            </Grid.RowDefinitions>

            <Grid Grid.Row="0" Background="#EBEBEB">
                <TextBlock Text="⚙️ TÙY CHỌN CẮT VIEW" VerticalAlignment="Center" Margin="15,0,0,0" FontWeight="Bold" FontSize="14" Foreground="#333333"/>
                <Button Name="btn_close" Content="CLOSE" Foreground="Red" FontWeight="ExtraBold" HorizontalAlignment="Right" Width="60" Margin="0,0,5,0" Click="btn_close_Click" Background="Transparent" BorderThickness="0" Cursor="Hand"/>
            </Grid>

            <StackPanel Grid.Row="1" Margin="20,15,20,10">
                <CheckBox Name="chk_callout" Content="1. Tạo View dạng Callout (Bỏ tick sẽ tạo Duplicate View)" IsChecked="True" Margin="0,5,0,15" FontSize="14"/>
                <CheckBox Name="chk_hide_crop" Content="2. Tự động ẩn viền đen Crop Box sau khi cắt xong" IsChecked="False" Margin="0,5,0,5" FontSize="14"/>
            </StackPanel>

            <StackPanel Grid.Row="2" Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,0,15,0">
                <Button Name="btn_ok" Content="TIẾP TỤC" Width="100" Height="32" Click="btn_ok_Click" Background="#0078D7" Foreground="White" FontWeight="Bold" BorderThickness="0" Cursor="Hand"/>
            </StackPanel>
        </Grid>
    </Border>
</Window>
"""

# ==========================================
# 1. CLASS XỬ LÝ GIAO DIỆN WPF
# ==========================================
class CustomWindow(forms.WPFWindow):
    def __init__(self):
        # Khởi tạo cửa sổ WPF bằng chuỗi XAML trực tiếp
        forms.WPFWindow.__init__(self, xaml_source, literal_string=True)
        self.is_ok = False # Biến cờ kiểm tra xem user có bấm Tiếp tục hay không
        self.is_callout = False
        self.hide_cropbox = False

    # Hàm hỗ trợ kéo thả Window (Chuẩn bắt buộc)
    def window_drag(self, sender, args):
        self.DragMove()

    # Hàm xử lý khi bấm nút CLOSE
    def btn_close_Click(self, sender, args):
        self.Close()

    # Hàm xử lý khi bấm nút TIẾP TỤC
    def btn_ok_Click(self, sender, args):
        self.is_callout = self.chk_callout.IsChecked
        self.hide_cropbox = self.chk_hide_crop.IsChecked
        self.is_ok = True
        self.Close()

# --- BỘ LỌC CHỌN (Giữ nguyên logic cũ) ---
class FilledRegionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, FilledRegion)
    def AllowReference(self, ref, point): return False

def execute_final_tool():
    try:
        # ==========================================
        # 2. GỌI GIAO DIỆN & LẤY KẾT QUẢ TÙY CHỌN
        # ==========================================
        ui = CustomWindow()
        ui.ShowDialog()

        # Nếu user tắt bảng (nhấn X / CLOSE) -> Im lặng dừng tool
        if not ui.is_ok:
            return

        is_callout = ui.is_callout
        hide_cropbox = ui.hide_cropbox

        # ==========================================
        # 3. INPUT (QUÉT CHỌN FILLED REGION)
        # ==========================================
        region_refs = uidoc.Selection.PickObjects(ObjectType.Element, FilledRegionFilter(), "QUÉT CHỌN CÁC FILLED REGION (Nhấn Finish góc trái khi xong)")
        if not region_refs or len(region_refs) == 0:
            return

        # Lấy ViewFamilyType (Dùng cho Callout nếu user tick chọn)
        view_type_id = view.GetTypeId()
        detail_type_id = None
        if is_callout:
            for vft in FilteredElementCollector(doc).OfClass(ViewFamilyType).ToElements():
                if vft.ViewFamily == ViewFamily.Detail:
                    detail_type_id = vft.Id
                    break

        # ==========================================
        # 4. THU THẬP DỮ LIỆU BOUDARIES
        # ==========================================
        region_data = []
        for ref in region_refs:
            region_elem = doc.GetElement(ref)
            boundaries = region_elem.GetBoundaries()
            
            if boundaries and boundaries.Count > 0:
                outer_loop = boundaries[0]
                bbox = region_elem.get_BoundingBox(view)
                if bbox:
                    region_data.append({
                        "loop": outer_loop,
                        "min": bbox.Min,
                        "max": bbox.Max,
                        "id": region_elem.Id
                    })

        if not region_data:
            return

        # ==========================================
        # 5. THỰC THI (TRANSACTION) - TẠO VIEW/CALLOUT
        # ==========================================
        t = Transaction(doc, "Tạo View/Callout theo Filled Region")
        t.Start()

        # Clean Code: Xoá toàn bộ Filled Region rác trước khi Duplicate
        for data in region_data:
            doc.Delete(data["id"])

        last_new_view = None

        # Vòng lặp: Tạo View/Callout và ốp biên dạng
        for data in region_data:
            new_view = None
            
            if is_callout:
                # --- CHẾ ĐỘ 1: TẠO CALLOUT ---
                try:
                    new_view = ViewSection.CreateCallout(doc, view.Id, view_type_id, data["min"], data["max"])
                except:
                    if detail_type_id:
                        new_view = ViewSection.CreateCallout(doc, view.Id, detail_type_id, data["min"], data["max"])
                    else:
                        print("LỖI: Không tìm thấy ViewFamilyType phù hợp để tạo Callout.")
                        continue
            else:
                # --- CHẾ ĐỘ 2: DUPLICATE VIEW ---
                new_view_id = view.Duplicate(ViewDuplicateOption.WithDetailing)
                new_view = doc.GetElement(new_view_id)

            if new_view:
                # Cài đặt hiển thị Crop Box dựa theo Tickbox số 2
                new_view.CropBoxActive = True
                new_view.CropBoxVisible = not hide_cropbox # Bật/tắt theo ý user
                
                # Ốp biên dạng đa giác
                crop_manager = new_view.GetCropRegionShapeManager()
                try:
                    crop_manager.SetCropShape(data["loop"])
                except Exception as e:
                    print("LỖI: Không thể áp biên dạng đa giác. Chi tiết: {}".format(e))
                    
                last_new_view = new_view

        t.Commit()

        # ==========================================
        # 6. AUTO SWITCH VIEW
        # ==========================================
        # Chuyển màn hình tự động sang View cuối cùng được tạo
        if last_new_view:
            uidoc.ActiveView = last_new_view

    except Autodesk.Revit.Exceptions.OperationCanceledException:
        # User nhấn ESC để hủy lúc đang Pick Objects -> Dừng an toàn
        pass
    except Exception as e:
        if 't' in locals() and t.HasStarted():
            t.RollBack()
        print("LỖI NGHIÊM TRỌNG: {}".format(e))

if __name__ == "__main__":
    execute_final_tool()