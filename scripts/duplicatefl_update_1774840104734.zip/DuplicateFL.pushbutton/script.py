# -*- coding: utf-8 -*-
"""
Smart Clone V16 (Stable & Fast): Tối ưu hóa vòng lặp, bỏ cấm thuật gây crash, giao diện Xanh #99CCFF
"""
__title__ = "Smart Clone V16\n(Speed & Stable)"

from Autodesk.Revit.DB import (
    Transaction, ViewPlan, FilteredElementCollector, View,
    ElementTransformUtils, ElementId, DatumEnds, Grid, IndependentTag, BuiltInParameter,
    PlanViewPlane, BuiltInCategory, DatumExtentType, Line, Arc, XYZ
)
from pyrevit import revit, script, forms
import clr

clr.AddReference("PresentationFramework")
from System.Windows import Markup, Window
from System.Collections.Generic import List

# ==============================================================================
# HÀM PHỤ TRỢ: COPY 2D AN TOÀN (Bắt lỗi từng cụm)
# ==============================================================================
def smart_copy_elements(doc, src_view, dest_view, element_ids_list):
    if not element_ids_list or element_ids_list.Count == 0:
        return True
    try:
        ElementTransformUtils.CopyElements(src_view, element_ids_list, dest_view, None, None)
        return True
    except:
        safe_ids = List[ElementId]()
        risky_ids = List[ElementId]()
        for eid in element_ids_list:
            el = doc.GetElement(eid)
            # Tag rất hay gây lỗi khi copy, tách ra xử lý riêng
            if isinstance(el, IndependentTag):
                risky_ids.Add(eid)
            else:
                safe_ids.Add(eid)
        if safe_ids.Count > 0:
            try: ElementTransformUtils.CopyElements(src_view, safe_ids, dest_view, None, None)
            except: pass
        for tag_id in risky_ids:
            try:
                single_list = List[ElementId]([tag_id])
                ElementTransformUtils.CopyElements(src_view, single_list, dest_view, None, None)
            except: pass
        return False

# ==============================================================================
# 1. GIAO DIỆN UI (#99CCFF) - GIỮ NGUYÊN ĐỘ ĐẸP TRAI
# ==============================================================================
INPUT_XAML = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Smart Clone V16 (Stable Speed)" Width="600" Height="650" MinWidth="450" MinHeight="500"
        WindowStartupLocation="CenterScreen" ResizeMode="CanResize"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent">
    
    <WindowChrome.WindowChrome>
        <WindowChrome CaptionHeight="0" ResizeBorderThickness="16" GlassFrameThickness="0" CornerRadius="0"/>
    </WindowChrome.WindowChrome>
    
    <Border Background="White" CornerRadius="10" Margin="15">
        <Border.Effect>
            <DropShadowEffect Color="Black" Direction="270" ShadowDepth="2" BlurRadius="10" Opacity="0.15"/>
        </Border.Effect>

        <Grid Margin="20">
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="1.2*"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="8"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <Grid Grid.Row="0" Margin="0,0,0,15" Background="Transparent" x:Name="header_grid">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="CREATE PLAN VIEWS (FAST &amp; STABLE)" FontWeight="Heavy" FontSize="16" Foreground="#99CCFF" VerticalAlignment="Center"/>
                <Button x:Name="close_button" Grid.Column="1" Content="✕" FontSize="16" Foreground="#999999" Background="Transparent" BorderThickness="0" Cursor="Hand" VerticalAlignment="Center" Height="25" Width="25"/>
            </Grid>

            <TextBlock Grid.Row="1" Text="Source View &amp; Template" Foreground="#9B9B9B" FontSize="12" Margin="0,0,0,5"/>
            <Border Grid.Row="2" BorderBrush="#99CCFF" BorderThickness="1" CornerRadius="5" Margin="0,0,0,12">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="2">
                    <ItemsControl x:Name="source_list" Margin="5">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Grid Margin="0,2,0,4">
                                    <Grid.ColumnDefinitions>
                                        <ColumnDefinition Width="*"/>
                                        <ColumnDefinition Width="150"/>
                                    </Grid.ColumnDefinitions>
                                    <TextBlock Text="{Binding ViewName}" VerticalAlignment="Center" Foreground="#333333" FontSize="12" TextTrimming="CharacterEllipsis" ToolTip="{Binding ViewName}"/>
                                    <ComboBox Grid.Column="1" ItemsSource="{Binding TemplateOptions}" SelectedItem="{Binding SelectedTemplate}" DisplayMemberPath="Name" Height="24" FontSize="11" Margin="5,0,0,0"/>
                                </Grid>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </ScrollViewer>
            </Border>

            <Grid Grid.Row="3" Margin="0,0,0,12">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="1.5*"/>
                    <ColumnDefinition Width="10"/>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="10"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>

                <StackPanel Grid.Column="0">
                    <TextBlock Text="Mode" Foreground="#9B9B9B" FontSize="12" Margin="0,0,0,5"/>
                    <Border BorderBrush="#99CCFF" BorderThickness="1" CornerRadius="5">
                        <ComboBox x:Name="cb_mode" SelectedIndex="1" Foreground="#333333" Padding="6,6" BorderThickness="0" Background="Transparent">
                            <ComboBoxItem Content="Duplicate (Model Only)"/>
                            <ComboBoxItem Content="Duplicate with Detailing"/>
                        </ComboBox>
                    </Border>
                </StackPanel>

                <StackPanel Grid.Column="2">
                    <TextBlock Text="Prefix" Foreground="#9B9B9B" FontSize="12" Margin="0,0,0,5"/>
                    <Border BorderBrush="#99CCFF" BorderThickness="1" CornerRadius="5">
                        <TextBox x:Name="txt_prefix" Padding="6,6" BorderThickness="0" Background="Transparent" Foreground="#333333" FontSize="12"/>
                    </Border>
                </StackPanel>

                <StackPanel Grid.Column="4">
                    <TextBlock Text="Suffix" Foreground="#9B9B9B" FontSize="12" Margin="0,0,0,5"/>
                    <Border BorderBrush="#99CCFF" BorderThickness="1" CornerRadius="5">
                        <TextBox x:Name="txt_suffix" Padding="6,6" BorderThickness="0" Background="Transparent" Foreground="#333333" FontSize="12"/>
                    </Border>
                </StackPanel>
            </Grid>

            <Grid Grid.Row="4" Margin="0,0,0,5">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="Target Levels" Foreground="#9B9B9B" FontSize="12" VerticalAlignment="Center"/>
                <CheckBox x:Name="chk_all" Grid.Column="1" Content="Select All" Foreground="#99CCFF" FontWeight="Bold" VerticalAlignment="Center" Cursor="Hand"/>
            </Grid>

            <Border Grid.Row="5" BorderBrush="#99CCFF" BorderThickness="1" CornerRadius="5" Margin="0,0,0,5">
                <ScrollViewer VerticalScrollBarVisibility="Auto" Margin="2">
                    <ItemsControl x:Name="levels_list" Margin="5">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <CheckBox Content="{Binding Name}" IsChecked="{Binding IsChecked}" Foreground="#333333" Margin="0,2,0,2" Cursor="Hand"/>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </ScrollViewer>
            </Border>

            <TextBlock Text="⚡ Lazy Sync Algorithm (Safe &amp; Fast)" 
                       Grid.Row="6" Foreground="#888888" FontStyle="Italic" FontSize="11" 
                       HorizontalAlignment="Center" Margin="0,5,0,0"/>

            <Button x:Name="btn_run" Grid.Row="8" Cursor="Hand" BorderThickness="0" Background="Transparent" Margin="0,5,0,0">
                <Button.Template>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="border" Background="#99CCFF" CornerRadius="20" Padding="0,12">
                            <TextBlock Text="CREATE PLANS" Foreground="White" FontWeight="Bold" FontSize="14" HorizontalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#B3D9FF"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#80BFFF"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Button.Template>
            </Button>
            
        </Grid>
    </Border>
</Window>
"""

RESULT_XAML = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Result" Width="500" Height="400" MinWidth="350" MinHeight="250"
        WindowStartupLocation="CenterScreen" ResizeMode="CanResize"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent">
    
    <WindowChrome.WindowChrome>
        <WindowChrome CaptionHeight="0" ResizeBorderThickness="16" GlassFrameThickness="0" CornerRadius="0"/>
    </WindowChrome.WindowChrome>
    
    <Border Background="White" CornerRadius="10" Margin="15">
        <Border.Effect>
            <DropShadowEffect Color="Black" Direction="270" ShadowDepth="2" BlurRadius="10" Opacity="0.15"/>
        </Border.Effect>

        <Grid Margin="20">
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="Auto"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="Auto"/>
            </Grid.RowDefinitions>

            <TextBlock Text="PROCESSING COMPLETE" FontWeight="Heavy" Foreground="#28A745" HorizontalAlignment="Center" Margin="0,0,0,15" FontSize="14"/>
            
            <Border Grid.Row="2" BorderBrush="#99CCFF" BorderThickness="1" CornerRadius="5" MaxHeight="300" Margin="0,0,0,15">
                <ScrollViewer VerticalScrollBarVisibility="Auto">
                    <ItemsControl x:Name="result_list" Margin="10">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <StackPanel Orientation="Horizontal" Margin="0,3,0,3">
                                    <TextBlock Text="{Binding Status}" Foreground="{Binding Color}" FontWeight="Bold" Margin="0,0,8,0"/>
                                    <TextBlock Text="{Binding Message}" TextTrimming="CharacterEllipsis" Foreground="#333333"/>
                                </StackPanel>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </ScrollViewer>
            </Border>

            <Button x:Name="btn_close" Grid.Row="3" Cursor="Hand" BorderThickness="0" Background="Transparent">
                <Button.Template>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="border" Background="#99CCFF" CornerRadius="20" Padding="0,12">
                            <TextBlock Text="CLOSE" Foreground="White" FontWeight="Bold" FontSize="14" HorizontalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#B3D9FF"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="border" Property="Background" Value="#80BFFF"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Button.Template>
            </Button>
            
        </Grid>
    </Border>
</Window>
"""

# --- DATA MODELS ---
class LevelItem:
    def __init__(self, level_elem):
        self.Name = level_elem.Name
        self.Element = level_elem
        self.IsChecked = False 

class TemplateOption:
    def __init__(self, name, id):
        self.Name = name
        self.Id = id

class SourceViewRow:
    def __init__(self, view_elem, available_templates):
        self.ViewName = view_elem.Name
        self.ViewElement = view_elem
        self.TemplateOptions = available_templates
        self.SelectedTemplate = available_templates[0]

class ResultItem:
    def __init__(self, status, message, is_success=True):
        self.Status = status
        self.Message = message
        self.Color = "#28A745" if is_success else "#DC3545"
        if status == "⚠": self.Color = "#FFC107"

# --- LOGIC CLASS CHO INPUT FORM ---
class SmartDupForm(object):
    def __init__(self, levels, source_views, template_options):
        self.window = Markup.XamlReader.Parse(INPUT_XAML)
        
        self.level_items = [LevelItem(l) for l in levels]
        self.levels_list = self.window.FindName("levels_list")
        self.levels_list.ItemsSource = self.level_items
        
        self.source_rows = []
        for view in source_views:
            row = SourceViewRow(view, template_options)
            self.source_rows.append(row)
            
        self.source_list = self.window.FindName("source_list")
        self.source_list.ItemsSource = self.source_rows
        
        self.txt_prefix = self.window.FindName("txt_prefix")
        self.txt_prefix.Text = "" 
        self.txt_suffix = self.window.FindName("txt_suffix")
        self.txt_suffix.Text = " Copy" 
        
        self.window.FindName("chk_all").Checked += self.CheckAll_Click
        self.window.FindName("chk_all").Unchecked += self.UncheckAll_Click
        self.window.FindName("btn_run").Click += self.Run_Click
        
        self.window.FindName("close_button").Click += self.Cancel_Click
        self.window.MouseLeftButtonDown += self.Drag_Window
        
        self.cb_mode = self.window.FindName("cb_mode")
        self.values = {}

    def Drag_Window(self, sender, args):
        try: self.window.DragMove()
        except: pass

    def Cancel_Click(self, sender, args):
        self.window.DialogResult = False
        self.window.Close()

    def CheckAll_Click(self, sender, args):
        for item in self.level_items: item.IsChecked = True
        self.levels_list.Items.Refresh()

    def UncheckAll_Click(self, sender, args):
        for item in self.level_items: item.IsChecked = False
        self.levels_list.Items.Refresh()

    def Run_Click(self, sender, args):
        selected_levels = [x.Element for x in self.level_items if x.IsChecked]
        if not selected_levels:
            forms.alert("Chọn ít nhất 1 Level đi fen!")
            return
        
        view_configs = []
        for row in self.source_rows:
            view_configs.append({
                "view": row.ViewElement,
                "template_id": row.SelectedTemplate.Id
            })

        self.values = {
            "levels": selected_levels,
            "mode": self.cb_mode.SelectedIndex,
            "prefix": self.txt_prefix.Text,
            "suffix": self.txt_suffix.Text,
            "view_configs": view_configs
        }
        self.window.DialogResult = True
        self.window.Close()

    def show(self):
        return self.window.ShowDialog()

class ResultWindow(object):
    def __init__(self, results):
        self.window = Markup.XamlReader.Parse(RESULT_XAML)
        self.window.FindName("result_list").ItemsSource = results
        self.window.FindName("btn_close").Click += lambda s, e: self.window.Close()
        self.window.MouseLeftButtonDown += self.Drag_Window
        
    def Drag_Window(self, sender, args):
        try: self.window.DragMove()
        except: pass

    def show(self):
        self.window.ShowDialog()

# ==============================================================================
# MAIN SCRIPT (TỐC ĐỘ ỔN ĐỊNH - AN TOÀN)
# ==============================================================================
doc = revit.doc
uidoc = revit.uidoc

# 1. THU THẬP VIEW NGUỒN
source_views = []
selection_ids = uidoc.Selection.GetElementIds()

if selection_ids:
    for eid in selection_ids:
        el = doc.GetElement(eid)
        if hasattr(el, "ViewType") and str(el.ViewType).endswith("Plan") and not el.IsTemplate:
            source_views.append(el)
if not source_views:
    if str(doc.ActiveView.ViewType).endswith("Plan"):
        source_views.append(doc.ActiveView)
if not source_views:
    forms.alert("Fen phải chọn View Plan trong Project Browser hoặc mở View lên nhé!", exitscript=True)

# 2. CHUẨN BỊ TEMPLATE OPTIONS
all_views = FilteredElementCollector(doc).OfClass(View).ToElements()
template_options = []
template_options.append(TemplateOption("Giữ nguyên (Gốc)", ElementId(-1)))
template_options.append(TemplateOption("<None> (Bỏ Template)", ElementId.InvalidElementId))

raw_templates = []
for v in all_views:
    if v.IsTemplate and v.ViewType == source_views[0].ViewType: 
        raw_templates.append(v)
raw_templates.sort(key=lambda x: x.Name)
for t in raw_templates:
    template_options.append(TemplateOption(t.Name, t.Id))

all_levels = sorted(FilteredElementCollector(doc).OfClass(revit.DB.Level).ToElements(), key=lambda x: x.Elevation)

form = SmartDupForm(all_levels, source_views, template_options)
if form.show() != True:
    script.exit()

inputs = form.values
selected_levels = inputs["levels"]
is_detailing = (inputs["mode"] == 1)
view_configs = inputs["view_configs"] 

t = Transaction(doc, "Smart Clone V16 - Lazy Speed")
t.Start()

results_log = []
new_views_data = []

# ==================================================
# GIAI ĐOẠN 1: TẠO MẺ VIEW VÀ LẤY SẴN DATA GỐC
# ==================================================
for config in view_configs:
    src_view = config["view"]
    selected_template_id = config["template_id"]
    src_type_id = src_view.GetTypeId()
    
    final_template_id = selected_template_id if selected_template_id != ElementId(-1) else src_view.ViewTemplateId

    # PRE-FETCH MỘT LẦN DUY NHẤT
    s_grids = FilteredElementCollector(doc, src_view.Id).OfCategory(BuiltInCategory.OST_Grids).WhereElementIsNotElementType().ToElements()
    s_grids_dict = {g.Id: g for g in s_grids}
    
    net_ids_to_copy = None
    if is_detailing:
        ids_to_copy = []
        for el in FilteredElementCollector(doc, src_view.Id).WhereElementIsNotElementType().ToElements():
            if el.ViewSpecific and el.Category and el.Category.Name != "Views" and el.Id != src_view.Id:
                 ids_to_copy.append(el.Id)
        if ids_to_copy:
            net_ids_to_copy = List[ElementId](ids_to_copy)

    for target_lvl in selected_levels:
        if src_view.GenLevel and src_view.GenLevel.Id == target_lvl.Id: continue
        try:
            # Tạo view
            new_view = ViewPlan.Create(doc, src_type_id, target_lvl.Id)
            
            # Đặt tên
            base_name = "{}{}{}".format(inputs["prefix"], src_view.Name, inputs["suffix"])
            try: new_view.Name = base_name
            except:
                safe_name = "{} - {}".format(base_name, target_lvl.Name)
                try: new_view.Name = safe_name
                except: new_view.Name = safe_name + " (Copy)"

            # Copy Scope Box
            try:
                sb_param_src = src_view.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP)
                if sb_param_src and sb_param_src.HasValue:
                    new_view.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP).Set(sb_param_src.AsElementId())
            except: pass

            # Set Template
            if final_template_id != ElementId.InvalidElementId:
                new_view.ViewTemplateId = final_template_id

            # Sync View Range (Cực nhẹ, copy nguyên si offset/level rules)
            try:
                src_vr = src_view.GetViewRange()
                src_idx, tgt_idx = -1, -1
                for i, lvl in enumerate(all_levels):
                    if lvl.Id == src_view.GenLevel.Id: src_idx = i
                    if lvl.Id == target_lvl.Id: tgt_idx = i
                delta = tgt_idx - src_idx if (src_idx != -1 and tgt_idx != -1) else 0
                planes = [PlanViewPlane.TopClipPlane, PlanViewPlane.CutPlane, PlanViewPlane.BottomClipPlane, PlanViewPlane.ViewDepthPlane]
                for plane in planes:
                    lvl_id = src_vr.GetLevelId(plane)
                    if lvl_id.IntegerValue > 0 and delta != 0:
                        lvl_idx = next((i for i, lvl in enumerate(all_levels) if lvl.Id == lvl_id), -1)
                        if lvl_idx != -1:
                            new_idx = max(0, min(lvl_idx + delta, len(all_levels) - 1))
                            src_vr.SetLevelId(plane, all_levels[new_idx].Id)
                new_view.SetViewRange(src_vr)
            except: pass

            try: new_view.Scale = src_view.Scale
            except: pass

            if src_view.CropBoxActive:
                new_view.CropBoxActive = True
                new_view.CropBoxVisible = src_view.CropBoxVisible

            new_views_data.append({
                "new_view": new_view,
                "src_view": src_view,
                "s_grids_dict": s_grids_dict,
                "is_detailing": is_detailing,
                "net_ids_to_copy": net_ids_to_copy,
                "target_lvl_name": target_lvl.Name
            })
        except Exception as e:
            results_log.append(ResultItem("✘", "Lỗi tạo {}: {}".format(target_lvl.Name, str(e)), False))

# ==================================================
# CHÌA KHÓA TỐC ĐỘ: Lệnh cập nhật hình học GỌI 1 LẦN DUY NHẤT
doc.Regenerate()
# ==================================================

# ==================================================
# GIAI ĐOẠN 2: THIẾT LẬP CROP SHAPE TỪ VIEW NGUỒN
# ==================================================
crop_changed = False
for data in new_views_data:
    if data["src_view"].CropBoxActive:
        try:
            loop = data["src_view"].GetCropRegionShapeManager().GetCropShape()[0]
            data["new_view"].GetCropRegionShapeManager().SetCropShape(loop)
            crop_changed = True
        except: pass

if crop_changed:
    doc.Regenerate() 

# ==================================================
# GIAI ĐOẠN 3: DÁN 2D & ĐỒNG BỘ LƯỚI TRỤC THEO THUẬT TOÁN "LƯỜI BIẾNG"
# Chỉ chỉnh sửa API khi có sự khác biệt rõ rệt để tránh overhead CPU
# ==================================================
for data in new_views_data:
    new_view = data["new_view"]
    src_view = data["src_view"]
    s_grids_dict = data["s_grids_dict"]
    
    status_symbol = "✔"
    
    # Paste Detailing
    if data["is_detailing"] and data["net_ids_to_copy"]:
        if not smart_copy_elements(doc, src_view, new_view, data["net_ids_to_copy"]):
            status_symbol = "⚠"
            
    # Sync Lưới trục (Cực nhẹ)
    if s_grids_dict:
        try:
            t_grids = FilteredElementCollector(doc, new_view.Id).OfCategory(BuiltInCategory.OST_Grids).WhereElementIsNotElementType().ToElements()
            t_grids_dict = {g.Id: g for g in t_grids}
            
            # Ẩn/Hiện đồng bộ
            to_hide = List[ElementId]()
            for t_id in t_grids_dict.keys():
                if t_id not in s_grids_dict: to_hide.Add(t_id)
            if to_hide.Count > 0:
                try: new_view.HideElements(to_hide)
                except: pass
                
            to_unhide = List[ElementId]()
            for s_id in s_grids_dict.keys():
                if s_id not in t_grids_dict: to_unhide.Add(s_id)
            if to_unhide.Count > 0:
                try: new_view.UnhideElements(to_unhide)
                except: pass
                
            # Duyệt từng trục "lười biếng"
            for s_id, s_grid in s_grids_dict.items():
                if s_id not in t_grids_dict: continue
                t_grid = t_grids_dict[s_id]
                
                # Extent Type (Chỉ set khi thực sự khác biệt)
                try:
                    for end in [DatumEnds.End0, DatumEnds.End1]:
                        s_ext = s_grid.GetDatumExtentTypeInView(end, src_view)
                        if t_grid.GetDatumExtentTypeInView(end, new_view) != s_ext:
                            t_grid.SetDatumExtentType(end, new_view, s_ext)
                except: pass
                
                # Bubble (Chỉ thay đổi trạng thái khi sai)
                try:
                    for end in [DatumEnds.End0, DatumEnds.End1]:
                        s_vis = s_grid.IsBubbleVisibleInView(end, src_view)
                        t_vis = t_grid.IsBubbleVisibleInView(end, new_view)
                        if s_vis != t_vis:
                            if s_vis: t_grid.ShowBubbleInView(end, new_view)
                            else: t_grid.HideBubbleInView(end, new_view)
                except: pass
                
                # 2D Curve
                try:
                    is_end0_2d = s_grid.GetDatumExtentTypeInView(DatumEnds.End0, src_view) == DatumExtentType.ViewSpecific
                    is_end1_2d = s_grid.GetDatumExtentTypeInView(DatumEnds.End1, src_view) == DatumExtentType.ViewSpecific
                    
                    if is_end0_2d or is_end1_2d:
                        s_curves = s_grid.GetCurvesInView(DatumExtentType.ViewSpecific, src_view)
                        t_curves_curr = t_grid.GetCurvesInView(DatumExtentType.ViewSpecific, new_view)
                        
                        if s_curves and t_curves_curr:
                            s_c = s_curves[0]
                            t_c_curr = t_curves_curr[0]
                            t_c = None
                            tgt_z = t_c_curr.GetEndPoint(0).Z
                            
                            if isinstance(s_c, Line) and isinstance(t_c_curr, Line):
                                p0 = XYZ(s_c.GetEndPoint(0).X, s_c.GetEndPoint(0).Y, tgt_z)
                                p1 = XYZ(s_c.GetEndPoint(1).X, s_c.GetEndPoint(1).Y, tgt_z)
                                if p0.DistanceTo(p1) > 0.001: t_c = Line.CreateBound(p0, p1)
                            elif isinstance(s_c, Arc) and isinstance(t_c_curr, Arc):
                                p0 = XYZ(s_c.GetEndPoint(0).X, s_c.GetEndPoint(0).Y, tgt_z)
                                p1 = XYZ(s_c.GetEndPoint(1).X, s_c.GetEndPoint(1).Y, tgt_z)
                                pMid = XYZ(s_c.Evaluate(0.5, True).X, s_c.Evaluate(0.5, True).Y, tgt_z)
                                if p0.DistanceTo(p1) > 0.001: t_c = Arc.Create(p0, p1, pMid)
                            
                            if t_c: t_grid.SetCurveInView(DatumExtentType.ViewSpecific, new_view, t_c)
                except: pass
                
                # Leader/Elbow (Chỉ copy nếu có bẻ gốc)
                try:
                    for end in [DatumEnds.End0, DatumEnds.End1]:
                        s_leader = None
                        try: s_leader = s_grid.GetLeader(end, src_view)
                        except: pass
                        
                        if s_leader:
                            t_leader = None
                            try: t_leader = t_grid.GetLeader(end, new_view)
                            except: pass
                            
                            if not t_leader:
                                try: t_leader = t_grid.AddLeader(end, new_view)
                                except: pass
                            
                            if t_leader:
                                try:
                                    t_curves = t_grid.GetCurvesInView(DatumExtentType.ViewSpecific, new_view)
                                    if not t_curves: t_curves = t_grid.GetCurvesInView(DatumExtentType.Model, new_view)
                                    tgt_z = t_curves[0].GetEndPoint(0).Z if t_curves else 0.0
                                    
                                    t_leader.Elbow = XYZ(s_leader.Elbow.X, s_leader.Elbow.Y, tgt_z)
                                    t_leader.End = XYZ(s_leader.End.X, s_leader.End.Y, tgt_z)
                                    t_grid.SetLeader(end, new_view, t_leader)
                                except: pass
                except: pass
        except: pass

    results_log.append(ResultItem(status_symbol, new_view.Name, True))

t.Commit()

res_window = ResultWindow(results_log)
res_window.show()