# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit, forms
import math

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- CẤU HÌNH ---
BASE_FAMILY_REVERSE = False 

# Filter chỉ cho chọn Duct
class DuctFilter(ISelectionFilter):
    def AllowElement(self, element):
        return isinstance(element, Duct)
    def AllowReference(self, reference, point):
        return False

def get_connector_closest_to_curve(element, target_curve):
    closest_connector = None
    min_dist = float('inf')
    try:
        connectors = element.ConnectorManager.Connectors
        for conn in connectors:
            result = target_curve.Project(conn.Origin)
            if result:
                dist = result.Distance
                if dist < min_dist:
                    min_dist = dist
                    closest_connector = conn
    except: return None
    return closest_connector

def main():
    duct_filter = DuctFilter()
    
    while True:
        try:
            # 1. Chọn Ống Chính & Lấy điểm Click (Bắt lỗi ESC tại đây)
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, duct_filter, "B1: Chọn hướng trên ống chính (Nhấn ESC để thoát)")
                main_duct = doc.GetElement(ref_main)
                click_point = ref_main.GlobalPoint

                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, duct_filter, "B2: Chọn ống nhánh")
                branch_duct = doc.GetElement(ref_branch)
            except OperationCanceledException:
                # Thoát vòng lặp khi người dùng nhấn ESC
                break 

            # --- THỰC THI TRANSACTION CHO MỖI CẶP ---
            t = Transaction(doc, "Align Center & Tap")
            t.Start()
            
            main_curve = main_duct.Location.Curve
            main_p0 = main_curve.GetEndPoint(0)
            main_p1 = main_curve.GetEndPoint(1)
            main_vec = (main_p1 - main_p0).Normalize()

            closest_conn = get_connector_closest_to_curve(branch_duct, main_curve)
            
            if closest_conn:
                # Giao điểm hình chiếu trên trục ống chính
                intersection_point = main_curve.Project(closest_conn.Origin).XYZPoint
                
                # --- AUTO ALIGN Z ---
                z_diff = intersection_point.Z - closest_conn.Origin.Z
                if abs(z_diff) > 0.00328: # > 1mm
                    ElementTransformUtils.MoveElement(doc, branch_duct.Id, XYZ(0, 0, z_diff))
                    doc.Regenerate()
                    # Cập nhật lại điểm sau khi move
                    intersection_point = main_curve.Project(closest_conn.Origin).XYZPoint

                # --- TẠO TAP ---
                new_fitting = doc.Create.NewTakeoffFitting(closest_conn, main_duct)
                doc.Regenerate()
                
                if new_fitting:
                    fit_origin = new_fitting.Location.Point
                    
                    # --- FIX LOGIC XOAY 4 MẶT ---
                        # Hướng người dùng muốn (Click)
                        vec_to_click = (click_point - fit_origin).Normalize()
                        dot_click = main_vec.DotProduct(vec_to_click)
                        
                        # Hướng hiện tại của Fitting
                        fit_facing = new_fitting.HandOrientation
                        dot_fit = main_vec.DotProduct(fit_facing)
                        
                        # Xác định xem ống nhánh đang nằm bên "Trái" hay "Phải" của vector ống chính
                        branch_vec = (closest_conn.Origin - fit_origin).Normalize()
                        side_check = main_vec.CrossProduct(branch_vec).Z
                        
                        # Quyết định xoay ban đầu
                        should_rotate = (dot_click * dot_fit < 0)

                        # BÙ TRỪ MẶT ĐỐI DIỆN: 
                        # Khi cắm sang mặt bên kia, Revit mirror family làm HandOrientation bị ngược.
                        # Đổi dấu '<' thành '>' so với code gốc của bro là giải quyết xong!
                        if side_check > 0: 
                            should_rotate = not should_rotate

                        if should_rotate:
                            # Ưu tiên lật chuẩn của Revit
                            if new_fitting.CanFlipHand:
                                new_fitting.flipHand()
                            else:
                                # Backup xoay 180 độ
                                axis_p1 = fit_origin
                                axis_p2 = axis_p1 + closest_conn.CoordinateSystem.BasisZ 
                                rotation_axis = Line.CreateBound(axis_p1, axis_p2)
                                ElementTransformUtils.RotateElement(doc, new_fitting.Id, rotation_axis, math.pi)
                
                t.Commit()
            else:
                t.RollBack()

        except Exception as e:
            # Nếu gặp lỗi không mong muốn, báo lỗi và tiếp tục vòng lặp
            print("Lỗi: {}".format(e))
            if t.GetStatus() == TransactionStatus.Started:
                t.RollBack()

if __name__ == "__main__":
    main()