# -*- coding: utf-8 -*-
from pyrevit import revit, DB, UI
from pyrevit import forms
import math

doc = revit.doc
uidoc = revit.uidoc

def get_distance_between_faces():
    try:
        # Yêu cầu người dùng chọn mặt thứ nhất
        ref1 = uidoc.Selection.PickObject(UI.Selection.ObjectType.Face, "Chọn mặt phẳng thứ nhất")
        element1 = doc.GetElement(ref1)
        face1 = element1.GetGeometryObjectFromReference(ref1)

        # Yêu cầu người dùng chọn mặt thứ hai
        ref2 = uidoc.Selection.PickObject(UI.Selection.ObjectType.Face, "Chọn mặt phẳng thứ hai")
        element2 = doc.GetElement(ref2)
        face2 = element2.GetGeometryObjectFromReference(ref2)

        # Kiểm tra xem cả 2 có phải là mặt phẳng (PlanarFace) không
        if isinstance(face1, DB.PlanarFace) and isinstance(face2, DB.PlanarFace):
            normal1 = face1.FaceNormal
            normal2 = face2.FaceNormal
            
            # Kiểm tra 2 mặt có song song với nhau không (cùng hướng hoặc ngược hướng)
            if normal1.IsAlmostEqualTo(normal2) or normal1.IsAlmostEqualTo(-normal2):
                # Tính vector nối giữa 2 điểm gốc của 2 mặt
                vector_between_origins = face2.Origin - face1.Origin
                
                # Chiếu vector đó lên pháp tuyến của mặt thứ nhất để lấy khoảng cách vuông góc (feet)
                distance_ft = abs(vector_between_origins.DotProduct(normal1))
                
                # Đổi từ Feet (internal unit của Revit) sang mm
                distance_mm = distance_ft * 304.8
                
                # Hiển thị kết quả
                forms.alert("Khoảng cách giữa 2 mặt là:\n\n{:.2f} mm".format(distance_mm), title="Kết quả đo")
            else:
                forms.alert("Hai mặt được chọn không song song với nhau!", title="Lỗi hình học")
        else:
            forms.alert("Vui lòng chỉ chọn các mặt phẳng (Planar Face). Mặt cong không được hỗ trợ trong script này.", title="Sai loại mặt")

    except Exception as e:
        # Bỏ qua lỗi nếu người dùng nhấn ESC để hủy lệnh
        if "Operation canceled" in str(e):
            pass
        else:
            forms.alert("Có lỗi xảy ra: {}".format(str(e)), title="Lỗi")

# Chạy hàm
get_distance_between_faces()