# -*- coding: utf-8 -*-
"""
Title: Auto Align Loop (V7 - Ninja Mode)
Description: Chế độ tàng hình. Không hiện thanh bar. Nhìn góc trái dưới để xem nhắc lệnh. ESC để thoát.
Author: Gemini Bro
"""
import math
from System.Collections.Generic import List 

# --- REVIT API ---
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType
from Autodesk.Revit.Exceptions import OperationCanceledException 

# --- PYREVIT ---
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

# =======================================================
# 1. CORE LOGIC (GIỮ NGUYÊN)
# =======================================================

def get_projected_vector(vector, plane_normal):
    n = plane_normal.Normalize()
    return vector - n * (vector.DotProduct(n))

def analyze_branch_connection(branch_pipe_elem):
    conns = branch_pipe_elem.ConnectorManager.Connectors
    for conn in conns:
        if not conn.IsConnected: continue
        for ref in conn.AllRefs:
            attached_elem = ref.Owner
            if str(attached_elem.Category.Name) == "Pipe Fittings":
                fitting = attached_elem
                fit_conns = fitting.MEPModel.ConnectorManager.Connectors
                for f_conn in fit_conns:
                    if not f_conn.IsConnected: continue
                    for f_ref in f_conn.AllRefs:
                        potential_parent = f_ref.Owner
                        if potential_parent.Id == branch_pipe_elem.Id: continue
                        try:
                            loc = potential_parent.Location
                            if isinstance(loc, LocationCurve) and isinstance(loc.Curve, Line):
                                return loc.Curve, fitting.Id, f_conn.Origin
                        except: pass
    return None, None, None

# =======================================================
# 2. MAIN FUNCTION (NINJA LOOP)
# =======================================================

def main():
    # Không dùng ProgressBar nữa để tránh cái thanh đen đen
    while True:
        try:
            # --- BƯỚC 1: Chọn Ống Nhánh ---
            # Dòng nhắc lệnh sẽ hiện ở STATUS BAR (Góc dưới trái màn hình)
            ref_branch = uidoc.Selection.PickObject(ObjectType.Element, "1. [ESC để thoát] Chọn Ống Nhánh")
            branch_elem = doc.GetElement(ref_branch)
        except OperationCanceledException:
            break # Nhấn ESC -> Thoát êm
        except Exception:
            break

        if str(branch_elem.Category.Name) != "Pipes":
            continue # Chọn sai thì lờ đi cho chọn lại

        # --- BƯỚC 2: Tự động dò tìm ---
        axis_line, fitting_id, pivot_point = analyze_branch_connection(branch_elem)
        
        if not axis_line:
            # Nếu lỗi thì bip nhẹ 1 cái hoặc hiện alert nhỏ, rồi cho làm tiếp
            # forms.alert("Lỗi: Không tìm thấy trục xoay!", warn_icon=True)
            continue 

        ids_to_rotate = List[ElementId]()
        ids_to_rotate.Add(branch_elem.Id)
        ids_to_rotate.Add(fitting_id)

        try:
            # --- BƯỚC 3: Chọn Ống Main ---
            ref_main = uidoc.Selection.PickObject(ObjectType.Element, "2. [ESC để thoát] Chọn Ống Main")
            main_elem = doc.GetElement(ref_main)
            main_line = main_elem.Location.Curve
        except OperationCanceledException:
            break
        except:
            continue

        # --- BƯỚC 4: Tính toán & Xoay ---
        try:
            axis_vec = axis_line.Direction.Normalize() 
            branch_line = branch_elem.Location.Curve
            branch_vec = branch_line.Direction
            
            p0 = branch_line.GetEndPoint(0)
            p1 = branch_line.GetEndPoint(1)
            if p0.DistanceTo(pivot_point) >= p1.DistanceTo(pivot_point):
                branch_vec = -branch_vec

            proj_result = main_line.Project(pivot_point)
            if not proj_result:
                unbound_main = Line.CreateUnbound(main_line.Origin, main_line.Direction)
                proj_result = unbound_main.Project(pivot_point)
                
            closest_pt_on_main = proj_result.XYZPoint
            target_vec_3d = closest_pt_on_main - pivot_point

            v_curr_flat = get_projected_vector(branch_vec, axis_vec)
            v_target_flat = get_projected_vector(target_vec_3d, axis_vec)
            
            angle_rad = v_curr_flat.AngleTo(v_target_flat)
            
            cross = v_curr_flat.CrossProduct(v_target_flat)
            if cross.DotProduct(axis_vec) < 0:
                angle_rad = -angle_rad

            if abs(angle_rad) > 0.001:
                t = Transaction(doc, "Align Ninja")
                t.Start()
                ElementTransformUtils.RotateElements(doc, ids_to_rotate, axis_line, angle_rad)
                t.Commit()
                
        except Exception:
            continue

if __name__ == "__main__":
    main()