# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Electrical import CableTray
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException
import math

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- HÀM HỖ TRỢ ---

class MEPFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category is None: return False
        cat_id = elem.Category.Id.IntegerValue
        if cat_id == int(BuiltInCategory.OST_PipeCurves) or \
           cat_id == int(BuiltInCategory.OST_DuctCurves) or \
           cat_id == int(BuiltInCategory.OST_CableTray):
            return True
        return False
    def AllowReference(self, reference, position):
        return False

def get_connectors_safe(element):
    if isinstance(element, (Pipe, Duct, CableTray)):
        return element.ConnectorManager.Connectors
    elif isinstance(element, FamilyInstance):
        if element.MEPModel:
            return element.MEPModel.ConnectorManager.Connectors
    return []

def get_connector_closest_to(element, point):
    connectors = get_connectors_safe(element)
    if not connectors: return None
    closest = None
    min_dist = float('inf')
    for con in connectors:
        dist = con.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist = dist
            closest = con
    return closest

def get_system_type_id(element):
    if isinstance(element, CableTray): return None # Máng cáp không dùng System Type
    pm = element.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
    if pm and pm.HasValue: return pm.AsElementId()
    pm = element.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
    if pm and pm.HasValue: return pm.AsElementId()
    return ElementId.InvalidElementId

def copy_size_parameters(source_elem, target_elem):
    params_to_copy = [
        BuiltInParameter.RBS_PIPE_DIAMETER_PARAM,
        BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,
        BuiltInParameter.RBS_CURVE_WIDTH_PARAM,
        BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
        BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM, # Kích thước máng cáp
        BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM
    ]
    for pid in params_to_copy:
        src_p = source_elem.get_Parameter(pid)
        tgt_p = target_elem.get_Parameter(pid)
        if src_p and tgt_p and not src_p.IsReadOnly and not tgt_p.IsReadOnly:
            try: tgt_p.Set(src_p.AsDouble())
            except: pass

def get_closest_points_between_lines(line1_p1, line1_dir, line2_p1, line2_dir):
    w0 = line1_p1 - line2_p1
    a = line1_dir.DotProduct(line1_dir)
    b = line1_dir.DotProduct(line2_dir)
    c = line2_dir.DotProduct(line2_dir)
    d = line1_dir.DotProduct(w0)
    e = line2_dir.DotProduct(w0)
    denom = a * c - b * b
    if abs(denom) < 1e-6: return None, None 
    sc = (b * e - c * d) / denom
    tc = (a * e - b * d) / denom
    return line1_p1 + line1_dir * sc, line2_p1 + line2_dir * tc

def project_point_on_line(point, line_origin, line_dir):
    v = point - line_origin
    dist = v.DotProduct(line_dir)
    return line_origin + line_dir * dist

# --- LOGIC TÍNH TOÁN 45 ĐỘ ---

def calculate_exact_45_point(p1_end, v1_dir, p2_curve):
    p2_start = p2_curve.GetEndPoint(0)
    p2_end = p2_curve.GetEndPoint(1)
    v2_dir = (p2_end - p2_start).Normalize()
    
    dot = abs(v1_dir.DotProduct(v2_dir))
    
    if dot > 0.99: # SONG SONG
        H = project_point_on_line(p1_end, p2_start, v2_dir)
        offset = p1_end.DistanceTo(H)
        candidate1 = H + v2_dir * offset
        candidate2 = H - v2_dir * offset
        mid_p2 = (p2_start + p2_end) / 2
        return candidate1 if candidate1.DistanceTo(mid_p2) < candidate2.DistanceTo(mid_p2) else candidate2
    else: # CẮT NHAU
        i1, i2 = get_closest_points_between_lines(p1_end, v1_dir, p2_start, v2_dir)
        if not i1: return None
        I = (i1 + i2) / 2
        L = I.DistanceTo(p1_end)
        
        dir_from_I = (p2_start - I).Normalize() if p2_start.DistanceTo(I) > p2_end.DistanceTo(I) else (p2_end - I).Normalize()
        return I + dir_from_I * L

def run():
    tg = TransactionGroup(doc, "Connect MEP 45 Auto Trim (Loop)")
    tg.Start()
    
    try:
        mep_filter = MEPFilter()
        
        while True:
            # 1. PICK
            try:
                ref1 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ỐNG GỐC (Nhấn ESC để ngưng lệnh)")
                ref2 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ỐNG ĐÍCH (Nhấn ESC để ngưng lệnh)")
            except OperationCanceledException:
                break 

            elem1 = doc.GetElement(ref1)
            elem2 = doc.GetElement(ref2)

            if type(elem1) != type(elem2) or not isinstance(elem1, (Pipe, Duct, CableTray)):
                 print("Lỗi: Vui lòng chọn 2 đối tượng cùng loại (Pipe, Duct hoặc CableTray).")
                 continue 

            t = Transaction(doc, "Connect MEP 45 Auto Trim")
            t.Start()
            
            try:
                # 2. XÁC ĐỊNH ĐIỂM GỐC P1
                c1 = elem1.Location.Curve
                c2 = elem2.Location.Curve
                
                p1_start_orig = c1.GetEndPoint(0)
                p1_end_orig = c1.GetEndPoint(1)
                
                mid_p2 = (c2.GetEndPoint(0) + c2.GetEndPoint(1)) / 2
                if p1_start_orig.DistanceTo(mid_p2) < p1_end_orig.DistanceTo(mid_p2):
                    p1_root = p1_start_orig
                    p1_fixed = p1_end_orig 
                    v1_axial = (p1_start_orig - p1_end_orig).Normalize() 
                else:
                    p1_root = p1_end_orig
                    p1_fixed = p1_start_orig
                    v1_axial = (p1_end_orig - p1_start_orig).Normalize()

                # 3. TÍNH TOÁN P2 LẦN ĐẦU
                p2_target = calculate_exact_45_point(p1_root, v1_axial, c2)
                if not p2_target:
                    t.RollBack()
                    print("Lỗi: Không tính được góc 45 độ cho cặp này.")
                    continue

                # 4. KIỂM TRA & TỰ ĐỘNG CẮT ỐNG 1 (AUTO TRIM)
                min_bridge_len = 0.7 # ~150mm (Feet)
                current_bridge_len = p1_root.DistanceTo(p2_target)

                if current_bridge_len < min_bridge_len:
                    trim_distance = min_bridge_len - current_bridge_len + 0.1
                    new_p1_root = p1_root - v1_axial * trim_distance
                    
                    try:
                        elem1.Location.Curve = Line.CreateBound(p1_fixed, new_p1_root)
                        p1_root = new_p1_root 
                        doc.Regenerate() 
                    except Exception as e:
                        t.RollBack()
                        print("Lỗi Trim: Ống 1 quá ngắn để cắt lùi lại. " + str(e))
                        continue
                    
                    p2_target = calculate_exact_45_point(p1_root, v1_axial, c2)
                    if not p2_target: 
                        t.RollBack()
                        continue

                # 5. CẬP NHẬT ỐNG 2 (TRIM/EXTEND)
                p2_start = c2.GetEndPoint(0)
                p2_end = c2.GetEndPoint(1)
                
                if p2_start.DistanceTo(p2_target) > p2_end.DistanceTo(p2_target):
                    new_c2 = Line.CreateBound(p2_start, p2_target)
                else:
                    new_c2 = Line.CreateBound(p2_target, p2_end)
                    
                try:
                    elem2.Location.Curve = new_c2
                    doc.Regenerate()
                except:
                    t.RollBack()
                    print("Lỗi: Không thể chỉnh ống 2.")
                    continue

                # 6. TẠO ỐNG GIỮA & FITTING
                try:
                    ptype_id = elem1.GetTypeId()
                    lvl_id = elem1.get_Parameter(BuiltInParameter.RBS_START_LEVEL_PARAM).AsElementId()

                    if isinstance(elem1, Pipe):
                        sys_id = get_system_type_id(elem1)
                        mid_elem = Pipe.Create(doc, sys_id, ptype_id, lvl_id, p1_root, p2_target)
                    elif isinstance(elem1, Duct):
                        sys_id = get_system_type_id(elem1)
                        mid_elem = Duct.Create(doc, sys_id, ptype_id, lvl_id, p1_root, p2_target)
                    elif isinstance(elem1, CableTray):
                        # Máng cáp dùng hàm Create khác, không cần System ID
                        mid_elem = CableTray.Create(doc, ptype_id, p1_root, p2_target, lvl_id)
                    
                    copy_size_parameters(elem1, mid_elem)
                    doc.Regenerate()

                    # Kết nối Elbow
                    c1_conn = get_connector_closest_to(elem1, p1_root)
                    cm1 = get_connector_closest_to(mid_elem, p1_root)
                    if c1_conn and cm1: doc.Create.NewElbowFitting(c1_conn, cm1)

                    c2_conn = get_connector_closest_to(elem2, p2_target)
                    cm2 = get_connector_closest_to(mid_elem, p2_target)
                    if c2_conn and cm2: doc.Create.NewElbowFitting(c2_conn, cm2)
                    
                except Exception as e:
                    print("Lỗi Fitting: Không thể tạo phụ kiện (góc quá gắt hoặc không đủ chỗ). " + str(e))
                    
                t.Commit()

            except Exception as e_geo:
                if t.GetStatus() == TransactionStatus.Started: t.RollBack()
                print("Lỗi xử lý hình học: " + str(e_geo))

    except Exception as e:
        if "OperationCanceled" not in str(e):
            TaskDialog.Show("Critical Error", str(e))
    finally:
        if tg.GetStatus() == TransactionStatus.Started:
            tg.Assimilate()

if __name__ == '__main__':
    run()