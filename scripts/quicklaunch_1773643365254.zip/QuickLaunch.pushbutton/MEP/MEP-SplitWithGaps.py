# -*- coding: utf-8 -*-
import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')

from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import PlumbingUtils
from Autodesk.Revit.DB.Mechanical import MechanicalUtils
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

class MEPCurveFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category is None: 
            return False
        
        allowed_cats = [
            BuiltInCategory.OST_PipeCurves,
            BuiltInCategory.OST_DuctCurves,
            BuiltInCategory.OST_CableTray,
            BuiltInCategory.OST_Conduit
        ]
        return elem.Category.BuiltInCategory in allowed_cats

    def AllowReference(self, ref, pos): return True

# Hàm phụ trợ: Lấy danh sách các đối tượng đang nối vào một vị trí (đầu ống)
def get_far_end_refs(mep_curve, target_pt):
    refs = []
    try:
        manager = mep_curve.ConnectorManager
        for c in manager.Connectors:
            if c.Origin.DistanceTo(target_pt) < 0.01:
                for ref in c.AllRefs:
                    if ref.Owner.Id != mep_curve.Id and ref.ConnectorType != ConnectorType.Logical:
                        refs.append(ref)
    except: pass
    return refs

# Hàm phụ trợ: Nối lại connector vào các đối tượng đã lưu
def reconnect_far_end(mep_curve, target_pt, refs_to_connect):
    if not refs_to_connect: return
    try:
        manager = mep_curve.ConnectorManager
        for c in manager.Connectors:
            if c.Origin.DistanceTo(target_pt) < 0.01:
                for ref in refs_to_connect:
                    try: c.ConnectTo(ref)
                    except: pass
    except: pass

def split_mep_with_gap():
    # Sửa lại thành 50.0mm tổng, mỗi bên lùi 25mm cho đúng text mô tả
    gap_mm = 50.0 
    gap_ft = gap_mm / 304.8
    half_gap = gap_ft / 2.0

    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, MEPCurveFilter(), "Chọn Duct/Pipe/Cable/Conduit để cắt 50mm (ESC để dừng)")
            elem = doc.GetElement(ref)
            
            loc = elem.Location
            curve = loc.Curve
            
            click_pt = ref.GlobalPoint
            projected_result = curve.Project(click_pt)
            if not projected_result: continue
            center_pt = projected_result.XYZPoint
            
            p_start = curve.GetEndPoint(0)
            p_end = curve.GetEndPoint(1)
            dir_vec = (p_end - p_start).Normalize()
            
            pt1 = center_pt - dir_vec * half_gap
            pt2 = center_pt + dir_vec * half_gap
            
            if p_start.DistanceTo(center_pt) <= half_gap or p_end.DistanceTo(center_pt) <= half_gap:
                print("Cắt sát đầu ống quá, đoạn bị cắt quá ngắn. Bỏ qua!")
                continue

            t = Transaction(doc, "Cắt hở MEP 50mm")
            t.Start()
            try:
                # 1. LƯU LẠI CONNECTORS Ở 2 ĐẦU TRƯỚC KHI CẮT/COPY
                refs_start = get_far_end_refs(elem, p_start)
                refs_end = get_far_end_refs(elem, p_end)

                cat_id = elem.Category.BuiltInCategory
                new_elem_id = None
                
                if cat_id == BuiltInCategory.OST_PipeCurves:
                    new_elem_id = PlumbingUtils.BreakCurve(doc, elem.Id, center_pt)
                elif cat_id == BuiltInCategory.OST_DuctCurves:
                    new_elem_id = MechanicalUtils.BreakCurve(doc, elem.Id, center_pt)
                else:
                    copied_ids = ElementTransformUtils.CopyElement(doc, elem.Id, XYZ.Zero)
                    new_elem_id = copied_ids[0]

                if new_elem_id:
                    new_elem = doc.GetElement(new_elem_id)

                    # 2. DỌN DẸP FITTING BỊ AUTO-CREATE TẠI ĐIỂM CẮT (Nếu có)
                    if cat_id in [BuiltInCategory.OST_PipeCurves, BuiltInCategory.OST_DuctCurves]:
                        unions = set()
                        for e in [elem, new_elem]:
                            try:
                                for c in e.ConnectorManager.Connectors:
                                    if c.Origin.DistanceTo(center_pt) < 0.1:
                                        for r in c.AllRefs:
                                            if r.Owner.Id != e.Id:
                                                r_cat = r.Owner.Category.BuiltInCategory
                                                if r_cat in [BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_DuctFitting]:
                                                    unions.add(r.Owner.Id)
                                                # Ngắt kết nối ở điểm giữa để rảnh tay nắn Curve
                                                try: c.DisconnectFrom(r)
                                                except: pass
                            except: pass
                        
                        # Xóa cục Union thừa
                        for u_id in unions:
                            try: doc.Delete(u_id)
                            except: pass
                    
                    # 3. NẮN LẠI CURVE ĐỂ TẠO GAP
                    c_elem = elem.Location.Curve
                    if c_elem.GetEndPoint(0).DistanceTo(p_start) < 0.01 or c_elem.GetEndPoint(1).DistanceTo(p_start) < 0.01:
                        elem.Location.Curve = Line.CreateBound(p_start, pt1)
                        new_elem.Location.Curve = Line.CreateBound(pt2, p_end)
                    else:
                        elem.Location.Curve = Line.CreateBound(pt2, p_end)
                        new_elem.Location.Curve = Line.CreateBound(p_start, pt1)
                        
                    # 4. NỐI LẠI 2 ĐẦU XA (Fix lỗi disconnect hiện hữu)
                    for e in [elem, new_elem]:
                        c = e.Location.Curve
                        if c.GetEndPoint(0).DistanceTo(p_start) < 0.01 or c.GetEndPoint(1).DistanceTo(p_start) < 0.01:
                            reconnect_far_end(e, p_start, refs_start)
                        if c.GetEndPoint(0).DistanceTo(p_end) < 0.01 or c.GetEndPoint(1).DistanceTo(p_end) < 0.01:
                            reconnect_far_end(e, p_end, refs_end)
                            
                t.Commit()
            except Exception as e:
                t.RollBack()
                print("Lỗi cắt khúc: " + str(e))
                
        except OperationCanceledException:
            break

if __name__ == "__main__":
    split_mep_with_gap()