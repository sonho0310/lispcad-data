# coding: utf8
import sys
from Autodesk.Revit import Exceptions
from Autodesk.Revit.DB import (InsulationLiningBase, Document, FamilyInstance, 
                               MEPCurve, Transaction)
from Autodesk.Revit.UI.Selection import ISelectionFilter, ObjectType

# --- CÁC HÀM HỖ TRỢ ---
def get_connectors(element):
    """Lấy danh sách connector từ MEPCurve (ống) hoặc FamilyInstance (phụ kiện)"""
    try:
        if isinstance(element, MEPCurve):
            return element.ConnectorManager.Connectors
        elif isinstance(element, FamilyInstance):
            mep_model = element.MEPModel
            if mep_model:
                return mep_model.ConnectorManager.Connectors
    except Exception:
        pass
    return None

def get_closest_unused_connector(connectors, point):
    """Tìm connector chưa kết nối gần điểm click nhất"""
    closest_connector = None
    min_dist = float('inf')
    
    if connectors is None:
        return None

    for conn in connectors:
        if not conn.IsConnected: # Chỉ lấy đầu hở
            dist = conn.Origin.DistanceTo(point)
            if dist < min_dist:
                min_dist = dist
                closest_connector = conn
    
    return closest_connector

# --- BỘ LỌC CHỌN ---
class NoInsulationFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if isinstance(elem, InsulationLiningBase):
            return False
        if isinstance(elem, MEPCurve) or isinstance(elem, FamilyInstance):
            return True
        return False

    def AllowReference(self, reference, position):
        return True

# --- LOGIC CHÍNH ---
def create_transition_fixed_first():
    uidoc = __revit__.ActiveUIDocument
    doc = uidoc.Document

    # 1. Chọn đối tượng GỐC (Muốn giữ nguyên vị trí)
    try:
        ref1 = uidoc.Selection.PickObject(
            ObjectType.Element, 
            NoInsulationFilter(), 
            "Chọn đối tượng 1 (GỐC - Sẽ đứng yên)"
        )
        element1 = doc.GetElement(ref1)
        pt1 = ref1.GlobalPoint
    except Exceptions.OperationCanceledException:
        return

    # 2. Chọn đối tượng ĐÍCH (Muốn nó tự co giãn)
    try:
        ref2 = uidoc.Selection.PickObject(
            ObjectType.Element, 
            NoInsulationFilter(), 
            "Chọn đối tượng 2 (ĐÍCH - Sẽ tự co giãn)"
        )
        element2 = doc.GetElement(ref2)
        pt2 = ref2.GlobalPoint
    except Exceptions.OperationCanceledException:
        return

    # 3. Lấy Connector
    conns1 = get_connectors(element1)
    conns2 = get_connectors(element2)
    
    c1 = get_closest_unused_connector(conns1, pt1)
    c2 = get_closest_unused_connector(conns2, pt2)

    if not c1 or not c2:
        return # Không tìm thấy đầu nối hợp lệ

    if c1.Domain != c2.Domain:
        return # Khác hệ (gió/nước)

    # 4. Thực thi
    t = Transaction(doc, "Tạo Transition")
    t.Start()
    try:
        # --- ĐIỂM QUAN TRỌNG NHẤT ---
        # Thay vì (c1, c2), ta dùng (c2, c1).
        # Điều này ép Revit coi c1 là điểm neo, và c2 là đối tượng phải thay đổi hình dáng để kết nối.
        doc.Create.NewTransitionFitting(c2, c1)
        
        t.Commit()
    except Exception:
        t.RollBack()

# Chạy script
create_transition_fixed_first()