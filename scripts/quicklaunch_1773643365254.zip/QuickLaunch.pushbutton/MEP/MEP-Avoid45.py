# -*- coding: utf-8 -*-
import clr
import math
from pyrevit import forms
from pyrevit import script
from System.Collections.Generic import List

# --- SETUP ---
import Autodesk
import System

clr.AddReference("PresentationCore")
clr.AddReference("PresentationFramework")
clr.AddReference("WindowsBase")

from System.Windows.Media import Brushes
from System.Windows import FontStyles

clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *

from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Electrical import CableTray, Conduit

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- GUI ---
xaml_string = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="MEP Offset 45 | Smart Logic" 
        Width="350" SizeToContent="Height" 
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize" Background="#F9F9F9">
    <Grid Margin="20">
        <StackPanel>
            <TextBlock Text="OFFSET 45 (SMART LOGIC)" FontSize="18" FontWeight="Bold" Foreground="#0078D7" HorizontalAlignment="Center" Margin="0,0,0,5"/>
            <TextBlock Text="(Dựa trên Core 90 - Ổn định tuyệt đối)" FontSize="11" FontStyle="Italic" Foreground="Gray" HorizontalAlignment="Center" Margin="0,0,0,20"/>
            
            <Grid Margin="0,0,0,15">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="140"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <TextBlock Grid.Column="0" Text="Khoảng né (mm):" VerticalAlignment="Center" FontWeight="SemiBold"/>
                <TextBox Grid.Column="1" Name="offset_tb" Height="30" 
                         Text="300" Foreground="Gray" FontStyle="Italic"
                         VerticalContentAlignment="Center" Padding="5,0,0,0" BorderBrush="#AAAAAA"/>
            </Grid>
            
            <TextBlock Text="Hướng xử lý:" FontWeight="SemiBold" Margin="0,0,0,10"/>
            <StackPanel Orientation="Horizontal" Margin="0,0,0,10">
                <RadioButton Name="rad_up" Content="Né Lên (UP)" GroupName="Dir" IsChecked="True" Width="140" FontSize="14" VerticalContentAlignment="Center"/>
                <RadioButton Name="rad_down" Content="Né Xuống (DOWN)" GroupName="Dir" FontSize="14" VerticalContentAlignment="Center"/>
            </StackPanel>
            <StackPanel Orientation="Horizontal" Margin="0,0,0,25">
                <RadioButton Name="rad_left" Content="Né Trái (LEFT)" GroupName="Dir" Width="140" FontSize="14" VerticalContentAlignment="Center"/>
                <RadioButton Name="rad_right" Content="Né Phải (RIGHT)" GroupName="Dir" FontSize="14" VerticalContentAlignment="Center"/>
            </StackPanel>
            
            <Button Name="btn_ok" Content="CHẠY NGAY" Height="45" 
                    Background="#0078D7" Foreground="White" FontWeight="Bold" FontSize="14" 
                    Click="ok_click" Cursor="Hand" BorderThickness="0" Margin="0,0,0,5"/>
        </StackPanel>
    </Grid>
</Window>
"""

class ClashWindow(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self, xaml_string, literal_string=True)
        self.offset_tb.GotFocus += self.tb_focus
        self.offset_tb.LostFocus += self.tb_blur

    def tb_focus(self, sender, args):
        if sender.Text == "300":
            sender.Text = ""
            sender.Foreground = Brushes.Black
            sender.FontStyle = FontStyles.Normal

    def tb_blur(self, sender, args):
        if not sender.Text.strip():
            sender.Text = "300"
            sender.Foreground = Brushes.Gray
            sender.FontStyle = FontStyles.Italic
        
    def ok_click(self, sender, args):
        val = self.offset_tb.Text
        if val == "" or val == "300": val = "300"
        self.offset_val = val
        if self.rad_up.IsChecked: self.dir_mode = "UP"
        elif self.rad_down.IsChecked: self.dir_mode = "DOWN"
        elif self.rad_left.IsChecked: self.dir_mode = "LEFT"
        elif self.rad_right.IsChecked: self.dir_mode = "RIGHT"
        self.DialogResult = True
        self.Close()

# --- CORE FUNCTIONS (Từ bản 90 độ) ---

def get_neighbor_at_end(element, end_point):
    try:
        cons = element.ConnectorManager.Connectors
        for c in cons:
            if c.Origin.DistanceTo(end_point) < 0.1: 
                if c.IsConnected:
                    for ref in c.AllRefs:
                        if ref.Owner.Id != element.Id and ref.ConnectorType != ConnectorType.Logical:
                            return ref 
    except: pass
    return None

def get_connector(element, point):
    if not element: return None
    cons = None
    try:
        if isinstance(element, FamilyInstance):
             cons = element.MEPModel.ConnectorManager.Connectors
        else:
             cons = element.ConnectorManager.Connectors
    except:
        return None

    min_dist = 999999
    closest = None
    for c in cons:
        d = c.Origin.DistanceTo(point)
        if d < min_dist:
            min_dist = d
            closest = c
    
    return closest if min_dist < 0.05 else None

def copy_parameters(src, dest):
    try:
        if isinstance(src, Duct):
            w = src.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM).AsDouble()
            h = src.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).AsDouble()
            dest.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(w)
            dest.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(h)
        elif isinstance(src, CableTray):
            w = src.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).AsDouble()
            h = src.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).AsDouble()
            dest.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(w)
            dest.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(h)
        elif isinstance(src, (Pipe, Conduit)):
            dia_param = src.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
            if not dia_param: dia_param = src.get_Parameter(BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM)
            if dia_param: dest.get_Parameter(dia_param.Definition).Set(dia_param.AsDouble())
        
        for bp in [BuiltInParameter.ALL_MODEL_INSTANCE_COMMENTS, 
                   BuiltInParameter.RBS_DUCT_PIPE_SYSTEM_ABBREVIATION_PARAM, 
                   BuiltInParameter.ALL_MODEL_MARK]:
            p_s, p_d = src.get_Parameter(bp), dest.get_Parameter(bp)
            if p_s and p_d and p_s.HasValue and not p_d.IsReadOnly and p_s.StorageType == StorageType.String: 
                p_d.Set(p_s.AsString())
    except: pass

def create_new_element(p1, p2, src_elem):
    if p1.DistanceTo(p2) < 0.01: return None 
    new_elem = None
    lvl_id = src_elem.LevelId
    try:
        if isinstance(src_elem, Duct):
            sys_id = src_elem.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).AsElementId()
            new_elem = Duct.Create(doc, sys_id, src_elem.DuctType.Id, lvl_id, p1, p2)
        elif isinstance(src_elem, Pipe):
            sys_id = src_elem.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
            new_elem = Pipe.Create(doc, sys_id, src_elem.PipeType.Id, lvl_id, p1, p2)
        elif isinstance(src_elem, CableTray):
            new_elem = CableTray.Create(doc, src_elem.GetTypeId(), p1, p2, lvl_id)
        elif isinstance(src_elem, Conduit):
            new_elem = Conduit.Create(doc, src_elem.GetTypeId(), p1, p2, lvl_id)
            
        if new_elem: copy_parameters(src_elem, new_elem)
        return new_elem
    except: return None

def set_workplane_to_element_level(element):
    try:
        z_val = element.Location.Curve.Origin.Z
        plane = Plane.CreateByNormalAndOrigin(XYZ.BasisZ, XYZ(0, 0, z_val))
        sp = SketchPlane.Create(doc, plane)
        uidoc.ActiveView.SketchPlane = sp
        return True
    except: return False

def fix_rotation(doc, ref_elem, target_elem, pt_ref, pt_tgt):
    if not ref_elem or not target_elem: return
    if isinstance(ref_elem, (Pipe, Conduit)): return
    if isinstance(ref_elem, Duct):
        dia = ref_elem.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
        if dia and dia.HasValue: return
        
    tgt_curve = target_elem.Location.Curve
    tgt_dir = (tgt_curve.GetEndPoint(1) - tgt_curve.GetEndPoint(0)).Normalize()
    is_vertical = abs(tgt_dir.Z) > 0.99
    
    if not is_vertical: return 
        
    c_ref = get_connector(ref_elem, pt_ref)
    c_tgt = get_connector(target_elem, pt_tgt)
    if not c_ref or not c_tgt: return
    
    v_ref = c_ref.CoordinateSystem.BasisX
    v_ref = XYZ(v_ref.X, v_ref.Y, 0)
    if v_ref.GetLength() < 0.01:
        v_ref = c_ref.CoordinateSystem.BasisY
        v_ref = XYZ(v_ref.X, v_ref.Y, 0)
        
    v_tgt = c_tgt.CoordinateSystem.BasisX
    v_tgt = XYZ(v_tgt.X, v_tgt.Y, 0)
    if v_tgt.GetLength() < 0.01:
        v_tgt = c_tgt.CoordinateSystem.BasisY
        v_tgt = XYZ(v_tgt.X, v_tgt.Y, 0)
        
    if v_ref.GetLength() > 0.01 and v_tgt.GetLength() > 0.01:
        v_ref = v_ref.Normalize()
        v_tgt = v_tgt.Normalize()
        
        angle = v_tgt.AngleTo(v_ref)
        cross = v_tgt.X * v_ref.Y - v_tgt.Y * v_ref.X
        if cross < 0: angle = -angle
        
        if abs(angle) > 0.01:
            axis = Line.CreateBound(tgt_curve.GetEndPoint(0), tgt_curve.GetEndPoint(1))
            try: ElementTransformUtils.RotateElement(doc, target_elem.Id, axis, angle)
            except: pass

# --- MAIN RUN ---
try:
    win = ClashWindow()
    win.ShowDialog()

    if win.DialogResult:
        try: off_mm = float(win.offset_val)
        except: off_mm = 300.0
        off_ft = off_mm / 304.8
        mode = win.dir_mode
        
        valid_types = (Duct, Pipe, CableTray, Conduit)
        
        tg = TransactionGroup(doc, "MEP Offset 45 Smart")
        tg.Start()
        
        first_run = True
        
        while True:
            try:
                mep_elements = []
                selected_ids = uidoc.Selection.GetElementIds()
                
                if first_run and selected_ids and selected_ids.Count > 0:
                    for eid in selected_ids:
                        el = doc.GetElement(eid)
                        if isinstance(el, valid_types): mep_elements.append(el)
                    uidoc.Selection.SetElementIds(List[ElementId]()) 
                else:
                    selection = uidoc.Selection.PickObjects(ObjectType.Element, "Quét chọn đối tượng (Nhấn ESC để NGƯNG lệnh)")
                    for ref in selection:
                        el = doc.GetElement(ref.ElementId)
                        if isinstance(el, valid_types): mep_elements.append(el)
                
                first_run = False
                if not mep_elements: continue

                master_elem = mep_elements[0]
                set_workplane_to_element_level(master_elem)
                
                master_curve = master_elem.Location.Curve
                master_vec = (master_curve.GetEndPoint(1) - master_curve.GetEndPoint(0)).Normalize()
                
                if abs(master_vec.Z) > 0.99: 
                    perp_relative = master_vec.CrossProduct(XYZ.BasisX).Normalize()
                else:
                    perp_relative = master_vec.CrossProduct(XYZ.BasisZ).Normalize()

                shift_vec = XYZ.Zero
                if mode == "UP": shift_vec = XYZ.BasisZ
                elif mode == "DOWN": shift_vec = -XYZ.BasisZ
                elif mode == "LEFT": shift_vec = -perp_relative 
                elif mode == "RIGHT": shift_vec = perp_relative 
                
                sorted_list = []
                for el in mep_elements:
                     mid_pt = (el.Location.Curve.GetEndPoint(0) + el.Location.Curve.GetEndPoint(1)) / 2
                     sort_val = mid_pt.DotProduct(shift_vec)
                     sorted_list.append({'elem': el, 'val': sort_val})
                
                sorted_list.sort(key=lambda x: x['val'], reverse=True)
                base_min_val = sorted_list[-1]['val']
                
                ref_pt1 = uidoc.Selection.PickObject(ObjectType.PointOnElement, "Click ĐIỂM 1 trên bề mặt ống/cấu kiện (Nhấn ESC hủy)")
                pt_global_1 = ref_pt1.GlobalPoint

                ref_pt2 = uidoc.Selection.PickObject(ObjectType.PointOnElement, "Click ĐIỂM 2 trên bề mặt ống/cấu kiện (Nhấn ESC hủy)")
                pt_global_2 = ref_pt2.GlobalPoint

                # GÓC 45 ĐỘ: Tan(22.5) = 0.41421356
                TAN_HALF_ANGLE = 0.41421356 

                t = Transaction(doc, "Offset Elements")
                fail_opt = t.GetFailureHandlingOptions()
                fail_opt.SetClearAfterRollback(True)
                t.SetFailureHandlingOptions(fail_opt)
                t.Start()

                for item in sorted_list:
                    try:
                        elem = item["elem"]
                        my_val = item["val"]
                        
                        curve = elem.Location.Curve
                        p_start = curve.GetEndPoint(0)
                        p_end = curve.GetEndPoint(1)
                        
                        neighbor_start_ref = get_neighbor_at_end(elem, p_start)
                        neighbor_end_ref = get_neighbor_at_end(elem, p_end)
                        
                        total_len = p_start.DistanceTo(p_end)
                        my_vec = (p_end - p_start).Normalize()

                        dist_from_base = abs(my_val - base_min_val)
                        extra_pull = dist_from_base * TAN_HALF_ANGLE
                        
                        raw_cut1_proj = curve.Project(pt_global_1).XYZPoint
                        raw_cut2_proj = curve.Project(pt_global_2).XYZPoint
                        
                        d_1 = p_start.DistanceTo(raw_cut1_proj)
                        d_2 = p_start.DistanceTo(raw_cut2_proj)
                        
                        if d_1 > d_2: d_1, d_2 = d_2, d_1
                            
                        dist_real_1 = d_1 - extra_pull
                        dist_real_2 = d_2 + extra_pull
                        
                        if dist_real_1 < 0.05: dist_real_1 = 0.05 
                        if dist_real_2 > total_len - 0.05: dist_real_2 = total_len - 0.05
                        
                        real_cut1 = p_start + (my_vec * dist_real_1)
                        real_cut2 = p_start + (my_vec * dist_real_2)
                        
                        # LOGIC HÌNH HỌC 45 ĐỘ: Tiến tới/Lùi lại 1 khoảng đúng bằng độ cao né
                        p_peak_1 = real_cut1 + (my_vec * off_ft) + (shift_vec * off_ft)
                        p_peak_2 = real_cut2 - (my_vec * off_ft) + (shift_vec * off_ft)
                        
                        if mode in ["LEFT", "RIGHT"]:
                            p_peak_1 = XYZ(p_peak_1.X, p_peak_1.Y, real_cut1.Z + (my_vec.Z * off_ft))
                            p_peak_2 = XYZ(p_peak_2.X, p_peak_2.Y, real_cut2.Z - (my_vec.Z * off_ft))
                        
                        pts = [p_start, real_cut1, p_peak_1, p_peak_2, real_cut2, p_end]
                        
                        try:
                            new_curve_e1 = Line.CreateBound(pts[0], pts[1])
                            elem.Location.Curve = new_curve_e1
                            e1 = elem 
                        except: continue 

                        e5 = create_new_element(pts[4], pts[5], elem)
                        if not e5: raise Exception("Lỗi tạo đuôi")

                        e2 = create_new_element(pts[1], pts[2], elem) 
                        e3 = create_new_element(pts[2], pts[3], elem) 
                        e4 = create_new_element(pts[3], pts[4], elem) 
                        
                        doc.Regenerate()
                        
                        fix_rotation(doc, e1, e2, pts[1], pts[1])
                        fix_rotation(doc, e1, e3, pts[1], pts[2])
                        fix_rotation(doc, e1, e4, pts[1], pts[3])
                        if e5: fix_rotation(doc, e1, e5, pts[1], pts[4])
                        
                        doc.Regenerate()
                        
                        if neighbor_start_ref:
                            c_head_start = get_connector(e1, pts[0])
                            nb_start_elem = neighbor_start_ref.Owner 
                            c_nb_start = get_connector(nb_start_elem, pts[0])
                            if c_head_start and c_nb_start:
                                try: 
                                    if not c_head_start.IsConnectedTo(c_nb_start): c_head_start.ConnectTo(c_nb_start)
                                except: pass

                        if e5 and neighbor_end_ref:
                            c_tail_end = get_connector(e5, pts[5])
                            nb_end_elem = neighbor_end_ref.Owner
                            c_nb_end = get_connector(nb_end_elem, pts[5])
                            if c_tail_end and c_nb_end:
                                try: 
                                    if not c_tail_end.IsConnectedTo(c_nb_end): c_tail_end.ConnectTo(c_nb_end)
                                except: pass
                        
                        internal_connections = [
                            (e1, e2, pts[1]),
                            (e2, e3, pts[2]),
                            (e3, e4, pts[3]),
                            (e4, e5, pts[4])
                        ]
                        
                        for el_a, el_b, pt_loc in internal_connections:
                            if el_a and el_b:
                                ca = get_connector(el_a, pt_loc)
                                cb = get_connector(el_b, pt_loc)
                                if ca and cb:
                                    try:
                                        ca.ConnectTo(cb)
                                        doc.Create.NewElbowFitting(ca, cb)
                                    except: pass

                    except Exception as ex:
                        pass 

                t.Commit()
                
            except Autodesk.Revit.Exceptions.OperationCanceledException:
                break 
            except Exception as e_loop:
                if 't' in locals() and t.GetStatus() == TransactionStatus.Started: t.RollBack()

        tg.Assimilate()

except Exception as e:
    pass # Im lặng, tàng hình 100%