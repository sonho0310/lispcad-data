# -*- coding: utf-8 -*-

import math
import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI as UI
import Autodesk.Revit.Exceptions as Extensions
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. CLASSES ---
class MEPElementFilter(ISelectionFilter):
    def AllowElement(self, element):
        cat = element.Category
        if cat and ("Duct" in cat.Name or "Pipe" in cat.Name or "Cable Tray" in cat.Name):
            if isinstance(element, DB.MEPCurve): return True
        return False
    def AllowReference(self, reference, position): return False

class WarningSwallower(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        if failures.Count == 0: return DB.FailureProcessingResult.Continue
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning: failuresAccessor.DeleteWarning(f)
            else: failuresAccessor.ResolveFailure(f); return DB.FailureProcessingResult.ProceedWithCommit
        return DB.FailureProcessingResult.Continue

# --- 2. UTILS ---
def copy_parameters(src, dest):
    """Sao chép thông số hệ thống và kích thước"""
    try:
        # System Type
        if hasattr(src, "MEPSystem") and src.MEPSystem:
            sys_id = src.MEPSystem.GetTypeId()
            if isinstance(dest, DB.Mechanical.Duct):
                dest.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).Set(sys_id)
            elif isinstance(dest, DB.Plumbing.Pipe):
                dest.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).Set(sys_id)
        
        # Size Parameters
        params = [
            DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM,
            DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
            DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM,
            DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM,
            DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM
        ]
        for p_id in params:
            p_src = src.get_Parameter(p_id)
            p_dest = dest.get_Parameter(p_id)
            if p_src and p_dest and p_src.HasValue:
                p_dest.Set(p_src.AsDouble())
    except: pass

def get_connector_at_point(element, point, tolerance=0.01):
    """Tìm connector tại vị trí cụ thể (đã tối ưu tolerance)"""
    try:
        connectors = element.ConnectorManager.Connectors if hasattr(element, "ConnectorManager") \
                     else element.GetConnectorManager(None).Connectors
        for c in connectors:
            if c.Origin.DistanceTo(point) < tolerance: return c
    except: pass
    return None

def get_direction_90_smart(vec_flow, origin, click_point):
    """Tính hướng nhánh vuông góc dựa trên vị trí click"""
    vec_click = (click_point - origin).Normalize()
    directions = [DB.XYZ.BasisX, -DB.XYZ.BasisX, DB.XYZ.BasisY, -DB.XYZ.BasisY, DB.XYZ.BasisZ, -DB.XYZ.BasisZ]
    best_dir = DB.XYZ.BasisZ
    max_dot = -1.0 
    for d in directions:
        if abs(vec_flow.DotProduct(d)) > 0.9: continue 
        val = vec_click.DotProduct(d)
        if val > max_dot:
            max_dot = val
            best_dir = d
    return best_dir

def create_branch(ref_elem, p_start, p_end):
    """Tạo ống/máng nhánh tương tự mẫu"""
    lvl_id = ref_elem.ReferenceLevel.Id
    new_el = None
    if isinstance(ref_elem, DB.Mechanical.Duct):
        new_el = DB.Mechanical.Duct.Create(doc, ref_elem.MEPSystem.GetTypeId(), ref_elem.GetTypeId(), lvl_id, p_start, p_end)
    elif isinstance(ref_elem, DB.Plumbing.Pipe):
        new_el = DB.Plumbing.Pipe.Create(doc, ref_elem.MEPSystem.GetTypeId(), ref_elem.GetTypeId(), lvl_id, p_start, p_end)
    elif isinstance(ref_elem, DB.Electrical.CableTray):
        new_el = DB.Electrical.CableTray.Create(doc, ref_elem.GetTypeId(), p_start, p_end, lvl_id)
    
    if new_el: copy_parameters(ref_elem, new_el)
    return new_el

# --- 3. CORE LOGIC ---
def process_force_tee(element, click_point):
    loc_curve = element.Location.Curve
    p_start_orig = loc_curve.GetEndPoint(0)
    p_end_orig = loc_curve.GetEndPoint(1)
    p_split = loc_curve.Project(click_point).XYZPoint
    
    # Tránh split quá sát đầu mút gây lỗi Revit
    if p_split.DistanceTo(p_start_orig) < 0.1 or p_split.DistanceTo(p_end_orig) < 0.1: return

    # A. XỬ LÝ SPLIT (GIỮ KẾT NỐI)
    new_main_id = None
    if isinstance(element, DB.Mechanical.Duct):
        new_main_id = DB.Mechanical.MechanicalUtils.BreakCurve(doc, element.Id, p_split)
    elif isinstance(element, DB.Plumbing.Pipe):
        new_main_id = DB.Plumbing.PlumbingUtils.BreakCurve(doc, element.Id, p_split)
    elif isinstance(element, DB.Electrical.CableTray):
        # Cable Tray không có BreakCurve, phải làm tay nhưng vẫn cứu connector
        # Lấy connector cũ ở đầu End
        conn_end_old = get_connector_at_point(element, p_end_orig)
        refs = []
        if conn_end_old and conn_end_old.IsConnected:
            for c in conn_end_old.AllRefs:
                if c.Owner.Id != element.Id: refs.append(c)

        # Rút ngắn ống cũ và tạo ống mới
        element.Location.Curve = DB.Line.CreateBound(p_start_orig, p_split)
        main_2 = create_branch(element, p_split, p_end_orig)
        new_main_id = main_2.Id
        
        # Kết nối lại Fitting cũ vào ống mới
        if refs:
            conn_end_new = get_connector_at_point(main_2, p_end_orig)
            for r in refs: conn_end_new.ConnectTo(r)

    if not new_main_id: return
    element_2 = doc.GetElement(new_main_id)

    # B. TẠO NHÁNH (BRANCH)
    vec_flow = (p_end_orig - p_start_orig).Normalize()
    dir_branch = get_direction_90_smart(vec_flow, p_split, click_point)
    
    # Độ dài nhánh mặc định = 3x Size
    size_val = 1.0
    p_size = element.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM) or \
             element.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
    if p_size: size_val = p_size.AsDouble() * 3.0
    
    p_branch_end = p_split + (dir_branch * size_val)
    branch_el = create_branch(element, p_split, p_branch_end)
    
    doc.Regenerate()

    # C. TẠO TEE FITTING
    c1 = get_connector_at_point(element, p_split)
    c2 = get_connector_at_point(element_2, p_split)
    c3 = get_connector_at_point(branch_el, p_split)
    
    if c1 and c2 and c3:
        try:
            doc.Create.NewTeeFitting(c1, c2, c3)
        except: pass

# --- 4. RUN ---
def run_script():
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, MEPElementFilter(), "Chọn ống để tạo TEE (ESC để thoát)")
            el = doc.GetElement(ref)
            pt = ref.GlobalPoint 

            with DB.Transaction(doc, "Sơn_82KT: Force Tee Smart") as t:
                opt = t.GetFailureHandlingOptions()
                opt.SetFailuresPreprocessor(WarningSwallower())
                t.SetFailureHandlingOptions(opt)
                t.Start()
                process_force_tee(el, pt)
                t.Commit()
        except Extensions.OperationCanceledException: break
        except Exception: break

if __name__ == "__main__":
    run_script()