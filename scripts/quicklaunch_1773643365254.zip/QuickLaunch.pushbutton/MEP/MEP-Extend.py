# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe, PipeType, PipingSystemType
from Autodesk.Revit.DB.Mechanical import Duct, DuctType, MechanicalSystemType
from Autodesk.Revit.DB.Electrical import CableTray, CableTrayType, Conduit, ConduitType
from Autodesk.Revit.UI.Selection import ISelectionFilter, ObjectType
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit

# --- CẤU HÌNH ---
EXTEND_LENGTH_MM = 500
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. FILTER ---
class MEPEntityFilter(ISelectionFilter):
    def AllowElement(self, e):
        if not e.Category: return False
        
        # Danh sách các Category cho phép chọn
        cats = [
            BuiltInCategory.OST_PipeFitting, 
            BuiltInCategory.OST_DuctFitting,
            BuiltInCategory.OST_CableTrayFitting, 
            BuiltInCategory.OST_ConduitFitting,
            BuiltInCategory.OST_MechanicalEquipment, 
            BuiltInCategory.OST_PlumbingFixtures,
            BuiltInCategory.OST_Sprinklers, 
            BuiltInCategory.OST_LightingFixtures,
            BuiltInCategory.OST_ElectricalEquipment,
            # --- MỚI BỔ SUNG ---
            BuiltInCategory.OST_DuctAccessory,   # Duct Accessory (Van gió, Damper...)
            BuiltInCategory.OST_DuctTerminal,    # Air Terminal (Miệng gió)
            BuiltInCategory.OST_PipeAccessory,   # Pipe Accessory (Van nước, Đồng hồ...)
        ]
        return e.Category.Id.IntegerValue in [int(c) for c in cats]
    
    def AllowReference(self, r, p): return True

# --- 2. LOGIC TÌM SYSTEM (CHẾ ĐỘ "BẤT CHẤP") ---
def get_most_recent_system_in_view(doc, domain):
    """Lấy System Type của ống vẽ gần nhất trong view (Bất kể loại gì)"""
    target_class = Pipe if domain == Domain.DomainPiping else Duct if domain == Domain.DomainHvac else None
    if not target_class: return None

    # Lấy 10 ống mới nhất
    collector = FilteredElementCollector(doc, doc.ActiveView.Id).OfClass(target_class).ToElements()
    if not collector: return None
    
    sorted_elements = sorted(collector, key=lambda x: x.Id.IntegerValue, reverse=True)[:5]

    for elem in sorted_elements:
        sys_param = elem.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if domain == Domain.DomainPiping else BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
        if sys_param and sys_param.HasValue:
            sys_id = sys_param.AsElementId()
            if sys_id != ElementId.InvalidElementId:
                return sys_id # Trả về ngay cái tìm thấy đầu tiên
    return None

def get_fallback_system_type(doc, domain):
    """Lấy đại System Type đầu tiên trong dự án"""
    cls = PipingSystemType if domain == Domain.DomainPiping else MechanicalSystemType if domain == Domain.DomainHvac else None
    if not cls: return ElementId.InvalidElementId
    res = FilteredElementCollector(doc).OfClass(cls).FirstElementId()
    return res

def get_system_type_smart(doc, element, target_conn):
    domain = target_conn.Domain
    
    # 1. THỪA KẾ TỪ HÀNG XÓM (Nếu fitting đã nối 1 đầu)
    cm = element.MEPModel.ConnectorManager if hasattr(element, "MEPModel") and element.MEPModel else None
    if not cm and hasattr(element, "ConnectorManager"): cm = element.ConnectorManager
    
    if cm:
        for c in cm.Connectors:
            if c.Id != target_conn.Id and c.Domain == domain and c.IsConnected:
                for ref in c.AllRefs:
                    neighbor = ref.Owner
                    if isinstance(neighbor, (Pipe, Duct)):
                        p_name = BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if domain == Domain.DomainPiping else BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
                        sys_param = neighbor.get_Parameter(p_name)
                        if sys_param and sys_param.AsElementId().IntegerValue != -1:
                            return sys_param.AsElementId()

    # 2. THỪA KẾ TỪ PARAMETER (Nếu fitting đã set param)
    p_name_self = BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if domain == Domain.DomainPiping else BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
    sys_param_self = element.get_Parameter(p_name_self)
    if sys_param_self and sys_param_self.AsElementId().IntegerValue != -1:
        return sys_param_self.AsElementId()

    # 3. KIỂM TRA PHÂN LOẠI (Classification)
    try:
        target_class_enum = target_conn.GetMEPSystemClassification()
        # Nếu Classification là "Fitting" hoặc "Global", ta KHÔNG THỂ tìm system trùng tên được
        is_generic = (str(target_class_enum) == "Fitting" or str(target_class_enum) == "Global")
        
        if not is_generic:
            cls = PipingSystemType if domain == Domain.DomainPiping else MechanicalSystemType if domain == Domain.DomainHvac else None
            possible_types = FilteredElementCollector(doc).OfClass(cls).ToElements()
            for st in possible_types:
                if st.SystemClassification == target_class_enum:
                    return st.Id
    except:
        pass

    # 4. LỊCH SỬ (HISTORY) - Quan trọng nhất cho Fitting mới
    recent_id = get_most_recent_system_in_view(doc, domain)
    if recent_id: return recent_id

    # 5. ĐƯỜNG CÙNG (FALLBACK) - Lấy đại cái đầu tiên
    return get_fallback_system_type(doc, domain)

# --- 3. LOGIC TÌM PIPE TYPE (Cũng Fallback mạnh mẽ) ---
def get_routing_preference_manager(element_type):
    if hasattr(element_type, "RoutingPreferenceManager"): return element_type.RoutingPreferenceManager
    return None

def find_curve_type_by_routing(doc, family_symbol, domain, shape):
    # Logic tìm routing cũ (đã tốt)
    if domain == Domain.DomainPiping:
        all_types = FilteredElementCollector(doc).OfClass(PipeType).ToElements()
        for p_type in all_types:
            rpm = get_routing_preference_manager(p_type)
            if not rpm: continue
            for group in [RoutingPreferenceRuleGroupType.Elbows, RoutingPreferenceRuleGroupType.Junctions, RoutingPreferenceRuleGroupType.Transitions]:
                for i in range(rpm.GetNumberOfRules(group)):
                    try:
                        if rpm.GetRule(group, i).MEPPartId == family_symbol.Id: return p_type.Id
                    except: continue
    return ElementId.InvalidElementId

def get_best_curve_type(doc, element, connector):
    domain = connector.Domain
    shape = getattr(connector, "Shape", ConnectorProfileType.Round)
    
    # 1. Thử Routing Preference
    if isinstance(element, FamilyInstance):
        matched_id = find_curve_type_by_routing(doc, element.Symbol, domain, shape)
        if matched_id != ElementId.InvalidElementId: return matched_id

    # 2. Fallback theo Shape
    if domain == Domain.DomainHvac:
        dct_types = FilteredElementCollector(doc).OfClass(DuctType).ToElements()
        for dt in dct_types:
            fam_name = dt.FamilyName
            if shape == ConnectorProfileType.Rectangular and "Rectangular" in fam_name: return dt.Id
            if shape == ConnectorProfileType.Round and "Round" in fam_name: return dt.Id
        # Fallback cuối cùng cho Duct nếu không khớp tên
        if dct_types: return dct_types[0].Id
            
    elif domain == Domain.DomainPiping:
        return FilteredElementCollector(doc).OfClass(PipeType).FirstElementId()
        
    elif domain == Domain.DomainElectrical:
        return FilteredElementCollector(doc).OfClass(ConduitType).FirstElementId()

    return ElementId.InvalidElementId

# --- 4. MAIN ---
def process_element(element):
    cm = None
    if hasattr(element, "MEPModel") and element.MEPModel: cm = element.MEPModel.ConnectorManager
    elif hasattr(element, "ConnectorManager"): cm = element.ConnectorManager
    if not cm: return

    len_ft = EXTEND_LENGTH_MM / 304.8
    level_id = element.LevelId
    if level_id == ElementId.InvalidElementId and doc.ActiveView.GenLevel:
        level_id = doc.ActiveView.GenLevel.Id

    count = 0
    for conn in cm.Connectors:
        if conn.ConnectorType == ConnectorType.Logical or conn.IsConnected: continue

        try:
            shape = conn.Shape
            domain = conn.Domain
            origin = conn.Origin
            
            # --- QUYẾT ĐỊNH QUAN TRỌNG ---
            sys_id = get_system_type_smart(doc, element, conn)
            type_id = get_best_curve_type(doc, element, conn)
            
            if sys_id == ElementId.InvalidElementId or type_id == ElementId.InvalidElementId: 
                continue

            direction = conn.CoordinateSystem.BasisZ
            end_pt = origin + (direction * len_ft)
            new_el = None

            if domain == Domain.DomainPiping:
                new_el = Pipe.Create(doc, sys_id, type_id, level_id, origin, end_pt)
                new_el.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(conn.Radius * 2)
            elif domain == Domain.DomainHvac:
                new_el = Duct.Create(doc, sys_id, type_id, level_id, origin, end_pt)
                if shape == ConnectorProfileType.Round:
                    new_el.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM).Set(conn.Radius * 2)
                else:
                    new_el.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(conn.Width)
                    new_el.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(conn.Height)
            elif domain == Domain.DomainElectrical:
                new_el = Conduit.Create(doc, type_id, origin, end_pt, level_id)
                new_el.get_Parameter(BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM).Set(conn.Radius * 2)

            if new_el:
                doc.Regenerate()
                # Connect Back
                cm_new = new_el.ConnectorManager if hasattr(new_el, "ConnectorManager") else new_el.MEPModel.ConnectorManager
                for c in cm_new.Connectors:
                    if c.Origin.DistanceTo(origin) < 0.01:
                        conn.ConnectTo(c)
                        count += 1
                        break
        except Exception:
            pass
    return count

def main():
    mep_filter = MEPEntityFilter()
    while True:
        try:
            uidoc.Application.Application.WriteJournalComment("Ready...", False)
            ref = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Click Element (ESC để thoát)")
            elem = doc.GetElement(ref)
            with revit.Transaction("Auto Pipe", doc):
                process_element(elem)
        except OperationCanceledException: break
        except Exception: continue

if __name__ == '__main__':
    main()