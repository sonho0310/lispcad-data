# -*- coding: utf-8 -*-
import clr
import math

# --- IMPORT ---
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Electrical import CableTray
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. CÁC HÀM HỖ TRỢ ---

class MEPFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category is None: return False
        cat_id = elem.Category.Id.IntegerValue
        if cat_id == int(BuiltInCategory.OST_PipeCurves) or \
           cat_id == int(BuiltInCategory.OST_DuctCurves) or \
           cat_id == int(BuiltInCategory.OST_CableTray):
            return True
        return False
    def AllowReference(self, reference, position):
        return False

def get_connectors_safe(element):
    if isinstance(element, (Pipe, Duct, CableTray)):
        return element.ConnectorManager.Connectors
    elif isinstance(element, FamilyInstance):
        if element.MEPModel:
            return element.MEPModel.ConnectorManager.Connectors
    return []

def get_connector_closest_to(element, point):
    connectors = get_connectors_safe(element)
    if not connectors: return None
    closest = None
    min_dist = float('inf')
    for con in connectors:
        dist = con.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist = dist
            closest = con
    return closest

def project_point_on_line(point, line_origin, line_dir):
    v = point - line_origin
    dist = v.DotProduct(line_dir)
    return line_origin + line_dir * dist

def calculate_exact_90_point(p1_point, p2_curve):
    p2_start = p2_curve.GetEndPoint(0)
    p2_end = p2_curve.GetEndPoint(1)
    v2_dir = (p2_end - p2_start).Normalize()
    return project_point_on_line(p1_point, p2_start, v2_dir)

def apply_size_and_system(source_elem, target_elem):
    try:
        # 1. System
        sys_param = None
        if isinstance(source_elem, Pipe):
            sys_param = BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM
        elif isinstance(source_elem, Duct):
            sys_param = BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
        
        if sys_param:
            sys_p = source_elem.get_Parameter(sys_param)
            if sys_p:
                target_elem.get_Parameter(sys_param).Set(sys_p.AsElementId())

        # 2. Size
        if isinstance(source_elem, Pipe):
            dia_src = source_elem.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
            if dia_src:
                target_elem.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_src.AsDouble())
        
        elif isinstance(source_elem, Duct):
            dia_src = source_elem.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
            if dia_src and dia_src.HasValue:
                target_elem.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM).Set(dia_src.AsDouble())
            else:
                w_src = source_elem.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
                h_src = source_elem.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
                if w_src and h_src:
                    target_elem.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(w_src.AsDouble())
                    target_elem.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(h_src.AsDouble())
        
        elif isinstance(source_elem, CableTray):
            w_src = source_elem.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM)
            h_src = source_elem.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM)
            if w_src and h_src:
                target_elem.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(w_src.AsDouble())
                target_elem.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(h_src.AsDouble())
    except Exception as e:
        print("Warning (Size): " + str(e))

def align_vertical_element(doc, elem1, mid_elem, p1_root, p2_target):
    if isinstance(elem1, Pipe): return
    if isinstance(elem1, Duct):
        dia_param = elem1.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
        if dia_param and dia_param.HasValue: return 

    c1_conn = get_connector_closest_to(elem1, p1_root)
    mid_conn = get_connector_closest_to(mid_elem, p1_root)

    if not c1_conn or not mid_conn: return

    v1_x = c1_conn.CoordinateSystem.BasisX
    v1_x = XYZ(v1_x.X, v1_x.Y, 0)
    
    if v1_x.GetLength() < 0.01:
        v1_x = c1_conn.CoordinateSystem.BasisY
        v1_x = XYZ(v1_x.X, v1_x.Y, 0)

    v_mid_x = mid_conn.CoordinateSystem.BasisX
    v_mid_x = XYZ(v_mid_x.X, v_mid_x.Y, 0)

    if v1_x.GetLength() > 0.01 and v_mid_x.GetLength() > 0.01:
        v1_x = v1_x.Normalize()
        v_mid_x = v_mid_x.Normalize()

        angle = v_mid_x.AngleTo(v1_x)
        
        cross_z = v_mid_x.X * v1_x.Y - v_mid_x.Y * v1_x.X
        if cross_z < 0:
            angle = -angle

        if abs(angle) > 0.01:
            axis = Line.CreateBound(p1_root, p2_target)
            ElementTransformUtils.RotateElement(doc, mid_elem.Id, axis, angle)

# --- 2. MAIN ---

def run():
    # Mở TransactionGroup bọc ngoài vòng lặp để gom Undo
    tg = TransactionGroup(doc, "Auto Connect MEP 90 (Loop)")
    tg.Start()
    
    try:
        mep_filter = MEPFilter()
        
        while True:
            try:
                # Thêm thông báo nhấn ESC để thoát
                ref1 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ống GỐC (Nhấn ESC để ngưng lệnh)")
                ref2 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ống ĐÍCH (Nhấn ESC để ngưng lệnh)")
            except OperationCanceledException:
                # Người dùng bấm ESC -> Thoát vòng lặp an toàn
                break 

            elem1 = doc.GetElement(ref1)
            elem2 = doc.GetElement(ref2)

            if elem1.Category.Id != elem2.Category.Id:
                print("Lỗi: Phải chọn cùng loại đối tượng. Vui lòng chọn lại.")
                continue # Bỏ qua cặp này, quay lại vòng lặp chọn lại

            is_pipe = isinstance(elem1, Pipe)
            is_duct = isinstance(elem1, Duct)
            is_cabletray = isinstance(elem1, CableTray)
            
            c1 = elem1.Location.Curve
            c2 = elem2.Location.Curve
            
            p1_ends = [c1.GetEndPoint(0), c1.GetEndPoint(1)]
            mid_p2 = (c2.GetEndPoint(0) + c2.GetEndPoint(1)) / 2
            p1_root = p1_ends[0] if p1_ends[0].DistanceTo(mid_p2) < p1_ends[1].DistanceTo(mid_p2) else p1_ends[1]

            p2_target = calculate_exact_90_point(p1_root, c2)
            
            # Mở Transaction con cho từng cặp
            t = Transaction(doc, "Modify Geometry Element")
            t.Start()
            
            try:
                # 1. Kéo ống đích
                p2_start = c2.GetEndPoint(0)
                p2_end = c2.GetEndPoint(1)
                
                if p2_start.DistanceTo(p2_target) > p2_end.DistanceTo(p2_target):
                    new_c2 = Line.CreateBound(p2_start, p2_target)
                else:
                    new_c2 = Line.CreateBound(p2_target, p2_end)
                
                elem2.Location.Curve = new_c2
                
                # 2. Tạo ống đứng (Bridge)
                if elem1.ReferenceLevel: lvl_id = elem1.ReferenceLevel.Id
                else: lvl_id = doc.ActiveView.GenLevel.Id
                
                type_id = elem1.GetTypeId()
                mid_elem = None

                if is_pipe:
                    sys_id = elem1.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
                    mid_elem_id = Pipe.Create(doc, sys_id, type_id, lvl_id, p1_root, p2_target)
                    if isinstance(mid_elem_id, ElementId): mid_elem = doc.GetElement(mid_elem_id)
                    else: mid_elem = mid_elem_id
                elif is_duct:
                    sys_id = elem1.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).AsElementId()
                    mid_elem = Duct.Create(doc, sys_id, type_id, lvl_id, p1_root, p2_target)
                elif is_cabletray:
                    mid_elem = CableTray.Create(doc, type_id, p1_root, p2_target, lvl_id)

                apply_size_and_system(elem1, mid_elem)
                doc.Regenerate() 

                align_vertical_element(doc, elem1, mid_elem, p1_root, p2_target)
                doc.Regenerate()

                # 3. Kết nối Fitting
                c1_conn = get_connector_closest_to(elem1, p1_root)
                mid_conn_1 = get_connector_closest_to(mid_elem, p1_root)
                if c1_conn and mid_conn_1:
                    try: doc.Create.NewElbowFitting(c1_conn, mid_conn_1)
                    except: pass

                c2_conn = get_connector_closest_to(elem2, p2_target)
                mid_conn_2 = get_connector_closest_to(mid_elem, p2_target)
                if c2_conn and mid_conn_2:
                    try: doc.Create.NewElbowFitting(c2_conn, mid_conn_2)
                    except: pass

                t.Commit()

            except Exception as e_geo:
                if t.GetStatus() == TransactionStatus.Started: t.RollBack()
                print("Lỗi tạo hình học cặp này: " + str(e_geo))

    except Exception as e:
        if "OperationCanceled" not in str(e):
            TaskDialog.Show("Critical Error", str(e))
    finally:
        # Luôn đảm bảo đóng TransactionGroup dù có lỗi hay bấm ESC
        if tg.GetStatus() == TransactionStatus.Started:
            tg.Assimilate()

if __name__ == '__main__':
    run()