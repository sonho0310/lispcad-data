# -*- coding: utf-8 -*-
"""
Title: Ultra Smart MEP (Extend Straight + Turn 45/90 + Auto Slope)
Description: Tự động nhận diện đầu ống, kéo dài nếu đi thẳng, nối cút nếu rẽ góc.
Author: Ho Phi Anh Son
"""

import math
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Electrical import CableTray

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- HELPER FUNCTIONS ---

def get_selected_mep():
    selection = uidoc.Selection.GetElementIds()
    selected_elems = []
    if selection.Count > 0:
        for eid in selection:
            elem = doc.GetElement(eid)
            if isinstance(elem, (Pipe, Duct, CableTray)):
                selected_elems.append(elem)
    
    if not selected_elems:
        try:
            class MEPSelectionFilter(ISelectionFilter):
                def AllowElement(self, e): return isinstance(e, (Pipe, Duct, CableTray))
                def AllowReference(self, r, p): return False
            
            refs = uidoc.Selection.PickObjects(ObjectType.Element, MEPSelectionFilter(), "Chọn các ống để vẽ tiếp")
            for ref in refs:
                selected_elems.append(doc.GetElement(ref))
        except:
            return []
    return selected_elems

def get_connectors(element):
    """Trả về list connector của element"""
    if not element or not element.ConnectorManager: return []
    return [c for c in element.ConnectorManager.Connectors]

def update_pipe_curve_safely(doc, elem, new_curve, fixed_pt):
    connected_refs = []
    try:
        manager = getattr(elem, "ConnectorManager", None)
        if manager:
            for c in manager.Connectors:
                if c.Origin.DistanceTo(fixed_pt) < 0.01:
                    if c.IsConnected:
                        for ref in c.AllRefs:
                            if ref.Owner.Id != elem.Id and str(ref.ConnectorType) != "Logical":
                                connected_refs.append(ref)
                    break
    except:
        pass
        
    elem.Location.Curve = new_curve
    doc.Regenerate()
    
    try:
        if connected_refs:
            manager = getattr(elem, "ConnectorManager", None)
            if manager:
                for c in manager.Connectors:
                    if c.Origin.DistanceTo(fixed_pt) < 0.05:
                        for ref in connected_refs:
                            try:
                                if not c.IsConnectedTo(ref):
                                    c.ConnectTo(ref)
                            except:
                                pass
                        break
    except:
        pass

class SmartRunner:
    def __init__(self, element):
        self.current_elem = element
        self.active_con = None # Connector đang chờ nối tiếp
        self.fixed_pt = None   # Điểm neo (đầu bên kia của ống)
        self.slope_ratio = 0.0
        self.valid = True

    def auto_detect_start(self, first_target_pt):
        """
        Logic tự động: 
        1. Lấy tất cả connector.
        2. Chọn cái nào đang HỞ (Unconnected).
        3. Nếu cả 2 đều hở, chọn cái nào HƯỚNG về phía chuột (Góc nhọn).
        """
        connectors = get_connectors(self.current_elem)
        candidates = []
        
        # Lọc connector hở
        open_cons = [c for c in connectors if not c.IsConnected]
        
        # Nếu không có cái nào hở (ống đã nối 2 đầu), ta buộc phải dừng hoặc báo lỗi
        # Nhưng để linh hoạt, nếu kín hết thì ta dùng logic "Gần chuột nhất" (fallback)
        pool = open_cons if open_cons else connectors
        
        best_con = None
        max_score = -999.0
        
        for con in pool:
            origin = con.Origin
            # Vector hướng ra của connector
            try:
                con_dir = con.CoordinateSystem.BasisZ
            except:
                continue # Bỏ qua connector lạ (như connector ảo)

            # Vector từ connector tới chuột
            to_target = (first_target_pt - origin).Normalize()
            
            # Tính Dot Product: Càng lớn (gần 1) tức là chuột đang ở phía trước mặt connector
            score = con_dir.DotProduct(to_target)
            
            if score > max_score:
                max_score = score
                best_con = con
        
        if best_con:
            self.active_con = best_con
            self.update_geometry_info()
        else:
            self.valid = False

    def update_geometry_info(self):
        """Cập nhật lại thông tin hình học sau mỗi bước vẽ"""
        # 1. Xác định điểm neo (Fixed Point) là đầu bên kia của ống
        curve = self.current_elem.Location.Curve
        p0 = curve.GetEndPoint(0)
        p1 = curve.GetEndPoint(1)
        
        # Connector đang active ở đâu thì Fixed Point ở đầu kia
        if self.active_con.Origin.DistanceTo(p0) < 0.01:
            self.fixed_pt = p1
            self.fixed_is_p0 = False
        else:
            self.fixed_pt = p0
            self.fixed_is_p0 = True
            
        # 2. Tính độ dốc (Slope Ratio)
        basis_z = self.active_con.CoordinateSystem.BasisZ
        run = math.sqrt(basis_z.X**2 + basis_z.Y**2)
        if run < 0.0001: 
            self.slope_ratio = 0.0
        else:
            self.slope_ratio = basis_z.Z / run

    def find_connector_at(self, element, point):
        """Helper tìm connector tại tọa độ chính xác"""
        if not element or not element.ConnectorManager: return None
        min_dist = float('inf')
        target = None
        for c in element.ConnectorManager.Connectors:
            d = c.Origin.DistanceTo(point)
            if d < min_dist:
                min_dist = d
                target = c
        return target

def execute_group_step(runners, target_pt):
    if not runners: return False
    
    # Leader là ống đầu tiên
    leader = runners[0]
    origin_L = leader.active_con.Origin
    con_dir_L = leader.active_con.CoordinateSystem.BasisZ
    
    dir_flat_L = XYZ(con_dir_L.X, con_dir_L.Y, 0).Normalize()
    up = XYZ.BasisZ
    right_L = dir_flat_L.CrossProduct(up)
    
    v_mouse = target_pt - origin_L
    v_mouse_flat = XYZ(v_mouse.X, v_mouse.Y, 0).Normalize()
    
    # Tính hướng nhóm (Leader Quyết Định)
    candidates = []
    candidates.append((dir_flat_L, "STRAIGHT")) 
    candidates.append((right_L, "TURN"))
    candidates.append((right_L.Negate(), "TURN"))
    candidates.append(((dir_flat_L + right_L).Normalize(), "TURN"))
    candidates.append(((dir_flat_L - right_L).Normalize(), "TURN"))
    
    best_vec = dir_flat_L
    action_type = "STRAIGHT"
    max_dot = -2.0
    for vec, type_name in candidates:
        dot = v_mouse_flat.DotProduct(vec)
        if dot > max_dot:
            max_dot = dot
            best_vec = vec
            action_type = type_name
            
    # Tính điểm cuối mặt bằng của Leader
    v_mouse_raw = target_pt - origin_L
    v_mouse_raw_flat = XYZ(v_mouse_raw.X, v_mouse_raw.Y, 0)
    length = v_mouse_raw_flat.DotProduct(best_vec)
    if length < 0.05: length = 0.05
    
    dz_L = length * leader.slope_ratio
    final_L = XYZ(origin_L.X + best_vec.X * length, 
                  origin_L.Y + best_vec.Y * length, 
                  origin_L.Z + dz_L)

    # Hệ tọa độ mới sau khi Leader di chuyển (dùng để áp offset cho follower)
    new_dir_flat = best_vec
    new_right = new_dir_flat.CrossProduct(up)
    
    # Bắt đầu xử lý từng ống trong nhóm
    for runner in runners:
        if not runner.valid: continue
        
        origin_R = runner.active_con.Origin
        vec_RL = origin_R - origin_L
        offset_right = vec_RL.DotProduct(right_L)
        
        # --- BƯỚC 3: THỰC THI (EXTEND HOẶC CREATE NEW) ---
        if action_type == "STRAIGHT":
            # --- TÍNH TOÁN OFFSET CHO FOLLOWER SO VỚI LEADER ---
            # ÉP FLAT MẶT THEO LEADER nhưng CỐ ĐỊNH PHƯƠNG ỐNG HIỆN TẠI (orig_dir)
            orig_curve = runner.current_elem.Location.Curve
            if isinstance(orig_curve, Line):
                orig_dir = orig_curve.Direction
                denom = orig_dir.DotProduct(best_vec)
                
                if abs(denom) > 0.0001:
                    # Giao điểm của tia "runner.fixed_pt + w * orig_dir" với mặt phẳng vuông góc best_vec tại final_L
                    w = (final_L - runner.fixed_pt).DotProduct(best_vec) / denom
                    final_R_3d = runner.fixed_pt + orig_dir.Multiply(w)
                else:
                    final_R_3d = final_L + new_right.Multiply(offset_right) + XYZ(0, 0, vec_RL.Z)
            else:
                final_R_3d = final_L + new_right.Multiply(offset_right) + XYZ(0, 0, vec_RL.Z)
            
            # >> CASE 1: ĐI THẲNG -> EXTEND ỐNG CŨ <<
            try:
                if final_R_3d.DistanceTo(origin_R) > 0.005:
                    if runner.fixed_is_p0:
                        new_curve = Line.CreateBound(runner.fixed_pt, final_R_3d)
                    else:
                        new_curve = Line.CreateBound(final_R_3d, runner.fixed_pt)
                    update_pipe_curve_safely(doc, runner.current_elem, new_curve, runner.fixed_pt)
                else:
                    final_R_3d = origin_R
                runner.active_con = runner.find_connector_at(runner.current_elem, final_R_3d)
            except Exception as e:
                import traceback
                TaskDialog.Show("Error Straight Follower", str(e) + "\n" + traceback.format_exc())
                
        else:
            # === RẼ GÓC ===
            # Tính hướng cũ dựa trên ĐIỂM ĐẦU CUỐI để không bị lệch trục làm gãy co (disconnect)
            vec_old_3d = origin_R - runner.fixed_pt
            d_flat_old = math.sqrt(vec_old_3d.X**2 + vec_old_3d.Y**2)
            
            if d_flat_old > 0.0001:
                v1_flat = XYZ(vec_old_3d.X / d_flat_old, vec_old_3d.Y / d_flat_old, 0)
                actual_slope = vec_old_3d.Z / d_flat_old
            else:
                con_dir = runner.active_con.CoordinateSystem.BasisZ
                v1_flat = XYZ(con_dir.X, con_dir.Y, 0).Normalize()
                actual_slope = runner.slope_ratio
            
            # Quỹ đạo mới của Follower sẽ là mặt phẳng song song quỹ đạo Leader
            pt_on_new_path_XY = final_L + new_right.Multiply(offset_right)
            
            p1 = runner.fixed_pt
            cross = v1_flat.X * best_vec.Y - v1_flat.Y * best_vec.X
            
            if abs(cross) < 0.0001: 
                # 2 ống song song
                P_turn = origin_R
            else:
                dp_XY = XYZ(pt_on_new_path_XY.X - p1.X, pt_on_new_path_XY.Y - p1.Y, 0)
                t = (dp_XY.X * best_vec.Y - dp_XY.Y * best_vec.X) / cross
                # Điểm P_turn luôn nằm trên tia chuẩn từ fixed_pt
                P_turn = XYZ(p1.X + t * v1_flat.X, p1.Y + t * v1_flat.Y, p1.Z + t * actual_slope)
            
            # GỌI LÀ MẶC KỆ SO LE: Ép luôn P_end phẳng mặt với Leader tại cuối khúc cua!
            P_end_XY = pt_on_new_path_XY
            
            L_new = (P_end_XY.X - P_turn.X)*best_vec.X + (P_end_XY.Y - P_turn.Y)*best_vec.Y
            if L_new < 0.05: 
                L_new = 0.05
                P_end_XY = XYZ(P_turn.X + best_vec.X * L_new, P_turn.Y + best_vec.Y * L_new, 0)
                
            new_dz = L_new * runner.slope_ratio
            P_end = XYZ(P_end_XY.X, P_end_XY.Y, P_turn.Z + new_dz)
            
            try:
                # 1. Cập nhật ống cũ chuẩn chỉnh theo quỹ đạo, tránh bung fitting
                if P_turn.DistanceTo(origin_R) > 0.005:
                    if runner.fixed_is_p0:
                        old_curve = Line.CreateBound(runner.fixed_pt, P_turn)
                    else:
                        old_curve = Line.CreateBound(P_turn, runner.fixed_pt)
                    update_pipe_curve_safely(doc, runner.current_elem, old_curve, runner.fixed_pt)
                else:
                    P_turn = origin_R # Nhỏ hơn sai số thì giữ nguyên để tránh disconnect co cũ
                
                runner.active_con = runner.find_connector_at(runner.current_elem, P_turn)
                
                # 2. Tạo đoạn rẽ
                new_ids = ElementTransformUtils.CopyElement(doc, runner.current_elem.Id, XYZ.Zero)
                new_elem = doc.GetElement(new_ids[0])
                
                new_curve = Line.CreateBound(P_turn, P_end)
                new_elem.Location.Curve = new_curve
                doc.Regenerate()
                
                # 3. Nối Elbow
                con_new_start = runner.find_connector_at(new_elem, P_turn)
                try:
                    doc.Create.NewElbowFitting(runner.active_con, con_new_start)
                except:
                    pass
                
                runner.current_elem = new_elem
                runner.active_con = runner.find_connector_at(new_elem, P_end)
                runner.update_geometry_info()
            except Exception as e:
                import traceback
                TaskDialog.Show("Error Turn Follower", str(e) + "\n" + traceback.format_exc())
                
    return True

# --- MAIN LOOP ---

try:
    elems = get_selected_mep()
    
    if elems:
        runners = [SmartRunner(elem) for elem in elems]
        
        is_first_click = True
        
        while True:
            try:
                if is_first_click:
                    msg = "Click điểm đích đầu tiên (Tự nhận diện đầu ống)"
                else:
                    msg = "Pick tiếp... (Thẳng=Extend, Góc=New)"
                    
                pt = uidoc.Selection.PickPoint(msg)
                
            except Autodesk.Revit.Exceptions.OperationCanceledException:
                break
                
            t = Transaction(doc, "Smart MEP")
            t.Start()
            
            try:
                if is_first_click:
                    valid_runners = []
                    for runner in runners:
                        runner.auto_detect_start(pt)
                        if runner.valid:
                            valid_runners.append(runner)
                    
                    if not valid_runners:
                        TaskDialog.Show("Lỗi", "Không xác định được đầu ống hở nào!")
                        t.RollBack()
                        break
                    runners = valid_runners
                
                execute_group_step(runners, pt)
                
                t.Commit()
                is_first_click = False # Đã xong lần đầu
                
            except Exception as e:
                t.RollBack()
                TaskDialog.Show("Error", str(e))
                break

except Exception as e:
    TaskDialog.Show("Fatal", str(e))