# -*- coding: utf-8 -*-

import math
import clr
import System

clr.AddReference("RevitAPI")
clr.AddReference("RevitAPIUI")

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.DB.Plumbing import Pipe, PlumbingUtils
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import forms

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

# ==============================================================================
# 1. UTILITIES
# ==============================================================================

class RevitUtils(object):
    @staticmethod
    def get_closest_connector(element, point):
        if not element: return None
        try:
            conns = element.ConnectorManager.Connectors
            min_dist = float('inf')
            best_conn = None
            for c in conns:
                dist = c.Origin.DistanceTo(point)
                if dist < min_dist:
                    min_dist = dist
                    best_conn = c
            return best_conn
        except: return None

    @staticmethod
    def get_ultimate_fitting_symbol(doc, pipe):
        try:
            collector = FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_PipeFitting)
            candidates = []
            pipe_type_name = doc.GetElement(pipe.GetTypeId()).Name.lower()
            
            for sym in collector:
                if not sym.IsActive: continue
                name = sym.Family.Name.lower()
                score = 0
                try:
                    p = sym.Family.get_Parameter(BuiltInParameter.FAMILY_CONTENT_PART_TYPE)
                    if not p: continue
                    ptype = p.AsInteger()
                    if ptype == 8: score += 1000 
                    elif ptype == 2: score += 10 
                    else: continue 
                except: continue

                if "wye" in name or "y" in name: score += 50
                if "45" in name: score += 50
                if "pvc" in pipe_type_name and "pvc" in name: score += 20
                
                if score > 0:
                    candidates.append((score, sym))
            
            if candidates:
                candidates.sort(key=lambda x: x[0], reverse=True)
                return candidates[0][1]
        except: pass
        return None

def get_location_curve(element):
    if isinstance(element.Location, LocationCurve):
        return element.Location.Curve
    return None

def ProjectPointToLine_Unlimited(line_origin, line_dir, point):
    v = point - line_origin
    d = v.DotProduct(line_dir)
    return line_origin + line_dir.Multiply(d)

def find_current_main_pipe(point, tolerance=0.1):
    outline = Outline(point - XYZ(tolerance, tolerance, tolerance),
                      point + XYZ(tolerance, tolerance, tolerance))
    bb_filter = BoundingBoxIntersectsFilter(outline)
    collector = FilteredElementCollector(doc).WherePasses(bb_filter).OfClass(Pipe)
    best_pipe = None
    for pipe in collector:
        dist = pipe.Location.Curve.Distance(point)
        if dist < 0.05:
            best_pipe = pipe
            break
    return best_pipe

def disconnect_connector(connector):
    if connector.IsConnected:
        for ref in connector.AllRefs:
            if ref.Owner.UniqueId != connector.Owner.UniqueId:
                try: connector.DisconnectFrom(ref)
                except: pass

def validate_point_on_curve(curve, point):
    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)
    vec_line = (p1 - p0).Normalize()
    v_pt = point - p0
    dist_along = v_pt.DotProduct(vec_line)
    pt_strict = p0 + vec_line.Multiply(dist_along)
    len_curve = p0.DistanceTo(p1)
    dist_0 = pt_strict.DistanceTo(p0)
    dist_1 = pt_strict.DistanceTo(p1)
    tolerance = 0.003 
    if dist_0 > len_curve + tolerance or dist_1 > len_curve + tolerance:
        return None, "OUT_OF_BOUNDS"
    if dist_0 < 0.03 or dist_1 < 0.03:
        return None, "TOO_CLOSE_END"
    return pt_strict, "OK"

# ==============================================================================
# 2. CALCULATION LOGIC
# ==============================================================================

def GetClosestPointBetweenLines(p1, v1, p2, v2):
    w0 = p1 - p2
    a = v1.DotProduct(v1)
    b = v1.DotProduct(v2)
    c = v2.DotProduct(v2)
    d = v1.DotProduct(w0)
    e = v2.DotProduct(w0)
    denominator = a * c - b * b
    if abs(denominator) < 1e-6:
        return None 
    sc = (b * e - c * d) / denominator
    return p1 + v1.Multiply(sc)

def Calculate_1E1Y_WithExtend(pipeMain, pipeSub, pt_pick_main, shift_len):
    l_main = get_location_curve(pipeMain)
    main_origin = l_main.GetEndPoint(0)
    main_dir = l_main.Direction.Normalize()

    l_sub = get_location_curve(pipeSub)
    p0 = l_sub.GetEndPoint(0)
    p1 = l_sub.GetEndPoint(1)
    
    proj0 = ProjectPointToLine_Unlimited(main_origin, main_dir, p0)
    proj1 = ProjectPointToLine_Unlimited(main_origin, main_dir, p1)
    
    if p0.DistanceTo(proj0) < p1.DistanceTo(proj1):
        P_Sub_Moving_Origin = p0
        P_Sub_Fixed = p1
        vec_sub_in = (p0 - p1).Normalize()
    else:
        P_Sub_Moving_Origin = p1
        P_Sub_Fixed = p0
        vec_sub_in = (p1 - p0).Normalize()

    P_Virtual_Intersect = GetClosestPointBetweenLines(P_Sub_Fixed, vec_sub_in, main_origin, main_dir)
    if not P_Virtual_Intersect:
        raise Exception("Hai ống song song, không thể đấu nối!")

    P_Sub_End_New = P_Virtual_Intersect - vec_sub_in.Multiply(shift_len)
    if (P_Sub_End_New - P_Sub_Fixed).DotProduct(vec_sub_in) < 0.01:
        raise Exception("SHIFT_LEN quá lớn, vượt quá chiều dài ống nhánh!")

    P_Proj = ProjectPointToLine_Unlimited(main_origin, main_dir, P_Sub_End_New)
    dist_perp = P_Sub_End_New.DistanceTo(P_Proj)

    P_Pick_Proj = ProjectPointToLine_Unlimited(main_origin, main_dir, pt_pick_main)
    vec_check = P_Pick_Proj - P_Proj
    
    if vec_check.IsZeroLength(): flow_vec = main_dir
    else:
        if vec_check.DotProduct(main_dir) > 0: flow_vec = main_dir
        else: flow_vec = main_dir.Negate()

    P_Tee = P_Proj + flow_vec.Multiply(dist_perp)
    return Line.CreateBound(P_Tee, P_Sub_End_New), flow_vec, P_Tee, P_Sub_Fixed, P_Sub_End_New

# ==============================================================================
# 3. MAIN LOOP
# ==============================================================================

class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, element): return isinstance(element, Pipe)
    def AllowReference(self, reference, point): return False

def main():
    pipe_filter = PipeSelectionFilter() 

    while True:
        try:
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B1: Click Main")
                p_main_origin = doc.GetElement(ref_main)
                pt_pick_main = ref_main.GlobalPoint
            except OperationCanceledException: break
            
            try:
                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B2: Chọn Ống Nhánh")
                p_sub = doc.GetElement(ref_branch)
            except OperationCanceledException: break
                
            if not p_main_origin or not p_sub: continue
            
            b_dia = p_sub.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
            shift_len = max(b_dia * 2.0, 0.3)
            
            t = Transaction(doc, "Instant 1E1Y Final")
            t.Start()
            
            try:
                target_symbol = RevitUtils.get_ultimate_fitting_symbol(doc, p_main_origin)
                if target_symbol and not target_symbol.IsActive: target_symbol.Activate()

                line_gom, flow_vec, p_tee_calc, p_sub_fixed, p_sub_end_new = Calculate_1E1Y_WithExtend(p_main_origin, p_sub, pt_pick_main, shift_len)

                current_main = find_current_main_pipe(p_tee_calc)
                if not current_main: current_main = p_main_origin
                
                p_tee_strict, status = validate_point_on_curve(current_main.Location.Curve, p_tee_calc)
                if status != "OK":
                    if status == "OUT_OF_BOUNDS":
                        forms.alert("Điểm Wye trượt ra ngoài ống Main.\nHãy kéo dài ống Main hoặc tăng SHIFT_LEN.")
                    elif status == "TOO_CLOSE_END":
                        forms.alert("Điểm Wye quá gần đầu mút ống Main.")
                    t.RollBack()
                    continue
                
                p_tee = p_tee_strict

                dist0 = p_sub.Location.Curve.GetEndPoint(0).DistanceTo(p_sub_fixed)
                dist1 = p_sub.Location.Curve.GetEndPoint(1).DistanceTo(p_sub_fixed)
                
                c_modify = None
                if dist0 > dist1: 
                     c_modify = RevitUtils.get_closest_connector(p_sub, p_sub.Location.Curve.GetEndPoint(0))
                else:
                     c_modify = RevitUtils.get_closest_connector(p_sub, p_sub.Location.Curve.GetEndPoint(1))
                
                if c_modify: disconnect_connector(c_modify)

                try:
                    new_sub_curve = Line.CreateBound(p_sub_fixed, p_sub_end_new)
                    p_sub.Location.Curve = new_sub_curve
                    doc.Regenerate()
                except Exception as e:
                    raise Exception("Lỗi resize ống nhánh: " + str(e))

                sys_id = p_sub.MEPSystem.GetTypeId() if p_sub.MEPSystem else doc.GetElement(p_sub.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()).Id
                
                line_gom_final = Line.CreateBound(p_tee, p_sub_end_new)

                pNew = Pipe.Create(doc, sys_id, p_sub.GetTypeId(), p_sub.LevelId, 
                                   line_gom_final.GetEndPoint(0), line_gom_final.GetEndPoint(1))
                
                dia = p_sub.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
                pNew.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia)
                doc.Regenerate()
                
                c_sub = RevitUtils.get_closest_connector(p_sub, p_sub_end_new)
                c_new = RevitUtils.get_closest_connector(pNew, p_sub_end_new)
                
                if c_sub and c_new:
                    try: doc.Create.NewElbowFitting(c_sub, c_new)
                    except: 
                        try:
                            c_sub.ConnectTo(c_new)
                            doc.Regenerate()
                            doc.Create.NewElbowFitting(c_sub, c_new)
                        except Exception as e:
                            raise Exception("Lỗi tạo Elbow: " + str(e))
                doc.Regenerate()

                # ==========================================================
                # 6. TẠO WYE (Logic An Toàn: 90 độ -> Đổi Type -> Bẻ góc)
                # ==========================================================
                
                v_branch_in = (line_gom_final.GetEndPoint(0) - line_gom_final.GetEndPoint(1)).Normalize()
                v_branch_out = v_branch_in.Negate()
                
                # 6.1 Tạo vector 90 độ vuông góc với Main Pipe
                v_cross = flow_vec.CrossProduct(v_branch_in)
                if v_cross.IsZeroLength():
                    v_cross = XYZ.BasisZ
                
                v_dummy_dir = v_cross.CrossProduct(flow_vec).Normalize()
                if v_dummy_dir.DotProduct(v_branch_out) < 0:
                    v_dummy_dir = v_dummy_dir.Negate()
                
                # Đặt dummy pipe vuông góc để pass API
                p_dummy_end = p_tee + v_dummy_dir.Multiply(2.0)

                new_main_id = PlumbingUtils.BreakCurve(doc, current_main.Id, p_tee)
                p_main_2 = doc.GetElement(new_main_id)
                doc.Regenerate()

                dummy_pipe = Pipe.Create(doc, current_main.MEPSystem.GetTypeId(), current_main.GetTypeId(), current_main.LevelId, p_tee, p_dummy_end)
                dummy_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia)
                doc.Regenerate()

                c_m1 = RevitUtils.get_closest_connector(current_main, p_tee)
                c_m2 = RevitUtils.get_closest_connector(p_main_2, p_tee)
                c_dum = RevitUtils.get_closest_connector(dummy_pipe, p_tee)
                
                fitting = None
                if c_m1 and c_m2 and c_dum:
                    # Lệnh này sẽ Pass 100% vì đang đâm 90 độ
                    fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
                    doc.Regenerate()

                    # Đổi sang Family thực tế
                    if fitting and target_symbol:
                        if fitting.Symbol.Id != target_symbol.Id:
                            fitting.ChangeTypeId(target_symbol.Id)
                            doc.Regenerate()
                    
                    fitting = doc.GetElement(fitting.Id) 
                    doc.Delete(dummy_pipe.Id)
                    doc.Regenerate()

                    # 6.2 Tính góc thực tế và gán vào Parameter
                    actual_angle = flow_vec.AngleTo(v_branch_out)
                    if actual_angle > math.pi / 2:
                        actual_angle = math.pi - actual_angle

                    for p in fitting.Parameters:
                        p_name = p.Definition.Name.lower()
                        if any(k in p_name for k in ["angle", "góc", "bend"]):
                            if not p.IsReadOnly:
                                try:
                                    p.Set(actual_angle)
                                    doc.Regenerate()
                                except:
                                    pass
                    
                    # 6.3 Chốt hạ nối ống gom vào phụ kiện
                    c_wye_branch = None
                    min_dist = float('inf')
                    for c in fitting.MEPModel.ConnectorManager.Connectors:
                        if c.IsConnected: continue
                        d = c.Origin.DistanceTo(line_gom_final.GetEndPoint(1))
                        if d < min_dist:
                            min_dist = d
                            c_wye_branch = c
                    
                    if c_wye_branch:
                        c_new_end = RevitUtils.get_closest_connector(pNew, p_tee)
                        diff = c_wye_branch.Origin - c_new_end.Origin
                        if not diff.IsZeroLength():
                             try: ElementTransformUtils.MoveElement(doc, pNew.Id, diff)
                             except: pass
                        try: c_wye_branch.ConnectTo(c_new_end)
                        except: pass
                        doc.Regenerate()

                t.Commit()
            except Exception as e:
                t.RollBack()
                forms.alert("Lỗi Runtime: " + str(e))

        except Exception as e:
            forms.alert("Lỗi Hệ Thống: " + str(e))
            break

if __name__ == "__main__":
    main()