# -*- coding: utf-8 -*-
import clr
import sys
import math
import traceback
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Structure import StructuralType
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
import Autodesk.Revit.Exceptions as Extensions

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- THÔNG SỐ CẤP NƯỚC LAVABO ---
MM_TO_FT = 1 / 304.8
ELEVATION_MM = 100.0         # Cao độ ống ngang ra thiết bị
HORIZ_LENGTH_MM = 100.0      # Chiều dài đoạn ống ngang

# CHỈ CHỐT ĐÍCH DANH CO REN TRONG, NÚT BỊT SẼ LẤY THEO ROUTING
ELBOW_TYPE_NAME = u"Co ren trong PPR"

class PipeFilter(ISelectionFilter):
    def AllowElement(self, element):
        if element.Category and element.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves):
            return True
        return False
    def AllowReference(self, reference, position): return False

class WarningSwallower(IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        if failures.Count == 0: return FailureProcessingResult.Continue
        for f in failures:
            if f.GetSeverity() == FailureSeverity.Warning: failuresAccessor.DeleteWarning(f)
            else: failuresAccessor.ResolveFailure(f); return FailureProcessingResult.ProceedWithCommit
        return FailureProcessingResult.Continue

# --- HÀM TÌM FITTING ---
def get_symbol_by_name(target_name):
    collector = FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_PipeFitting)
    for symbol in collector:
        name_param = symbol.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
        type_name = name_param.AsString() if name_param else ""
        if not type_name:
            try: type_name = symbol.Name
            except: pass
        if type_name == target_name:
            if not symbol.IsActive: symbol.Activate()
            return symbol
    return None

def get_cap_symbol_from_routing(pipe):
    """Lấy Nút bịt từ Routing Preferences của loại ống đang vẽ"""
    pipe_type = doc.GetElement(pipe.GetTypeId())
    rp = pipe_type.RoutingPreferenceManager
    if rp.GetNumberOfRules(RoutingPreferenceRuleGroupType.Caps) > 0:
        cap_id = rp.GetRule(RoutingPreferenceRuleGroupType.Caps, 0).MEPPartId
        if cap_id != ElementId.InvalidElementId:
            sym = doc.GetElement(cap_id)
            if not sym.IsActive: sym.Activate()
            return sym
    return None

def get_connector_closest_to(mep_element, pt):
    best_conn = None
    min_dist = float('inf')
    if mep_element.ConnectorManager:
        for conn in mep_element.ConnectorManager.Connectors:
            dist = conn.Origin.DistanceTo(pt)
            if dist < min_dist:
                min_dist = dist
                best_conn = conn
    return best_conn

def get_first_connector(inst):
    if inst.MEPModel and inst.MEPModel.ConnectorManager:
        for conn in inst.MEPModel.ConnectorManager.Connectors:
            return conn
    return None

# --- LOGIC XỬ LÝ CHÍNH ---
def process_water_supply_smart(pipe_main, click_pt):
    level = doc.GetElement(pipe_main.LevelId)
    if not level: return

    sys_type_id = pipe_main.MEPSystem.GetTypeId()
    pipe_type_id = pipe_main.GetTypeId()
    level_id = pipe_main.LevelId
    
    pipe_dia_ft = pipe_main.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
    z_600 = level.Elevation + (ELEVATION_MM * MM_TO_FT)

    curve = pipe_main.Location.Curve
    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)
    
    cx, cy = p0.X, p0.Y
    vec_click = XYZ(click_pt.X - cx, click_pt.Y - cy, 0)
    if vec_click.GetLength() < 0.001: vec_click = XYZ(1, 0, 0) 
    vec_click = vec_click.Normalize()

    directions = [XYZ(1, 0, 0), XYZ(-1, 0, 0), XYZ(0, 1, 0), XYZ(0, -1, 0)]
    best_dir = XYZ(1, 0, 0)
    max_dot = -1.0 
    
    for d in directions:
        val = vec_click.DotProduct(d)
        if val > max_dot:
            max_dot = val
            best_dir = d
    dir_vec = best_dir

    # 1. SMART TRIM ỐNG ĐỨNG TẠI CAO ĐỘ +600
    d0 = abs(p0.Z - z_600)
    d1 = abs(p1.Z - z_600)
    kept_pt = p0 if d0 > d1 else p1

    new_end_pt = XYZ(cx, cy, z_600)
    pipe_main.Location.Curve = Line.CreateBound(kept_pt, new_end_pt)
    doc.Regenerate()

    # 2. TẠO ỐNG NGANG
    p_h_start = new_end_pt
    p_h_end = p_h_start + dir_vec * (HORIZ_LENGTH_MM * MM_TO_FT)
    pipe_h = Pipe.Create(doc, sys_type_id, pipe_type_id, level_id, p_h_start, p_h_end)
    pipe_h.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(pipe_dia_ft)
    doc.Regenerate()

    # 3. GẮN CO (Để Revit tự nối rồi Tráo Type thành Co ren trong)
    conn_v = get_connector_closest_to(pipe_main, new_end_pt)
    conn_h_start = get_connector_closest_to(pipe_h, p_h_start)
    
    try:
        elbow_inst = doc.Create.NewElbowFitting(conn_v, conn_h_start)
        doc.Regenerate()
        
        elbow_sym = get_symbol_by_name(ELBOW_TYPE_NAME)
        if elbow_sym and elbow_inst.GetTypeId() != elbow_sym.Id:
            elbow_inst.ChangeTypeId(elbow_sym.Id)
    except Exception as e:
        print("\n[LƯU Ý] Lỗi nối Co: ", e)

    # 4. GẮN NÚT BỊT TỪ ROUTING PREFERENCES & ÉP PARAMETER "d"
    cap_inst = None
    try:
        # Bốc Nút bịt chuẩn từ Routing Preferences
        cap_symbol = get_cap_symbol_from_routing(pipe_main)
        
        if cap_symbol:
            conn_h_end = get_connector_closest_to(pipe_h, p_h_end)
            cap_inst = doc.Create.NewFamilyInstance(conn_h_end.Origin, cap_symbol, level, StructuralType.NonStructural)
            doc.Regenerate()
            
            # Ép biến d theo kích thước ống
            param_d = cap_inst.LookupParameter("d")
            if param_d and not param_d.IsReadOnly:
                try: param_d.Set(pipe_dia_ft)
                except: pass
            else:
                for p_name in ["ND", "Nominal Diameter", "Kích thước"]:
                    p = cap_inst.LookupParameter(p_name)
                    if p and not p.IsReadOnly:
                        try: p.Set(pipe_dia_ft)
                        except: pass
            doc.Regenerate()
            
            cap_conn = get_first_connector(cap_inst)

            # Xoay và Dịch chuyển khớp tâm ngàm
            pipe_dir = conn_h_end.CoordinateSystem.BasisZ
            cap_dir = cap_conn.CoordinateSystem.BasisZ
            target_dir = pipe_dir.Negate()
            
            angle = cap_dir.AngleTo(target_dir)
            if angle > 0.001:
                axis = cap_dir.CrossProduct(target_dir)
                if axis.GetLength() < 0.001: axis = cap_conn.CoordinateSystem.BasisX
                rot_line = Line.CreateBound(cap_conn.Origin, cap_conn.Origin + axis)
                ElementTransformUtils.RotateElement(doc, cap_inst.Id, rot_line, angle)
                doc.Regenerate()
                cap_conn = get_first_connector(cap_inst)

            vec = conn_h_end.Origin - cap_conn.Origin
            if vec.GetLength() > 0.001:
                ElementTransformUtils.MoveElement(doc, cap_inst.Id, vec)
                doc.Regenerate()

            # Nối vào hệ thống
            is_pinned = pipe_h.Pinned
            pipe_h.Pinned = True
            try: conn_h_end.ConnectTo(cap_conn)
            except: pass 
            finally: pipe_h.Pinned = is_pinned
        else:
            print("\n[LƯU Ý] Chưa set Nút Bịt (Cap) trong Routing Preferences của loại ống này!")

    except Exception as e:
        print("\n[LƯU Ý] Lỗi đặt Nút bịt: ", e)

    # 5. BÙ TRỪ NGÀM ĐỂ FIX CỨNG CHIỀU DÀI 100MM
    if cap_inst:
        try:
            doc.Regenerate() 
            current_length_ft = pipe_h.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH).AsDouble()
            target_length_ft = HORIZ_LENGTH_MM * MM_TO_FT
            
            diff_ft = target_length_ft - current_length_ft
            
            if abs(diff_ft) > 0.0001:
                move_vec = dir_vec * diff_ft
                ElementTransformUtils.MoveElement(doc, cap_inst.Id, move_vec)
                doc.Regenerate()
        except: pass

# --- VÒNG LẶP CHÍNH ---
def run_script():
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, PipeFilter(), "Click hướng cấp nước Lavabo (ESC thoát)")
            pipe_main = doc.GetElement(ref)
            pick_point = ref.GlobalPoint 

            t = Transaction(doc, "Auto Water Supply Rough-in")
            t.Start()
            
            opt = t.GetFailureHandlingOptions()
            opt.SetFailuresPreprocessor(WarningSwallower())
            opt.SetClearAfterRollback(True)
            t.SetFailureHandlingOptions(opt)
            
            try:
                process_water_supply_smart(pipe_main, pick_point)
                t.Commit()
            except Exception as e:
                t.RollBack()
                print("\n[LỖI TỔNG] Có lỗi văng script, Transaction đã được Rollback. Chi tiết:")
                print(traceback.format_exc())
            
        except Extensions.OperationCanceledException:
            break
        except Exception as e:
            break

if __name__ == "__main__": 
    run_script()