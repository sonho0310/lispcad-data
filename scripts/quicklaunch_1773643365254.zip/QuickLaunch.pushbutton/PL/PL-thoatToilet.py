# -*- coding: utf-8 -*-
import clr
import sys
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import StructuralType
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.UI.Selection import ObjectType

# Thiết lập Document
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# Đổi cao độ: 200mm
MM_TO_FT = 1 / 304.8
OFFSET_MM = 200.0
OFFSET_FT = OFFSET_MM * MM_TO_FT

def get_specific_cap_symbol():
    target_type_name = u"Đầu bịt trơn uPVC" 
    collector = FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_PipeFitting)
    for symbol in collector:
        name_param = symbol.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
        type_name = name_param.AsString() if name_param else ""
        if not type_name:
            try: type_name = symbol.Name
            except: pass
                
        if type_name == target_type_name:
            if not symbol.IsActive: symbol.Activate()
            return symbol
    return None

def get_top_open_connector(pipe):
    top_conn = None
    max_z = -float('inf')
    for conn in pipe.ConnectorManager.Connectors:
        if not conn.IsConnected and conn.Origin.Z > max_z:
            top_conn = conn
            max_z = conn.Origin.Z
    return top_conn

def get_first_connector(inst):
    if inst.MEPModel and inst.MEPModel.ConnectorManager:
        for conn in inst.MEPModel.ConnectorManager.Connectors:
            return conn
    return None

def process_pipe_logic(pipe):
    level = doc.GetElement(pipe.LevelId)
    if not level: return False
    
    target_z = level.Elevation + OFFSET_FT
    curve = pipe.Location.Curve
    p0, p1 = curve.GetEndPoint(0), curve.GetEndPoint(1)

    if p0.Z > p1.Z:
        new_curve = Line.CreateBound(XYZ(p0.X, p0.Y, target_z), p1)
    else:
        new_curve = Line.CreateBound(p0, XYZ(p1.X, p1.Y, target_z))

    pipe.Location.Curve = new_curve
    doc.Regenerate()

    top_conn = get_top_open_connector(pipe)
    cap_symbol = get_specific_cap_symbol()

    if top_conn and cap_symbol:
        cap_inst = doc.Create.NewFamilyInstance(top_conn.Origin, cap_symbol, level, StructuralType.NonStructural)
        doc.Regenerate()
        
        cap_conn = get_first_connector(cap_inst)
        if cap_conn:
            pipe_diameter = top_conn.Radius * 2.0
            params_to_try = ["ND", "Nominal Diameter", "Nominal Radius", u"Kích thước"]
            
            for p_name in params_to_try:
                param = cap_inst.LookupParameter(p_name)
                if param and not param.IsReadOnly:
                    try: 
                        val = top_conn.Radius if "Radius" in p_name else pipe_diameter
                        param.Set(val)
                    except: pass
            
            doc.Regenerate()
            cap_conn = get_first_connector(cap_inst)

            # Khớp hướng và vị trí
            target_dir = top_conn.CoordinateSystem.BasisZ.Negate()
            cap_dir = cap_conn.CoordinateSystem.BasisZ
            
            if cap_dir.AngleTo(target_dir) > 0.001:
                axis = cap_dir.CrossProduct(target_dir)
                if axis.GetLength() < 0.001: axis = cap_conn.CoordinateSystem.BasisX
                ElementTransformUtils.RotateElement(doc, cap_inst.Id, Line.CreateBound(cap_conn.Origin, cap_conn.Origin + axis), cap_dir.AngleTo(target_dir))
                doc.Regenerate()
                cap_conn = get_first_connector(cap_inst)

            ElementTransformUtils.MoveElement(doc, cap_inst.Id, top_conn.Origin - cap_conn.Origin)
            doc.Regenerate()

            # Connect
            is_pinned = pipe.Pinned
            pipe.Pinned = True
            try: top_conn.ConnectTo(cap_conn)
            finally: pipe.Pinned = is_pinned
        return True
    return False

def run_loop():
    # Sử dụng thanh trạng thái thay vì print console
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, "Chọn ống (ESC để thoát)")
            pipe = doc.GetElement(ref)
            
            if pipe.Category.Id.IntegerValue != int(BuiltInCategory.OST_PipeCurves):
                continue

            with Transaction(doc, "Auto Cap Pipe") as t:
                t.Start()
                if process_pipe_logic(pipe):
                    t.Commit()
                else:
                    t.RollBack()
        except:
            break # Thoát khi nhấn ESC hoặc Close

if __name__ == "__main__":
    run_loop()