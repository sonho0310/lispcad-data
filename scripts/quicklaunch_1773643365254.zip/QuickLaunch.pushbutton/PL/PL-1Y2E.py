# -*- coding: utf-8 -*-
"""
Tool: Auto Wye Solver (V30 - SPEED OPTIMIZED)
Fix: Tăng tốc độ khởi động lệnh (Lazy Import + Local Scope).
Core: V7.5 Logic + Loop Mode + Smart Parameter Scanner.
"""
__title__ = 'Auto Wye\nFast Sel'

# --- TỐI ƯU IMPORT (CHỈ LOAD CÁI CẦN THIẾT) ---
from Autodesk.Revit.DB import (Transaction, XYZ, Line, BuiltInParameter, BuiltInCategory, 
                               FilteredElementCollector, FamilySymbol, ElementTransformUtils, 
                               UnitUtils, UnitTypeId, Reference)
from Autodesk.Revit.UI.Selection import ISelectionFilter, ObjectType
from Autodesk.Revit.DB.Plumbing import Pipe, PlumbingUtils
from Autodesk.Revit.Exceptions import OperationCanceledException
import math

# --- CẤU HÌNH ---
ANGLE_MIN = 42.0
ANGLE_MAX = 48.0
TARGET_ANGLE = 45.0 

OFFSET_E_MIN_MM = 100.0
OFFSET_E_MAX_MM = 600.0
STEP_E_SCAN_MM = 10.0
LEN_EF_MIN_MM = 100.0
LEN_EF_MAX_MM = 600.0
STEP_EF_SCAN_MM = 10.0

# ==============================================================================
# 1. UTILITIES & FIX SELECTION FILTER
# ==============================================================================

def show_alert(msg):
    try:
        from pyrevit import forms
        forms.alert(msg)
    except:
        import clr
        clr.AddReference("System.Windows.Forms")
        from System.Windows.Forms import MessageBox
        MessageBox.Show(msg)

class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, Pipe)
    
    def AllowReference(self, ref, xyz):
        return False

class RevitUtils(object):
    @staticmethod
    def get_closest_connector(element, point):
        if not element: return None
        try:
            conns = element.ConnectorManager.Connectors
            min_dist = float('inf')
            best_conn = None
            for c in conns:
                dist = c.Origin.DistanceTo(point)
                if dist < min_dist:
                    min_dist = dist
                    best_conn = c
            return best_conn
        except: return None

    @staticmethod
    def get_ultimate_fitting_symbol(doc, pipe):
        try:
            collector = FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_PipeFitting)
            candidates = []
            pipe_type_name = doc.GetElement(pipe.GetTypeId()).Name.lower()
            
            for sym in collector:
                if not sym.IsActive: continue
                name = sym.Family.Name.lower()
                score = 0
                try:
                    p = sym.Family.get_Parameter(BuiltInParameter.FAMILY_CONTENT_PART_TYPE)
                    if not p: continue
                    ptype = p.AsInteger()
                    if ptype == 8: score += 1000 
                    elif ptype == 2: score += 10 
                    else: continue 
                except: continue

                if "wye" in name or "y" in name: score += 50
                if "45" in name: score += 50
                if "pvc" in pipe_type_name and "pvc" in name: score += 20
                
                if score > 0:
                    candidates.append((score, sym))
            
            if candidates:
                candidates.sort(key=lambda x: x[0], reverse=True)
                return candidates[0][1]
        except: pass
        return None

# --- GEOMETRY HELPERS ---

def unit_mm_to_feet(mm):
    return UnitUtils.ConvertToInternalUnits(mm, UnitTypeId.Millimeters)

def get_angle_between_vectors(v1, v2):
    return math.degrees(v1.AngleTo(v2))

def get_gravity_flow_info(pipe):
    curve = pipe.Location.Curve
    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)
    if abs(p0.Z - p1.Z) < 0.0001: return (p1 - p0).Normalize(), p0, p1
    elif p0.Z > p1.Z: return (p1 - p0).Normalize(), p0, p1
    else: return (p0 - p1).Normalize(), p1, p0

def rotate_vector_z(vector, radians):
    nx = vector.X * math.cos(radians) - vector.Y * math.sin(radians)
    ny = vector.X * math.sin(radians) + vector.Y * math.cos(radians)
    return XYZ(nx, ny, 0).Normalize()

def calculate_point_H_geometry(line_origin, line_dir, point_F, target_angle_deg):
    vec_w = point_F - line_origin
    proj_len = vec_w.DotProduct(line_dir)
    point_P = line_origin + (line_dir * proj_len)
    dist_d = point_F.DistanceTo(point_P)
    angle_rad = math.radians(target_angle_deg)
    if angle_rad == 0: return point_P
    dist_x = dist_d / math.tan(angle_rad)
    return point_P + (line_dir * dist_x)

def get_connector_at_point(element, point):
    try:
        if element is None: return None
        for c in element.ConnectorManager.Connectors:
            if c.Origin.IsAlmostEqualTo(point, 0.001): return c
    except: pass
    return None

def validate_and_extend_main_pipe(doc, pipe_main, break_point):
    curve = pipe_main.Location.Curve
    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)
    vec = (p1 - p0).Normalize()
    v_pt = break_point - p0
    dist_along = v_pt.DotProduct(vec)
    pt_strict = p0 + vec.Multiply(dist_along)
    
    len_pipe = p0.DistanceTo(p1)
    dist_0 = pt_strict.DistanceTo(p0)
    dist_1 = pt_strict.DistanceTo(p1)
    tolerance = 0.003
    
    if dist_0 + dist_1 <= len_pipe + tolerance: return True
        
    c0 = RevitUtils.get_closest_connector(pipe_main, p0)
    c1 = RevitUtils.get_closest_connector(pipe_main, p1)
    
    connector_to_move, point_to_move_to = None, None
    if dist_0 < dist_1: 
        if c0 and not c0.IsConnected: connector_to_move, point_to_move_to = c0, pt_strict - vec.Multiply(0.1)
    else: 
        if c1 and not c1.IsConnected: connector_to_move, point_to_move_to = c1, pt_strict + vec.Multiply(0.1)
            
    if connector_to_move and point_to_move_to:
        try:
            new_p0 = point_to_move_to if connector_to_move.Origin.IsAlmostEqualTo(p0) else p0
            new_p1 = point_to_move_to if connector_to_move.Origin.IsAlmostEqualTo(p1) else p1
            pipe_main.Location.Curve = Line.CreateBound(new_p0, new_p1)
            doc.Regenerate()
            return True
        except: return False
    return False

# ==============================================================================
# 2. CORE V7.5 LOGIC (WYE CREATION)
# ==============================================================================

def Core_V75_CreateWye(doc, p_main, p_tee, p_branch_incoming, main_flow_vec, wye_symbol):
    l_branch = p_branch_incoming.Location.Curve
    v_branch_in = (l_branch.GetEndPoint(1) - l_branch.GetEndPoint(0)).Normalize() 
    if l_branch.GetEndPoint(0).DistanceTo(p_tee) < l_branch.GetEndPoint(1).DistanceTo(p_tee):
         v_branch_in = (l_branch.GetEndPoint(0) - l_branch.GetEndPoint(1)).Normalize()

    v_cross = main_flow_vec.CrossProduct(v_branch_in)
    v_dummy_dir = v_cross.CrossProduct(main_flow_vec).Normalize()
    
    if v_dummy_dir.DotProduct(v_branch_in.Negate()) < 0:
        v_dummy_dir = v_dummy_dir.Negate()
    
    p_dummy_end = p_tee + v_dummy_dir.Multiply(1.0)

    dia = p_branch_incoming.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
    sys_id = p_main.MEPSystem.GetTypeId()
    type_id = p_main.GetTypeId()
    lev_id = p_main.LevelId

    new_main_id = PlumbingUtils.BreakCurve(doc, p_main.Id, p_tee)
    p_main_2 = doc.GetElement(new_main_id)
    doc.Regenerate()

    dummy_pipe = Pipe.Create(doc, sys_id, type_id, lev_id, p_tee, p_dummy_end)
    dummy_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia)
    doc.Regenerate()

    c_m1 = RevitUtils.get_closest_connector(p_main, p_tee)
    c_m2 = RevitUtils.get_closest_connector(p_main_2, p_tee)
    c_dum = RevitUtils.get_closest_connector(dummy_pipe, p_tee)
    
    fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
    doc.Regenerate()

    if fitting and wye_symbol:
        if fitting.Symbol.Id != wye_symbol.Id:
            fitting.ChangeTypeId(wye_symbol.Id)
            doc.Regenerate()
    
    fitting = doc.GetElement(fitting.Id)

    doc.Delete(dummy_pipe.Id)
    doc.Regenerate()

    # ==========================================================
    # SMART PARAMETER SCANNER ĐÃ ĐƯỢC THÊM VÀO ĐÂY
    # ==========================================================
    for p in fitting.Parameters:
        p_name = p.Definition.Name.lower()
        if any(k in p_name for k in ["angle", "góc", "bend"]):
            if not p.IsReadOnly:
                try:
                    p.Set(math.pi / 4)
                    doc.Regenerate()
                    break
                except:
                    pass
    
    c_wye_branch = None
    min_dist = float('inf')
    for c in fitting.MEPModel.ConnectorManager.Connectors:
        if c.IsConnected: continue
        d = c.Origin.DistanceTo(p_branch_incoming.Location.Curve.GetEndPoint(0))
        if d < min_dist: min_dist = d; c_wye_branch = c
        d2 = c.Origin.DistanceTo(p_branch_incoming.Location.Curve.GetEndPoint(1))
        if d2 < min_dist: min_dist = d2; c_wye_branch = c
    
    if c_wye_branch:
        c_branch_end = RevitUtils.get_closest_connector(p_branch_incoming, p_tee)
        diff = c_wye_branch.Origin - c_branch_end.Origin
        if not diff.IsZeroLength():
             try: ElementTransformUtils.MoveElement(doc, p_branch_incoming.Id, diff)
             except: pass
        c_wye_branch.ConnectTo(c_branch_end)
        doc.Regenerate()

# ==============================================================================
# 3. SOLVER LOGIC
# ==============================================================================

def solve_fully_constrained(pt_Click, vec_CD, slope_CD, pt_AB_origin, vec_AB):
    best_score = 999.0
    best_result = None 
    final_angles = (0, 0, 0) 
    
    min_offset = unit_mm_to_feet(OFFSET_E_MIN_MM)
    max_offset = unit_mm_to_feet(OFFSET_E_MAX_MM)
    step_e = unit_mm_to_feet(STEP_E_SCAN_MM)
    min_ef = unit_mm_to_feet(LEN_EF_MIN_MM)
    max_ef = unit_mm_to_feet(LEN_EF_MAX_MM)
    step_ef = unit_mm_to_feet(STEP_EF_SCAN_MM)
    
    vec_CD_xy = XYZ(vec_CD.X, vec_CD.Y, 0).Normalize()
    directions = [rotate_vector_z(vec_CD_xy, math.radians(45)), 
                  rotate_vector_z(vec_CD_xy, math.radians(-45))]
    
    curr_offset = min_offset
    while curr_offset <= max_offset:
        pt_E_curr = pt_Click + (vec_CD * curr_offset)
        curr_len_ef = min_ef
        while curr_len_ef <= max_ef:
            for vec_EF_xy in directions:
                pt_F_curr = XYZ(pt_E_curr.X + vec_EF_xy.X * curr_len_ef,
                                pt_E_curr.Y + vec_EF_xy.Y * curr_len_ef,
                                pt_E_curr.Z - (curr_len_ef * slope_CD))
                
                pt_H_curr = calculate_point_H_geometry(pt_AB_origin, vec_AB, pt_F_curr, TARGET_ANGLE)
                
                vec_EF_3d = (pt_F_curr - pt_E_curr).Normalize()
                vec_GH_3d = (pt_H_curr - pt_F_curr).Normalize()
                
                ang1 = get_angle_between_vectors(vec_CD, vec_EF_3d)
                ang2 = get_angle_between_vectors(vec_EF_3d, vec_GH_3d)
                ang3 = get_angle_between_vectors(vec_GH_3d, vec_AB)
                
                if (ANGLE_MIN <= ang1 <= ANGLE_MAX) and \
                   (ANGLE_MIN <= ang2 <= ANGLE_MAX) and \
                   (ANGLE_MIN <= ang3 <= ANGLE_MAX):
                    score = abs(ang1 - 45) + abs(ang2 - 45) + abs(ang3 - 45)
                    if score < best_score:
                        best_score = score
                        best_result = (pt_E_curr, pt_F_curr, pt_H_curr)
                        final_angles = (ang1, ang2, ang3)
                        if score < 0.5: return best_result, final_angles, True
            curr_len_ef += step_ef
        curr_offset += step_e

    found = (best_result is not None)
    return best_result, final_angles, found

# ==============================================================================
# 4. MAIN LOOP
# ==============================================================================

def main():
    uidoc = __revit__.ActiveUIDocument
    doc = uidoc.Document
    
    sel_filter = PipeSelectionFilter()

    while True:
        try:
            try:
                ref_AB = uidoc.Selection.PickObject(ObjectType.Element, sel_filter, "Chọn Main Pipe (ESC thoát)")
                pipe_AB = doc.GetElement(ref_AB)
                ref_CD = uidoc.Selection.PickObject(ObjectType.Element, sel_filter, "Chọn Branch Pipe")
                pipe_CD = doc.GetElement(ref_CD)
            except OperationCanceledException: break

            wye_symbol = RevitUtils.get_ultimate_fitting_symbol(doc, pipe_AB)
            
            vec_AB, pt_A_orig, pt_B_orig = get_gravity_flow_info(pipe_AB)
            vec_CD, start_CD, end_CD = get_gravity_flow_info(pipe_CD)
            p_slope = pipe_CD.get_Parameter(BuiltInParameter.RBS_PIPE_SLOPE)
            slope_val = p_slope.AsDouble() if p_slope else 0.0
            pt_Click_E = pipe_CD.Location.Curve.Project(ref_CD.GlobalPoint).XYZPoint

            result, angles, is_found = solve_fully_constrained(pt_Click_E, vec_CD, slope_val, pt_A_orig, vec_AB)
            
            if not is_found:
                show_alert("Không tìm thấy giải pháp! Thử click xa hơn.")
                continue 
                
            pt_E, pt_F, pt_H = result

            t = Transaction(doc, "Auto Wye V30 Fixed")
            t.Start()

            try:
                if wye_symbol and not wye_symbol.IsActive: wye_symbol.Activate()

                is_valid = validate_and_extend_main_pipe(doc, pipe_AB, pt_H)
                if not is_valid:
                    t.RollBack()
                    show_alert("Lỗi: Điểm đấu nối nằm ngoài ống chính.")
                    continue

                sys_id = pipe_CD.MEPSystem.GetTypeId()
                type_id = pipe_CD.GetTypeId()
                lvl_id = pipe_CD.ReferenceLevel.Id
                diam_val = pipe_CD.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()

                pipe_CD.Location.Curve = Line.CreateBound(start_CD, pt_E)
                pipe_EF = Pipe.Create(doc, sys_id, type_id, lvl_id, pt_E, pt_F)
                pipe_EF.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(diam_val)
                pipe_GH = Pipe.Create(doc, sys_id, type_id, lvl_id, pt_F, pt_H)
                pipe_GH.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(diam_val)

                def auto_elbow(p1, p2, pt):
                    c1, c2 = get_connector_at_point(p1, pt), get_connector_at_point(p2, pt)
                    if c1 and c2: 
                        try: doc.Create.NewElbowFitting(c1, c2)
                        except: pass
                
                auto_elbow(pipe_CD, pipe_EF, pt_E)
                auto_elbow(pipe_EF, pipe_GH, pt_F)

                # Core V7.5 Logic
                Core_V75_CreateWye(doc, pipe_AB, pt_H, pipe_GH, vec_AB, wye_symbol)

                t.Commit()

            except Exception as e:
                t.RollBack()
                show_alert("Lỗi Runtime: " + str(e))

        except Exception as e:
            show_alert("Lỗi Hệ Thống: " + str(e))
            break

if __name__ == '__main__':
    main()