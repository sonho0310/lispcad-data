# -*- coding: utf-8 -*-
"""
TOOL: AUTO 45-UP & CAP (V15.11 - OMNI SCANNER TRỊ BÁCH BỆNH)
AUTHOR: Gemini & User
CHANGE: Brute-force parameter value scanning. Ignores parameter names, searches for matching values directly.
"""

import math
import clr
import re
import Autodesk

import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI.Selection as Sel
from Autodesk.Revit.DB import *
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

# =======================================================
# 0. CLASS FILTER
# =======================================================
class PipeSelectionFilter(Sel.ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, DB.Plumbing.Pipe)
    def AllowReference(self, ref, point):
        return True

# =======================================================
# 1. LOGIC TÍNH TOÁN & HÌNH HỌC
# =======================================================
def safe_inject_size(cap_inst, pipe_dia_feet):
    # 1. Cố gắng dùng biến chuẩn
    try:
        bip = DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM
        p = cap_inst.get_Parameter(bip)
        if p and not p.IsReadOnly: p.Set(pipe_dia_feet)
    except: pass

    val_mm = int(round(pipe_dia_feet * 304.8))
    
    # 2. Danh sách tên phổ biến (Thêm ENG_DN của Tiền Phong)
    other_names = ["ENG_DN", "REDY_BDN_DN", "DN", "Size", "Diameter", "Kích thước", "Nominal Diameter"]
    for name in other_names:
        try:
            p = cap_inst.LookupParameter(name)
            if p and not p.IsReadOnly:
                if p.StorageType == DB.StorageType.Double: p.Set(pipe_dia_feet)
                elif p.StorageType == DB.StorageType.String: p.Set(str(val_mm))
                elif p.StorageType == DB.StorageType.Integer: p.Set(val_mm)
        except: pass
        
    # 3. Quét mù: Thấy biến nào có chữ DN/Size mà ghi được là nhét luôn
    for p in cap_inst.Parameters:
        if not p.IsReadOnly:
            p_name = p.Definition.Name.lower()
            if "dn" in p_name or "size" in p_name or "kích thước" in p_name:
                try:
                    if p.StorageType == DB.StorageType.Double: p.Set(pipe_dia_feet)
                    elif p.StorageType == DB.StorageType.Integer: p.Set(val_mm)
                except: pass

def get_best_cap_symbol(doc, pipe, pipe_dia_feet):
    base_sym = None
    val_mm = int(round(pipe_dia_feet * 304.8))

    try:
        pipe_type = doc.GetElement(pipe.GetTypeId())
        rpm = pipe_type.RoutingPreferenceManager
        if rpm.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Caps) > 0:
            rule = rpm.GetRule(DB.RoutingPreferenceRuleGroupType.Caps, 0)
            sym_id = rule.MEPPartId
            if sym_id != DB.ElementId.InvalidElementId: 
                base_sym = doc.GetElement(sym_id)
    except: pass

    # Mở rộng từ khóa tìm Family (Thêm Clean Out, CO)
    if not base_sym:
        collector = DB.FilteredElementCollector(doc).OfClass(DB.FamilySymbol).OfCategory(DB.BuiltInCategory.OST_PipeFitting)
        keywords = ["thông tắc", "thong tac", "clean out", "cleanout", "cap", "bịt", "bit"]
        for sym in collector:
            try:
                s_name = (sym.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() or "").lower()
                f_name = (sym.FamilyName or "").lower()
                if any(kw in s_name or kw in f_name for kw in keywords): 
                    base_sym = sym
                    break
            except: pass
    
    if base_sym:
        family = base_sym.Family
        candidates = []
        
        for s_id in family.GetFamilySymbolIds():
            s = doc.GetElement(s_id)
            s_name = s.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString() or ""
            
            found_size_mm = None
            
            # A. Quét Tên Type (Trường hợp tên có số: D90, Phi 114)
            try:
                nums = re.findall(r'\d+', s_name)
                for n_str in nums:
                    n_val = float(n_str)
                    if n_val > 10 and abs(n_val - val_mm) < 2.0: 
                        found_size_mm = val_mm
                        break
            except: pass
            
            # B. TRỊ BÁCH BỆNH: Quét MỌI Parameter để tìm giá trị khớp với val_mm
            # (Trường hợp tên Type là "CO" chả có số gì cả)
            if not found_size_mm:
                for p in s.Parameters:
                    try:
                        if p.StorageType == DB.StorageType.Double:
                            p_val_mm = p.AsDouble() * 304.8
                            if abs(p_val_mm - val_mm) < 2.0:
                                found_size_mm = val_mm; break
                        elif p.StorageType == DB.StorageType.Integer:
                            if abs(p.AsInteger() - val_mm) < 2.0:
                                found_size_mm = val_mm; break
                        elif p.StorageType == DB.StorageType.String:
                            s_val = p.AsString() or ""
                            # Trích xuất số từ chuỗi kiểu "125 mmø"
                            nums = re.findall(r'\d+', s_val)
                            if any(abs(float(nx) - val_mm) < 2.0 for nx in nums if float(nx) > 10):
                                found_size_mm = val_mm; break
                    except: pass
            
            if found_size_mm is not None:
                candidates.append((abs(found_size_mm - val_mm), s))
            else:
                candidates.append((9999, s))
        
        if candidates:
            candidates.sort(key=lambda x: x[0])
            return candidates[0][1] 
            
        return base_sym
        
    return None

# =======================================================
# HÀM TẠO ỐNG 45 VỚI ĐỘ DÀI ĐỘNG (ĐÃ THU NGẮN 1.5D)
# =======================================================
def create_45_up_extension_dynamic(doc, pipe, open_connector):
    vec_out = open_connector.CoordinateSystem.BasisZ
    if abs(vec_out.Z) > 0.9: return None 
    
    vec_z = XYZ.BasisZ
    vec_45 = (vec_out + vec_z).Normalize() 
    p_start = open_connector.Origin

    try:
        dia_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
        b_dia = dia_param.AsDouble()
    except:
        b_dia = 0.1 

    stub_len = max(b_dia * 1.5, 0.25) 
    p_end = p_start + vec_45.Multiply(stub_len)

    try:
        sys_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
        sys_id = sys_param.AsElementId() if sys_param else pipe.MEPSystem.GetTypeId()
        
        new_pipe = DB.Plumbing.Pipe.Create(doc, sys_id, pipe.GetTypeId(), pipe.LevelId, p_start, p_end)
        new_pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
        return new_pipe
    except: return None

def place_cap_v14_robot(doc, pipe_end_connector, cap_symbol, pipe_dia_feet):
    insert_point = pipe_end_connector.Origin
    cap_inst = doc.Create.NewFamilyInstance(insert_point, cap_symbol, DB.Structure.StructuralType.NonStructural)
    safe_inject_size(cap_inst, pipe_dia_feet)
    doc.Regenerate()

    cap_conn = None
    try:
        for c in cap_inst.MEPModel.ConnectorManager.Connectors: cap_conn = c; break
    except: return False 
    if not cap_conn: return False

    pipe_vec = pipe_end_connector.CoordinateSystem.BasisZ
    target_vec = pipe_vec.Negate()
    cap_vec = cap_conn.CoordinateSystem.BasisZ
    
    angle = cap_vec.AngleTo(target_vec)
    if angle > 0.01:
        axis = cap_vec.CrossProduct(target_vec)
        if axis.IsZeroLength():
             if abs(cap_vec.Z) < 0.99: axis = cap_vec.CrossProduct(XYZ.BasisZ)
             else: axis = cap_vec.CrossProduct(XYZ.BasisX)
        line_axis = Line.CreateBound(insert_point, insert_point + axis)
        DB.ElementTransformUtils.RotateElement(doc, cap_inst.Id, line_axis, angle)
        doc.Regenerate()

    cap_conn_new = None
    for c in cap_inst.MEPModel.ConnectorManager.Connectors: cap_conn_new = c; break
    
    translation = pipe_end_connector.Origin - cap_conn_new.Origin
    if not translation.IsZeroLength():
        DB.ElementTransformUtils.MoveElement(doc, cap_inst.Id, translation)

    try:
        cap_conn_new.ConnectTo(pipe_end_connector)
        return True
    except: return False

def get_connector_closest(element, point):
    if not element: return None
    conns = element.ConnectorManager.Connectors
    min_d = float('inf'); best_c = None
    for c in conns:
        d = c.Origin.DistanceTo(point)
        if d < min_d: min_d = d; best_c = c
    return best_c

# =======================================================
# 2. MAIN LOOP (INTERACTIVE)
# =======================================================
def main():
    while True:
        try:
            ref = uidoc.Selection.PickObject(Sel.ObjectType.Element, PipeSelectionFilter(), "Click đầu ống (ESC thoát)")
            pipe = doc.GetElement(ref)
            click_point = ref.GlobalPoint
            
            t = DB.Transaction(doc, "Auto Cap V15.11 Omni")
            t.Start()

            try:
                target_conn = get_connector_closest(pipe, click_point)
                if not target_conn or target_conn.IsConnected:
                    t.RollBack(); continue

                dia_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
                pipe_dia = dia_param.AsDouble()
                
                cap_symbol = get_best_cap_symbol(doc, pipe, pipe_dia)
                if not cap_symbol:
                    t.RollBack(); continue
                
                if not cap_symbol.IsActive: cap_symbol.Activate(); doc.Regenerate()

                new_pipe = create_45_up_extension_dynamic(doc, pipe, target_conn)
                doc.Regenerate()

                if new_pipe:
                    c1 = target_conn
                    c2 = get_connector_closest(new_pipe, target_conn.Origin)
                    try: 
                        doc.Create.NewElbowFitting(c1, c2)
                    except Exception: 
                        doc.Delete(new_pipe.Id)
                        t.RollBack(); continue
                    
                    doc.Regenerate()

                    conns_new = new_pipe.ConnectorManager.Connectors
                    c_pipe_end = None
                    for c in conns_new:
                        if not c.IsConnected: c_pipe_end = c; break
                    
                    if c_pipe_end:
                        place_cap_v14_robot(doc, c_pipe_end, cap_symbol, pipe_dia)
                
                t.Commit()
            
            except Exception:
                t.RollBack()

        except Autodesk.Revit.Exceptions.OperationCanceledException:
            break
        except Exception as e:
            forms.alert("LỖI NGHIÊM TRỌNG: " + str(e))
            break

if __name__ == "__main__":
    main()