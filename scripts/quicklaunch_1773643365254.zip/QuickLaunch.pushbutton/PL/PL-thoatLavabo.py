# -*- coding: utf-8 -*-
import clr
import sys
import math
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Structure import StructuralType
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
import Autodesk.Revit.Exceptions as Extensions

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- THÔNG SỐ ĐẦU VÀO ---
MM_TO_FT = 1 / 304.8
ELEVATION_MM = 450.0         # Cao độ ống ngang (so với Level)
REDUCER_ELEVATION_MM = 100.0 # Cao độ đặt giảm cấp (so với Level)
HORIZ_LENGTH_MM = 150.0      # Chiều dài ống ngang MONG MUỐN
PIPE_DIA_MM = 48.0           # Đường kính ống nhánh (D48)

# --- CLASSES HỖ TRỢ LẶP LIÊN TỤC VÀ NUỐT CẢNH BÁO ---
class PipeFilter(ISelectionFilter):
    def AllowElement(self, element):
        if element.Category and element.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves):
            return True
        return False
    def AllowReference(self, reference, position): return False

class WarningSwallower(IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        if failures.Count == 0: return FailureProcessingResult.Continue
        for f in failures:
            if f.GetSeverity() == FailureSeverity.Warning: failuresAccessor.DeleteWarning(f)
            else: failuresAccessor.ResolveFailure(f); return FailureProcessingResult.ProceedWithCommit
        return FailureProcessingResult.Continue

# --- HÀM PHỤ TRỢ ---
def get_specific_cap_symbol():
    target_type_name = u"Đầu bịt trơn uPVC" 
    collector = FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_PipeFitting)
    for symbol in collector:
        name_param = symbol.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
        type_name = name_param.AsString() if name_param else ""
        if not type_name:
            try: type_name = symbol.Name
            except: pass
        if type_name == target_type_name:
            if not symbol.IsActive: symbol.Activate()
            return symbol
    return None

def get_connector_closest_to(mep_element, pt):
    best_conn = None
    min_dist = float('inf')
    if mep_element.ConnectorManager:
        for conn in mep_element.ConnectorManager.Connectors:
            dist = conn.Origin.DistanceTo(pt)
            if dist < min_dist:
                min_dist = dist
                best_conn = conn
    return best_conn

def get_first_connector(inst):
    if inst.MEPModel and inst.MEPModel.ConnectorManager:
        for conn in inst.MEPModel.ConnectorManager.Connectors:
            return conn
    return None

# --- LOGIC XỬ LÝ CHÍNH ---
def process_lavabo_smart(pipe_main, click_pt):
    level = doc.GetElement(pipe_main.LevelId)
    if not level: return

    sys_type_id = pipe_main.MEPSystem.GetTypeId()
    pipe_type_id = pipe_main.GetTypeId()
    level_id = pipe_main.LevelId
    
    z_450 = level.Elevation + (ELEVATION_MM * MM_TO_FT)
    z_100 = level.Elevation + (REDUCER_ELEVATION_MM * MM_TO_FT)
    dia_48_ft = PIPE_DIA_MM * MM_TO_FT

    curve = pipe_main.Location.Curve
    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)
    
    if p0.Z > p1.Z:
        top_pt, bot_pt = p0, p1
    else:
        top_pt, bot_pt = p1, p0

    cx, cy = bot_pt.X, bot_pt.Y
    
    # -------------------------------------------------------------------
    # THUẬT TOÁN BẮT HƯỚNG VUÔNG GÓC
    # -------------------------------------------------------------------
    vec_click = XYZ(click_pt.X - cx, click_pt.Y - cy, 0)
    if vec_click.GetLength() < 0.001: vec_click = XYZ(1, 0, 0) 
    vec_click = vec_click.Normalize()

    directions = [XYZ(1, 0, 0), XYZ(-1, 0, 0), XYZ(0, 1, 0), XYZ(0, -1, 0)]
    best_dir = XYZ(1, 0, 0)
    max_dot = -1.0 
    
    for d in directions:
        val = vec_click.DotProduct(d)
        if val > max_dot:
            max_dot = val
            best_dir = d
            
    dir_vec = best_dir

    # 1. ÉP ỐNG CHÍNH VỀ CAO ĐỘ GIẢM CẤP
    if bot_pt.Z >= z_100: return 

    new_top = XYZ(cx, cy, z_100)
    pipe_main.Location.Curve = Line.CreateBound(bot_pt, new_top)
    doc.Regenerate()

    # 2. TẠO ỐNG ĐỨNG D48
    p_v_bot = new_top
    p_v_top = XYZ(cx, cy, z_450)
    pipe_v = Pipe.Create(doc, sys_type_id, pipe_type_id, level_id, p_v_bot, p_v_top)
    pipe_v.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_48_ft)
    doc.Regenerate()

    # 3. TẠO ỐNG NGANG D48
    p_h_end = p_v_top + dir_vec * (HORIZ_LENGTH_MM * MM_TO_FT)
    pipe_h = Pipe.Create(doc, sys_type_id, pipe_type_id, level_id, p_v_top, p_h_end)
    pipe_h.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_48_ft)
    doc.Regenerate()

    # 4. GẮN PHỤ KIỆN (GIẢM CẤP & CO)
    conn_main_top = get_connector_closest_to(pipe_main, p_v_bot)
    conn_v_bot = get_connector_closest_to(pipe_v, p_v_bot)
    conn_v_top = get_connector_closest_to(pipe_v, p_v_top)
    conn_h_start = get_connector_closest_to(pipe_h, p_v_top)
    conn_h_end = get_connector_closest_to(pipe_h, p_h_end)

    try: doc.Create.NewTransitionFitting(conn_main_top, conn_v_bot)
    except: conn_main_top.ConnectTo(conn_v_bot)

    doc.Create.NewElbowFitting(conn_v_top, conn_h_start)
    doc.Regenerate()

    # 5. GẮN NẮP BỊT & XOAY HƯỚNG
    cap_symbol = get_specific_cap_symbol()
    if cap_symbol:
        cap_inst = doc.Create.NewFamilyInstance(conn_h_end.Origin, cap_symbol, level, StructuralType.NonStructural)
        doc.Regenerate()
        
        cap_conn = get_first_connector(cap_inst)
        
        # Ép size
        pipe_radius = dia_48_ft / 2.0
        params_to_try = [("ND", dia_48_ft), ("Nominal Diameter", dia_48_ft), ("Nominal Radius", pipe_radius), ("Kích thước", dia_48_ft)]
        for p_name, p_val in params_to_try:
            param = cap_inst.LookupParameter(p_name)
            if param and not param.IsReadOnly:
                try: param.Set(p_val)
                except: pass
        doc.Regenerate()
        cap_conn = get_first_connector(cap_inst)

        # Xoay Cap
        pipe_dir = conn_h_end.CoordinateSystem.BasisZ
        cap_dir = cap_conn.CoordinateSystem.BasisZ
        target_dir = pipe_dir.Negate()
        
        angle = cap_dir.AngleTo(target_dir)
        if angle > 0.001:
            axis = cap_dir.CrossProduct(target_dir)
            if axis.GetLength() < 0.001: axis = cap_conn.CoordinateSystem.BasisX
            rot_line = Line.CreateBound(cap_conn.Origin, cap_conn.Origin + axis)
            ElementTransformUtils.RotateElement(doc, cap_inst.Id, rot_line, angle)
            doc.Regenerate()
            cap_conn = get_first_connector(cap_inst)

        # Khớp tâm và nối ngàm
        vec = conn_h_end.Origin - cap_conn.Origin
        if vec.GetLength() > 0.001:
            ElementTransformUtils.MoveElement(doc, cap_inst.Id, vec)
            doc.Regenerate()

        is_pinned = pipe_h.Pinned
        pipe_h.Pinned = True
        try: conn_h_end.ConnectTo(cap_conn)
        finally: pipe_h.Pinned = is_pinned

        # -------------------------------------------------------------------
        # 6. FIX CHIỀU DÀI ỐNG NGANG CHUẨN 150MM (BÙ TRỪ NGÀM)
        # -------------------------------------------------------------------
        doc.Regenerate() # Cập nhật mô hình sau khi ConnectTo
        
        # Đọc chiều dài thực tế hiện tại
        current_length_ft = pipe_h.get_Parameter(BuiltInParameter.CURVE_ELEM_LENGTH).AsDouble()
        target_length_ft = HORIZ_LENGTH_MM * MM_TO_FT
        
        # Tính khoảng hao hụt
        diff_ft = target_length_ft - current_length_ft
        
        # Nếu hụt, kéo cái nắp bịt tịnh tiến ra ngoài, ống sẽ tự giãn theo
        if abs(diff_ft) > 0.0001:
            move_vec = dir_vec * diff_ft
            ElementTransformUtils.MoveElement(doc, cap_inst.Id, move_vec)
            doc.Regenerate()

# --- CHẠY VÒNG LẶP LIÊN TỤC ---
def run_script():
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, PipeFilter(), "Click hướng nào -> Chĩa Lavabo hướng đó (Bấm ESC để thoát)")
            pipe_main = doc.GetElement(ref)
            pick_point = ref.GlobalPoint 

            t = Transaction(doc, "Auto Lavabo Rough-in")
            
            opt = t.GetFailureHandlingOptions()
            opt.SetFailuresPreprocessor(WarningSwallower())
            opt.SetClearAfterRollback(True)
            t.SetFailureHandlingOptions(opt)
            
            t.Start()
            process_lavabo_smart(pipe_main, pick_point)
            t.Commit()
            
        except Extensions.OperationCanceledException:
            break
        except Exception as e:
            # print("Lỗi: ", e)
            break

if __name__ == "__main__": 
    run_script()