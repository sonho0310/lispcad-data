# -*- coding: utf-8 -*-
import clr
import math

# Import thư viện Revit API
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

# Khai báo biến
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# Bộ lọc đối tượng MEP
class MEPCurveFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Location and isinstance(elem.Location, LocationCurve):
            return True
        return False
    def AllowReference(self, reference, position):
        return True

def align_3d_no_slide():
    while True:
        t = Transaction(doc, "Align 3D No Slide")
        try:
            # ==========================================
            # BƯỚC 1: Chọn ống CHUẨN (Source)
            # ==========================================
            try:
                ref_source = uidoc.Selection.PickObject(
                    ObjectType.Element, 
                    MEPCurveFilter(), 
                    "Chọn ống CHUẨN (Source) - ESC để thoát"
                )
            except Autodesk.Revit.Exceptions.OperationCanceledException:
                break 

            elem_source = doc.GetElement(ref_source)
            c_src = elem_source.Location.Curve
            # Đường thẳng vô tận của Source
            line_source = Line.CreateUnbound(c_src.Origin, c_src.Direction)

            # ==========================================
            # BƯỚC 2: Chọn ống CẦN ALIGN (Target)
            # ==========================================
            try:
                ref_target = uidoc.Selection.PickObject(
                    ObjectType.Element, 
                    MEPCurveFilter(), 
                    "Chọn ống CẦN ALIGN (Target)"
                )
            except Autodesk.Revit.Exceptions.OperationCanceledException:
                break 

            elem_target = doc.GetElement(ref_target)
            if elem_target.Id == elem_source.Id:
                continue

            # ==========================================
            # TÍNH TOÁN VECTOR (QUAN TRỌNG)
            # ==========================================
            t.Start()

            # 1. Lấy điểm bất kỳ trên tim ống Target (tại vị trí click)
            # Lưu ý: Lấy GlobalPoint rồi chiếu vào Curve để lấy đúng tâm ống
            pt_clicked = ref_target.GlobalPoint
            c_target = elem_target.Location.Curve
            line_target_axis = Line.CreateUnbound(c_target.Origin, c_target.Direction)
            
            # Điểm tâm thực sự trên ống Target
            pt_center_target = line_target_axis.Project(pt_clicked).XYZPoint

            # 2. Tìm điểm đích trên ống Source (Project điểm Target lên Source)
            # Đây là vị trí mà ống Target muốn bay tới (để cắt nhau hoặc đồng phẳng)
            res_proj_source = line_source.Project(pt_center_target)
            
            if res_proj_source:
                pt_destination = res_proj_source.XYZPoint
                
                # 3. Vector thô (Raw Vector): Kéo Target đập thẳng vào Source
                # Vector này chứa cả thành phần X, Y, Z
                raw_vector_3d = pt_destination - pt_center_target
                
                # 4. KHỬ TRƯỢT (Anti-Slide Logic)
                # Lấy hướng của ống Target
                target_dir = c_target.Direction.Normalize()
                
                # Tính thành phần trượt (Projection của raw_vector lên trục ống Target)
                # DotProduct cho biết độ dài hình chiếu
                slide_magnitude = raw_vector_3d.DotProduct(target_dir)
                
                # Tạo vector trượt
                slide_vector = target_dir.Multiply(slide_magnitude)
                
                # 5. Vector cuối cùng = Vector thô - Vector trượt
                # Kết quả: Chỉ còn lại chuyển động vuông góc với thân ống
                final_move_vector = raw_vector_3d - slide_vector
                
                # 6. Di chuyển
                if final_move_vector.GetLength() > 0.001:
                    ElementTransformUtils.MoveElement(doc, elem_target.Id, final_move_vector)
            
            t.Commit()

        except Exception as e:
            print("Lỗi: " + str(e))
            if t.GetStatus() == TransactionStatus.Started:
                t.RollBack()
            break

# Chạy script
align_3d_no_slide()