# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import revit, script

# ==========================================
# CẤU HÌNH (SỬA Ở ĐÂY)
# True  = Chế độ CẶP (PAIRS): Chọn A -> Chọn B (B nhảy), rồi lại Chọn C -> Chọn D (D nhảy)...
# False = Chế độ CHÙM (BATCH): Chọn A làm gốc -> Quét chọn B, C, D, E... (tất cả nhảy theo A)
SINGLE_MODE = True 
# ==========================================

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

class FastGeom:
    @staticmethod
    def get_info(elem):
        """Lấy thông tin hình học"""
        loc = elem.Location
        if not isinstance(loc, LocationCurve):
            return None
        line = loc.Curve
        p0 = line.GetEndPoint(0)
        p1 = line.GetEndPoint(1)
        # Check vertical
        is_vert = abs(p0.X - p1.X) < 0.001 and abs(p0.Y - p1.Y) < 0.001
        return {"line": line, "p0": p0, "p1": p1, "is_vert": is_vert}

    @staticmethod
    def flatten(pt):
        return XYZ(pt.X, pt.Y, 0)

def get_align_vector(src, target_elem):
    """Tính toán vector dịch chuyển"""
    tgt = FastGeom.get_info(target_elem)
    if not tgt: return None

    src_p0_2d = FastGeom.flatten(src['p0'])
    src_p1_2d = FastGeom.flatten(src['p1'])
    src_vec_2d = (src_p1_2d - src_p0_2d).Normalize() if not src['is_vert'] else None
    
    final_vec = None

    # CASE: Source ĐỨNG
    if src['is_vert']:
        tgt_p0_2d = FastGeom.flatten(tgt['p0'])
        if not tgt['is_vert']:
            # Target ngang: Chiếu tâm source lên line target
            line_tgt_2d = Line.CreateUnbound(tgt_p0_2d, (FastGeom.flatten(tgt['p1']) - tgt_p0_2d).Normalize())
            proj = line_tgt_2d.Project(src_p0_2d)
            if proj: final_vec = src_p0_2d - proj.XYZPoint
        else:
            # Target đứng: Khớp tâm XY
            final_vec = src_p0_2d - tgt_p0_2d

    # CASE: Source NGANG
    else:
        tgt_p0_2d = FastGeom.flatten(tgt['p0'])
        line_src_2d = Line.CreateUnbound(src_p0_2d, src_vec_2d)
        
        if tgt['is_vert']:
            # Target đứng -> Về nằm trên line source
            proj = line_src_2d.Project(tgt_p0_2d)
            if proj: final_vec = proj.XYZPoint - tgt_p0_2d
        else:
            # Target ngang -> Align Cao độ (Z)
            tgt_p1_2d = FastGeom.flatten(tgt['p1'])
            mid_tgt_2d = (tgt_p0_2d + tgt_p1_2d) * 0.5
            proj = line_src_2d.Project(mid_tgt_2d)
            
            if proj:
                # Tính Z tương đối
                dist_src = (proj.XYZPoint - src_p0_2d).DotProduct(src_vec_2d)
                len_src_2d = src_p0_2d.DistanceTo(src_p1_2d)
                z_src = src['p0'].Z + (dist_src * (src['p1'].Z - src['p0'].Z) / len_src_2d) if len_src_2d > 0 else src['p0'].Z
                
                tgt_vec_2d = (tgt_p1_2d - tgt_p0_2d).Normalize()
                dist_tgt = (proj.XYZPoint - tgt_p0_2d).DotProduct(tgt_vec_2d)
                len_tgt_2d = tgt_p0_2d.DistanceTo(tgt_p1_2d)
                z_tgt = tgt['p0'].Z + (dist_tgt * (tgt['p1'].Z - tgt['p0'].Z) / len_tgt_2d) if len_tgt_2d > 0 else tgt['p0'].Z
                
                final_vec = XYZ(0, 0, z_src - z_tgt)
    
    return final_vec

def main():
    # ---------------------------------------------------------
    # MODE 1: ALIGN TỪNG CẶP (A->B, C->D...)
    # ---------------------------------------------------------
    if SINGLE_MODE:
        while True:
            # 1. Chọn Source (Nếu Esc ở bước này -> Thoát luôn)
            try:
                source_ref = uidoc.Selection.PickObject(ObjectType.Element, "Align Center: Chọn MẪU (Esc để thoát)")
                source_elem = doc.GetElement(source_ref)
                src = FastGeom.get_info(source_elem)
                if not src: continue # Chọn sai loại đối tượng thì chọn lại
            except: 
                break # Thoát vòng lặp chính

            # 2. Chọn Target (Nếu Esc ở bước này -> Quay lại chọn Source mới hay Thoát? Thường là thoát)
            try:
                target_ref = uidoc.Selection.PickObject(ObjectType.Element, "Align Center: Chọn đối tượng cần Align")
                if target_ref.ElementId == source_elem.Id: continue
                target_elem = doc.GetElement(target_ref)
                
                # Tính toán & Move
                vec = get_align_vector(src, target_elem)
                if vec and vec.GetLength() > 0.0001:
                    with revit.Transaction("Align Element"):
                        ElementTransformUtils.MoveElement(doc, target_elem.Id, vec)
            except:
                break # Thoát vòng lặp

    # ---------------------------------------------------------
    # MODE 2: ALIGN HÀNG LOẠT (A -> B, C, D...)
    # ---------------------------------------------------------
    else:
        # 1. Chọn Source (Chỉ 1 lần)
        try:
            source_ref = uidoc.Selection.PickObject(ObjectType.Element, "Align BATCH: Chọn MẪU Center")
            source_elem = doc.GetElement(source_ref)
            src = FastGeom.get_info(source_elem)
            if not src: return
        except: return

        # 2. Quét chọn nhiều Target
        try:
            target_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Quét chọn các đối tượng cần Align")
            if not target_refs: return
        except: return

        # 3. Thực hiện
        with revit.Transaction("Batch Align"):
            for ref in target_refs:
                if ref.ElementId == source_elem.Id: continue
                target_elem = doc.GetElement(ref)
                
                vec = get_align_vector(src, target_elem)
                if vec and vec.GetLength() > 0.0001:
                    try:
                        ElementTransformUtils.MoveElement(doc, target_elem.Id, vec)
                    except: pass

if __name__ == "__main__":
    main()