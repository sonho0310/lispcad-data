# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit

# --- TỐI ƯU HÓA: KHAI BÁO BIẾN TOÀN CỤC ĐỂ GIẢM TẢI ---
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
t_ops = ElementTransformUtils

# --- TỐI ƯU HÓA: BỘ LỌC CHỈ CHO PHÉP CHỌN MEP (Click cực nhanh) ---
class MEPCurveFilter(ISelectionFilter):
    def AllowElement(self, elem):
        # Chỉ cho phép chọn đối tượng có đường dẫn (MEP Curve)
        # Giúp chuột không bị dính vào tường, sàn, cột...
        return hasattr(elem.Location, "Curve")

    def AllowReference(self, reference, position):
        return True

# Khởi tạo bộ lọc 1 lần dùng mãi mãi
mep_filter = MEPCurveFilter()

# Cache các tham số thường dùng để không phải load lại
PARAMS_TO_CHECK = [
    BuiltInParameter.RBS_PIPE_OUTER_DIAMETER,       # Ống nước
    BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,        # Ống gió Rect / Máng
    BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,      # Ống gió Tròn
    BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM,    # Conduit
    BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM     # Cable Tray
]

def get_half_dim_fast(elem):
    """Lấy bán kính/nửa chiều cao cực nhanh"""
    for p_code in PARAMS_TO_CHECK:
        p = elem.get_Parameter(p_code)
        if p and p.HasValue:
            val = p.AsDouble()
            return val * 0.5 if val > 0 else 0.0
    return 0.0

def main():
    # Vòng lặp vô tận, chỉ dừng khi nhấn ESC
    while True:
        try:
            # --- BƯỚC 1: CHỌN MẪU (A) ---
            # Dùng mep_filter để bắt dính ngay lập tức
            ref_src = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn MẪU (A)")
            elem_src = doc.GetElement(ref_src)

            # --- BƯỚC 2: CHỌN ĐỐI TƯỢNG CẦN SỬA (B) ---
            ref_tgt = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ĐỐI TƯỢNG (B) -> Align ngay")
            elem_tgt = doc.GetElement(ref_tgt)

            # Bỏ qua nếu chọn trùng hoặc target không có curve
            if elem_src.Id == elem_tgt.Id or not hasattr(elem_tgt.Location, "Curve"):
                continue

            # --- BƯỚC 3: TÍNH TOÁN VÀ DI CHUYỂN (Gộp Transaction để xử lý tức thì) ---
            with revit.Transaction("Align Fast", doc):
                # 1. Lấy hình học Source
                c_src = elem_src.Location.Curve
                r_src = get_half_dim_fast(elem_src)
                
                # Tạo Line vô tận từ Source để chiếu (nhanh hơn tạo mặt phẳng)
                p0 = c_src.GetEndPoint(0)
                p1 = c_src.GetEndPoint(1)
                
                # Trick: Project điểm 2D (bỏ qua Z để tìm giao điểm trên mặt bằng)
                line_src_2d = Line.CreateUnbound(XYZ(p0.X, p0.Y, 0), (XYZ(p1.X, p1.Y, 0) - XYZ(p0.X, p0.Y, 0)).Normalize())
                
                # 2. Lấy hình học Target
                c_tgt = elem_tgt.Location.Curve
                r_tgt = get_half_dim_fast(elem_tgt)
                
                # Lấy trung điểm Target
                mid_tgt = c_tgt.Evaluate(0.5, True)
                mid_tgt_2d = XYZ(mid_tgt.X, mid_tgt.Y, 0)

                # 3. Tính Delta Z
                # Chiếu trung điểm Target vào đường Source trên mặt bằng
                proj_res = line_src_2d.Project(mid_tgt_2d)
                
                if proj_res:
                    # Tính Z tại điểm chiếu trên Source (Interpolation cho ống dốc)
                    dist_src = XYZ(p0.X, p0.Y, 0).DistanceTo(proj_res.XYZPoint)
                    total_len = XYZ(p0.X, p0.Y, 0).DistanceTo(XYZ(p1.X, p1.Y, 0))
                    
                    if total_len > 0.001:
                        # Nội suy tuyến tính cao độ Z của Source tại vị trí cắt
                        z_src_at_cut = p0.Z + (p1.Z - p0.Z) * (dist_src / total_len)
                        
                        # Cao độ đỉnh Source = z_src_at_cut + r_src
                        # Cao độ đỉnh Target hiện tại = mid_tgt.Z + r_tgt
                        # Delta cần dịch = Top_Source - Top_Target
                        
                        top_src = z_src_at_cut + r_src
                        top_tgt = mid_tgt.Z + r_tgt
                        move_z = top_src - top_tgt

                        # Di chuyển nếu sai số > 0.1mm
                        if abs(move_z) > 0.0003: # ~0.1mm
                            t_ops.MoveElement(doc, elem_tgt.Id, XYZ(0, 0, move_z))

        except OperationCanceledException:
            # Nhấn ESC để thoát êm
            break
        except Exception:
            # Gặp lỗi lạ (click trượt) thì bỏ qua vòng lặp này, cho chọn lại ngay
            continue

if __name__ == "__main__":
    main()