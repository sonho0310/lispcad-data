# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit

# --- KHAI BÁO GLOBAL ---
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
t_ops = ElementTransformUtils

# --- BỘ LỌC ĐỐI TƯỢNG (Giúp chuột bắt dính cực nhanh) ---
class MEPCurveFilter(ISelectionFilter):
    def AllowElement(self, elem):
        # Chỉ cho phép chọn đối tượng MEP có đường dẫn (LocationCurve)
        return hasattr(elem.Location, "Curve")

    def AllowReference(self, reference, position):
        return True

# Khởi tạo filter
mep_filter = MEPCurveFilter()

# Cache Parameter ID để không phải tra cứu lại nhiều lần
PARAMS_TO_CHECK = [
    BuiltInParameter.RBS_PIPE_OUTER_DIAMETER,       # Ống nước
    BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,        # Ống gió Rect / Máng / Conduit Rect
    BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,      # Ống gió Tròn
    BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM,    # Conduit Tròn
    BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM     # Cable Tray
]

def get_half_dim_fast(elem):
    """Lấy bán kính hoặc 1/2 chiều cao cực nhanh"""
    for p_code in PARAMS_TO_CHECK:
        p = elem.get_Parameter(p_code)
        if p and p.HasValue:
            val = p.AsDouble()
            return val * 0.5 if val > 0 else 0.0
    return 0.0

def main():
    while True:
        try:
            # --- BƯỚC 1: CHỌN MẪU (Source) ---
            # Status bar sẽ hiện nhắc lệnh
            uidoc.Application.Application.WriteJournalComment("Align Bottom: Waiting for Source...", False)
            ref_src = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Align ĐÁY: Chọn Mẫu (A)")
            elem_src = doc.GetElement(ref_src)

            # --- BƯỚC 2: CHỌN ĐÍCH (Target) ---
            ref_tgt = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Align ĐÁY: Chọn Đối tượng sửa (B)")
            elem_tgt = doc.GetElement(ref_tgt)

            # Kiểm tra cơ bản (tránh lỗi chọn trùng hoặc không phải MEP)
            if elem_src.Id == elem_tgt.Id or not hasattr(elem_tgt.Location, "Curve"):
                continue
            
            # --- BƯỚC 3: TÍNH TOÁN VÀ DI CHUYỂN ---
            with revit.Transaction("Align Bottom Fast", doc):
                # Lấy thông tin Source
                c_src = elem_src.Location.Curve
                r_src = get_half_dim_fast(elem_src) # Bán kính Source
                
                # Tạo Line 2D từ Source để chiếu
                p0 = c_src.GetEndPoint(0)
                p1 = c_src.GetEndPoint(1)
                line_src_2d = Line.CreateUnbound(XYZ(p0.X, p0.Y, 0), (XYZ(p1.X, p1.Y, 0) - XYZ(p0.X, p0.Y, 0)).Normalize())

                # Lấy thông tin Target
                c_tgt = elem_tgt.Location.Curve
                r_tgt = get_half_dim_fast(elem_tgt) # Bán kính Target
                
                # Lấy trung điểm Target
                mid_tgt = c_tgt.Evaluate(0.5, True)
                mid_tgt_2d = XYZ(mid_tgt.X, mid_tgt.Y, 0)

                # Chiếu trung điểm Target vào đường Source (trên mặt bằng 2D)
                proj_res = line_src_2d.Project(mid_tgt_2d)
                
                if proj_res:
                    # Tính khoảng cách từ đầu ống Source đến điểm cắt
                    dist_src = XYZ(p0.X, p0.Y, 0).DistanceTo(proj_res.XYZPoint)
                    total_len = XYZ(p0.X, p0.Y, 0).DistanceTo(XYZ(p1.X, p1.Y, 0))
                    
                    if total_len > 0.001:
                        # Nội suy cao độ tâm (Center Z) của Source tại vị trí cắt
                        z_src_center = p0.Z + (p1.Z - p0.Z) * (dist_src / total_len)
                        
                        # --- CÔNG THỨC ALIGN ĐÁY (BOTTOM) ---
                        # Bottom = Center - Radius
                        bottom_src = z_src_center - r_src
                        bottom_tgt = mid_tgt.Z - r_tgt
                        
                        # Delta Z cần dịch chuyển
                        move_z = bottom_src - bottom_tgt

                        # Thực thi nếu sai số > 0.1mm
                        if abs(move_z) > 0.0003: 
                            t_ops.MoveElement(doc, elem_tgt.Id, XYZ(0, 0, move_z))

        except OperationCanceledException:
            # Nhấn ESC để thoát
            break
        except Exception:
            # Bắt lỗi lặt vặt (click trượt) để không bị crash tool
            continue

if __name__ == "__main__":
    main()