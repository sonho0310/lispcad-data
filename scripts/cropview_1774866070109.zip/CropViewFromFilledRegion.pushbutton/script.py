﻿# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument
view = doc.ActiveView

# --- BỘ LỌC CHỌN ---
class FilledRegionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, FilledRegion)
    def AllowReference(self, ref, point): return False

def execute_final_tool():
    try:
        # 1. INPUT: Cho phép chọn nhiều đối tượng (PickObjects)
        # Lưu ý: Khi dùng PickObjects, User phải quét chọn xong rồi nhấn nút "Finish" trên thanh Option Bar (dưới Ribbon).
        region_refs = uidoc.Selection.PickObjects(ObjectType.Element, FilledRegionFilter(), "QUÉT CHỌN CÁC FILLED REGION (Nhấn nút Finish góc trên bên trái khi chọn xong)")
        
        if not region_refs or len(region_refs) == 0:
            return

        # 2. THU THẬP DỮ LIỆU BIÊN DẠNG TRƯỚC
        boundaries_list = []
        for ref in region_refs:
            region_elem = doc.GetElement(ref)
            boundaries = region_elem.GetBoundaries()
            if boundaries and boundaries.Count > 0:
                boundaries_list.append(boundaries[0]) # Lưu lại vòng ngoài cùng của từng Filled Region

        # 3. THỰC THI (TRANSACTION)
        t = Transaction(doc, "Tạo nhiều View theo Filled Region")
        t.Start()

        # Clean Code: Xóa TẤT CẢ Filled Region vừa chọn ở View gốc TRƯỚC KHI Duplicate.
        # Việc này đảm bảo tất cả các View sinh ra sau đó đều sạch sẽ, không dính bất kỳ Filled Region rác nào.
        for ref in region_refs:
            doc.Delete(ref.ElementId)

        last_new_view = None

        # Vòng lặp: Nhân bản View và áp từng biên dạng
        for outer_loop in boundaries_list:
            # Duplicate View (Nhân bản có kèm chi tiết - WithDetailing)
            new_view_id = view.Duplicate(ViewDuplicateOption.WithDetailing)
            new_view = doc.GetElement(new_view_id)

            # Bật hiển thị Crop View cho View MỚI
            new_view.CropBoxActive = True
            new_view.CropBoxVisible = True 

            # Ốp biên dạng vào Crop Box của View MỚI
            crop_manager = new_view.GetCropRegionShapeManager()
            try:
                crop_manager.SetCropShape(outer_loop)
            except Exception as e:
                print("LỖI: Không thể áp biên dạng đa giác vào View mới. Chi tiết: {}".format(e))
            
            last_new_view = new_view # Lưu lại view cuối cùng được tạo

        t.Commit()

        # 4. AUTO SWITCH VIEW
        # Chuyển màn hình làm việc sang View CUỐI CÙNG vừa được tạo
        if last_new_view:
            uidoc.ActiveView = last_new_view

    except Autodesk.Revit.Exceptions.OperationCanceledException:
        # User nhấn ESC để hủy lệnh -> Im lặng thoát
        pass
    except Exception as e:
        if 't' in locals() and t.HasStarted():
            t.RollBack() # Bảo vệ file nếu crash
        print("LỖI NGHIÊM TRỌNG: {}".format(e))

if __name__ == "__main__":
    execute_final_tool()