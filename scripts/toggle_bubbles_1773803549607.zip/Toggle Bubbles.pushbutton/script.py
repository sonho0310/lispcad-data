# -*- coding: utf-8 -*-
"""
Toggle Head Bubbles V18: Final Fix (Auto Height)
"""
__title__ = "Toggle Bubbles"

from Autodesk.Revit.DB import (
    Transaction, Grid, Level, DatumEnds, ElementId
)
from Autodesk.Revit.UI.Selection import ISelectionFilter, ObjectType
from pyrevit import revit, forms, script
import clr
from System.Collections.Generic import List

# --- WPF IMPORTS ---
clr.AddReference("PresentationFramework")
from System.Windows import Markup, Window, Application
from System.Windows.Input import MouseButtonState

# ==============================================================================
# 1. LOGIC HÌNH HỌC (GIỮ NGUYÊN)
# ==============================================================================
def set_bubble_by_direction(element, view, settings):
    is_show_mode = settings['is_show_mode']
    
    def apply_state(el, end_val, is_active):
        if is_active: 
            if is_show_mode:
                el.ShowBubbleInView(end_val, view)
            else:
                el.HideBubbleInView(end_val, view)

    try:
        # --- LEVEL ---
        if isinstance(element, Level):
            curve = element.Curve
            p0 = curve.GetEndPoint(0)
            p1 = curve.GetEndPoint(1)
            
            if p0.X < p1.X: # End0 bên Trái
                end_left, end_right = DatumEnds.End0, DatumEnds.End1
            else: 
                end_left, end_right = DatumEnds.End1, DatumEnds.End0
            
            apply_state(element, end_left, settings['lvl_left'])
            apply_state(element, end_right, settings['lvl_right'])
            return

        # --- GRID ---
        if isinstance(element, Grid):
            curve = element.Curve
            p0 = curve.GetEndPoint(0)
            p1 = curve.GetEndPoint(1)
            dx = abs(p0.X - p1.X)
            dy = abs(p0.Y - p1.Y)
            is_vertical = dy > dx

            if is_vertical: # DỌC
                if p0.Y > p1.Y: end_top, end_bot = DatumEnds.End0, DatumEnds.End1
                else: end_top, end_bot = DatumEnds.End1, DatumEnds.End0
                
                apply_state(element, end_top, settings['top'])     
                apply_state(element, end_bot, settings['bottom'])  

            else: # NGANG
                if p0.X > p1.X: end_right, end_left = DatumEnds.End0, DatumEnds.End1
                else: end_right, end_left = DatumEnds.End1, DatumEnds.End0
                
                apply_state(element, end_left, settings['left'])  
                apply_state(element, end_right, settings['right'])  
    except: pass

# ==============================================================================
# 2. GIAO DIỆN WPF (AUTO HEIGHT)
# ==============================================================================
XAML_UI = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Toggle Head Bubbles" Width="320" SizeToContent="Height"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize" 
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True">
    
    <Window.Resources>
        <SolidColorBrush x:Key="BrandColor" Color="#99CCFF"/>
        <SolidColorBrush x:Key="BrandDark" Color="#005B9F"/>
        <SolidColorBrush x:Key="BrandHover" Color="#Cce5ff"/> 
        <SolidColorBrush x:Key="GrayText" Color="#666666"/>
        <SolidColorBrush x:Key="LightBorder" Color="#E0E0E0"/>

        <Style x:Key="DirectionToggle" TargetType="CheckBox">
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="CheckBox">
                        <Border x:Name="border" Width="60" Height="60" 
                                BorderBrush="{StaticResource BrandColor}" BorderThickness="1.5" 
                                Background="White" CornerRadius="12">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsChecked" Value="True">
                                <Setter TargetName="border" Property="Background" Value="{StaticResource BrandColor}"/>
                                <Setter Property="Foreground" Value="{StaticResource BrandDark}"/>
                                <Setter Property="FontWeight" Value="Bold"/>
                                <Setter TargetName="border" Property="BorderThickness" Value="0"/>
                            </Trigger>
                            <Trigger Property="IsChecked" Value="False">
                                <Setter TargetName="border" Property="Background" Value="White"/>
                                <Setter TargetName="border" Property="BorderBrush" Value="{StaticResource LightBorder}"/>
                                <Setter Property="Foreground" Value="{StaticResource GrayText}"/>
                            </Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="BorderBrush" Value="{StaticResource BrandDark}"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
        
        <Style x:Key="LevelToggle" TargetType="CheckBox">
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="CheckBox">
                        <Border x:Name="border" Width="90" Height="35" 
                                BorderBrush="{StaticResource BrandColor}" BorderThickness="1.5" 
                                Background="White" CornerRadius="8">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsChecked" Value="True">
                                <Setter TargetName="border" Property="Background" Value="{StaticResource BrandColor}"/>
                                <Setter Property="Foreground" Value="{StaticResource BrandDark}"/>
                                <Setter Property="FontWeight" Value="Bold"/>
                                <Setter TargetName="border" Property="BorderThickness" Value="0"/>
                            </Trigger>
                            <Trigger Property="IsChecked" Value="False">
                                <Setter TargetName="border" Property="Background" Value="White"/>
                                <Setter TargetName="border" Property="BorderBrush" Value="{StaticResource LightBorder}"/>
                                <Setter Property="Foreground" Value="{StaticResource GrayText}"/>
                            </Trigger>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="border" Property="BorderBrush" Value="{StaticResource BrandDark}"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="PillBtn" TargetType="Control">
            <Setter Property="Height" Value="28"/>
            <Setter Property="Width" Value="75"/>
            <Setter Property="FontSize" Value="11"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Margin" Value="5"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Control">
                        <Border x:Name="bd" Background="White" BorderBrush="{StaticResource BrandColor}" BorderThickness="1.5" CornerRadius="14">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="ModeRadio" TargetType="RadioButton" BasedOn="{StaticResource PillBtn}">
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="RadioButton">
                         <Border x:Name="bd" Background="White" BorderBrush="{StaticResource BrandColor}" BorderThickness="1.5" CornerRadius="14">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsChecked" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="{StaticResource BrandColor}"/>
                                <Setter Property="Foreground" Value="{StaticResource BrandDark}"/>
                                <Setter TargetName="bd" Property="BorderThickness" Value="0"/>
                            </Trigger>
                            <Trigger Property="IsChecked" Value="False">
                                <Setter TargetName="bd" Property="Background" Value="White"/>
                                <Setter Property="Foreground" Value="{StaticResource BrandDark}"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="ActionBtn" TargetType="Button" BasedOn="{StaticResource PillBtn}">
            <Setter Property="Foreground" Value="{StaticResource BrandDark}"/>
             <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                         <Border x:Name="bd" Background="White" BorderBrush="{StaticResource BrandColor}" BorderThickness="1.5" CornerRadius="14">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="#E3F2FD"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Border Background="White" CornerRadius="20" Margin="10">
        <Border.Effect>
            <DropShadowEffect Color="#B0BEC5" BlurRadius="20" ShadowDepth="0" Opacity="0.5"/>
        </Border.Effect>
        
        <Grid Margin="20">
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> </Grid.RowDefinitions>

            <Grid Grid.Row="0" Margin="0,0,0,10" Background="Transparent" x:Name="HeaderArea">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/> <ColumnDefinition Width="*"/> <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                
                <Path Grid.Column="0" Fill="{StaticResource BrandColor}" Height="24" Width="24" Stretch="Uniform"
                      Data="M12,2C6.48,2 2,6.48 2,12C2,17.52 6.48,22 12,22C17.52,22 22,17.52 22,12C22,6.48 17.52,2 12,2M13,17H11V15H13V17M13,13H11V7H13V13Z"
                      VerticalAlignment="Center" Margin="0,0,10,0"/>

                <StackPanel Grid.Column="1" VerticalAlignment="Center">
                    <TextBlock Text="TOGGLE BUBBLES" FontWeight="Bold" FontSize="16" Foreground="{StaticResource BrandDark}"/>
                    <TextBlock x:Name="txt_Count" Text="Selected: 0" FontSize="11" Foreground="#999" Margin="2,0,0,0"/>
                </StackPanel>

                <Button x:Name="btn_Close" Grid.Column="2" Content="✕" Width="30" Height="30" 
                        Background="Transparent" BorderThickness="0" Foreground="#999" FontWeight="Bold" FontSize="14" Cursor="Hand">
                    <Button.Template>
                        <ControlTemplate TargetType="Button">
                            <Border Background="{TemplateBinding Background}" CornerRadius="15">
                                <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                            </Border>
                            <ControlTemplate.Triggers>
                                <Trigger Property="IsMouseOver" Value="True">
                                    <Setter Property="Background" Value="#F5F5F5"/>
                                    <Setter Property="Foreground" Value="Red"/>
                                </Trigger>
                            </ControlTemplate.Triggers>
                        </ControlTemplate>
                    </Button.Template>
                </Button>
            </Grid>
            
            <Border Grid.Row="1" Margin="0,0,0,15">
                <StackPanel HorizontalAlignment="Center">
                    <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,5">
                        <TextBlock Text="Mode:" VerticalAlignment="Center" Foreground="{StaticResource GrayText}" Margin="0,0,5,0" FontSize="11"/>
                        <RadioButton x:Name="rdo_Show" Content="SHOW" Style="{StaticResource ModeRadio}" IsChecked="True"/>
                        <RadioButton x:Name="rdo_Hide" Content="HIDE" Style="{StaticResource ModeRadio}"/>
                    </StackPanel>
                    
                    <StackPanel Orientation="Horizontal" HorizontalAlignment="Center">
                        <TextBlock Text="Quick:" VerticalAlignment="Center" Foreground="{StaticResource GrayText}" Margin="0,0,5,0" FontSize="11"/>
                        <Button x:Name="btn_All" Content="All" Style="{StaticResource ActionBtn}"/>
                        <Button x:Name="btn_None" Content="None" Style="{StaticResource ActionBtn}"/>
                    </StackPanel>
                </StackPanel>
            </Border>

            <StackPanel Grid.Row="2" Margin="0,0,0,15">
                <TextBlock Text="GRID HEADS" HorizontalAlignment="Center" Foreground="{StaticResource BrandDark}" FontSize="12" FontWeight="Bold" Margin="0,0,0,8"/>
                <Grid HorizontalAlignment="Center">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="65"/> <RowDefinition Height="65"/> <RowDefinition Height="65"/>
                    </Grid.RowDefinitions>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="65"/> <ColumnDefinition Width="65"/> <ColumnDefinition Width="65"/>
                    </Grid.ColumnDefinitions>

                    <CheckBox x:Name="chk_Top" Grid.Row="0" Grid.Column="1" Content="TOP" Style="{StaticResource DirectionToggle}"/>
                    <CheckBox x:Name="chk_Left" Grid.Row="1" Grid.Column="0" Content="LEFT" Style="{StaticResource DirectionToggle}"/>
                    <TextBlock Grid.Row="1" Grid.Column="1" Text="GRIDS" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="#DDD" FontWeight="Bold" FontSize="10"/>
                    <CheckBox x:Name="chk_Right" Grid.Row="1" Grid.Column="2" Content="RIGHT" Style="{StaticResource DirectionToggle}"/>
                    <CheckBox x:Name="chk_Bottom" Grid.Row="2" Grid.Column="1" Content="BOT" Style="{StaticResource DirectionToggle}"/>
                </Grid>
            </StackPanel>

            <StackPanel Grid.Row="3" Margin="0,0,0,20">
                <TextBlock Text="LEVEL HEADS" HorizontalAlignment="Center" Foreground="{StaticResource BrandDark}" FontSize="12" FontWeight="Bold" Margin="0,0,0,8"/>
                <StackPanel Orientation="Horizontal" HorizontalAlignment="Center">
                    <CheckBox x:Name="chk_Lvl_Left" Content="LEFT" Style="{StaticResource LevelToggle}" Margin="0,0,10,0"/>
                    <CheckBox x:Name="chk_Lvl_Right" Content="RIGHT" Style="{StaticResource LevelToggle}"/>
                </StackPanel>
            </StackPanel>

            <Button x:Name="btn_Apply" Grid.Row="4" Content="APPLY CHANGES" Height="45" FontSize="14" FontWeight="Bold" Foreground="White" Cursor="Hand" Margin="0,0,0,10">
                <Button.Template>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" Background="{StaticResource BrandColor}" CornerRadius="22.5">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="{StaticResource BrandHover}"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Button.Template>
            </Button>
            
            <Button x:Name="btn_Sweep" Grid.Row="5" Content="QUÉT CHỌN ĐẦU TRỤC (SWEEP)" Height="45" FontSize="14" FontWeight="Bold" Foreground="White" Cursor="Hand">
                <Button.Template>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" Background="{StaticResource BrandColor}" CornerRadius="22.5">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Background" Value="{StaticResource BrandHover}"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Button.Template>
            </Button>
        </Grid>
    </Border>
</Window>
"""

SWEEP_XAML = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Sweep Toolbar" Height="36" ShowInTaskbar="False"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" Topmost="True">
    
    <Border BorderBrush="#C0D0C0" BorderThickness="0,1,0,1" Background="#EAF1E8" CornerRadius="0">
        <Grid Height="36">
            <StackPanel Orientation="Horizontal" Margin="30,0,0,0" HorizontalAlignment="Left" VerticalAlignment="Center">
                <RadioButton x:Name="rdo_Hide" Content="Ẩn đầu lưới trục" IsChecked="True" VerticalAlignment="Center" Margin="0,0,30,0" Foreground="#333" FontSize="13" FontWeight="SemiBold"/>
                <RadioButton x:Name="rdo_Show" Content="Hiện đầu lưới trục" VerticalAlignment="Center" Foreground="#333" FontSize="13" FontWeight="SemiBold"/>
            </StackPanel>
            
            <TextBlock Text="Quét chọn đầu lưới trục để áp dụng thay đổi, nhấn 'ESC' để thoát lệnh..." 
                       Foreground="#E91E63" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center" FontSize="13"/>
        </Grid>
    </Border>
</Window>
"""

# ==============================================================================
# 3. PYTHON LOGIC
# ==============================================================================
class GridLevelFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, (Grid, Level))
    def AllowReference(self, reference, position): return False

class DirectionForm(Window):
    def __init__(self, count):
        self.ui = Markup.XamlReader.Parse(XAML_UI)
        self.action = None
        
        self.chk_Top = self.ui.FindName("chk_Top")
        self.chk_Bottom = self.ui.FindName("chk_Bottom")
        self.chk_Left = self.ui.FindName("chk_Left")
        self.chk_Right = self.ui.FindName("chk_Right")
        self.chk_Lvl_Left = self.ui.FindName("chk_Lvl_Left")
        self.chk_Lvl_Right = self.ui.FindName("chk_Lvl_Right")
        self.rdo_Show = self.ui.FindName("rdo_Show")
        self.rdo_Hide = self.ui.FindName("rdo_Hide")
        
        self.ui.FindName("txt_Count").Text = "Selected: {}".format(count)
        
        self.ui.FindName("btn_Apply").Click += self.btn_Apply_Click
        self.ui.FindName("btn_Sweep").Click += self.btn_Sweep_Click
        self.ui.FindName("btn_All").Click += self.btn_All_Click
        self.ui.FindName("btn_None").Click += self.btn_None_Click
        self.ui.FindName("btn_Close").Click += self.btn_Close_Click
        self.ui.MouseDown += self.Window_MouseDown

        self.values = None

    def Window_MouseDown(self, sender, args):
        if args.LeftButton == MouseButtonState.Pressed:
            self.ui.DragMove()

    def btn_Close_Click(self, sender, args):
        self.ui.Close()

    def btn_All_Click(self, sender, args):
        for chk in [self.chk_Top, self.chk_Bottom, self.chk_Left, self.chk_Right, self.chk_Lvl_Left, self.chk_Lvl_Right]:
            chk.IsChecked = True

    def btn_None_Click(self, sender, args):
        for chk in [self.chk_Top, self.chk_Bottom, self.chk_Left, self.chk_Right, self.chk_Lvl_Left, self.chk_Lvl_Right]:
            chk.IsChecked = False

    def btn_Apply_Click(self, sender, args):
        self.action = "Apply"
        self.values = {
            "top": self.chk_Top.IsChecked,
            "bottom": self.chk_Bottom.IsChecked,
            "left": self.chk_Left.IsChecked,
            "right": self.chk_Right.IsChecked,
            "lvl_left": self.chk_Lvl_Left.IsChecked,
            "lvl_right": self.chk_Lvl_Right.IsChecked,
            "is_show_mode": self.rdo_Show.IsChecked 
        }
        self.ui.DialogResult = True
        self.ui.Close()

    def btn_Sweep_Click(self, sender, args):
        self.action = "Sweep"
        self.ui.DialogResult = True
        self.ui.Close()
        
    def show_dialog(self):
        return self.ui.ShowDialog()

# ==============================================================================
# 4. MAIN SCRIPT
# ==============================================================================
doc = revit.doc
uidoc = revit.uidoc
view = doc.ActiveView

from Autodesk.Revit.UI.Selection import PickBoxStyle
from Autodesk.Revit.DB import FilteredElementCollector, DatumExtentType

current_selection = []
selection_ids = uidoc.Selection.GetElementIds()

if selection_ids:
    for eid in selection_ids:
        el = doc.GetElement(eid)
        if isinstance(el, (Grid, Level)): current_selection.append(el)

form = DirectionForm(len(current_selection))
if form.show_dialog() == True:
    if form.action == "Apply":
        if not current_selection:
            try:
                refs = uidoc.Selection.PickObjects(
                    ObjectType.Element, 
                    GridLevelFilter(), 
                    "Quét chọn Grid/Level (Finish để hiện bảng)"
                )
                current_selection = [doc.GetElement(r) for r in refs]
            except: script.exit()

        if not current_selection: script.exit()

        ids = List[ElementId]([el.Id for el in current_selection])
        uidoc.Selection.SetElementIds(ids)

        settings = form.values
        t = Transaction(doc, "Toggle Head Bubbles")
        t.Start()
        for el in current_selection:
            set_bubble_by_direction(el, view, settings)
        t.Commit()
        
    elif form.action == "Sweep":
        view_dir = view.ViewDirection
        right_dir = view.RightDirection
        up_dir = view.UpDirection
        origin = view.Origin
        
        def project_to_view(pt):
            v = pt - origin
            x = v.DotProduct(right_dir)
            y = v.DotProduct(up_dir)
            return x, y
            
        all_datums = []
        all_datums.extend(FilteredElementCollector(doc, view.Id).OfClass(Grid).ToElements())
        all_datums.extend(FilteredElementCollector(doc, view.Id).OfClass(Level).ToElements())
        
        if not all_datums:
            forms.alert("Không tìm thấy Grid/Level nào trong View hiện tại.", title="Thông báo")
            script.exit()
            
        class SweepToolbar:
            def __init__(self):
                self.ui = Markup.XamlReader.Parse(SWEEP_XAML)
                self.rdo_Hide = self.ui.FindName("rdo_Hide")
                self.rdo_Show = self.ui.FindName("rdo_Show")
                self.is_closed = False
                self.ui.Closed += self.on_closed

            def on_closed(self, sender, args):
                self.is_closed = True

            def show(self):
                from System.Windows.Interop import WindowInteropHelper
                try:
                    # Khai báo Revit làm Owner để cửa sổ luôn hiển thị trên Revit và thu nhỏ cùng Revit
                    helper = WindowInteropHelper(self.ui)
                    helper.Owner = uidoc.Application.MainWindowHandle
                    
                    # Căn chỉnh vị trí bằng cách lấy toàn bộ kích thước của cửa sổ Revit
                    rect = uidoc.Application.MainWindowExtents
                    self.ui.Width = rect.Right - rect.Left
                    self.ui.Left = rect.Left
                    self.ui.Top = rect.Top + 140
                except Exception as e:
                    import traceback
                    traceback.print_exc()
                    
                self.ui.Show()
                self.ui.UpdateLayout()
                
        sweep_ui = SweepToolbar()
        sweep_ui.show()
        
        while not sweep_ui.is_closed:
            try:
                box = uidoc.Selection.PickBox(PickBoxStyle.Crossing, "Quét Chọn Đầu Trục Tắt/Mở (Nhấn ESC để thoát)")
                
                is_show = sweep_ui.rdo_Show.IsChecked
                
                min_proj = project_to_view(box.Min)
                max_proj = project_to_view(box.Max)
                box_min_x = min(min_proj[0], max_proj[0])
                box_max_x = max(min_proj[0], max_proj[0])
                box_min_y = min(min_proj[1], max_proj[1])
                box_max_y = max(min_proj[1], max_proj[1])
                
                t = Transaction(doc, "Toggle Bubbles (Sweep)")
                t.Start()
                for el in all_datums:
                    try:
                        curves = el.GetCurvesInView(DatumExtentType.ViewSpecific, view)
                        if not curves: continue
                        curve = list(curves)[0] if hasattr(curves, '__iter__') else curves[0]
                        
                        # End 0
                        p0 = curve.GetEndPoint(0)
                        p0_proj = project_to_view(p0)
                        if box_min_x <= p0_proj[0] <= box_max_x and box_min_y <= p0_proj[1] <= box_max_y:
                            if is_show and not el.IsBubbleVisibleInView(DatumEnds.End0, view):
                                el.ShowBubbleInView(DatumEnds.End0, view)
                            elif not is_show and el.IsBubbleVisibleInView(DatumEnds.End0, view):
                                el.HideBubbleInView(DatumEnds.End0, view)
                                
                        # End 1
                        p1 = curve.GetEndPoint(1)
                        p1_proj = project_to_view(p1)
                        if box_min_x <= p1_proj[0] <= box_max_x and box_min_y <= p1_proj[1] <= box_max_y:
                            if is_show and not el.IsBubbleVisibleInView(DatumEnds.End1, view):
                                el.ShowBubbleInView(DatumEnds.End1, view)
                            elif not is_show and el.IsBubbleVisibleInView(DatumEnds.End1, view):
                                el.HideBubbleInView(DatumEnds.End1, view)
                    except:
                        pass
                t.Commit()
            except Exception as e:
                # Cancelled or Error
                if sweep_ui.ui.IsMouseOver:
                    continue
                else:
                    sweep_ui.ui.Close()
                    break