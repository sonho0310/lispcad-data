# -*- coding: utf-8 -*-
"""
Transfer Drafting Views from a source file to the CURRENT active file.
"""
__title__ = 'Transfer\nDrafting Views'

from pyrevit import revit, DB, UI
from pyrevit import forms
from pyrevit import script
import System
from System.Collections.Generic import List
from System.Collections.ObjectModel import ObservableCollection
import os
import stat

doc = revit.doc
app = __revit__.Application

class CopyOptionHandler(DB.IDuplicateTypeNamesHandler):
    def OnDuplicateTypeNamesFound(self, args):
        return DB.DuplicateTypeAction.UseDestinationTypes

class IgnoreWarningsHandler(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning:
                failuresAccessor.DeleteWarning(f)
        return DB.FailureProcessingResult.Continue

class DocItem(object):
    def __init__(self, doc_obj, name):
        self.Doc = doc_obj
        self.Name = name
        self.IsBackground = False
        self._cached_views = None

    def GetViews(self):
        if self._cached_views is not None:
            return self._cached_views
        
        if not self.Doc:
            return []
            
        draft_view_collector = DB.FilteredElementCollector(self.Doc)\
                                 .OfClass(DB.ViewDrafting)\
                                 .WhereElementIsNotElementType()\
                                 .ToElements()
        
        drafting_views = sorted([v for v in draft_view_collector if not v.IsTemplate], key=lambda v: v.Name)
        self._cached_views = [ViewItem(v) for v in drafting_views]
        return self._cached_views

class ViewItem(object):
    def __init__(self, view):
        self.View = view
        self.Name = view.Name
        self._is_selected = True

    @property
    def IsSelected(self):
        return self._is_selected

    @IsSelected.setter
    def IsSelected(self, value):
        self._is_selected = value

class TransferWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name, docs_list):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        self.docs_collection = ObservableCollection[DocItem](docs_list)
        self.ComboDocs.ItemsSource = self.docs_collection
        if self.docs_collection.Count > 0:
            self.ComboDocs.SelectedIndex = 0
            
        self.selected_doc_item = None
        self.selected_views = []
        self._current_views_list = []
        
    def window_mouse_down(self, sender, e):
        from System.Windows.Input import MouseButtonState
        if e.LeftButton == MouseButtonState.Pressed:
            self.DragMove()
            
    def btn_close_click(self, sender, e):
        self.selected_views = []
        self.Close()
        
    def combo_docs_selection_changed(self, sender, e):
        doc_item = self.ComboDocs.SelectedItem
        if doc_item:
            self._current_views_list = doc_item.GetViews()
            self.ListViews.ItemsSource = self._current_views_list
        else:
            self.ListViews.ItemsSource = None
            self._current_views_list = []
            
    def btn_browse_click(self, sender, e):
        file_path = forms.pick_file(file_ext='rvt', title='Pick Source Revit File (.rvt)')
        if not file_path:
            return
            
        # check if already open
        found_d = None
        for d in app.Documents:
            if d.PathName.lower() == file_path.lower():
                found_d = d
                break
                
        if found_d:
            # check if it's already in the list
            for doc_item in self.docs_collection:
                if doc_item.Doc and doc_item.Doc.PathName.lower() == found_d.PathName.lower():
                    self.ComboDocs.SelectedItem = doc_item
                    return
            
            # not in list but open (maybe it's the current doc?, shouldn't copy from itself)
            if found_d.PathName.lower() == doc.PathName.lower():
                forms.alert(u"Không thể copy view từ chính file hiện hành. Vui lòng chọn file khác.")
                return
                
            new_item = DocItem(found_d, found_d.Title + " (Selected)")
            self.docs_collection.Add(new_item)
            self.ComboDocs.SelectedItem = new_item
            return
            
        # Open background
        try:
            if os.path.exists(file_path):
                os.chmod(file_path, stat.S_IWRITE)
        except: pass
        
        try:
            model_path = DB.ModelPathUtils.ConvertUserVisiblePathToModelPath(file_path)
            opts = DB.OpenOptions()
            bg_doc = app.OpenDocumentFile(model_path, opts)
            
            new_item = DocItem(bg_doc, os.path.basename(file_path) + " (Background)")
            new_item.IsBackground = True
            self.docs_collection.Add(new_item)
            self.ComboDocs.SelectedItem = new_item
            
        except Exception as ex:
            forms.alert(u"Lỗi mở file:\n{}".format(ex))

    def txt_search_changed(self, sender, e):
        search_term = self.TxtSearch.Text.lower()
        if not search_term:
            self.ListViews.ItemsSource = self._current_views_list
        else:
            filtered = [item for item in self._current_views_list if search_term in item.Name.lower()]
            self.ListViews.ItemsSource = filtered

    def btn_all_click(self, sender, e):
        displayed_items = self.ListViews.ItemsSource
        if displayed_items:
            for item in displayed_items:
                item.IsSelected = True
            self.ListViews.Items.Refresh()
        
    def btn_none_click(self, sender, e):
        displayed_items = self.ListViews.ItemsSource
        if displayed_items:
            for item in displayed_items:
                item.IsSelected = False
            self.ListViews.Items.Refresh()
        
    def btn_transfer_click(self, sender, e):
        self.selected_doc_item = self.ComboDocs.SelectedItem
        if not self.selected_doc_item:
            forms.alert(u"Vui lòng chọn File Nguồn!")
            return
            
        self.selected_views = [item for item in self._current_views_list if item.IsSelected]
        if not self.selected_views:
            forms.alert(u"Vui lòng chọn ít nhất 1 Drafting View!")
            return
            
        self.Close()

def get_elements_to_copy(source_doc, selected_views):
    view_ids_set = set() # O(1) lookup thay vì O(N) của List, giúp không bị lag
    for v_item in selected_views:
        v = v_item.View
        view_ids_set.add(v.Id)
            
        collector = DB.FilteredElementCollector(source_doc, v.Id).WhereElementIsNotElementType().ToElementIds()
        for eid in collector:
            view_ids_set.add(eid)
            
    # Chuyển trở lại thành List .NET cho revit copy
    view_ids = List[DB.ElementId]()
    for eid in view_ids_set:
        view_ids.Add(eid)
    return view_ids

def main():
    doc_options = []
    for d in app.Documents:
        if d.PathName == doc.PathName and d.Title == doc.Title:
            continue
        name = d.Title
        if d.IsLinked:
            name += " (Link)"
        doc_options.append(DocItem(d, name))
        
    xaml_path = os.path.join(os.path.dirname(__file__), 'window.xaml')
    window = TransferWindow(xaml_path, doc_options)
    window.ShowDialog()
    
    if not window.selected_views:
        return
        
    source_doc_item = window.selected_doc_item
    selected_views = window.selected_views
    source_doc = source_doc_item.Doc
    
    if not source_doc:
        forms.alert(u"Không xác định được file nguồn.", exitscript=True)
        
    copy_ids = get_elements_to_copy(source_doc, selected_views)
    
    copy_options = DB.CopyPasteOptions()
    copy_options.SetDuplicateTypeNamesHandler(CopyOptionHandler())
    
    trans_success = False
    error_msg = ""
    
    try:
        t = DB.Transaction(doc, "Pull Drafting Views")
        t.Start()
        
        failure_opts = t.GetFailureHandlingOptions()
        failure_opts.SetFailuresPreprocessor(IgnoreWarningsHandler())
        t.SetFailureHandlingOptions(failure_opts)
        
        DB.ElementTransformUtils.CopyElements(source_doc, copy_ids, doc, DB.Transform.Identity, copy_options)
        
        t.Commit()
        trans_success = True
    except Exception as e:
        error_msg = str(e)
        if hasattr(t, 'HasStarted') and t.HasStarted():
            t.RollBack()
            
    # Clean up background docs
    for di in window.docs_collection:
        if getattr(di, 'IsBackground', False) and di.Doc:
            try: di.Doc.Close(False)
            except: pass
            
    if trans_success:
        forms.alert(u"Tuyệt vời! Đã nhận (pull) {} view(s) thành công vào File A của bạn.".format(len(selected_views)))
    else:
        forms.alert(u"Lỗi trong quá trình copy:\n{}".format(error_msg))

if __name__ == '__main__':
    main()
