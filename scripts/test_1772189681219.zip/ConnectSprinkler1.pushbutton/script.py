# -*- coding: utf-8 -*-
import math
import traceback
import clr

import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.DB.Plumbing import Pipe, PlumbingUtils
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

# --- CẤU HÌNH ---
SPACER_MM = 200.0   # Khoảng cách đệm
SPACER_FEET = SPACER_MM / 304.8
ELBOW_ROOM_FEET = 0.15 

# --- 1. BỘ LỌC & HÀM SIZE (ĐÃ SỬA LẠI CHUẨN) ---
class SprinklerFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, FamilyInstance) and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_Sprinklers)
    def AllowReference(self, ref, point): return True

class PipeFilter(ISelectionFilter):
    def AllowElement(self, elem): return isinstance(elem, Pipe)
    def AllowReference(self, ref, point): return True

def get_diameter_feet(count):
    """
    Quy tắc size ống CHUẨN:
    1 - 2 đầu: DN25
    3 đầu: DN32
    4 đầu: DN40
    >= 5 đầu: DN50
    """
    if count <= 2: return 25.0 / 304.8  # <--- Đã sửa về DN25
    elif count == 3: return 32.0 / 304.8
    elif count == 4: return 40.0 / 304.8
    else: return 50.0 / 304.8

# --- 2. HÀM KẾT NỐI HỖ TRỢ ---
def get_closest_connector(elem, pt):
    if not elem: return None
    cons = None
    if isinstance(elem, Pipe): cons = elem.ConnectorManager.Connectors
    elif isinstance(elem, FamilyInstance): cons = elem.MEPModel.ConnectorManager.Connectors
    if not cons: return None
    best = None
    min_d = float('inf')
    for c in cons:
        d = c.Origin.DistanceTo(pt)
        if d < min_d: min_d = d; best = c
    return best

def connect_safe(e1, e2):
    try:
        c1_best, c2_best = None, None
        min_dist = float('inf')
        cons1 = e1.ConnectorManager.Connectors
        cons2 = e2.ConnectorManager.Connectors
        for c1 in cons1:
            for c2 in cons2:
                d = c1.Origin.DistanceTo(c2.Origin)
                if d < min_dist: min_dist = d; c1_best = c1; c2_best = c2
        if c1_best and c2_best and min_dist < 0.1:
             if not c1_best.IsConnectedTo(c2_best): c1_best.ConnectTo(c2_best)
    except: pass

def create_elbow_safe(e1, e2, pt):
    try:
        c1 = get_closest_connector(e1, pt)
        c2 = get_closest_connector(e2, pt)
        if c1 and c2: doc.Create.NewElbowFitting(c1, c2)
    except: pass

# --- 3. HÀM CHÍNH ---
def create_branch_final_fix():
    # A. INPUT
    try:
        with forms.WarningBar(title="Quét chọn SPRINKLERS (Xa -> Gần)"):
            refs = uidoc.Selection.PickObjects(ObjectType.Element, SprinklerFilter(), "Chọn Sprinklers")
            sprinklers = [doc.GetElement(r.ElementId) for r in refs]
        if not sprinklers: return

        with forms.WarningBar(title="Chọn ỐNG CHÍNH"):
            ref_main = uidoc.Selection.PickObject(ObjectType.Element, PipeFilter(), "Chọn Main Pipe")
            main_pipe = doc.GetElement(ref_main.ElementId)

        res_h = forms.ask_for_string(default='150', prompt='Độ cao nhánh (mm):', title='Setting')
        if not res_h: return
        offset_feet = float(res_h) / 304.8
    except: return

    # B. XỬ LÝ
    t = Transaction(doc, "Auto Branch Final Fix")
    t.Start()

    try:
        # Thông số
        sys_id = main_pipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
        type_id = main_pipe.PipeType.Id
        level_id = main_pipe.get_Parameter(BuiltInParameter.RBS_START_LEVEL_PARAM).AsElementId()
        dn25 = 25.0 / 304.8

        # 1. Sắp xếp Sprinklers
        main_curve = main_pipe.Location.Curve
        sp_data = []
        for sp in sprinklers:
            pt = sp.Location.Point
            proj = main_curve.Project(pt)
            dist = pt.DistanceTo(proj.XYZPoint) if proj else 0
            sp_data.append({'elem': sp, 'pt': pt, 'dist': dist, 'proj': proj.XYZPoint})
        sp_data.sort(key=lambda x: x['dist'])

        # 2. Chuẩn bị Nodes
        z_main = main_curve.GetEndPoint(0).Z
        z_branch = z_main + offset_feet
        root_proj = sp_data[0]['proj']
        pt_root_branch = XYZ(root_proj.X, root_proj.Y, z_branch)
        
        nodes = []
        # Node Root: Chịu tải TOÀN BỘ đầu phun
        nodes.append({'pt': pt_root_branch, 'type': 'root', 'load': len(sprinklers)})

        for i, item in enumerate(sp_data):
            sp_pt = item['pt']
            node_pt = XYZ(sp_pt.X, sp_pt.Y, z_branch)
            # FIX LỖI TÍNH TẢI Ở ĐÂY:
            # Load tại điểm này = Số lượng đầu phun còn lại (bao gồm cả chính nó)
            load_here = len(sprinklers) - i 
            nodes.append({
                'pt': node_pt,
                'type': 'spk',
                'load': load_here,
                'sp_elem': item['elem']
            })

        # 3. TẠO ỐNG NHÁNH
        for i in range(len(nodes) - 1):
            curr = nodes[i]
            nxt = nodes[i+1]
            p_start = curr['pt']
            p_end = nxt['pt']
            dist_seg = p_start.DistanceTo(p_end)

            # Dia In: Size ống đi vào Node hiện tại
            dia_in = 0.0
            if curr.get('pipe_in'):
                 dia_in = curr['pipe_in'].get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
            elif i == 0: 
                 dia_in = get_diameter_feet(curr['load'])

            # Dia Needed: Size ống cần thiết cho đoạn tiếp theo
            # Đoạn tiếp theo chịu tải của Node tiếp theo (nxt['load'])
            dia_needed = get_diameter_feet(nxt['load'])

            # Logic giảm cấp
            if dia_in > (dia_needed + 0.001) and dist_seg > (SPACER_FEET * 1.5):
                vec = (p_end - p_start).Normalize()
                p_spacer_end = p_start + (vec * SPACER_FEET)
                
                # Spacer (Size to)
                p_spacer = Pipe.Create(doc, sys_id, type_id, level_id, p_start, p_spacer_end)
                p_spacer.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_in)
                
                # Main Pipe (Size nhỏ)
                p_main = Pipe.Create(doc, sys_id, type_id, level_id, p_spacer_end, p_end)
                p_main.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_needed)
                
                connect_safe(p_spacer, p_main)
                curr['pipe_out'] = p_spacer 
                nxt['pipe_in'] = p_main
            else:
                if dist_seg > 0.01:
                    p = Pipe.Create(doc, sys_id, type_id, level_id, p_start, p_end)
                    p.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_needed)
                    curr['pipe_out'] = p
                    nxt['pipe_in'] = p

        # 4. TẠO RISER
        for item in nodes:
            if item['type'] == 'spk':
                sp = item['sp_elem']
                sp_pt = get_closest_connector(sp, sp.Location.Point).Origin
                node_pt = item['pt']
                
                if sp_pt.DistanceTo(node_pt) > 0.01:
                    r = Pipe.Create(doc, sys_id, type_id, level_id, sp_pt, node_pt)
                    r.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dn25)
                    try: get_closest_connector(sp, sp_pt).ConnectTo(get_closest_connector(r, sp_pt))
                    except: pass
                    
                    p_in = item.get('pipe_in')
                    p_out = item.get('pipe_out')
                    c_riser = get_closest_connector(r, node_pt)
                    c_in = get_closest_connector(p_in, node_pt) if p_in else None
                    c_out = get_closest_connector(p_out, node_pt) if p_out else None

                    if c_in and c_out and c_riser:
                        doc.Create.NewTeeFitting(c_in, c_out, c_riser)
                    elif c_in and c_riser and not c_out:
                        doc.Create.NewElbowFitting(c_in, c_riser)

        # 5. KẾT NỐI VÀO MAIN (End Elbow)
        root_node = nodes[0]
        p_first_branch = root_node.get('pipe_out')
        
        if p_first_branch:
            pt_branch = root_node['pt']
            pt_main_center = XYZ(pt_branch.X, pt_branch.Y, main_curve.GetEndPoint(0).Z)
            pt_elbow_loc = XYZ(pt_main_center.X, pt_main_center.Y, pt_main_center.Z + ELBOW_ROOM_FEET)
            
            drop_main = Pipe.Create(doc, sys_id, type_id, level_id, pt_branch, pt_elbow_loc)
            first_dia = p_first_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
            drop_main.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(first_dia)
            
            create_elbow_safe(p_first_branch, drop_main, pt_branch)
            
            p_dummy = Pipe.Create(doc, sys_id, type_id, level_id, pt_elbow_loc, pt_main_center)
            p_dummy.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(first_dia)
            create_elbow_safe(drop_main, p_dummy, pt_elbow_loc)
            doc.Delete(p_dummy.Id)

        t.Commit()
        forms.toast("Đã sửa lỗi size và vị trí giảm!", title="Thành công")

    except Exception as e:
        t.RollBack()
        forms.alert("Lỗi: " + traceback.format_exc())

# Chạy lệnh
create_branch_final_fix()