# -*- coding: utf-8 -*-
"""
Tạo Ceiling Plan từ Floor Plan (View Template = None).
"""

__title__ = "Floor to RCP"
# Imports
from Autodesk.Revit.DB import (
    Transaction,
    ViewPlan,
    ViewType,
    ViewFamilyType,
    ViewFamily,
    ElementId,
    BuiltInParameter,
    FilteredElementCollector
)
from pyrevit import revit, script, forms

# Imports WPF
import clr
clr.AddReference("PresentationFramework")
from System.Windows import Markup
from System.Windows.Controls import (
    Label, TextBox, Button, Grid, ColumnDefinition, RowDefinition, Separator
)

# --- XAML FORM ---
XAML_STRING = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Create Ceiling Plans (No Template)"
        SizeToContent="WidthAndHeight"
        WindowStartupLocation="CenterScreen"
        ResizeMode="NoResize">
    <Grid Margin="15">
        <Grid.ColumnDefinitions>
            <ColumnDefinition Width="Auto" />
            <ColumnDefinition Width="250" />
        </Grid.ColumnDefinitions>
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> <RowDefinition Height="Auto" /> </Grid.RowDefinitions>
        
        <Label Content="Find:" Grid.Row="1" Grid.Column="0" VerticalAlignment="Center" Margin="0,0,10,5"/>
        <TextBox x:Name="find_tb" Grid.Row="1" Grid.Column="1" Margin="0,0,0,5" VerticalAlignment="Center"/>
        
        <Label Content="Replace:" Grid.Row="2" Grid.Column="0" VerticalAlignment="Center" Margin="0,0,10,5"/>
        <TextBox x:Name="replace_tb" Grid.Row="2" Grid.Column="1" Margin="0,0,0,5" VerticalAlignment="Center"/>
        
        <Label Content="Prefix:" Grid.Row="3" Grid.Column="0" VerticalAlignment="Center" Margin="0,0,10,5"/>
        <TextBox x:Name="prefix_tb" Grid.Row="3" Grid.Column="1" Margin="0,0,0,5" VerticalAlignment="Center"/>
        
        <Label Content="Suffix:" Grid.Row="4" Grid.Column="0" VerticalAlignment="Center" Margin="0,0,10,10"/>
        <TextBox x:Name="suffix_tb" Grid.Row="4" Grid.Column="1" Margin="0,0,0,10" VerticalAlignment="Center" /> 
        
        <Separator Grid.Row="5" Grid.ColumnSpan="2" Margin="0,5,0,10" />
        
        <Grid Grid.Row="6" Grid.ColumnSpan="2">
            <Button x:Name="create_button" Content="Create Ceiling Plans" Padding="10" IsDefault="True" FontWeight="Bold"/>
        </Grid>
        
        <Button x:Name="cancel_button" Content="Cancel" Grid.Row="7" Grid.ColumnSpan="2" Margin="0,10,0,0" Padding="3" IsCancel="True"/>
    </Grid>
</Window>
"""

# --- LOGIC FORM ---
class RenameForm(object):
    def __init__(self):
        self.window = Markup.XamlReader.Parse(XAML_STRING)
        self.result = None
        self.find_tb = self.window.FindName("find_tb")
        self.replace_tb = self.window.FindName("replace_tb")
        self.prefix_tb = self.window.FindName("prefix_tb")
        self.suffix_tb = self.window.FindName("suffix_tb")
        self.window.FindName("create_button").Click += self.create_click
        self.window.FindName("cancel_button").Click += self.cancel_click

    def get_values(self):
        return {
            "find": self.find_tb.Text,
            "replace": self.replace_tb.Text,
            "prefix": self.prefix_tb.Text,
            "suffix": self.suffix_tb.Text
        }

    def create_click(self, sender, args):
        self.result = self.get_values()
        self.window.DialogResult = True
        self.window.Close()

    def cancel_click(self, sender, args):
        self.window.DialogResult = False
        self.window.Close()

    def show(self):
        return self.window.ShowDialog()

# --- MAIN SCRIPT ---
doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()

# 1. Lấy Selection
selected_ids = uidoc.Selection.GetElementIds()
if not selected_ids:
    forms.alert("Vui lòng chọn Floor Plan trước.", exitscript=True)

selected_views = []
for view_id in selected_ids:
    el = doc.GetElement(view_id)
    if isinstance(el, ViewPlan) and el.ViewType == ViewType.FloorPlan and not el.IsTemplate:
        selected_views.append(el)

if not selected_views:
    forms.alert("Không có Floor Plan nào hợp lệ được chọn.", exitscript=True)

# 2. Tìm ViewFamilyType cho Ceiling Plan
rcp_type = None
view_types = FilteredElementCollector(doc).OfClass(ViewFamilyType).ToElements()
for vt in view_types:
    if vt.ViewFamily == ViewFamily.CeilingPlan:
        rcp_type = vt
        break

if not rcp_type:
    forms.alert("Không tìm thấy kiểu View Ceiling Plan trong dự án.", exitscript=True)

# 3. Hiện Form
form = RenameForm()
if form.show() != True:
    script.exit()
res = form.result

# 4. Thực thi
new_views_created = []
failed_views = []

with Transaction(doc, 'Create RCP (No Template)') as t:
    t.Start()

    for floor_view in selected_views:
        current_name = floor_view.Name
        
        # Xử lý tên
        base_name = current_name
        if res["find"]:
            base_name = current_name.replace(res["find"], res["replace"])
        final_view_name = "{}{}{}".format(res["prefix"], base_name, res["suffix"])

        level = floor_view.GenLevel
        if not level:
            failed_views.append((current_name, "Không có Level"))
            continue

        try:
            # Tạo RCP
            new_rcp = ViewPlan.Create(doc, rcp_type.Id, level.Id)

            # --- QUAN TRỌNG: GỠ VIEW TEMPLATE ---
            # Set về InvalidElementId để đảm bảo là "None"
            new_rcp.ViewTemplateId = ElementId.InvalidElementId

            # Copy Scope Box & Crop (Để vị trí hiển thị giống Floor Plan)
            try:
                sb_param = floor_view.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP)
                if sb_param and sb_param.HasValue:
                    new_rcp.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP).Set(sb_param.AsElementId())
                
                new_rcp.CropBoxActive = floor_view.CropBoxActive
                new_rcp.CropBoxVisible = floor_view.CropBoxVisible
            except:
                pass # Bỏ qua nếu lỗi property phụ

            # Đổi tên
            try:
                new_rcp.Name = final_view_name
                new_views_created.append((final_view_name, new_rcp.Id))
            except Exception as e:
                failed_views.append((current_name, "Lỗi tên: " + e.message))
                # doc.Delete(new_rcp.Id) # Uncomment nếu muốn xóa view lỗi tên

        except Exception as e:
             failed_views.append((current_name, "Lỗi tạo: " + e.message))

    t.Commit()

# 5. Kết quả
if failed_views:
    output.show()
    print("KẾT QUẢ:")
    print("✔️ Đã tạo: {}".format(len(new_views_created)))
    print("❌ Thất bại: {}".format(len(failed_views)))
    for f in failed_views:
        print("  - {}: {}".format(f[0], f[1]))
elif new_views_created:
    forms.alert("Đã tạo xong {} Ceiling Plan (No Template)!".format(len(new_views_created)))