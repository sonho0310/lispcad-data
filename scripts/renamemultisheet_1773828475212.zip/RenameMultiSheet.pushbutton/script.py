# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from pyrevit import forms, revit, script
import wpf
import os
import codecs 
from System.Windows import Window
from System.Collections.ObjectModel import ObservableCollection
from System.Diagnostics import Process

doc = revit.doc
uidoc = revit.uidoc

# --- Lớp dữ liệu ---
class SheetItem(object):
    def __init__(self, sheet):
        self.Element = sheet
        self.Id = str(sheet.Id.IntegerValue) 
        self.CurrentNumber = sheet.SheetNumber
        self.CurrentName = sheet.Name
        self.NewNumber = sheet.SheetNumber 
        self.NewName = sheet.Name
        self.Status = ""

# --- Giao diện XAML (Thêm Topmost="True") ---
xaml_string = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Batch Rename Sheets" 
        Height="600" Width="900" 
        WindowStartupLocation="CenterScreen"
        Topmost="True"> 
    <Grid Margin="10">
        <Grid.RowDefinitions>
            <RowDefinition Height="50"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="60"/>
        </Grid.RowDefinitions>
        
        <StackPanel Grid.Row="0" Orientation="Horizontal" HorizontalAlignment="Left" VerticalAlignment="Center">
            <Button Content="Export Excel (CSV)" Width="150" Height="30" Margin="0,0,10,0" Click="export_click" Background="#DDDDDD"/>
            <Button Content="Import Excel (CSV)" Width="150" Height="30" Click="import_click" Background="#DDDDDD"/>
            <Label Content="* Xuất > Tool tự mở Excel > Sửa > Import lại." VerticalAlignment="Center" Margin="10,0,0,0" Foreground="Gray" FontStyle="Italic"/>
        </StackPanel>

        <DataGrid Name="dgSheets" Grid.Row="1" AutoGenerateColumns="False" CanUserAddRows="False" SelectionMode="Extended">
            <DataGrid.Columns>
                <DataGridTextColumn Header="ID" Binding="{Binding Id}" IsReadOnly="True" Width="60" Foreground="Gray"/>
                <DataGridTextColumn Header="Current Number" Binding="{Binding CurrentNumber}" IsReadOnly="True" Width="120" Foreground="Gray"/>
                <DataGridTextColumn Header="Current Name" Binding="{Binding CurrentName}" IsReadOnly="True" Width="200" Foreground="Gray"/>
                
                <DataGridTextColumn Header="NEW Number" Binding="{Binding NewNumber}" Width="120" FontWeight="Bold" Foreground="Blue"/>
                <DataGridTextColumn Header="NEW Name" Binding="{Binding NewName}" Width="*" FontWeight="Bold" Foreground="Blue"/>
            </DataGrid.Columns>
        </DataGrid>
        
        <StackPanel Grid.Row="2" Orientation="Horizontal" HorizontalAlignment="Right" VerticalAlignment="Center">
            <Label Content="Tool tự động xử lý trùng lặp (Swap Name)." VerticalAlignment="Center" Margin="0,0,20,0"/>
            <Button Name="btnApply" Content="APPLY RENAME TO REVIT" Width="180" Height="40" Click="apply_click" FontWeight="Bold" Background="#90EE90"/>
        </StackPanel>
    </Grid>
</Window>
"""

class BatchRenameWindow(Window):
    def __init__(self, xaml_source):
        wpf.LoadComponent(self, xaml_source)
        self.sheet_list = ObservableCollection[SheetItem]()
        self.collect_sheets()
        self.dgSheets.ItemsSource = self.sheet_list

    def collect_sheets(self):
        selection = [doc.GetElement(id) for id in uidoc.Selection.GetElementIds()]
        sheets = [s for s in selection if isinstance(s, ViewSheet)]
        
        if not sheets:
            collector = FilteredElementCollector(doc).OfCategory(BuiltInCategory.OST_Sheets).WhereElementIsNotElementType()
            sheets = list(collector)

        sheets.sort(key=lambda x: x.SheetNumber)
        for s in sheets:
            self.sheet_list.Add(SheetItem(s))

    def export_click(self, sender, args):
        # Tạm thời tắt Topmost để hộp thoại Save File hiện lên dễ nhìn hơn
        self.Topmost = False 
        file_path = forms.save_file(file_ext='csv', default_name='Revit_Sheets_Export.csv')
        self.Topmost = True # Bật lại ngay

        if file_path:
            try:
                with codecs.open(file_path, 'w', encoding='utf-8-sig') as f:
                    f.write("ID,CurrentNumber,CurrentName,NewNumber,NewName\n")
                    for item in self.sheet_list:
                        c_name = item.CurrentName.replace(',', ';')
                        n_name = item.NewName.replace(',', ';')
                        line = "{},{},{},{},{}\n".format(item.Id, item.CurrentNumber, c_name, item.NewNumber, n_name)
                        f.write(line)
                
                try:
                    Process.Start(file_path)
                except: pass
            except Exception as e:
                forms.alert("Lỗi: " + str(e))

    def import_click(self, sender, args):
        # Tạm thời tắt Topmost để hộp thoại Pick File hiện lên
        self.Topmost = False
        file_path = forms.pick_file(file_ext='csv')
        self.Topmost = True # Bật lại Topmost ngay lập tức sau khi chọn xong
        
        # Kích hoạt lại cửa sổ để chắc chắn nó focus
        self.Activate() 

        if file_path:
            try:
                updated_count = 0
                with codecs.open(file_path, 'r', encoding='utf-8-sig') as f:
                    lines = f.readlines()
                
                data_map = {} 
                for line in lines[1:]:
                    parts = line.strip().split(',')
                    if len(parts) >= 5:
                        data_map[parts[0]] = (parts[3], parts[4])

                for item in self.sheet_list:
                    if item.Id in data_map:
                        item.NewNumber = data_map[item.Id][0]
                        item.NewName = data_map[item.Id][1]
                        updated_count += 1
                
                self.dgSheets.Items.Refresh()
            except Exception as e:
                forms.alert("Lỗi đọc file: " + str(e))

    def apply_click(self, sender, args):
        t = Transaction(doc, "Batch Rename Sheets")
        t.Start()
        try:
            # STEP 1
            for item in self.sheet_list:
                if item.NewNumber != item.CurrentNumber or item.NewName != item.CurrentName:
                    try:
                        item.Element.SheetNumber = item.NewNumber + "_TEMP_" + item.Id
                    except: pass 
            doc.Regenerate()

            # STEP 2
            success_count = 0
            for item in self.sheet_list:
                if item.NewNumber != item.CurrentNumber or item.NewName != item.CurrentName:
                    try:
                        item.Element.SheetNumber = item.NewNumber
                        item.Element.Name = item.NewName
                        success_count += 1
                    except: pass
            
            t.Commit()
            self.Close()
            forms.alert("Xong! Đã cập nhật {} bản vẽ.".format(success_count))
        except Exception as e:
            t.RollBack()
            forms.alert("Lỗi: " + str(e))

try:
    from System.IO import StringReader
    xaml_reader = StringReader(xaml_string)
    window = BatchRenameWindow(xaml_reader)
    window.ShowDialog()
except Exception as e:
    print(e)