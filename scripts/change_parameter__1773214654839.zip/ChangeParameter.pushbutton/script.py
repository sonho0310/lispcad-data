# -*- coding: utf-8 -*-
import clr
clr.AddReference('System.Windows.Forms')
clr.AddReference('System.Drawing')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')

from Autodesk.Revit.DB import *
from pyrevit import revit, DB, UI, forms, script
import wpf
import sys
import re

doc = revit.doc
uidoc = revit.uidoc

# Lấy các elements được chọn
selected_ids = uidoc.Selection.GetElementIds()

if not selected_ids:
    forms.alert("Vui lòng chọn các View hoặc đối tượng (Elements) từ Project Browser / Màn hình trước khi chạy tool.", title="Cảnh báo")
    sys.exit()

class ElementItem(object):
    def __init__(self, element, param_name=""):
        self.element = element
        self.Id = str(element.Id.IntegerValue)
        self.OriginalValue = self._get_param_value(param_name)
        self.NewValue = self.OriginalValue
        self.Status = ""
        self.param_name = param_name

    def _get_param_value(self, param_name):
        if not param_name:
            return ""
        param = self.element.LookupParameter(param_name)
        if param and param.StorageType == DB.StorageType.String:
            return param.AsString() or ""
        return ""

    def UpdateValue(self, prefix, suffix, find_str, replace_str, delete_str, is_uppercase):
        val = self.OriginalValue
        if find_str:
            # Case-insensitive replace for find_str
            val = re.sub(re.escape(find_str), replace_str, val, flags=re.IGNORECASE)
        if delete_str:
            # Case-insensitive replace for delete_str
            val = re.sub(re.escape(delete_str), "", val, flags=re.IGNORECASE)
        val = prefix + val + suffix
        if is_uppercase:
            val = val.upper()
        self.NewValue = val

    def ReloadOriginal(self, param_name):
        self.param_name = param_name
        self.OriginalValue = self._get_param_value(param_name)
        self.UpdateValue("", "", "", "", "", False)
        self.Status = ""

class BatchRenameWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name):
        forms.WPFWindow.__init__(self, xaml_file_name)
        self.selected_elements = [doc.GetElement(e_id) for e_id in selected_ids]
        
        # Get common string parameters from the first element
        first_elem = self.selected_elements[0]
        self.param_names = []
        for param in first_elem.Parameters:
            # We only allow changing string parameters
            if param.StorageType == DB.StorageType.String and not param.IsReadOnly:
                self.param_names.append(param.Definition.Name)
        
        self.param_names = sorted(list(set(self.param_names)))
        
        if not self.param_names:
            forms.alert("Không tìm thấy parameters dạng chữ (String) có thể sửa trên đối tượng đầu tiên được chọn.", title="Thông báo")
            self.Close()
            return
            
        self.cbParameters.ItemsSource = self.param_names
        if hasattr(self, 'cbCopyToParam'):
            copy_to_params = ["<None>"] + self.param_names
            self.cbCopyToParam.ItemsSource = copy_to_params
            if "Title on Sheet" in self.param_names:
                self.cbCopyToParam.SelectedItem = "Title on Sheet"
            elif "Tiêu đề trên bản vẽ" in self.param_names:
                self.cbCopyToParam.SelectedItem = "Tiêu đề trên bản vẽ"
            else:
                self.cbCopyToParam.SelectedIndex = 0
        
        # Default parameter
        if "View Name" in self.param_names:
            self.cbParameters.SelectedItem = "View Name"
        elif "Tên khung nhìn" in self.param_names:
            self.cbParameters.SelectedItem = "Tên khung nhìn"
        else:
            self.cbParameters.SelectedIndex = 0

        self.element_items = [ElementItem(el, self.cbParameters.SelectedItem) for el in self.selected_elements]
        self.dgElements.ItemsSource = self.element_items

    def CbParameters_SelectionChanged(self, sender, e):
        if not hasattr(self, 'element_items'):
            return
        param_name = self.cbParameters.SelectedItem
        if param_name:
            for item in self.element_items:
                item.ReloadOriginal(param_name)
            self.PreviewChanges(None, None)

    def PreviewChanges(self, sender, e):
        if not hasattr(self, 'element_items'):
            return
            
        is_uppercase = bool(self.chkUpperCase.IsChecked) if hasattr(self, 'chkUpperCase') else False

        # Apply uppercase to textboxes immediately when checked
        if is_uppercase:
            if hasattr(self, 'txtDelete') and self.txtDelete.Text != self.txtDelete.Text.upper():
                self.txtDelete.Text = self.txtDelete.Text.upper()
            if self.txtPrefix.Text != self.txtPrefix.Text.upper():
                self.txtPrefix.Text = self.txtPrefix.Text.upper()
            if self.txtSuffix.Text != self.txtSuffix.Text.upper():
                self.txtSuffix.Text = self.txtSuffix.Text.upper()
            if self.txtFind.Text != self.txtFind.Text.upper():
                self.txtFind.Text = self.txtFind.Text.upper()
            if self.txtReplace.Text != self.txtReplace.Text.upper():
                self.txtReplace.Text = self.txtReplace.Text.upper()

        prefix = self.txtPrefix.Text
        suffix = self.txtSuffix.Text
        find_str = self.txtFind.Text
        replace_str = self.txtReplace.Text
        delete_str = self.txtDelete.Text if hasattr(self, 'txtDelete') else ""

        for item in self.element_items:
            item.UpdateValue(prefix, suffix, find_str, replace_str, delete_str, is_uppercase)
        
        self.dgElements.Items.Refresh()

    def BtnApply_Click(self, sender, e):
        param_name = self.cbParameters.SelectedItem
        if not param_name:
            return

        copy_to_checked = self.chkCopyToParam.IsChecked if hasattr(self, 'chkCopyToParam') else False
        copy_to_param_name = None
        if copy_to_checked and hasattr(self, 'cbCopyToParam'):
            selected = self.cbCopyToParam.SelectedItem
            if selected and selected != "<None>":
                copy_to_param_name = selected

        with revit.Transaction("Batch Change Parameter Value - " + param_name):
            for item in self.element_items:
                param = item.element.LookupParameter(param_name)
                if param and not param.IsReadOnly:
                    try:
                        param.Set(item.NewValue)
                        
                        # Apply to target param if selected and checked
                        if copy_to_param_name:
                            target_param = item.element.LookupParameter(copy_to_param_name)
                            # Fallback if BuiltIn
                            if not target_param and copy_to_param_name == "Title on Sheet":
                                target_param = item.element.get_Parameter(DB.BuiltInParameter.VIEW_DESCRIPTION)
                                
                            if target_param and not target_param.IsReadOnly:
                                target_param.Set(item.NewValue)

                        item.Status = "Thành công"
                    except Exception as ex:
                        item.Status = "Lỗi (Trùng tên?)"
                else:
                    item.Status = "Không có/Chỉ đọc"
        
        # Cập nhật lại OriginalValue sau khi đã apply
        for item in self.element_items:
            if item.Status == "Thành công":
                item.OriginalValue = item.NewValue
        
        self.dgElements.Items.Refresh()
        forms.alert("Đã cập nhật xong!", title="Thành công", warn_icon=False)

    def BtnCancel_Click(self, sender, e):
        self.Close()

    def Window_MouseLeftButtonDown(self, sender, e):
        try:
            from System.Windows.Input import MouseButtonState
            if e.LeftButton == MouseButtonState.Pressed:
                self.DragMove()
        except:
            pass

# Show Window
xaml_path = script.get_bundle_file('ui.xaml')
BatchRenameWindow(xaml_path).ShowDialog()
