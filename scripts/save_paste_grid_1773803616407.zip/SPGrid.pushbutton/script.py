# -*- coding: utf-8 -*-
__title__   = "Lưu/Dán\nLưới trục"
__doc__     = "Công cụ hỗ trợ Lưu/Dán bố cục lưới trục."

import os
import clr

try:
    clr.AddReference('PresentationCore')
    clr.AddReference('PresentationFramework')
    clr.AddReference('WindowsBase')
    clr.AddReference('System.Core')
except Exception:
    pass

from System.Windows.Media import BrushConverter
from System.Windows.Controls import CheckBox
from System.Windows import Thickness
from System.Collections.Generic import HashSet

from pyrevit import revit, DB, UI, forms
from pyrevit.forms import WPFWindow

doc = revit.doc
uidoc = revit.uidoc
active_view = doc.ActiveView

ENV_KEY = "MASTERW_GRID_LAYOUT_VIEW_ID"

bc = BrushConverter()
ColorRed = bc.ConvertFrom("#FF5A5A")
ColorGreen = bc.ConvertFrom("#32CD32")
ColorDark = bc.ConvertFrom("#333333")

class ViewportSelectionFilter(UI.Selection.ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, DB.Viewport)
    def AllowReference(self, ref, pos):
        return True

def do_copy_layout(view):
    if not isinstance(view, (DB.ViewPlan, DB.ViewSection)):
        forms.alert("Vui lòng mở một mặt bằng, mặt đứng/mặt cắt \nhoặc Pick đúng Viewport để LƯU bố cục.", title="Cảnh báo")
        return False
    
    grids = DB.FilteredElementCollector(doc, view.Id)\
              .OfCategory(DB.BuiltInCategory.OST_Grids)\
              .WhereElementIsNotElementType().ToElements()
              
    if not grids:
        forms.alert("Không tìm thấy lưới trục nào trong View được chọn để lưu.", title="Cảnh báo")
        return False

    os.environ[ENV_KEY] = str(view.Id.IntegerValue)
    forms.alert("Đã LƯU (Copy) bố cục lưới trục của View:\n\n👉 {}".format(view.Name), title="Thành công", warn_icon=False)
    return True

def do_apply_layout_to_views(target_views_list):
    if not target_views_list:
        return
        
    view_id_str = os.environ.get(ENV_KEY)
    if not view_id_str:
        forms.alert("Chưa có bố cục lưới trục nào được lưu.\nVui lòng chọn LƯU BỐ CỤC trước.", title="Lỗi")
        return
        
    try:
        source_view_id = DB.ElementId(int(view_id_str))
        source_view = doc.GetElement(source_view_id)
    except Exception:
        source_view = None

    if not source_view:
        forms.alert("View nguồn đã bị xóa hoặc không thể truy cập.", title="Lỗi")
        return
        
    source_grids = DB.FilteredElementCollector(doc, source_view.Id)\
                     .OfCategory(DB.BuiltInCategory.OST_Grids)\
                     .WhereElementIsNotElementType().ToElements()
                     
    if not source_grids:
        return
        
    source_grids_dict = {g.Id: g for g in source_grids}
    matched_views_count = 0
    with revit.Transaction("Dán bố cục lưới trục"):
        for t_view in target_views_list:
            if t_view.Id == source_view.Id:
                continue
                
            if not isinstance(t_view, (DB.ViewPlan, DB.ViewSection)):
                continue

            try:
                # Kiểm tra View parallel (Song song) để tránh lỗi văng
                dir_source = source_view.ViewDirection
                dir_target = t_view.ViewDirection
                if abs(dir_source.DotProduct(dir_target)) < 0.99:
                    continue
            except Exception:
                pass
                
            t_grids = DB.FilteredElementCollector(doc, t_view.Id)\
                        .OfCategory(DB.BuiltInCategory.OST_Grids)\
                        .WhereElementIsNotElementType().ToElements()
                        
            from System.Collections.Generic import List
            t_grids_dict = {g.Id: g for g in t_grids}
            
            applied = False
            
            to_hide = List[DB.ElementId]()
            for t_id in t_grids_dict.keys():
                if t_id not in source_grids_dict:
                    to_hide.Add(t_id)
            if to_hide.Count > 0:
                try:
                    t_view.HideElements(to_hide)
                    applied = True
                except Exception: pass
                
            to_unhide = List[DB.ElementId]()
            for s_id in source_grids_dict.keys():
                if s_id not in t_grids_dict:
                    to_unhide.Add(s_id)
            if to_unhide.Count > 0:
                try:
                    t_view.UnhideElements(to_unhide)
                    applied = True
                except Exception: pass

            for t_grid in source_grids_dict.values():
                s_grid = t_grid
                applied = True
                
                # 1. Đồng bộ 2D/3D Extent Type
                try:
                    for end in [DB.DatumEnds.End0, DB.DatumEnds.End1]:
                        s_ext = s_grid.GetDatumExtentTypeInView(end, source_view)
                        if t_grid.GetDatumExtentTypeInView(end, t_view) != s_ext:
                            t_grid.SetDatumExtentType(end, t_view, s_ext)
                except Exception: pass
                
                # 2. Đồng bộ ẩn hiện bong bóng trục
                try:
                    end0_vis = s_grid.IsBubbleVisibleInView(DB.DatumEnds.End0, source_view)
                    end1_vis = s_grid.IsBubbleVisibleInView(DB.DatumEnds.End1, source_view)
                    
                    try:
                        if end0_vis: t_grid.ShowBubbleInView(DB.DatumEnds.End0, t_view)
                        else: t_grid.HideBubbleInView(DB.DatumEnds.End0, t_view)
                    except Exception: pass
                    
                    try:
                        if end1_vis: t_grid.ShowBubbleInView(DB.DatumEnds.End1, t_view)
                        else: t_grid.HideBubbleInView(DB.DatumEnds.End1, t_view)
                    except Exception: pass
                except Exception: pass
                
                # 3. Đồng bộ Curve 2D (Lấy chính xác Z nguyên bản để fix lỗi không dán được ở MB Trần RCP)
                try:
                    is_end0_2d = s_grid.GetDatumExtentTypeInView(DB.DatumEnds.End0, source_view) == DB.DatumExtentType.ViewSpecific
                    is_end1_2d = s_grid.GetDatumExtentTypeInView(DB.DatumEnds.End1, source_view) == DB.DatumExtentType.ViewSpecific
                    
                    if is_end0_2d or is_end1_2d:
                        s_curves = s_grid.GetCurvesInView(DB.DatumExtentType.ViewSpecific, source_view)
                        t_curves_curr = t_grid.GetCurvesInView(DB.DatumExtentType.ViewSpecific, t_view)
                        
                        if s_curves and t_curves_curr:
                            s_c = s_curves[0]
                            t_c_curr = t_curves_curr[0]
                            t_c = None
                            
                            # Cốt lõi: Chỉ mượn X và Y của cao độ cũ, giữ rịt Z của View đích
                            tgt_z = t_c_curr.GetEndPoint(0).Z
                            
                            if isinstance(s_c, DB.Line) and isinstance(t_c_curr, DB.Line):
                                p0 = DB.XYZ(s_c.GetEndPoint(0).X, s_c.GetEndPoint(0).Y, tgt_z)
                                p1 = DB.XYZ(s_c.GetEndPoint(1).X, s_c.GetEndPoint(1).Y, tgt_z)
                                if p0.DistanceTo(p1) > 0.001:
                                    t_c = DB.Line.CreateBound(p0, p1)
                            elif isinstance(s_c, DB.Arc) and isinstance(t_c_curr, DB.Arc):
                                p0 = DB.XYZ(s_c.GetEndPoint(0).X, s_c.GetEndPoint(0).Y, tgt_z)
                                p1 = DB.XYZ(s_c.GetEndPoint(1).X, s_c.GetEndPoint(1).Y, tgt_z)
                                pMid = DB.XYZ(s_c.Evaluate(0.5, True).X, s_c.Evaluate(0.5, True).Y, tgt_z)
                                if p0.DistanceTo(p1) > 0.001:
                                    t_c = DB.Arc.Create(p0, p1, pMid)
                            
                            if t_c:
                                t_grid.SetCurveInView(DB.DatumExtentType.ViewSpecific, t_view, t_c)
                except Exception: pass
                
            if applied: 
                matched_views_count += 1
                
    if matched_views_count > 0:
        forms.alert("Đã áp dụng bố cục lưới trục cho {} View thành công!".format(matched_views_count), title="Hoàn tất", warn_icon=False)
    else:
        forms.alert("Không có View nào được áp dụng (Do không cùng hướng nhìn hoặc không có lưới trục chung).", title="Thông báo")

class GridLayoutWindow(WPFWindow):
    def __init__(self, xaml_file_name):
        WPFWindow.__init__(self, xaml_file_name)
        self.all_views = self.get_valid_views()
        self.action = None
        self.action_data = None
        self.populate_list()
        self.update_status()
        
    def get_valid_views(self):
        collector = DB.FilteredElementCollector(doc).OfClass(DB.View).WhereElementIsNotElementType().ToElements()
        valid = []
        for v in collector:
            if isinstance(v, (DB.ViewPlan, DB.ViewSection)) and not v.IsTemplate:
                valid.append(v)
        return sorted(valid, key=lambda x: x.Name)

    def populate_list(self, search_text=""):
        self.ListPanel.Children.Clear()
        search_text = search_text.lower()
        for v in self.all_views:
            if search_text in v.Name.lower():
                chk = CheckBox()
                chk.Content = " " + v.Name
                chk.Tag = v.Id
                chk.Margin = Thickness(0, 0, 0, 8)
                chk.FontSize = 13
                chk.Foreground = ColorDark
                self.ListPanel.Children.Add(chk)

    def update_status(self):
        view_id_str = os.environ.get(ENV_KEY)
        if view_id_str:
            try:
                source_view_id = DB.ElementId(int(view_id_str))
                source_view = doc.GetElement(source_view_id)
                if source_view:
                    self.TxtStatus.Text = "Đang ngậm bản sao: 👉 {}".format(source_view.Name)
                    self.TxtStatus.Foreground = ColorGreen
                    return
            except:
                pass
        self.TxtStatus.Text = "Status: Chưa có dữ liệu"
        self.TxtStatus.Foreground = ColorRed

    def Window_MouseLeftButtonDown(self, sender, e):
        self.DragMove()

    def BtnClose_Click(self, sender, e):
        self.action = "CLOSE"
        self.Close()

    def BtnCopy_Click(self, sender, e):
        self.action = "COPY"
        self.Close()
        
    def BtnPasteCurrent_Click(self, sender, e):
        self.action = "PASTE_CURRENT"
        self.Close()
        
    def BtnPickCopy_Click(self, sender, e):
        self.action = "PICK_COPY"
        self.Close()
        
    def BtnPickPaste_Click(self, sender, e):
        self.action = "PICK_PASTE"
        self.Close()

    def TxtSearch_TextChanged(self, sender, e):
        self.populate_list(self.TxtSearch.Text)

    def BtnPasteMultiple_Click(self, sender, e):
        selected_views = []
        for child in self.ListPanel.Children:
            if isinstance(child, CheckBox) and child.IsChecked:
                v = doc.GetElement(child.Tag)
                if v:
                    selected_views.append(v)
                    
        if not selected_views:
            forms.alert("Bạn chưa chọn View nào trong danh sách!", title="Thông báo")
            return
            
        self.action = "PASTE_MULTIPLE"
        self.action_data = selected_views
        self.Close()

def main():
    ui_path = os.path.join(os.path.dirname(__file__), "ui.xaml")
    
    # Dialog Loop pattern
    while True:
        window = GridLayoutWindow(ui_path)
        window.ShowDialog()
        
        if window.action == "CLOSE" or window.action is None:
            break
            
        if window.action == "COPY":
            do_copy_layout(active_view)
            
        elif window.action == "PASTE_CURRENT":
            do_apply_layout_to_views([active_view])
            
        elif window.action == "PICK_COPY":
            try:
                picked_ref = uidoc.Selection.PickObject(UI.Selection.ObjectType.Element, ViewportSelectionFilter(), "Nhấp chuột vào Viewport trên Sheet để LƯU bố cục. (Bấm ESC để hủy)")
                vp = doc.GetElement(picked_ref)
                source_view = doc.GetElement(vp.ViewId)
                do_copy_layout(source_view)
            except UI.Exceptions.OperationCanceledException:
                pass
            except Exception as ex:
                pass

        elif window.action == "PICK_PASTE":
            view_id_str = os.environ.get(ENV_KEY)
            if not view_id_str:
                forms.alert("Chưa lưu bố cục (Bấm nút COPY trước khi dán).", title="Lỗi")
                continue
                
            try:
                picked_refs = uidoc.Selection.PickObjects(UI.Selection.ObjectType.Element, ViewportSelectionFilter(), "QUÉT HOẶC CHỌN NHIỀU Viewports để DÁN. (Nhấn Finish góc trên trái để hoàn tất)")
                targets = []
                for ref in picked_refs:
                    vp = doc.GetElement(ref)
                    if vp:
                        targets.append(doc.GetElement(vp.ViewId))
                if targets:
                    do_apply_layout_to_views(targets)
            except UI.Exceptions.OperationCanceledException:
                pass
            except Exception as ex:
                pass
                
        elif window.action == "PASTE_MULTIPLE":
            do_apply_layout_to_views(window.action_data)

if __name__ == "__main__":
    main()
