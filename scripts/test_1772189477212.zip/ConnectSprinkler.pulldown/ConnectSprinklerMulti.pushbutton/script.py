# -*- coding: utf-8 -*-
import math
import traceback
import clr

import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

# --- CẤU HÌNH ---
SPACER_MM = 200.0   
SPACER_FEET = SPACER_MM / 304.8
ELBOW_ROOM_FEET = 0.15 
TOLERANCE_GROUPING = 100.0 / 304.8 # Khoảng sai số gom nhóm (100mm)

# --- 1. BỘ LỌC & HÀM SIZE ---
class SprinklerFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, FamilyInstance) and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_Sprinklers)
    def AllowReference(self, ref, point): return True

class PipeFilter(ISelectionFilter):
    def AllowElement(self, elem): return isinstance(elem, Pipe)
    def AllowReference(self, ref, point): return True

def get_diameter_feet(count):
    # Quy tắc size ống
    if count <= 2: return 25.0 / 304.8 
    elif count == 3: return 32.0 / 304.8
    elif count == 4: return 40.0 / 304.8
    else: return 50.0 / 304.8

# --- 2. HÀM KẾT NỐI HỖ TRỢ ---
def get_closest_connector(elem, pt):
    if not elem: return None
    cons = None
    if isinstance(elem, Pipe): cons = elem.ConnectorManager.Connectors
    elif isinstance(elem, FamilyInstance): cons = elem.MEPModel.ConnectorManager.Connectors
    if not cons: return None
    best = None
    min_d = float('inf')
    for c in cons:
        d = c.Origin.DistanceTo(pt)
        if d < min_d: min_d = d; best = c
    return best

def connect_safe(e1, e2):
    try:
        c1_best, c2_best = None, None
        min_dist = float('inf')
        cons1 = e1.ConnectorManager.Connectors
        cons2 = e2.ConnectorManager.Connectors
        for c1 in cons1:
            for c2 in cons2:
                d = c1.Origin.DistanceTo(c2.Origin)
                if d < min_dist: min_dist = d; c1_best = c1; c2_best = c2
        if c1_best and c2_best and min_dist < 0.1:
             if not c1_best.IsConnectedTo(c2_best): c1_best.ConnectTo(c2_best)
    except: pass

def create_elbow_safe(e1, e2, pt):
    try:
        c1 = get_closest_connector(e1, pt)
        c2 = get_closest_connector(e2, pt)
        if c1 and c2: doc.Create.NewElbowFitting(c1, c2)
    except: pass

# --- 3. HÀM PHÂN NHÓM ---
def group_sprinklers_by_branch(sprinklers, main_pipe):
    """
    Gom nhóm các sprinkler dựa trên vị trí chiếu lên ống Main.
    """
    main_curve = main_pipe.Location.Curve
    groups = {} 
    
    for sp in sprinklers:
        pt = sp.Location.Point
        proj = main_curve.Project(pt)
        
        if proj:
            param_dist = main_curve.GetEndPoint(0).DistanceTo(proj.XYZPoint)
            # Làm tròn vị trí để gom nhóm
            key = int(param_dist / TOLERANCE_GROUPING)
            
            if key not in groups:
                groups[key] = []
            groups[key].append(sp)
            
    return list(groups.values())

# --- 4. LOGIC TẠO 1 NHÁNH ---
def create_single_branch_logic(doc, sprinklers, main_pipe, offset_feet):
    sys_id = main_pipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
    type_id = main_pipe.PipeType.Id
    level_id = main_pipe.get_Parameter(BuiltInParameter.RBS_START_LEVEL_PARAM).AsElementId()
    dn25 = 25.0 / 304.8

    # Sắp xếp
    main_curve = main_pipe.Location.Curve
    sp_data = []
    for sp in sprinklers:
        pt = sp.Location.Point
        proj = main_curve.Project(pt)
        dist = pt.DistanceTo(proj.XYZPoint) if proj else 0
        sp_data.append({'elem': sp, 'pt': pt, 'dist': dist, 'proj': proj.XYZPoint})
    
    sp_data.sort(key=lambda x: x['dist'])

    if not sp_data: return

    # Nodes
    z_main = main_curve.GetEndPoint(0).Z
    z_branch = z_main + offset_feet
    root_proj = sp_data[0]['proj']
    pt_root_branch = XYZ(root_proj.X, root_proj.Y, z_branch)
    
    nodes = []
    nodes.append({'pt': pt_root_branch, 'type': 'root', 'load': len(sprinklers)})

    for i, item in enumerate(sp_data):
        sp_pt = item['pt']
        node_pt = XYZ(sp_pt.X, sp_pt.Y, z_branch)
        load_here = len(sprinklers) - i 
        nodes.append({
            'pt': node_pt,
            'type': 'spk',
            'load': load_here,
            'sp_elem': item['elem']
        })

    # Tạo ống ngang
    for i in range(len(nodes) - 1):
        curr = nodes[i]
        nxt = nodes[i+1]
        p_start = curr['pt']
        p_end = nxt['pt']
        dist_seg = p_start.DistanceTo(p_end)

        dia_in = 0.0
        if curr.get('pipe_in'):
             dia_in = curr['pipe_in'].get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
        elif i == 0: 
             dia_in = get_diameter_feet(curr['load'])

        dia_needed = get_diameter_feet(nxt['load'])

        if dia_in > (dia_needed + 0.001) and dist_seg > (SPACER_FEET * 1.5):
            vec = (p_end - p_start).Normalize()
            p_spacer_end = p_start + (vec * SPACER_FEET)
            
            p_spacer = Pipe.Create(doc, sys_id, type_id, level_id, p_start, p_spacer_end)
            p_spacer.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_in)
            
            p_main = Pipe.Create(doc, sys_id, type_id, level_id, p_spacer_end, p_end)
            p_main.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_needed)
            
            connect_safe(p_spacer, p_main)
            curr['pipe_out'] = p_spacer 
            nxt['pipe_in'] = p_main
        else:
            if dist_seg > 0.01:
                p = Pipe.Create(doc, sys_id, type_id, level_id, p_start, p_end)
                p.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia_needed)
                curr['pipe_out'] = p
                nxt['pipe_in'] = p

    # Tạo Riser
    for item in nodes:
        if item['type'] == 'spk':
            sp = item['sp_elem']
            c_sp = get_closest_connector(sp, sp.Location.Point)
            sp_pt = c_sp.Origin if c_sp else sp.Location.Point
            node_pt = item['pt']
            
            if sp_pt.DistanceTo(node_pt) > 0.01:
                r = Pipe.Create(doc, sys_id, type_id, level_id, sp_pt, node_pt)
                r.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dn25)
                try: 
                    c_r_bottom = get_closest_connector(r, sp_pt)
                    if c_sp and c_r_bottom: c_sp.ConnectTo(c_r_bottom)
                except: pass
                
                p_in = item.get('pipe_in')
                p_out = item.get('pipe_out')
                c_riser_top = get_closest_connector(r, node_pt)
                c_in = get_closest_connector(p_in, node_pt) if p_in else None
                c_out = get_closest_connector(p_out, node_pt) if p_out else None

                if c_in and c_out and c_riser_top:
                    doc.Create.NewTeeFitting(c_in, c_out, c_riser_top)
                elif c_in and c_riser_top and not c_out:
                    doc.Create.NewElbowFitting(c_in, c_riser_top)

    # Nối vào Main (Elbow drop)
    root_node = nodes[0]
    p_first_branch = root_node.get('pipe_out')
    
    if p_first_branch:
        pt_branch = root_node['pt']
        main_proj = main_curve.Project(pt_branch)
        if main_proj:
            pt_main_center = main_proj.XYZPoint
            pt_elbow_loc = XYZ(pt_main_center.X, pt_main_center.Y, pt_main_center.Z + ELBOW_ROOM_FEET)
            
            if pt_branch.DistanceTo(pt_elbow_loc) > 0.01:
                p_conn = Pipe.Create(doc, sys_id, type_id, level_id, pt_branch, pt_elbow_loc)
                first_dia = p_first_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
                p_conn.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(first_dia)
                create_elbow_safe(p_first_branch, p_conn, pt_branch)

# --- 5. HÀM CHÍNH ---
def execute_multi_branch():
    try:
        with forms.WarningBar(title="Chọn TOÀN BỘ SPRINKLERS (Quét hết)"):
            refs = uidoc.Selection.PickObjects(ObjectType.Element, SprinklerFilter(), "Quét chọn Sprinklers")
            all_sprinklers = [doc.GetElement(r.ElementId) for r in refs]
        if not all_sprinklers: return

        with forms.WarningBar(title="Chọn ỐNG CHÍNH (Main Pipe)"):
            ref_main = uidoc.Selection.PickObject(ObjectType.Element, PipeFilter(), "Chọn Main Pipe")
            main_pipe = doc.GetElement(ref_main.ElementId)

        res_h = forms.ask_for_string(default='150', prompt='Độ cao nhánh so với Main (mm):', title='Setting')
        if not res_h: return
        offset_feet = float(res_h) / 304.8
    except: return

    t = Transaction(doc, "Auto Multi Branch")
    t.Start()

    try:
        branch_groups = group_sprinklers_by_branch(all_sprinklers, main_pipe)
        
        # Đã xóa lệnh print ở đây để không hiện bảng đen
        
        for sp_group in branch_groups:
            create_single_branch_logic(doc, sp_group, main_pipe, offset_feet)

        t.Commit()
        forms.toast("Đã hoàn thành {} nhánh!".format(len(branch_groups)), title="Thành công")

    except Exception as e:
        t.RollBack()
        forms.alert("Lỗi: " + traceback.format_exc())

# Chạy lệnh
execute_multi_branch()