# -*- coding: utf-8 -*-
from pyrevit import revit, DB, forms
# Import các thư viện xử lý giao diện của Windows
from System.Windows.Media import Brushes
from System.Windows import FontStyles

doc = revit.doc
uidoc = revit.uidoc

# --- PHẦN 1: THIẾT KẾ GIAO DIỆN (XAML) ---
xaml_content = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Auto Numbering | Sonhpa" Height="280" Width="350"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize"
        Background="#F4F4F4">
    
    <Border Padding="20">
        <StackPanel>
            <TextBlock Text="ĐÁNH SỐ THỨ TỰ SHEET" FontSize="18" FontWeight="Bold" 
                       HorizontalAlignment="Center" Foreground="#005A9E" Margin="0,0,0,20"/>
            
            <Grid Margin="0,0,0,10">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="120"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="Tên Parameter:" VerticalAlignment="Center" FontWeight="SemiBold"/>
                
                <TextBox Grid.Column="1" Name="param_input" Text="Nhập Parameter..." 
                         Height="30" VerticalContentAlignment="Center" Padding="5,0,0,0"
                         Foreground="#888888" FontStyle="Italic"/>
            </Grid>
            
            <Grid Margin="0,0,0,20">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="120"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="Số bắt đầu:" VerticalAlignment="Center" FontWeight="SemiBold"/>
                
                <TextBox Grid.Column="1" Name="start_input" Text="Nhập số..." 
                         Height="30" VerticalContentAlignment="Center" Padding="5,0,0,0"
                         Foreground="#888888" FontStyle="Italic"/>
            </Grid>
            
            <Button Content="THỰC HIỆN NGAY" Height="40" 
                    Click="run_click" Background="#007ACC" Foreground="White" 
                    FontWeight="Bold" FontSize="14" Cursor="Hand">
                <Button.Resources>
                    <Style TargetType="Border">
                        <Setter Property="CornerRadius" Value="5"/>
                    </Style>
                </Button.Resources>
            </Button>
            
             <TextBlock Text="*Tool sẽ sắp xếp theo Sheet Number trước khi đánh số" 
                       FontSize="10" Foreground="Gray" HorizontalAlignment="Center" Margin="0,10,0,0" FontStyle="Italic"/>
        </StackPanel>
    </Border>
</Window>
"""

# --- PHẦN 2: LOGIC XỬ LÝ ---

class NumberingWindow(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self, xaml_content, literal_string=True)
        
        # 1. Định nghĩa các giá trị mặc định (Phải khớp chính xác với XAML ở trên)
        self.ph_param = "Nhập Parameter..."
        self.ph_start = "Nhập số..."
        
        # 2. Gán sự kiện (Event)
        self.param_input.GotFocus += self.param_got_focus
        self.param_input.LostFocus += self.param_lost_focus
        
        self.start_input.GotFocus += self.start_got_focus
        self.start_input.LostFocus += self.start_lost_focus

    # --- Xử lý ô Parameter ---
    def param_got_focus(self, sender, args):
        if sender.Text == self.ph_param:
            sender.Text = ""
            sender.Foreground = Brushes.Black
            sender.FontStyle = FontStyles.Normal

    def param_lost_focus(self, sender, args):
        if not sender.Text.strip():
            sender.Text = self.ph_param
            sender.Foreground = Brushes.Gray
            sender.FontStyle = FontStyles.Italic

    # --- Xử lý ô Start Number ---
    def start_got_focus(self, sender, args):
        if sender.Text == self.ph_start:
            sender.Text = ""
            sender.Foreground = Brushes.Black
            sender.FontStyle = FontStyles.Normal

    def start_lost_focus(self, sender, args):
        if not sender.Text.strip():
            sender.Text = self.ph_start
            sender.Foreground = Brushes.Gray
            sender.FontStyle = FontStyles.Italic

    # --- Xử lý nút RUN ---
    def run_click(self, sender, args):
        p_val = self.param_input.Text
        s_val = self.start_input.Text
        
        # Kiểm tra xem người dùng có nhập không
        if p_val == self.ph_param or not p_val.strip():
            forms.alert("Vui lòng nhập Tên Parameter!") 
            return
            
        if s_val == self.ph_start or not s_val.strip():
            forms.alert("Vui lòng nhập Số bắt đầu!")
            return
            
        if not s_val.isdigit():
            forms.alert("Số bắt đầu phải là số nguyên dương!")
            return
        
        self.final_param = p_val
        self.final_start = s_val
        self.Close()

def get_selected_sheets():
    selection_ids = uidoc.Selection.GetElementIds()
    selected_elements = [doc.GetElement(id) for id in selection_ids]
    sheets = [el for el in selected_elements if isinstance(el, DB.ViewSheet)]
    return sheets

def run():
    sheets = get_selected_sheets()
    if not sheets:
        forms.alert("Bạn chưa chọn Sheet nào trong Project Browser!", warn_icon=True)
        return

    sheets.sort(key=lambda x: x.SheetNumber)

    try:
        window = NumberingWindow()
        window.ShowDialog()
    except Exception as e:
        forms.alert("Lỗi UI: " + str(e))
        return

    if not hasattr(window, 'final_param'): 
        return

    param_name_user = window.final_param
    start_str = window.final_start

    padding_length = len(start_str)
    current_val = int(start_str)

    t = DB.Transaction(doc, "Auto Numbering")
    t.Start()

    count_ok = 0
    errors = []

    for s in sheets:
        try:
            param = s.LookupParameter(param_name_user)
            if param and not param.IsReadOnly:
                new_val_str = str(current_val).zfill(padding_length)
                param.Set(new_val_str)
                current_val += 1
                count_ok += 1
            else:
                errors.append(s.SheetNumber + ": Không tìm thấy param '{}' hoặc bị khóa.".format(param_name_user))
        except Exception as e:
            errors.append(s.SheetNumber + ": " + str(e))

    t.Commit()

    if len(errors) > 0:
        msg = "Đã xử lý: {}/{} Sheet.\n\nLỗi:\n{}".format(count_ok, len(sheets), "\n".join(errors))
        forms.alert(msg, title="Cảnh báo", warn_icon=True)
    else:
        forms.alert("Đã đánh số '{}' xong cho {} sheet!".format(param_name_user, count_ok), title="Thành công", warn_icon=False)

if __name__ == '__main__':
    run()