# -*- coding: utf-8 -*-
import clr
clr.AddReference("System.Drawing")
clr.AddReference("System.Windows.Forms")

from pyrevit import revit, DB, forms
from System.Windows.Media import Brushes, ImageSource
from System.Windows import FontStyles
from System.Windows.Interop import Imaging
from System.Windows.Media.Imaging import BitmapSizeOptions
from System.Drawing import Icon
from System.Diagnostics import Process
import System

doc = revit.doc
uidoc = revit.uidoc

# --- HÀM HỖ TRỢ LẤY ICON REVIT ---
def get_revit_icon_source():
    try:
        process = Process.GetCurrentProcess()
        icon = Icon.ExtractAssociatedIcon(process.MainModule.FileName)
        return Imaging.CreateBitmapSourceFromHIcon(
            icon.Handle,
            System.Windows.Int32Rect.Empty,
            BitmapSizeOptions.FromEmptyOptions()
        )
    except:
        return None

# --- PHẦN 1: GIAO DIỆN (Đã chỉnh gọn) ---
xaml_content = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Auto Numbering | Sonhpa" Width="360"
        SizeToContent="Height"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize"
        Background="#F4F4F4" Icon="{Binding IconSource}">
    <Border Padding="20">
        <StackPanel>
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Center" Margin="0,0,0,20">
                <Image Name="ui_icon" Width="24" Height="24" Margin="0,0,10,0" VerticalAlignment="Center"/>
                <TextBlock Text="ĐÁNH SỐ THỨ TỰ SHEET" FontSize="18" FontWeight="Bold" 
                           Foreground="#005A9E" VerticalAlignment="Center"/>
            </StackPanel>

            <Grid Margin="0,0,0,10">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="120"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="Tên Parameter:" VerticalAlignment="Center" FontWeight="SemiBold"/>
                <TextBox Grid.Column="1" Name="param_input" Text="STT" 
                         Height="30" VerticalContentAlignment="Center" Padding="5,0,0,0"/>
            </Grid>
            <Grid Margin="0,0,0,10">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="120"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="Số bắt đầu:" VerticalAlignment="Center" FontWeight="SemiBold"/>
                <TextBox Grid.Column="1" Name="start_input" Text="01" 
                         Height="30" VerticalContentAlignment="Center" Padding="5,0,0,0"/>
            </Grid>
            
            <TextBlock Text="(Số đếm sẽ được RESET lại từ đầu cho mỗi Bảng thống kê được chọn)" 
                       FontSize="10" Foreground="#D9534F" HorizontalAlignment="Center" 
                       Margin="0,0,0,20" TextWrapping="Wrap" TextAlignment="Center"/>

            <Button Content="THỰC HIỆN NGAY" Height="40" 
                    Click="run_click" Background="#007ACC" Foreground="White" 
                    FontWeight="Bold" FontSize="14" Cursor="Hand">
                <Button.Resources>
                    <Style TargetType="Border"> <Setter Property="CornerRadius" Value="5"/> </Style>
                </Button.Resources>
            </Button>
        </StackPanel>
    </Border>
</Window>
"""

class NumberingWindow(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self, xaml_content, literal_string=True)
        self.icon_source = get_revit_icon_source()
        if self.icon_source:
            self.Icon = self.icon_source
            self.ui_icon.Source = self.icon_source

        self.param_input.GotFocus += self.got_focus
        self.param_input.LostFocus += self.lost_focus
        self.start_input.GotFocus += self.got_focus
        self.start_input.LostFocus += self.lost_focus

    def got_focus(self, sender, args):
        sender.Foreground = Brushes.Black

    def lost_focus(self, sender, args):
        if not sender.Text.strip():
            sender.Foreground = Brushes.Gray

    def run_click(self, sender, args):
        self.final_param = self.param_input.Text
        self.final_start = self.start_input.Text
        self.Close()

# --- PHẦN 2: LOGIC XỬ LÝ (CHIA BATCH - GIỮ NGUYÊN) ---

def get_sheet_batches():
    selection_ids = uidoc.Selection.GetElementIds()
    
    batches = []
    direct_sheets = [] 

    if selection_ids:
        for el_id in selection_ids:
            el = doc.GetElement(el_id)
            
            if isinstance(el, DB.ScheduleSheetInstance):
                schedule_id = el.ScheduleId
                if schedule_id != DB.ElementId.InvalidElementId:
                    col = DB.FilteredElementCollector(doc, schedule_id).OfClass(DB.ViewSheet).ToElements()
                    sorted_sheets = sorted(list(col), key=lambda x: x.SheetNumber)
                    if sorted_sheets:
                        batches.append(sorted_sheets)
            
            elif isinstance(el, DB.ViewSheet):
                direct_sheets.append(el)

    if direct_sheets:
        direct_sheets.sort(key=lambda x: x.SheetNumber)
        batches.append(direct_sheets)

    return batches

def get_all_sheets_in_active_view_schedule():
    col = DB.FilteredElementCollector(doc, doc.ActiveView.Id).OfClass(DB.ViewSheet).ToElements()
    sheets = list(col)
    sheets.sort(key=lambda x: x.SheetNumber)
    return [sheets] if sheets else []

def run():
    batches = get_sheet_batches()
    
    if not batches and isinstance(doc.ActiveView, DB.ViewSchedule):
        res = forms.alert("Bạn chưa chọn dòng nào.\n\nĐánh số toàn bộ Sheet trong bảng này?", 
                          title="Phát hiện Schedule", yes=True, no=True)
        if res:
            batches = get_all_sheets_in_active_view_schedule()
        else:
            return 

    if not batches:
        forms.alert("Vui lòng chọn Schedule Graphics trên bản vẽ hoặc chọn Sheet!", warn_icon=True)
        return

    try:
        window = NumberingWindow()
        window.ShowDialog()
    except Exception as e:
        forms.alert("Lỗi UI: " + str(e))
        return

    if not hasattr(window, 'final_param'): return

    param_name = window.final_param
    start_str = window.final_start
    
    if not start_str.isdigit():
        forms.alert("Số bắt đầu phải là số!")
        return

    padding = len(start_str)
    start_val_int = int(start_str) 
    
    t = DB.Transaction(doc, "Auto Numbering")
    t.Start()
    
    total_count = 0
    errors = []
    
    for batch_sheets in batches:
        curr_val = start_val_int 
        
        for s in batch_sheets:
            try:
                p = s.LookupParameter(param_name)
                if p and not p.IsReadOnly:
                    if p.StorageType == DB.StorageType.String:
                        p.Set(str(curr_val).zfill(padding))
                    elif p.StorageType == DB.StorageType.Integer:
                        p.Set(curr_val)
                    else:
                        p.Set(str(curr_val).zfill(padding))
                        
                    curr_val += 1
                    total_count += 1
                else:
                    errors.append(s.SheetNumber + ": Lỗi Param/ReadOnly")
            except:
                errors.append(s.SheetNumber + ": Lỗi")
            
    t.Commit()
    
    if errors:
        forms.alert("Xong {} sheet. Có lỗi xảy ra với một số sheet.".format(total_count))
        print("\n".join(errors))
    else:
        forms.alert("Thành công! Đã đánh số {} sheet (Reset theo từng Schedule).".format(total_count))

if __name__ == '__main__':
    run()