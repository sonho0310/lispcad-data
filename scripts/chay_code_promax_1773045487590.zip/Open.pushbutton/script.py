# -*- coding: utf-8 -*-
__title__ = 'Chạy Code\nPro Max'
__doc__ = 'IDE Thu nhỏ V.I.P - Chủ đề Sáng (Light Theme)'

import clr
clr.AddReference('PresentationFramework')
clr.AddReference('PresentationCore')

import os
import codecs
import json
from pyrevit import forms
import System.Windows
from System.Windows.Markup import XamlReader
from System.Windows.Controls import TreeViewItem
from System.Windows import Visibility
clr.AddReference('System.Drawing')

CACHE_FILE = os.path.join(os.environ.get('APPDATA', ''), 'SonMEP_IDE_config.json')

xaml_str = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Sơn MEP IDE" Height="800" Width="1200" WindowStartupLocation="CenterScreen" 
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" FontFamily="Segoe UI">
    <Window.Resources>
        <Style TargetType="Button" x:Key="RunBtnStyle">
            <Setter Property="Background" Value="#00E676"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="25,10"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="4">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
            <Style.Triggers>
                <Trigger Property="IsMouseOver" Value="True">
                    <Setter Property="Opacity" Value="0.8"/>
                </Trigger>
            </Style.Triggers>
        </Style>
        <Style TargetType="Button" x:Key="FlatBtnStyle">
            <Setter Property="Background" Value="Transparent"/>
            <Setter Property="Foreground" Value="#555"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" Padding="10,5" CornerRadius="3">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
            <Style.Triggers>
                <Trigger Property="IsMouseOver" Value="True">
                    <Setter Property="Background" Value="#F0F0F0"/>
                </Trigger>
            </Style.Triggers>
        </Style>
    </Window.Resources>
    
    <Border Background="White" BorderBrush="#E0E0E0" BorderThickness="1" CornerRadius="8">
        <Border.Effect>
            <DropShadowEffect BlurRadius="20" ShadowDepth="4" Color="Black" Opacity="0.3"/>
        </Border.Effect>
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="50"/> 
                <RowDefinition Height="*"/>
                <RowDefinition Height="25"/>
            </Grid.RowDefinitions>
            
            <!-- TOP BAR -->
            <!-- Allow dragging window by clicking top bar -->
            <Border Name="TitleBar" Background="White" BorderBrush="#EAEAEA" BorderThickness="0,0,0,1" CornerRadius="8,8,0,0">
                <Grid Margin="15,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    
                    <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
                        <!-- Lấy Icon của chính Revit Mẹ đang chạy qua C# Interop -->
                        <Image Name="AppIcon" Width="28" Height="28" Margin="0,0,15,0"/>
                    </StackPanel>
                    
                    <!-- Search -->
                    <Border Grid.Column="1" HorizontalAlignment="Center" Background="#F1F3F4" Width="400" Height="38" CornerRadius="6" VerticalAlignment="Center">
                        <Grid Margin="10,0">
                            <TextBlock Text="🔍" Foreground="#888" VerticalAlignment="Center" Margin="0,0,10,0" HorizontalAlignment="Left"/>
                            <TextBox Name="SearchBox" Foreground="#333" Background="Transparent" BorderThickness="0" VerticalAlignment="Center" Margin="30,0,0,0" FontSize="14" ToolTip="Search files..."/>
                        </Grid>
                    </Border>
                    
                    <!-- Right Actions -->
                    <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center">
                        <Button Name="BtnOpenFile" Style="{StaticResource RunBtnStyle}" Background="#555555" Content="📂 OPEN FILE" Margin="0,0,10,0"/>
                        <Button Name="BtnSaveFile" Style="{StaticResource RunBtnStyle}" Background="#1A73E8" Content="💾 SAVE AS" Margin="0,0,10,0"/>
                        <Button Name="BtnRunCode" Style="{StaticResource RunBtnStyle}" Content="▶ Run Script" Margin="0,0,15,0"/>
                        <Button Name="BtnClose" Style="{StaticResource FlatBtnStyle}" Content="CLOSE" FontWeight="Bold" Foreground="Red" FontSize="14" Padding="15,8"/>
                    </StackPanel>
                </Grid>
            </Border>
            
            <!-- MAIN CONTENT -->
            <Grid Grid.Row="1">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="220"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                
                <!-- SIDEBAR: Project Explorer Thật -->
                <Border BorderBrush="#EAEAEA" BorderThickness="0,0,1,0" Background="#FAFAFA">
                    <Grid>
                        <Grid.RowDefinitions>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="Auto"/>
                            <RowDefinition Height="*"/>
                        </Grid.RowDefinitions>
                        <TextBlock Text="PROJECT EXPLORER" FontSize="11" FontWeight="Bold" Foreground="#888" Margin="15,15,15,5"/>
                        <Button Name="BtnOpenFolder" Grid.Row="1" Content="📂 Chọn Thư Mục Chứa Code..." Background="Transparent" Foreground="#1A73E8" Cursor="Hand" BorderThickness="0" Margin="15,0,15,5" HorizontalAlignment="Left" FontSize="12" FontWeight="Bold"/>
                        
                        <TreeView Name="ProjectTree" Grid.Row="2" Background="Transparent" BorderThickness="0" Margin="5"/>
                    </Grid>
                </Border>
                
                <!-- RIGHT WORKSPACE -->
                <Grid Grid.Column="1">
                    <Grid.RowDefinitions>
                        <RowDefinition Height="40"/>
                        <RowDefinition Height="*"/>
                        <RowDefinition Height="5"/>
                        <RowDefinition Height="200"/>
                    </Grid.RowDefinitions>
                    
                    <!-- TABS -->
                    <Border BorderBrush="#EAEAEA" BorderThickness="0,0,0,1" Background="#F8F9FA">
                        <StackPanel Orientation="Horizontal">
                            <!-- Active Tab -->
                            <Border Background="White" BorderBrush="#1A73E8" BorderThickness="0,2,0,0" Margin="10,0,0,0" Padding="15,10">
                                <StackPanel Orientation="Horizontal">
                                    <TextBlock Name="TabTitle" Text="📄 file_moi.py" Foreground="#333" FontWeight="SemiBold"/>
                                </StackPanel>
                            </Border>
                        </StackPanel>
                    </Border>
                    
                    <!-- EDITOR -->
                    <TextBox Name="CodeEditor" Grid.Row="1" AcceptsReturn="True" AcceptsTab="True" 
                             FontFamily="Consolas" FontSize="15" Background="White" Foreground="#2A2A2A" 
                             BorderThickness="0" Padding="30,20" xml:space="preserve"
                             VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Auto">
# -*- coding: utf-8 -*-
import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from pyrevit import revit, forms

# Get active document
doc = __revit__.ActiveUIDocument.Document

def collect_walls():
    collector = FilteredElementCollector(doc)
    walls = collector.OfCategory(BuiltInCategory.OST_Walls).WhereElementIsNotElementType().ToElements()
    return walls

# Execution
all_walls = collect_walls()
forms.alert("Script started. Found {} walls in current model.".format(len(all_walls)))
</TextBox>
                             
                    <GridSplitter Grid.Row="2" Height="5" HorizontalAlignment="Stretch" Background="#F1F3F4"/>
                    
                    <!-- CONSOLE / TERMINAL -->
                    <Grid Grid.Row="3" Background="White">
                        <Grid.RowDefinitions>
                            <RowDefinition Height="35"/>
                            <RowDefinition Height="*"/>
                        </Grid.RowDefinitions>
                        
                        <Border BorderThickness="0,1,0,1" BorderBrush="#EAEAEA">
                            <StackPanel Orientation="Horizontal" Margin="15,0">
                                <Border BorderBrush="#00E676" BorderThickness="0,0,0,2" Padding="0,8">
                                    <TextBlock Text="CONSOLE" Foreground="#00E676" FontWeight="Bold" VerticalAlignment="Center"/>
                                </Border>
                                <TextBlock Text="TERMINAL" Foreground="#888" VerticalAlignment="Center" Margin="25,0,0,0"/>
                                <TextBlock Text="PROBLEMS (0)" Foreground="#888" VerticalAlignment="Center" Margin="25,0,0,0"/>
                            </StackPanel>
                        </Border>
                        
                        <!-- Console Text -->
                        <TextBox Name="ConsoleOutput" Grid.Row="1" Background="White" Foreground="#555" FontFamily="Consolas" FontSize="13" BorderThickness="0" Padding="15" IsReadOnly="True" VerticalScrollBarVisibility="Auto" xml:space="preserve">
14:02:11 [INFO] Khởi động IDE Sơn MEP thành công...
14:02:12 [INFO] Đã bổ sung tính năng Lưu File gốc &amp; Khám phá Thư mụcc...
14:02:12 &gt;&gt;&gt;</TextBox>
                    </Grid>
                </Grid>
            </Grid>
            
            <!-- STATUS BAR -->
            <Border Grid.Row="2" Background="#00E676" CornerRadius="0,0,8,8">
                <Grid Margin="15,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>
                    
                    <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
                        <TextBlock Text="🔄 Connected to Revit" Foreground="#0D3F1E" FontWeight="SemiBold" Margin="0,0,15,0" FontSize="11"/>
                        <TextBlock Text="🐍 IronPython 2.7.12" Foreground="#0D3F1E" FontSize="11"/>
                    </StackPanel>
                    
                    <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center">
                        <TextBlock Text="UTF-8" Foreground="#0D3F1E" Margin="0,0,15,0" FontSize="11"/>
                        <TextBlock Text="Python" Foreground="#0D3F1E" Margin="0,0,15,0" FontSize="11"/>
                        <TextBlock Text="⚡ Ready" Foreground="#0D3F1E" FontWeight="Bold" FontSize="11"/>
                    </StackPanel>
                </Grid>
            </Border>
        </Grid>
    </Border>
</Window>
"""

class PythonRunnerApp(object):
    def __init__(self):
        self.current_file_path = None
        
        # Render Giao diện từ chuỗi XAML
        self.window = XamlReader.Parse(xaml_str)
        
        # Lấy các Control
        self.title_bar = self.window.FindName("TitleBar")
        self.btn_close = self.window.FindName("BtnClose")
        self.code_editor = self.window.FindName("CodeEditor")
        self.btn_open_file = self.window.FindName("BtnOpenFile")
        self.btn_run = self.window.FindName("BtnRunCode")
        self.btn_save = self.window.FindName("BtnSaveFile")
        
        self.tree_view = self.window.FindName("ProjectTree")
        self.btn_open_folder = self.window.FindName("BtnOpenFolder")
        self.tab_title = self.window.FindName("TabTitle")
        self.console = self.window.FindName("ConsoleOutput")
        self.app_icon = self.window.FindName("AppIcon")
        self.search_box = self.window.FindName("SearchBox")
        
        # TRÍCH XUẤT ICON TỪ FILE CHẠY REVIT.EXE
        try:
            import System.Drawing
            import System.Diagnostics
            from System.Windows.Interop import Imaging
            from System.Windows import Int32Rect
            from System.Windows.Media.Imaging import BitmapSizeOptions
            
            p = System.Diagnostics.Process.GetCurrentProcess()
            ico = System.Drawing.Icon.ExtractAssociatedIcon(p.MainModule.FileName)
            bs = Imaging.CreateBitmapSourceFromHIcon(
                ico.Handle,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions()
            )
            if self.app_icon and bs:
                self.app_icon.Source = bs
        except Exception as ex:
            pass

        # Gán sự kiện Title Bar
        self.title_bar.MouseLeftButtonDown += self.drag_window
        self.btn_close.Click += self.close_window
        
        # Gán sự kiện Chức năng File
        self.btn_open_file.Click += self.open_file
        self.btn_open_folder.Click += self.choose_folder
        self.btn_save.Click += self.save_file
        self.btn_run.Click += self.run_code
        self.search_box.TextChanged += self.search_tree
        
        # Thử load sẵn Folder Extension hiện tại (nếu có cache)
        folders = self.get_config()
        if folders:
            for folder in folders:
                if os.path.exists(folder):
                    self.load_tree(folder)
        else:
            try:
                my_dir = os.path.dirname(__file__)
                self.load_tree(my_dir)
            except:
                pass
            
        # Hiển thị
        self.window.ShowDialog()
        
    def get_config(self):
        try:
            if os.path.exists(CACHE_FILE):
                with open(CACHE_FILE, 'r') as f:
                    return json.load(f).get("folders", [])
        except: pass
        return []
        
    def save_config(self, folder):
        try:
            folders = self.get_config()
            if folder not in folders:
                folders.append(folder)
            with open(CACHE_FILE, 'w') as f:
                json.dump({"folders": folders}, f)
        except: pass

    def drag_window(self, sender, args):
        self.window.DragMove()
        
    def close_window(self, sender, args):
        self.window.Close()
        
    def choose_folder(self, sender, args):
        folder = forms.pick_folder()
        if folder:
            # Check trùng Folder
            for root_node in self.tree_view.Items:
                if root_node.Tag == folder:
                    self.console.Text += "\\n[INFO] Workspace đã có sẵn: " + folder
                    self.console.ScrollToEnd()
                    return
            self.load_tree(folder)
            self.save_config(folder)
            self.console.Text += "\\n[INFO] Đã nạp Workspace mới: " + folder
            self.console.ScrollToEnd()

    def search_tree(self, sender, args):
        query = self.search_box.Text.lower()
        
        def filter_node(node):
            if not isinstance(node, TreeViewItem): return False
            visible = False
            for child in node.Items:
                if filter_node(child):
                    visible = True
            
            if node.Items.Count == 0:
                header = node.Header.lower() if isinstance(node.Header, str) else str(node.Header).lower()
                if query in header:
                    visible = True
            
            if query == "":
                node.Visibility = Visibility.Visible
                return True
            else:
                node.Visibility = Visibility.Visible if visible else Visibility.Collapsed
                if visible and node.Items.Count > 0:
                    node.IsExpanded = True
                return visible
                
        for node in self.tree_view.Items:
            if query == "":
                node.Visibility = Visibility.Visible
            filter_node(node)

    def load_tree(self, folder_path):
        # self.tree_view.Items.Clear() --> BỎ CLEAR ĐỂ CHO PHÉP NHIỀU THƯ MỤC
        root_node = TreeViewItem()
        root_node.Header = "📁 " + os.path.basename(folder_path)
        root_node.Tag = folder_path
        root_node.IsExpanded = True
        self.tree_view.Items.Add(root_node)
        self.build_tree(folder_path, root_node)
        
    def build_tree(self, folder, parent_node):
        try:
            for item in os.listdir(folder):
                full_path = os.path.join(folder, item)
                if os.path.isdir(full_path):
                    # Bỏ qua thư mục ẩn hoặc pycache
                    if item.startswith('.') or item.startswith('__'): continue
                    node = TreeViewItem()
                    node.Header = "📁 " + item
                    node.Tag = full_path
                    parent_node.Items.Add(node)
                    self.build_tree(full_path, node)
                elif full_path.endswith('.py'):
                    node = TreeViewItem()
                    node.Header = "📄 " + item
                    node.Tag = full_path
                    # Sự kiện khi double-click file 
                    node.MouseDoubleClick += self.on_file_selected
                    parent_node.Items.Add(node)
        except:
            pass
            
    def on_file_selected(self, sender, args):
        file_path = sender.Tag
        args.Handled = True # Chặn event phát sinh
        if file_path and os.path.isfile(file_path):
            try:
                # Dùng codecs mở UTF-8 để khỏi bị lỗi hiển thị tiếng Việt
                with codecs.open(file_path, 'r', 'utf-8') as f:
                    self.code_editor.Text = f.read()
                self.current_file_path = file_path
                self.tab_title.Text = "📄 " + os.path.basename(file_path)
                self.console.Text += "\\n[INFO] Nạp file thành công: " + os.path.basename(file_path)
                self.console.ScrollToEnd()
            except Exception as e:
                self.console.Text += "\\n[ERROR] Lỗi đọc file: " + str(e)
                self.console.ScrollToEnd()
                
    def open_file(self, sender, args):
        file_path = forms.pick_file(file_ext='py')
        if file_path:
            try:
                with codecs.open(file_path, 'r', 'utf-8') as f:
                    self.code_editor.Text = f.read()
                self.current_file_path = file_path
                self.tab_title.Text = "📄 " + os.path.basename(file_path)
                self.console.Text += "\\n[INFO] Mở file độc lập: " + os.path.basename(file_path)
                self.console.ScrollToEnd()
            except Exception as e:
                forms.alert("Lỗi đọc file: {}".format(e))
                
    def save_file(self, sender, args):
        # Bấm SAVE AS thì luôn luôn hiện bảng chọn file
        file_path = forms.save_file(file_ext='py')
        if not file_path:
            return # User cancel
        self.current_file_path = file_path
        self.tab_title.Text = "📄 " + os.path.basename(file_path)
            
        try:
            with codecs.open(self.current_file_path, 'w', 'utf-8') as f:
                f.write(self.code_editor.Text)
            
            self.console.Text += "\\n[SUCCESS] Đã Lưu (SAVE AS) thành công tại: " + self.current_file_path
            self.console.ScrollToEnd()
        except Exception as e:
            forms.alert(str(e))
                
    def run_code(self, sender, args):
        code_str = self.code_editor.Text
        self.window.Close() # Bắt buộc Close để giải phóng luồng cho Revit chạy Code
        
        try:
            clean_code = code_str.replace('\r', '')
            exec(clean_code, globals())
        except Exception as e:
            forms.alert("Lỗi:\\n\\n{}".format(e), title="Lỗi Script")

def main():
    PythonRunnerApp()

if __name__ == '__main__':
    main()
