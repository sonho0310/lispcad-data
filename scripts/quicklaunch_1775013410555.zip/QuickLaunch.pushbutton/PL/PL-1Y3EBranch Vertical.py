# -*- coding: utf-8 -*-
"""
TOOL: PROMAX SANITARY SOLVER - INSTANT CLICK MODE (V8.1 - HYBRID ULTIMATE)
AUTHOR: Gemini & User
DESCRIPTION: 
    1. MODE: Chạy liên tục (Loop). Bấm ESC để thoát.
    2. LOGIC V8.1: Đã nâng cấp mắt thần Routing Preferences API. Không còn đoán tên Family.
"""

import math
import clr
from System.Collections.Generic import List

# --- REVIT API IMPORTS ---
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.DB.Plumbing import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException

# --- GLOBAL VARS ---
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# ============================================================================
# 0. UTILITIES (NÂNG CẤP LÊN BẢN CHUẨN API)
# ============================================================================

class RevitUtils(object):
    @staticmethod
    def get_closest_connector(element, point):
        if not element: return None
        try:
            conns = element.ConnectorManager.Connectors
            min_dist = float('inf')
            best_conn = None
            for c in conns:
                dist = c.Origin.DistanceTo(point)
                if dist < min_dist:
                    min_dist = dist
                    best_conn = c
            return best_conn
        except: return None

    # [SUPERPOWERS FIXED] - MẮT THẦN NATIVE API ROUTING
    @staticmethod
    def get_routing_junction_symbol(doc, pipe):
        try:
            pipe_type = doc.GetElement(pipe.GetTypeId())
            routing_manager = pipe_type.RoutingPreferenceManager
            group_type = Autodesk.Revit.DB.Plumbing.RoutingPreferenceRuleGroupType.Junction
            if routing_manager.GetNumberOfRules(group_type) == 0: return None
            
            rule = routing_manager.GetRule(group_type, 0)
            symbol_id = rule.MEPPartId
            if symbol_id and symbol_id != ElementId.InvalidElementId:
                return doc.GetElement(symbol_id)
        except: pass
        return None

def get_line_from_element(elem):
    if isinstance(elem.Location, LocationCurve):
        return elem.Location.Curve
    return None

def project_point_on_line_unlimited(pt, line_origin, line_dir):
    v = pt - line_origin
    d = v.DotProduct(line_dir)
    return line_origin + line_dir.Multiply(d)

def create_elbow(c1, c2):
    try: doc.Create.NewElbowFitting(c1, c2)
    except: pass

# ============================================================================
# 1. CALCULATION LOGIC
# ============================================================================

def calculate_geometry_stretch(p_main, p_branch, pt_pick_flow):
    l_main = get_line_from_element(p_main)
    l_branch = get_line_from_element(p_branch)
    b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()

    main_origin = l_main.GetEndPoint(0)
    main_dir = l_main.Direction.Normalize() 
    main_dir_xy = XYZ(main_dir.X, main_dir.Y, 0).Normalize()
    
    main_xy_len = math.sqrt(main_dir.X**2 + main_dir.Y**2)
    slope_ratio = main_dir.Z / main_xy_len
    slope_abs = abs(slope_ratio)

    b_p1 = l_branch.GetEndPoint(0)
    b_p2 = l_branch.GetEndPoint(1)
    
    if b_p1.Z > b_p2.Z:
        p_top_fixed, p_bottom_old = b_p1, b_p2
    else:
        p_top_fixed, p_bottom_old = b_p2, b_p1
        
    p0_xy_ref = XYZ(p_bottom_old.X, p_bottom_old.Y, 0)

    proj_p0_on_main = project_point_on_line_unlimited(p_bottom_old, main_origin, main_dir)
    vec_perp_raw = proj_p0_on_main - p_bottom_old
    vec_perp_xy = XYZ(vec_perp_raw.X, vec_perp_raw.Y, 0).Normalize()

    pick_proj = project_point_on_line_unlimited(pt_pick_flow, main_origin, main_dir)
    vec_flow_check = pick_proj - proj_p0_on_main
    
    is_flow_same_dir = vec_flow_check.DotProduct(main_dir) > 0
    vec_flow_dir = main_dir_xy if is_flow_same_dir else main_dir_xy.Negate()

    vec_stub_xy = (vec_perp_xy + vec_flow_dir).Normalize()

    stub_len = max(b_dia * 2.8, 0.25) 
    diag_len_target = max(b_dia * 2.0, 0.3) 

    total_dist_perp = p0_xy_ref.DistanceTo(XYZ(proj_p0_on_main.X, proj_p0_on_main.Y, 0))
    stub_consume_perp = stub_len * 0.7071
    diag_consume_perp_target = diag_len_target * 0.7071
    
    spacer_len_perp = total_dist_perp - stub_consume_perp - diag_consume_perp_target
    
    if spacer_len_perp < 0.1:
        diff = 0.1 - spacer_len_perp
        diag_consume_perp_target -= diff
        if diag_consume_perp_target < 0.05: diag_consume_perp_target = 0.05
        spacer_len_perp = 0.1
        
    diag_len_final = diag_consume_perp_target / 0.7071

    shift_xy_dist = stub_len * 0.7071
    shift_3d_dist = shift_xy_dist / main_xy_len
    shift_vec_3d = main_dir.Multiply(shift_3d_dist)
    
    if not is_flow_same_dir: shift_vec_3d = shift_vec_3d.Negate()
    p3 = proj_p0_on_main + shift_vec_3d
    
    vec_stub_rev_xy = vec_stub_xy.Negate()
    p2_xy = XYZ(p3.X, p3.Y, 0) + vec_stub_rev_xy.Multiply(stub_len)
    z_p2 = p3.Z + (stub_len * slope_abs)
    p2 = XYZ(p2_xy.X, p2_xy.Y, z_p2)
    
    vec_perp_rev = vec_perp_xy.Negate()
    p1_xy = XYZ(p2.X, p2.Y, 0) + vec_perp_rev.Multiply(spacer_len_perp)
    dist_spacer = p1_xy.DistanceTo(XYZ(p2.X, p2.Y, 0))
    z_p1 = p2.Z + (dist_spacer * slope_abs)
    p1 = XYZ(p1_xy.X, p1_xy.Y, z_p1)
    
    z_new_bottom = z_p1 + (diag_len_final * 0.7071)
    p_new_bottom = XYZ(p0_xy_ref.X, p0_xy_ref.Y, z_new_bottom)
    
    if p_new_bottom.Z >= p_top_fixed.Z: return None

    return {
        "p_top": p_top_fixed, "p_new_bot": p_new_bottom, "p_diag_end": p1,
        "p_spacer_end": p2, "p_main_conn": p3, "main_dir": main_dir
    }

# ============================================================================
# 2. MAIN EXECUTION
# ============================================================================

class PipeFilter(ISelectionFilter):
    def AllowElement(self, element): return element.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves)
    def AllowReference(self, reference, point): return False

def main():
    pipe_filter = PipeFilter()
    while True:
        try:
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B1: Click Main Pipe. ESC thoát.")
                p_main = doc.GetElement(ref_main)
                pt_pick = ref_main.GlobalPoint 
                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B2: Click Branch Pipe")
                p_branch = doc.GetElement(ref_branch)
            except OperationCanceledException: break

            geo = calculate_geometry_stretch(p_main, p_branch, pt_pick)
            if not geo: continue

            p_top, p_new_bot, p_diag_end, p_spacer_end, p_main_conn, main_dir = geo["p_top"], geo["p_new_bot"], geo["p_diag_end"], geo["p_spacer_end"], geo["p_main_conn"], geo["main_dir"]

            t = Transaction(doc, "Instant Click V8.1 Hybrid")
            t.Start()
            try:
                b_sys = p_branch.MEPSystem.GetTypeId() if p_branch.MEPSystem else doc.GetElement(p_branch.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()).Id
                b_type = p_branch.GetTypeId()
                b_lev = p_branch.ReferenceLevel.Id
                b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
                
                target_symbol = RevitUtils.get_routing_junction_symbol(doc, p_main)
                if target_symbol and not target_symbol.IsActive: target_symbol.Activate()

                new_curve = Line.CreateBound(p_top, p_new_bot)
                p_branch.Location.Curve = new_curve
                
                p_diag = Pipe.Create(doc, b_sys, b_type, b_lev, p_new_bot, p_diag_end)
                p_diag.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)

                p_spacer = Pipe.Create(doc, b_sys, b_type, b_lev, p_diag_end, p_spacer_end)
                p_spacer.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                doc.Regenerate()
                
                c_br = RevitUtils.get_closest_connector(p_branch, p_new_bot)
                c_d1 = RevitUtils.get_closest_connector(p_diag, p_new_bot)
                if c_br and c_d1: create_elbow(c_br, c_d1)

                c_d2 = RevitUtils.get_closest_connector(p_diag, p_diag_end)
                c_s1 = RevitUtils.get_closest_connector(p_spacer, p_diag_end)
                if c_d2 and c_s1: create_elbow(c_d2, c_s1)

                try:
                    v_stub_in = (p_main_conn - p_spacer_end).Normalize()
                    v_cross = main_dir.CrossProduct(v_stub_in)
                    v_dummy_dir = v_cross.CrossProduct(main_dir).Normalize()
                    if v_dummy_dir.DotProduct(v_stub_in.Negate()) < 0: v_dummy_dir = v_dummy_dir.Negate()
                        
                    p_dummy_end = p_main_conn + v_dummy_dir.Multiply(1.0)

                    new_main_id = PlumbingUtils.BreakCurve(doc, p_main.Id, p_main_conn)
                    p_main_2 = doc.GetElement(new_main_id)
                    doc.Regenerate()

                    dummy_pipe = Pipe.Create(doc, b_sys, b_type, b_lev, p_main_conn, p_dummy_end)
                    dummy_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                    doc.Regenerate()

                    c_m1 = RevitUtils.get_closest_connector(p_main, p_main_conn)
                    c_m2 = RevitUtils.get_closest_connector(p_main_2, p_main_conn)
                    c_dum = RevitUtils.get_closest_connector(dummy_pipe, p_main_conn)
                    
                    fitting = None
                    if c_m1 and c_m2 and c_dum:
                        fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
                        doc.Regenerate()

                        if fitting and target_symbol:
                            if fitting.Symbol.Id != target_symbol.Id:
                                fitting.ChangeTypeId(target_symbol.Id)
                                doc.Regenerate()
                        
                        fitting = doc.GetElement(fitting.Id)
                        doc.Delete(dummy_pipe.Id)
                        doc.Regenerate()

                        for p in fitting.Parameters:
                            p_name = p.Definition.Name.lower()
                            if any(k in p_name for k in ["angle", "góc", "bend", "goc"]):
                                if not p.IsReadOnly:
                                    try: p.Set(math.pi / 4); doc.Regenerate()
                                    except: pass
                        
                        c_wye_branch = None
                        min_dist = float('inf')
                        for c in fitting.MEPModel.ConnectorManager.Connectors:
                            if c.IsConnected: continue
                            d = c.Origin.DistanceTo(p_spacer_end)
                            if d < min_dist:
                                min_dist = d
                                c_wye_branch = c
                        
                        if c_wye_branch:
                            p_stub = Pipe.Create(doc, b_sys, b_type, b_lev, p_spacer_end, c_wye_branch.Origin)
                            p_stub.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                            doc.Regenerate()
                            
                            c_s2 = RevitUtils.get_closest_connector(p_spacer, p_spacer_end)
                            c_st1 = RevitUtils.get_closest_connector(p_stub, p_spacer_end)
                            if c_s2 and c_st1: create_elbow(c_s2, c_st1)
                            
                            c_st2 = RevitUtils.get_closest_connector(p_stub, c_wye_branch.Origin)
                            c_wye_branch.ConnectTo(c_st2)
                            doc.Regenerate()

                except Exception as e_fit: pass
                t.Commit()
            except Exception as e: t.RollBack()
        except Exception as e: break

if __name__ == "__main__":
    main()