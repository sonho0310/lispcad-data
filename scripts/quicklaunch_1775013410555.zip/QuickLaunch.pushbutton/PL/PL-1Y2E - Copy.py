# -*- coding: utf-8 -*-
import math
import clr
import traceback

clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.DB.Plumbing import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. UTILITIES ---
def mm_to_feet(mm): return mm / 304.8

def get_location_curve(element):
    if isinstance(element.Location, LocationCurve): return element.Location.Curve
    return None

def ProjectPointToLine(point, line_origin, line_dir):
    v = point - line_origin
    d = v.DotProduct(line_dir)
    return line_origin + line_dir.Multiply(d)

class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, Pipe)
    def AllowReference(self, ref, pos):
        return False

def get_connectors(element):
    if hasattr(element, "ConnectorManager") and element.ConnectorManager:
        return element.ConnectorManager.Connectors
    elif hasattr(element, "MEPModel") and element.MEPModel:
        return element.MEPModel.ConnectorManager.Connectors
    return []

def get_connector_closest(element, point):
    connectors = get_connectors(element)
    best_conn, min_dist = None, float('inf')
    for c in connectors:
        dist = c.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist, best_conn = dist, c
    return best_conn

# --- 3. CORE MATH CẬP NHẬT (BIÊN ĐỘ LINH HOẠT 43-47°) ---
def calculate_geometry(pt_pick, p_main, p_branch):
    l_main = get_location_curve(p_main)
    l_branch = get_location_curve(p_branch)
    if not l_main or not l_branch: return None

    m_org, m_dir = l_main.GetEndPoint(0), l_main.Direction.Normalize()
    b_org, b_dir = l_branch.GetEndPoint(0), l_branch.Direction.Normalize()
    
    # 1. Xác định hướng dòng chảy và điểm tham chiếu
    pt_proj = ProjectPointToLine(pt_pick, m_org, m_dir)
    pt_target_raw = l_branch.Project(pt_proj).XYZPoint
    pt_ref = ProjectPointToLine(pt_target_raw, m_org, m_dir)
    
    vec_rad = (pt_target_raw - pt_ref).Normalize()
    vec_pick = pt_pick - pt_ref
    v_long = m_dir.Negate() if vec_pick.DotProduct(m_dir) >= 0 else m_dir
    v_stub = (v_long + vec_rad).Normalize() 
    
    b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
    stub_len = max(b_dia * 3.0, mm_to_feet(350))
    
    # 2. MÁY QUÉT ĐIỂM VÀNG (SCANNING ENGINE)
    best_geo = None
    min_total_error = float('inf')
    
    # Quét dải lùi s từ 0 đến 6 feet (tăng thêm 1 foot để bao quát hơn)
    for i in range(0, 600): 
        s_test = float(i) * 0.01 
        Start_test = pt_ref + v_long.Multiply(s_test)
        StubEnd_test = Start_test + v_stub.Multiply(stub_len)
        
        # Tìm Target trên nhánh (Isosceles Triangle Logic)
        W = b_org - StubEnd_test
        w_v = W.DotProduct(b_dir)
        W_perp = W - b_dir.Multiply(w_v)
        D_actual = W_perp.GetLength() 
        
        t_c1, t_c2 = D_actual - w_v, -D_actual - w_v
        T_cand1, T_cand2 = b_org + b_dir.Multiply(t_c1), b_org + b_dir.Multiply(t_c2)
        
        # Chọn nghiệm thuận chiều dòng chảy (Chống gập ngược)
        Target_test = T_cand1 if (T_cand1 - StubEnd_test).DotProduct(v_long) > (T_cand2 - StubEnd_test).DotProduct(v_long) else T_cand2
        
        # 3. KIỂM TRA ĐIỀU KIỆN GÓC 43-47
        v_spool = (Target_test - StubEnd_test).Normalize()
        
        ang1 = math.degrees(v_spool.AngleTo(b_dir)) # Elbow 1 (Gần nhánh)
        if ang1 > 90: ang1 = 180 - ang1
        
        ang2 = math.degrees(v_spool.AngleTo(v_stub)) # Elbow 2 (Gần Wye)
        if ang2 > 90: ang2 = 180 - ang2
        
        # CHỐT BIÊN ĐỘ MỚI: 43.0 - 47.0
        if 43.0 <= ang1 <= 47.0 and 43.0 <= ang2 <= 47.0:
            total_error = abs(ang1 - 45.0) + abs(ang2 - 45.0)
            if total_error < min_total_error:
                min_total_error = total_error
                best_geo = {
                    "Start": Start_test, 
                    "StubEnd": StubEnd_test, 
                    "Target": Target_test,
                    "VecDummy90": vec_rad
                }
    
    if not best_geo:
        raise Exception("LỖI HÌNH HỌC: Không tìm được điểm kết nối nào thỏa mãn dải 43°-47°.\n" +
                        "Gợi ý: Hãy nhích nhẹ cao độ ống nhánh để lọt vào vùng an toàn!")

    return best_geo

# --- 3. MAIN EXECUTION ---
def main():
    pipe_filter = PipeSelectionFilter()
    while True:
        try:
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "1/2: Click Ống Chính (ESC để thoát)")
                p_main = doc.GetElement(ref_main)
                pt_pick = ref_main.GlobalPoint 
                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "2/2: Chọn Ống Nhánh")
                p_branch = doc.GetElement(ref_branch)
            except OperationCanceledException: break

            t = Transaction(doc, "ProMax Wye 6-Parts")
            t.Start()
            try:
                geo = calculate_geometry(pt_pick, p_main, p_branch)
                b_sys = p_branch.MEPSystem.GetTypeId() if p_branch.MEPSystem else doc.GetElement(p_branch.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()).Id
                b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()

                # Xử lý đầu ống nhánh
                l_c = p_branch.Location.Curve
                p0, p1 = l_c.GetEndPoint(0), l_c.GetEndPoint(1)
                p_branch.Location.Curve = Line.CreateBound(geo["Target"], p1) if p0.DistanceTo(geo["Target"]) < p1.DistanceTo(geo["Target"]) else Line.CreateBound(p0, geo["Target"])
                doc.Regenerate()

                # Tạo Nipple và Spool
                nip = Pipe.Create(doc, b_sys, p_branch.GetTypeId(), p_branch.LevelId, geo["Start"], geo["StubEnd"])
                nip.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                spl = Pipe.Create(doc, b_sys, p_branch.GetTypeId(), p_branch.LevelId, geo["StubEnd"], geo["Target"])
                spl.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                doc.Regenerate()
                
                # Bọc 2 Elbow
                doc.Create.NewElbowFitting(get_connector_closest(nip, geo["StubEnd"]), get_connector_closest(spl, geo["StubEnd"]))
                doc.Create.NewElbowFitting(get_connector_closest(spl, geo["Target"]), get_connector_closest(p_branch, geo["Target"]))

                # Wye Hack
                new_main_id = PlumbingUtils.BreakCurve(doc, p_main.Id, geo["Start"])
                p_main_2 = doc.GetElement(new_main_id)
                doc.Regenerate()

                dummy = Pipe.Create(doc, b_sys, p_branch.GetTypeId(), p_branch.LevelId, geo["Start"], geo["Start"] + geo["VecDummy90"].Multiply(2.0))
                dummy.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                doc.Regenerate()

                fit = doc.Create.NewTeeFitting(get_connector_closest(p_main, geo["Start"]), get_connector_closest(p_main_2, geo["Start"]), get_connector_closest(dummy, geo["Start"]))
                doc.Regenerate()
                
                # Đổi Type và nối Nipple
                rpm = doc.GetElement(p_main.GetTypeId()).RoutingPreferenceManager
                rule = rpm.GetRule(RoutingPreferenceRuleGroupType.Junctions, 0)
                if rule: fit.ChangeTypeId(rule.MEPPartId)
                doc.Delete(dummy.Id)
                doc.Regenerate()

                c_wye = None
                for c in fit.MEPModel.ConnectorManager.Connectors:
                    if not c.IsConnected: c_wye = c; break
                
                if c_wye:
                    c_nip = get_connector_closest(nip, geo["Start"])
                    ElementTransformUtils.MoveElement(doc, nip.Id, c_wye.Origin - c_nip.Origin)
                    doc.Regenerate()
                    c_wye.ConnectTo(c_nip)

                t.Commit()
            except Exception as e:
                t.RollBack()
                TaskDialog.Show("Lỗi", str(e))
        except: break

if __name__ == "__main__":
    main()