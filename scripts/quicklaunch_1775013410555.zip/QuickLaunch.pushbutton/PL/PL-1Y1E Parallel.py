# -*- coding: utf-8 -*-
import clr
import math
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

# ==============================================================================
# 1. UTILITIES & SELECTION FILTER
# ==============================================================================
class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, Pipe)
    def AllowReference(self, ref, pos):
        return False

def get_connectors(element):
    if hasattr(element, "ConnectorManager") and element.ConnectorManager:
        return element.ConnectorManager.Connectors
    elif hasattr(element, "MEPModel") and element.MEPModel:
        return element.MEPModel.ConnectorManager.Connectors
    return []

def get_connector_closest_to(element, point):
    connectors = get_connectors(element)
    best_conn = None
    min_dist = float('inf')
    for c in connectors:
        dist = c.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist = dist
            best_conn = c
    return best_conn

def ProjectPointToLine_Unlimited(line_origin, line_dir, point):
    v = point - line_origin
    d = v.DotProduct(line_dir)
    return line_origin + line_dir.Multiply(d)

# ==============================================================================
# 2. CORE MATH CHO 2 ỐNG SONG SONG (GÓC 45 ĐỘ)
# ==============================================================================
def Calculate_Parallel_1E1Y(pipeMain, pipeSub, pt_pick_main):
    l_main = pipeMain.Location.Curve
    main_origin = l_main.GetEndPoint(0)
    main_dir = l_main.Direction.Normalize()

    l_sub = pipeSub.Location.Curve
    p0 = l_sub.GetEndPoint(0)
    p1 = l_sub.GetEndPoint(1)

    if p0.DistanceTo(pt_pick_main) < p1.DistanceTo(pt_pick_main):
        p_b = p0 
    else:
        p_b = p1

    p_proj = ProjectPointToLine_Unlimited(main_origin, main_dir, p_b)
    h = p_b.DistanceTo(p_proj)

    if h < 0.1:
        raise Exception("Hai ống đang giao nhau hoặc quá sát nhau, không đủ khoảng cách gắn cụm fitting.")

    p_m1 = p_proj + main_dir.Multiply(h)
    p_m2 = p_proj - main_dir.Multiply(h)

    if p_m1.DistanceTo(pt_pick_main) < p_m2.DistanceTo(pt_pick_main):
        p_tee = p_m1
    else:
        p_tee = p_m2

    return p_tee, main_dir, p_b

# ==============================================================================
# 3. MAIN LOOP
# ==============================================================================
def main():
    pipe_filter = PipeSelectionFilter()
    
    while True:
        try:
            # 1. Bắt sự kiện chọn đối tượng (Nhấn ESC để văng ra khỏi vòng lặp)
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "1/2: Click Ống Chính (Nhấn ESC để thoát)")
                main_pipe = doc.GetElement(ref_main)
                pt_pick_main = ref_main.GlobalPoint 
            except OperationCanceledException:
                break # Thoát vòng lặp êm ái
                
            try:
                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "2/2: Click Ống Nhánh (Nhấn ESC để thoát)")
                branch_pipe = doc.GetElement(ref_branch)
            except OperationCanceledException:
                break # Thoát vòng lặp êm ái

            # Tránh user click đúp 1 ống
            if main_pipe.Id == branch_pipe.Id:
                continue

            t = Transaction(doc, "Superpowers: Auto Parallel 1Y-1E")
            t.Start()

            try:
                branch_dia = branch_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
                sys_type_id = main_pipe.MEPSystem.GetTypeId()
                pipe_type_id = main_pipe.GetTypeId()
                level_id = main_pipe.ReferenceLevel.Id

                p_tee, flow_vec, p_sub_end = Calculate_Parallel_1E1Y(main_pipe, branch_pipe, pt_pick_main)

                pipe_type = doc.GetElement(pipe_type_id)
                rpm = pipe_type.RoutingPreferenceManager
                rule = rpm.GetRule(RoutingPreferenceRuleGroupType.Junctions, 0)
                if not rule:
                    raise Exception("Ống chính chưa cài đặt Wye trong Routing Preferences.")
                wye_symbol_id = rule.MEPPartId
                wye_symbol = doc.GetElement(wye_symbol_id)
                if not wye_symbol.IsActive: wye_symbol.Activate()

                nipple_pipe = Pipe.Create(doc, sys_type_id, pipe_type_id, level_id, p_tee, p_sub_end)
                nipple_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(branch_dia)
                doc.Regenerate()

                c_sub = get_connector_closest_to(branch_pipe, p_sub_end)
                c_new = get_connector_closest_to(nipple_pipe, p_sub_end)
                if c_sub and c_new:
                    try: doc.Create.NewElbowFitting(c_sub, c_new)
                    except:
                        try:
                            c_sub.ConnectTo(c_new)
                            doc.Regenerate()
                            doc.Create.NewElbowFitting(c_sub, c_new)
                        except: pass
                doc.Regenerate()

                v_branch_out = (p_sub_end - p_tee).Normalize()
                v_branch_in = v_branch_out.Negate()
                
                v_cross = flow_vec.CrossProduct(v_branch_in)
                if v_cross.IsAlmostEqualTo(XYZ.Zero): v_cross = XYZ.BasisZ
                    
                v_dummy_dir = v_cross.CrossProduct(flow_vec).Normalize()
                if v_dummy_dir.DotProduct(v_branch_out) < 0: v_dummy_dir = v_dummy_dir.Negate()
                    
                p_dummy_end = p_tee + v_dummy_dir.Multiply(2.0)

                new_main_id = PlumbingUtils.BreakCurve(doc, main_pipe.Id, p_tee)
                p_main_2 = doc.GetElement(new_main_id)
                doc.Regenerate()

                dummy_pipe = Pipe.Create(doc, sys_type_id, pipe_type_id, level_id, p_tee, p_dummy_end)
                dummy_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(branch_dia)
                doc.Regenerate()

                c_m1 = get_connector_closest_to(main_pipe, p_tee)
                c_m2 = get_connector_closest_to(p_main_2, p_tee)
                c_dum = get_connector_closest_to(dummy_pipe, p_tee)

                fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
                doc.Regenerate()

                if fitting.Symbol.Id != wye_symbol_id:
                    fitting.ChangeTypeId(wye_symbol_id)
                    doc.Regenerate()
                    
                fitting = doc.GetElement(fitting.Id) 
                doc.Delete(dummy_pipe.Id)
                doc.Regenerate()

                actual_angle = flow_vec.AngleTo(v_branch_out)
                if actual_angle > math.pi / 2: actual_angle = math.pi - actual_angle

                for p in fitting.Parameters:
                    p_name = p.Definition.Name.lower()
                    if any(k in p_name for k in ["angle", "góc", "bend", "goc"]):
                        if not p.IsReadOnly:
                            try: p.Set(actual_angle); doc.Regenerate()
                            except: pass

                c_wye_branch = None
                min_dist = float('inf')
                for c in fitting.MEPModel.ConnectorManager.Connectors:
                    if c.IsConnected: continue
                    d = c.Origin.DistanceTo(p_sub_end)
                    if d < min_dist:
                        min_dist = d
                        c_wye_branch = c
                        
                if c_wye_branch:
                    c_nipple_m = get_connector_closest_to(nipple_pipe, p_tee)
                    diff = c_wye_branch.Origin - c_nipple_m.Origin
                    if not diff.IsAlmostEqualTo(XYZ.Zero):
                        try: 
                            ElementTransformUtils.MoveElement(doc, nipple_pipe.Id, diff)
                            doc.Regenerate()
                        except: pass
                    try: 
                        c_wye_branch.ConnectTo(c_nipple_m)
                        doc.Regenerate()
                    except: pass

                t.Commit()
                # ẨN TASKDIALOG THÀNH CÔNG THEO YÊU CẦU

            except Exception as e:
                if t.HasStarted():
                    t.RollBack() # Rollback riêng cho cặp ống bị lỗi
                import traceback
                TaskDialog.Show("Lỗi Xử Lý", "Phát hiện lỗi với cặp ống vừa chọn:\n" + str(e))
                # Không break, vẫn cho phép vòng lặp chạy tiếp với cặp ống khác

        except Exception as system_e:
            import traceback
            TaskDialog.Show("Lỗi Hệ Thống", traceback.format_exc())
            break

if __name__ == '__main__':
    main()