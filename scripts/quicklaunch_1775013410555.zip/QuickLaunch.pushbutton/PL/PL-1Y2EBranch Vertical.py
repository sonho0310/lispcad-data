# -*- coding: utf-8 -*-
"""
TOOL: PROMAX SANITARY SOLVER - FISHBONE DIRECT (V8.1 - HYBRID ULTIMATE)
AUTHOR: Gemini & User
DESCRIPTION: 
    1. LOGIC CHUẨN V8.1: Tạo Fitting Wye BẰNG ROUTING PREFERENCES.
    2. FIX CLASH: Ống Long Pipe sẽ được vẽ từ Nipple tới Connector của Wye.
"""

import math
import clr
from System.Collections.Generic import List

# --- REVIT API IMPORTS ---
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.DB.Plumbing import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException

# --- GLOBAL VARS ---
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# ============================================================================
# 1. UTILITIES
# ============================================================================
class RevitUtils(object):
    @staticmethod
    def get_closest_connector(element, point):
        if not element: return None
        try:
            conns = element.ConnectorManager.Connectors
            min_dist = float('inf')
            best_conn = None
            for c in conns:
                dist = c.Origin.DistanceTo(point)
                if dist < min_dist:
                    min_dist = dist
                    best_conn = c
            return best_conn
        except: return None

    # [SUPERPOWERS FIXED] - MẮT THẦN NATIVE API ROUTING
    @staticmethod
    def get_routing_junction_symbol(doc, pipe):
        try:
            pipe_type = doc.GetElement(pipe.GetTypeId())
            routing_manager = pipe_type.RoutingPreferenceManager
            group_type = Autodesk.Revit.DB.Plumbing.RoutingPreferenceRuleGroupType.Junction
            if routing_manager.GetNumberOfRules(group_type) == 0: return None
            
            rule = routing_manager.GetRule(group_type, 0)
            symbol_id = rule.MEPPartId
            if symbol_id and symbol_id != ElementId.InvalidElementId:
                return doc.GetElement(symbol_id)
        except: pass
        return None

# ============================================================================
# 2. CALCULATION LOGIC
# ============================================================================
def get_line_from_element(elem):
    return elem.Location.Curve if isinstance(elem.Location, LocationCurve) else None

def project_point_on_line_2d(pt_xy, line_origin_xy, line_dir_xy):
    v = pt_xy - line_origin_xy
    d = v.DotProduct(line_dir_xy)
    return line_origin_xy + line_dir_xy.Multiply(d)

def create_elbow(c1, c2):
    try: doc.Create.NewElbowFitting(c1, c2)
    except: pass

def calculate_fishbone_one_click(p_main, p_branch, pt_pick_main):
    l_main = get_line_from_element(p_main)
    l_branch = get_line_from_element(p_branch)
    b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
    
    main_p_start = l_main.GetEndPoint(0)
    main_p_end = l_main.GetEndPoint(1)
    
    main_dir_3d = (main_p_end - main_p_start).Normalize()
    main_dir_xy = XYZ(main_dir_3d.X, main_dir_3d.Y, 0).Normalize()
    main_start_xy = XYZ(main_p_start.X, main_p_start.Y, 0)
    slope_vec_3d = main_p_end - main_p_start

    b_p1 = l_branch.GetEndPoint(0)
    b_p2 = l_branch.GetEndPoint(1)
    
    if b_p1.Z > b_p2.Z: p_top_fixed, p_bottom_old = b_p1, b_p2
    else: p_top_fixed, p_bottom_old = b_p2, b_p1
        
    p0_xy_ref = XYZ(p_bottom_old.X, p_bottom_old.Y, 0)
    proj_p0_xy = project_point_on_line_2d(p0_xy_ref, main_start_xy, main_dir_xy)
    dist_perp_xy = p0_xy_ref.DistanceTo(proj_p0_xy)
    
    pt_pick_xy = XYZ(pt_pick_main.X, pt_pick_main.Y, 0)
    pick_proj_xy = project_point_on_line_2d(pt_pick_xy, main_start_xy, main_dir_xy)
    
    vec_flow_check = pick_proj_xy - proj_p0_xy
    is_flow_same_dir = True if vec_flow_check.GetLength() < 0.01 else vec_flow_check.DotProduct(main_dir_xy) > 0
    
    shift_vec_xy = main_dir_xy.Multiply(dist_perp_xy)
    if not is_flow_same_dir: shift_vec_xy = shift_vec_xy.Negate()
    
    p_end_xy = proj_p0_xy + shift_vec_xy
    vec_to_end_xy = p_end_xy - main_start_xy
    slope_vec_xy = XYZ(slope_vec_3d.X, slope_vec_3d.Y, 0)
    
    len_sq = slope_vec_xy.DotProduct(slope_vec_xy) 
    if len_sq == 0: len_sq = 0.0001
    
    t_factor = vec_to_end_xy.DotProduct(slope_vec_xy) / len_sq
    p_end = main_p_start + slope_vec_3d.Multiply(t_factor)
    
    slope_abs = abs(main_dir_3d.Z / math.sqrt(main_dir_3d.X**2 + main_dir_3d.Y**2))
    nipple_len = max(b_dia * 2.0, 0.15) 
    nipple_offset_xy = nipple_len * 0.7071

    vec_fishbone_xy = (XYZ(p_end.X, p_end.Y, 0) - p0_xy_ref).Normalize()
    p2_xy = p0_xy_ref + vec_fishbone_xy.Multiply(nipple_offset_xy)
    
    dist_long_pipe_xy = p2_xy.DistanceTo(XYZ(p_end.X, p_end.Y, 0))
    z_p2 = p_end.Z + (dist_long_pipe_xy * slope_abs)
    p2 = XYZ(p2_xy.X, p2_xy.Y, z_p2)
    
    p1_xy = p0_xy_ref
    delta_xy_nipple = p1_xy.DistanceTo(p2_xy)
    z_p1 = z_p2 + delta_xy_nipple
    p1 = XYZ(p1_xy.X, p1_xy.Y, z_p1)
    
    if p1.Z >= p_top_fixed.Z: return None
    
    return {
        "p_top": p_top_fixed, "p1": p1, "p2": p2, "p_end": p_end, 
        "main_dir": main_dir_3d
    }

# ============================================================================
# 3. MAIN EXECUTION
# ============================================================================
class PipeFilter(ISelectionFilter):
    def AllowElement(self, element):
        return element.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves)
    def AllowReference(self, reference, point): return False

def main():
    pipe_filter = PipeFilter()
    
    while True:
        try:
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B1: Chọn Main Pipe")
                p_main = doc.GetElement(ref_main)
                pt_pick_main = ref_main.GlobalPoint 
                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B2: Chọn Branch Pipe")
                p_branch = doc.GetElement(ref_branch)
            except OperationCanceledException: break 

            geo = calculate_fishbone_one_click(p_main, p_branch, pt_pick_main)
            if not geo: continue

            p_top, p_new_bot, p_nipple_end, p_end, main_dir = geo["p_top"], geo["p1"], geo["p2"], geo["p_end"], geo["main_dir"]

            t = Transaction(doc, "Fishbone V8.1 Hybrid")
            t.Start()
            
            try:
                b_sys = p_branch.MEPSystem.GetTypeId() if p_branch.MEPSystem else doc.GetElement(p_branch.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()).Id
                b_type = p_branch.GetTypeId()
                b_lev = p_branch.ReferenceLevel.Id
                b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
                
                target_symbol = RevitUtils.get_routing_junction_symbol(doc, p_main)
                if target_symbol and not target_symbol.IsActive: target_symbol.Activate()

                new_curve = Line.CreateBound(p_top, p_new_bot)
                p_branch.Location.Curve = new_curve
                
                p_nipple = Pipe.Create(doc, b_sys, b_type, b_lev, p_new_bot, p_nipple_end)
                p_nipple.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                doc.Regenerate()
                
                c_br = RevitUtils.get_closest_connector(p_branch, p_new_bot)
                c_n1 = RevitUtils.get_closest_connector(p_nipple, p_new_bot)
                if c_br and c_n1: create_elbow(c_br, c_n1)
                doc.Regenerate()

                try:
                    v_branch_in = (p_end - p_nipple_end).Normalize()
                    v_cross = main_dir.CrossProduct(v_branch_in)
                    v_dummy_dir = v_cross.CrossProduct(main_dir).Normalize() 
                    if v_dummy_dir.DotProduct(v_branch_in.Negate()) < 0: v_dummy_dir = v_dummy_dir.Negate()
                    p_dummy_end = p_end + v_dummy_dir.Multiply(1.0) 

                    new_main_id = PlumbingUtils.BreakCurve(doc, p_main.Id, p_end)
                    p_main_2 = doc.GetElement(new_main_id)
                    dummy_pipe = Pipe.Create(doc, b_sys, b_type, b_lev, p_end, p_dummy_end)
                    dummy_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                    doc.Regenerate()

                    c_m1 = RevitUtils.get_closest_connector(p_main, p_end)
                    c_m2 = RevitUtils.get_closest_connector(p_main_2, p_end)
                    c_dum = RevitUtils.get_closest_connector(dummy_pipe, p_end)
                    
                    fitting = None
                    if c_m1 and c_m2 and c_dum:
                        fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
                        doc.Regenerate()

                        if fitting and target_symbol:
                            if fitting.Symbol.Id != target_symbol.Id:
                                fitting.ChangeTypeId(target_symbol.Id)
                                doc.Regenerate()
                        
                        fitting = doc.GetElement(fitting.Id) 
                        doc.Delete(dummy_pipe.Id) 
                        doc.Regenerate()

                        for p in fitting.Parameters:
                            p_name = p.Definition.Name.lower()
                            if any(k in p_name for k in ["angle", "góc", "bend", "goc"]):
                                if not p.IsReadOnly:
                                    try: p.Set(math.pi / 4); doc.Regenerate(); break
                                    except: pass
                        
                        c_wye_branch = None
                        min_dist = float('inf')
                        for c in fitting.MEPModel.ConnectorManager.Connectors:
                            if c.IsConnected: continue
                            d = c.Origin.DistanceTo(p_nipple_end)
                            if d < min_dist:
                                min_dist = d
                                c_wye_branch = c
                        
                        if c_wye_branch:
                            p_long = Pipe.Create(doc, b_sys, b_type, b_lev, p_nipple_end, c_wye_branch.Origin)
                            p_long.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
                            doc.Regenerate()
                            
                            c_n2 = RevitUtils.get_closest_connector(p_nipple, p_nipple_end)
                            c_l1 = RevitUtils.get_closest_connector(p_long, p_nipple_end)
                            if c_n2 and c_l1: create_elbow(c_n2, c_l1)
                            
                            c_l2 = RevitUtils.get_closest_connector(p_long, c_wye_branch.Origin)
                            c_wye_branch.ConnectTo(c_l2)
                            doc.Regenerate()
                except Exception as e_fit: pass
                t.Commit()
            except: t.RollBack()
        except: break

if __name__ == "__main__":
    main()