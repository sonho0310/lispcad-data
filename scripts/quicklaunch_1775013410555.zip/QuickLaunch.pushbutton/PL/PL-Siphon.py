# -*- coding: utf-8 -*-
__title__ = "Siphon Supreme"

import clr
clr.AddReference('RevitAPIUI')
clr.AddReference('System.Drawing')
clr.AddReference('PresentationCore')

import System
from System.Diagnostics import Process
from System.Windows.Interop import Imaging
from System.Windows import Int32Rect
import math, traceback, tempfile, os, io

from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

doc = revit.doc
uidoc = revit.uidoc

# --- KỊCH BẢN GIAO DIỆN (WPF XAML) ĐÃ GIẢM 2 SIZE ---
XAML_CONTENT = u"""<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Replace with Siphon" Height="260" Width="520"
        WindowStartupLocation="CenterScreen"
        Background="#FAFAFA"
        ResizeMode="NoResize"
        ShowInTaskbar="False"
        Topmost="True"
        FontFamily="Segoe UI">
    <Window.Resources>
        <Style x:Key="PrimaryBtn" TargetType="Button">
            <Setter Property="Background" Value="#3B82F6"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Padding" Value="10,6"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="6">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
            <Style.Triggers>
                <Trigger Property="IsMouseOver" Value="True">
                    <Setter Property="Background" Value="#2563EB"/>
                </Trigger>
            </Style.Triggers>
        </Style>
    </Window.Resources>
    
    <Grid Margin="20,20,20,15">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <TextBlock Text="Target Siphon Type" FontSize="13" FontWeight="SemiBold" Foreground="#6B7280" Margin="0,0,0,8" Grid.Row="0"/>
        
        <Border Grid.Row="1" BorderBrush="#D1D5DB" BorderThickness="1" CornerRadius="4" Background="White">
            <ComboBox x:Name="combo_box" Height="34" VerticalContentAlignment="Center" FontSize="15" BorderThickness="0" Background="Transparent"/>
        </Border>

        <Border Grid.Row="2" BorderBrush="#D1D5DB" BorderThickness="1" CornerRadius="4" Background="White" Margin="0,12,0,0">
            <Grid>
                <TextBlock Text="🔍 Gõ để tìm kiếm..." Foreground="#9CA3AF" FontSize="13" Margin="10,0,0,0" VerticalAlignment="Center" IsHitTestVisible="False">
                    <TextBlock.Style>
                        <Style TargetType="TextBlock">
                            <Setter Property="Visibility" Value="Collapsed"/>
                            <Style.Triggers>
                                <DataTrigger Binding="{Binding Text, ElementName=txt_search}" Value="">
                                    <Setter Property="Visibility" Value="Visible"/>
                                </DataTrigger>
                            </Style.Triggers>
                        </Style>
                    </TextBlock.Style>
                </TextBlock>
                <TextBox x:Name="txt_search" Height="34" VerticalContentAlignment="Center" FontSize="15" BorderThickness="0" Background="Transparent" Padding="10,0"/>
            </Grid>
        </Border>

        <Border Grid.Row="4" BorderBrush="#E5E7EB" BorderThickness="0,1,0,0" Padding="0,15,0,0" Margin="0,10,0,0">
            <StackPanel Orientation="Horizontal" HorizontalAlignment="Right">
                <Button x:Name="btn_ok" Content="Apply Change" FontSize="13" Style="{StaticResource PrimaryBtn}" Width="120" Height="34" />
            </StackPanel>
        </Border>
    </Grid>
</Window>"""

class SiphonUI(forms.WPFWindow):
    def __init__(self, dict_items):
        self.selected_family = None
        self.dict_items = dict_items
        self.all_keys = sorted(dict_items.keys())
        
        # Khởi tạo Config của pyRevit để lưu data
        try:
            self.cfg = script.get_config("SiphonSupremeApp")
        except:
            self.cfg = None
        
        self.xaml_path = os.path.join(tempfile.gettempdir(), 'siphon_luxury_ui.xaml')
        with io.open(self.xaml_path, 'w', encoding='utf-8') as f:
            f.write(XAML_CONTENT)
            
        forms.WPFWindow.__init__(self, self.xaml_path)
        
        try:
            process_path = Process.GetCurrentProcess().MainModule.FileName
            sys_icon = System.Drawing.Icon.ExtractAssociatedIcon(process_path)
            bmp_src = Imaging.CreateBitmapSourceFromHIcon(
                sys_icon.Handle,
                Int32Rect.Empty,
                System.Windows.Media.Imaging.BitmapSizeOptions.FromEmptyOptions())
            self.Icon = bmp_src
        except Exception:
            pass 
        
        self.combo_box.ItemsSource = self.all_keys
        
        # --- LOGIC NHỚ LỰA CHỌN CUỐI CÙNG ---
        last_choice = None
        if self.cfg:
            last_choice = getattr(self.cfg, "last_siphon_type", None)
            
        if last_choice and last_choice in self.all_keys:
            self.combo_box.SelectedItem = last_choice
        elif self.combo_box.ItemsSource:
            self.combo_box.SelectedIndex = 0
            
        self.btn_ok.Click += self.Apply_Click
        self.txt_search.TextChanged += self.Search_TextChanged
            
    def Search_TextChanged(self, sender, e):
        keyword = self.txt_search.Text.lower()
        if not keyword:
            filtered_keys = self.all_keys
        else:
            filtered_keys = [k for k in self.all_keys if keyword in k.lower()]
        
        self.combo_box.ItemsSource = filtered_keys
        if filtered_keys:
            self.combo_box.SelectedIndex = 0

    def Apply_Click(self, sender, e):
        sel_key = self.combo_box.SelectedItem
        if sel_key:
            self.selected_family = self.dict_items[sel_key]
            
            # Lưu lại lựa chọn vào config
            if self.cfg:
                try:
                    self.cfg.last_siphon_type = sel_key
                    script.save_config()
                except:
                    pass
                    
        self.Close()


# --- LỚP LỌC CO ỐNG KHI CLICK CHUỘT ---
class FittingFilter(ISelectionFilter):
    def AllowElement(self, e):
        return e.Category and e.Category.Id.IntegerValue == int(DB.BuiltInCategory.OST_PipeFitting)
    def AllowReference(self, r, p): return False

def get_phys_conns(el):
    try:
        mgr = el.MEPModel.ConnectorManager if hasattr(el, "MEPModel") else el.ConnectorManager
        return [c for c in mgr.Connectors if c.ConnectorType != DB.ConnectorType.Logical]
    except: return []

def force_size_instance(instance, size_mm):
    r_ft = (size_mm / 2.0) / 304.8
    d_ft = size_mm / 304.8
    for p in instance.Parameters:
        if p.IsReadOnly: continue
        nm = p.Definition.Name.lower()
        if any(x in nm for x in ["radius", "bán kính", "r", "phi"]):
            try: p.Set(r_ft)
            except: pass
        elif any(x in nm for x in ["diameter", "đường kính", "dn", "d "]):
            try: p.Set(d_ft)
            except: pass
    for c in get_phys_conns(instance):
        try:
            p_rad = c.get_Parameter(DB.BuiltInParameter.RBS_CON_RADIUS)
            if p_rad and not p_rad.IsReadOnly: p_rad.Set(r_ft)
        except: pass

def stretch_vertical_perfect(p_conn, target_z):
    try:
        pipe = p_conn.Owner
        lc = pipe.Location
        line = lc.Curve
        p0 = line.GetEndPoint(0)
        p1 = line.GetEndPoint(1)
        if p0.DistanceTo(p_conn.Origin) < p1.DistanceTo(p_conn.Origin):
            lc.Curve = DB.Line.CreateBound(DB.XYZ(p0.X, p0.Y, target_z), p1)
        else:
            lc.Curve = DB.Line.CreateBound(p0, DB.XYZ(p1.X, p1.Y, target_z))
    except: pass

def stretch_slope_perfect(p_conn, target_pt):
    try:
        pipe = p_conn.Owner
        line = pipe.Location.Curve
        inf_line = DB.Line.CreateUnbound(line.GetEndPoint(0), line.Direction)
        proj_pt = inf_line.Project(target_pt).XYZPoint
        p0 = line.GetEndPoint(0)
        p1 = line.GetEndPoint(1)
        if p0.DistanceTo(p_conn.Origin) < p1.DistanceTo(p_conn.Origin):
            pipe.Location.Curve = DB.Line.CreateBound(proj_pt, p1)
        else:
            pipe.Location.Curve = DB.Line.CreateBound(p0, proj_pt)
    except: pass

def get_pipe_away_dir(pipe_conn):
    curve = pipe_conn.Owner.Location.Curve
    p0 = curve.GetEndPoint(0)
    p1 = curve.GetEndPoint(1)
    if p0.DistanceTo(pipe_conn.Origin) < p1.DistanceTo(pipe_conn.Origin):
        return (p1 - p0).Normalize()
    else:
        return (p0 - p1).Normalize()


def main():
    f_types = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_PipeFitting).WhereElementIsElementType().ToElements()
    f_dict = {"[{}] {}".format(t.Family.FamilyCategory.Name, t.Family.Name): t.Family for t in f_types}
    
    ui = SiphonUI(f_dict)
    ui.ShowDialog()
    
    if not ui.selected_family: 
        return
        
    s_family = ui.selected_family

    success_count = 0
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, FittingFilter(), "Click Co (Elbow) đổi Siphon - Tạch tạch... Bấm ESC để Dừng")
            elbow = doc.GetElement(ref)
        except OperationCanceledException: 
            break
        except: 
            break

        try:
            with revit.Transaction("Siphon Thần Thánh"):
                conns = get_phys_conns(elbow)
                p_refs = []
                for c in conns:
                    if c.IsConnected:
                        for r in c.AllRefs:
                            if r.Owner.Id != elbow.Id: p_refs.append(r)
                if len(p_refs) < 2: continue
                
                p_sorted = sorted(p_refs, key=lambda p: abs(p.CoordinateSystem.BasisZ.Z), reverse=True)
                v_p = p_sorted[0]
                h_p = p_sorted[1]
                
                v_pipe_id = v_p.Owner.Id
                h_pipe_id = h_p.Owner.Id
                v_pipe_origin = v_p.Origin
                h_pipe_origin = h_p.Origin

                size_mm = int(round(v_p.Radius * 2 * 304.8))
                lvl_id = elbow.LevelId if elbow.LevelId.IntegerValue != -1 else v_p.Owner.LevelId

                target_pipe_vec = get_pipe_away_dir(h_p)
                target_pipe_vec = DB.XYZ(target_pipe_vec.X, target_pipe_vec.Y, 0).Normalize()
                ang_target = math.atan2(target_pipe_vec.Y, target_pipe_vec.X)

                for c in get_phys_conns(elbow):
                    if c.IsConnected:
                        for r in c.AllRefs:
                            try: c.DisconnectFrom(r)
                            except: pass

                doc.Delete(elbow.Id)

                f_symbols = [doc.GetElement(id) for id in s_family.GetFamilySymbolIds()]
                target_type = next((fs for fs in f_symbols if str(size_mm) in fs.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()), f_symbols[0])
                if not target_type.IsActive: target_type.Activate()

                siphon = doc.Create.NewFamilyInstance(DB.XYZ(99999,99999,0), target_type, doc.GetElement(lvl_id), DB.Structure.StructuralType.NonStructural)
                
                force_size_instance(siphon, size_mm)
                doc.Regenerate()

                for c in get_phys_conns(siphon):
                    if c.IsConnected:
                        for r in c.AllRefs:
                            try: c.DisconnectFrom(r)
                            except: pass
                doc.Regenerate()

                tf_inv = siphon.GetTransform().Inverse 
                s_conns = list(get_phys_conns(siphon))
                
                def sort_key(c):
                    lp = tf_inv.OfPoint(c.Origin)
                    return (round(lp.Z, 3), -lp.DistanceTo(DB.XYZ.Zero))
                s_conns_sorted = sorted(s_conns, key=sort_key, reverse=True)
                
                s_v = s_conns_sorted[0]
                s_h = min([c for c in s_conns if c.Id != s_v.Id], key=lambda c: abs(tf_inv.OfVector(c.CoordinateSystem.BasisZ).Z))

                s_v_id = s_v.Id
                s_h_id = s_h.Id

                c_up = s_v.CoordinateSystem.BasisZ
                t_up = DB.XYZ.BasisZ
                if not c_up.IsAlmostEqualTo(t_up):
                    ang_v = c_up.AngleTo(t_up)
                    axis_v = c_up.CrossProduct(t_up)
                    if axis_v.GetLength() < 0.001: axis_v = DB.XYZ.BasisX
                    DB.ElementTransformUtils.RotateElement(doc, siphon.Id, DB.Line.CreateBound(s_v.Origin, s_v.Origin + axis_v), ang_v)
                    doc.Regenerate()

                s_v = next(c for c in get_phys_conns(siphon) if c.Id == s_v_id)
                s_h = next(c for c in get_phys_conns(siphon) if c.Id == s_h_id)

                curr_body_vec = DB.XYZ(s_h.Origin.X - s_v.Origin.X, s_h.Origin.Y - s_v.Origin.Y, 0)
                if curr_body_vec.GetLength() < 0.01:
                    curr_body_vec = DB.XYZ(s_h.CoordinateSystem.BasisZ.X, s_h.CoordinateSystem.BasisZ.Y, 0)
                curr_body_vec = curr_body_vec.Normalize()

                ang_current = math.atan2(curr_body_vec.Y, curr_body_vec.X)
                diff_angle = (ang_target - ang_current) % (2 * math.pi)

                if diff_angle > 0.0001 and diff_angle < (2 * math.pi - 0.0001):
                    rot_axis = DB.Line.CreateBound(s_v.Origin, s_v.Origin + DB.XYZ.BasisZ)
                    DB.ElementTransformUtils.RotateElement(doc, siphon.Id, rot_axis, diff_angle)
                    doc.Regenerate()

                s_v = next(c for c in get_phys_conns(siphon) if c.Id == s_v_id)
                move_xy = DB.XYZ(v_pipe_origin.X - s_v.Origin.X, v_pipe_origin.Y - s_v.Origin.Y, 0)
                DB.ElementTransformUtils.MoveElement(doc, siphon.Id, move_xy)
                doc.Regenerate()

                s_h = next(c for c in get_phys_conns(siphon) if c.Id == s_h_id)
                h_pipe_elem = doc.GetElement(h_pipe_id)
                h_curve = h_pipe_elem.Location.Curve
                inf_line = DB.Line.CreateUnbound(h_curve.GetEndPoint(0), h_curve.Direction)
                snap_pt = inf_line.Project(s_h.Origin).XYZPoint
                
                z_diff = snap_pt.Z - s_h.Origin.Z
                if abs(z_diff) > 0.0001:
                    DB.ElementTransformUtils.MoveElement(doc, siphon.Id, DB.XYZ(0, 0, z_diff))
                    doc.Regenerate()

                s_v_f = next(c for c in get_phys_conns(siphon) if c.Id == s_v_id)
                s_h_f = next(c for c in get_phys_conns(siphon) if c.Id == s_h_id)

                def get_closest_conn(pipe_elem, p_origin):
                    conns = get_phys_conns(pipe_elem)
                    return sorted(conns, key=lambda c: c.Origin.DistanceTo(p_origin))[0] if conns else None

                current_vp = get_closest_conn(doc.GetElement(v_pipe_id), v_pipe_origin)
                current_hp = get_closest_conn(doc.GetElement(h_pipe_id), h_pipe_origin)

                if current_vp:
                    stretch_vertical_perfect(current_vp, s_v_f.Origin.Z)
                    current_vp.ConnectTo(s_v_f)

                if current_hp:
                    stretch_slope_perfect(current_hp, s_h_f.Origin)
                    current_hp.ConnectTo(s_h_f)

            success_count += 1
        except Exception:
            pass


if __name__ == '__main__':
    main()