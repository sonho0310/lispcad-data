# -*- coding: utf-8 -*-
import clr
import sys
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Structure import StructuralType
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.UI.Selection import ObjectType

# Thiết lập Document
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# Đổi cao độ: 200mm
MM_TO_FT = 1 / 304.8
OFFSET_MM = 200.0
OFFSET_FT = OFFSET_MM * MM_TO_FT

def get_specific_cap_symbol():
    target_type_name = u"Đầu bịt trơn uPVC" 
    collector = FilteredElementCollector(doc).OfClass(FamilySymbol).OfCategory(BuiltInCategory.OST_PipeFitting)
    for symbol in collector:
        name_param = symbol.get_Parameter(BuiltInParameter.SYMBOL_NAME_PARAM)
        type_name = name_param.AsString() if name_param else ""
        if not type_name:
            try: type_name = symbol.Name
            except: pass
                
        if type_name == target_type_name:
            if not symbol.IsActive: symbol.Activate()
            return symbol
    return None

def get_top_open_connector(pipe):
    top_conn = None
    max_z = -float('inf')
    for conn in pipe.ConnectorManager.Connectors:
        if not conn.IsConnected and conn.Origin.Z > max_z:
            top_conn = conn
            max_z = conn.Origin.Z
    return top_conn

def get_first_connector(inst):
    if inst.MEPModel and inst.MEPModel.ConnectorManager:
        for conn in inst.MEPModel.ConnectorManager.Connectors:
            return conn
    return None

def get_closest_level_by_z(document, z_elevation):
    """
    TASK: Dò tìm Tầng dựa trên tọa độ Z hình học thực tế, 
    bỏ qua hoàn toàn thuộc tính LevelId ảo của ống để chống lỗi.
    """
    all_levels = FilteredElementCollector(document).OfClass(Level).ToElements()
    if not all_levels: return None
    
    # Tìm level có cao độ gần với điểm hở của ống nhất
    closest_level = min(all_levels, key=lambda lvl: abs(lvl.Elevation - z_elevation))
    return closest_level

def process_pipe_logic(pipe):
    # Lấy đầu hở của ống trước để biết nó đang ở cao độ thực tế nào
    top_conn = get_top_open_connector(pipe)
    if not top_conn: return False
    
    top_z = top_conn.Origin.Z
    
    # --- SMART LEVEL DETECTION (GEOMETRIC) ---
    target_level = get_closest_level_by_z(doc, top_z)
    if not target_level: return False
    
    target_z = target_level.Elevation + OFFSET_FT
    curve = pipe.Location.Curve
    p0, p1 = curve.GetEndPoint(0), curve.GetEndPoint(1)

    # Ép đỉnh ống về đúng cao độ Target Z
    if p0.Z > p1.Z:
        new_curve = Line.CreateBound(XYZ(p0.X, p0.Y, target_z), p1)
    else:
        new_curve = Line.CreateBound(p0, XYZ(p1.X, p1.Y, target_z))

    pipe.Location.Curve = new_curve
    doc.Regenerate()

    cap_symbol = get_specific_cap_symbol()

    if cap_symbol:
        # Gán Target Level cho Object Nắp Bịt
        cap_inst = doc.Create.NewFamilyInstance(top_conn.Origin, cap_symbol, target_level, StructuralType.NonStructural)
        doc.Regenerate()
        
        cap_conn = get_first_connector(cap_inst)
        if cap_conn:
            pipe_diameter = top_conn.Radius * 2.0
            params_to_try = ["ND", "Nominal Diameter", "Nominal Radius", u"Kích thước"]
            
            for p_name in params_to_try:
                param = cap_inst.LookupParameter(p_name)
                if param and not param.IsReadOnly:
                    try: 
                        val = top_conn.Radius if "Radius" in p_name else pipe_diameter
                        param.Set(val)
                    except: pass
            
            doc.Regenerate()
            cap_conn = get_first_connector(cap_inst)

            # Khớp hướng và vị trí
            target_dir = top_conn.CoordinateSystem.BasisZ.Negate()
            cap_dir = cap_conn.CoordinateSystem.BasisZ
            
            if cap_dir.AngleTo(target_dir) > 0.001:
                axis = cap_dir.CrossProduct(target_dir)
                if axis.GetLength() < 0.001: axis = cap_conn.CoordinateSystem.BasisX
                ElementTransformUtils.RotateElement(doc, cap_inst.Id, Line.CreateBound(cap_conn.Origin, cap_conn.Origin + axis), cap_dir.AngleTo(target_dir))
                doc.Regenerate()
                cap_conn = get_first_connector(cap_inst)

            ElementTransformUtils.MoveElement(doc, cap_inst.Id, top_conn.Origin - cap_conn.Origin)
            doc.Regenerate()

            # Connect
            is_pinned = pipe.Pinned
            pipe.Pinned = True
            try: top_conn.ConnectTo(cap_conn)
            finally: pipe.Pinned = is_pinned
        return True
    return False

def run_loop():
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, "Chọn ống Toilet (ESC để thoát)")
            pipe = doc.GetElement(ref)
            
            if pipe.Category.Id.IntegerValue != int(BuiltInCategory.OST_PipeCurves):
                continue

            with Transaction(doc, "Auto Cap Toilet Pipe Smart Level") as t:
                t.Start()
                if process_pipe_logic(pipe):
                    t.Commit()
                else:
                    t.RollBack()
        except:
            break

if __name__ == "__main__":
    run_loop()