# -*- coding: utf-8 -*-
import math
import clr
import traceback

clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.DB.Plumbing import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. UTILITIES ---
def mm_to_feet(mm): return mm / 304.8

def get_location_curve(element):
    if isinstance(element.Location, LocationCurve): return element.Location.Curve
    return None

def ProjectPointToLine(point, line_origin, line_dir):
    v = point - line_origin
    d = v.DotProduct(line_dir)
    return line_origin + line_dir.Multiply(d)

class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, Pipe)
    def AllowReference(self, ref, pos):
        return False

def get_connectors(element):
    if hasattr(element, "ConnectorManager") and element.ConnectorManager:
        return element.ConnectorManager.Connectors
    elif hasattr(element, "MEPModel") and element.MEPModel:
        return element.MEPModel.ConnectorManager.Connectors
    return []

def get_connector_closest(element, point):
    connectors = get_connectors(element)
    best_conn = None
    min_dist = float('inf')
    for c in connectors:
        dist = c.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist = dist
            best_conn = c
    return best_conn

# --- 2. TÌM FAMILY WYE CHUẨN (TỪ PROMAX V53) ---
def get_ultimate_fitting_symbol(doc, pipe):
    try:
        pipe_type = doc.GetElement(pipe.GetTypeId())
        rpm = pipe_type.RoutingPreferenceManager
        rule = rpm.GetRule(RoutingPreferenceRuleGroupType.Junctions, 0)
        sym_id = rule.MEPPartId
        if sym_id != ElementId.InvalidElementId:
            return doc.GetElement(sym_id)
    except: pass
    return None

# --- 3. CORE MATH (ĐÃ NGHIỆM THU Ở TASK 1) ---
def calculate_geometry(pt_pick, p_main, p_branch):
    l_main = get_location_curve(p_main)
    l_branch = get_location_curve(p_branch)
    if not l_main or not l_branch: return None

    m_org, m_dir = l_main.GetEndPoint(0), l_main.Direction.Normalize()
    b_org, b_dir = l_branch.GetEndPoint(0), l_branch.Direction.Normalize()
    
    pt_proj = ProjectPointToLine(pt_pick, m_org, m_dir)
    pt_target_raw = l_branch.Project(pt_proj).XYZPoint
    pt_ref = ProjectPointToLine(pt_target_raw, m_org, m_dir)
    
    vec_rad = pt_target_raw - pt_ref
    if vec_rad.IsAlmostEqualTo(XYZ.Zero): vec_rad = b_dir 
    vec_rad = vec_rad.Normalize()
        
    vec_pick = pt_pick - pt_ref
    v_long = m_dir.Negate() if vec_pick.DotProduct(m_dir) >= 0 else m_dir
    v_stub = (v_long + vec_rad).Normalize() 
    
    b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
    stub_len = max(b_dia * 3.0, mm_to_feet(350))
    
    target_spool_len = max(b_dia * 2.5, 0.25)
    D_req = target_spool_len / math.sqrt(2)
    
    C = pt_ref + v_stub.Multiply(stub_len) - b_org
    A = 1.0 - (v_long.DotProduct(b_dir))**2
    B = 2.0 * (C.DotProduct(v_long) - C.DotProduct(b_dir) * v_long.DotProduct(b_dir))
    K = C.DotProduct(C) - (C.DotProduct(b_dir))**2
    
    s = 0.0
    if abs(A) > 1e-5:
        discriminant = B**2 - 4 * A * (K - D_req**2)
        if discriminant >= 0:
            s1 = (-B + math.sqrt(discriminant)) / (2*A)
            s2 = (-B - math.sqrt(discriminant)) / (2*A)
            valid_s = [x for x in (s1, s2) if x >= -0.01]
            if valid_s: s = max(valid_s)
            else: s = -B / (2*A)
        else:
            s = -B / (2*A)
            if s < 0: s = 0.0
    else:
        s = stub_len * 0.70710678
        
    Start = pt_ref + v_long.Multiply(s)
    StubEnd = Start + v_stub.Multiply(stub_len)
    
    W = b_org - StubEnd
    w_v = W.DotProduct(b_dir)
    W_perp = W - b_dir.Multiply(w_v)
    D_actual = W_perp.GetLength() 
    
    t1 = D_actual - w_v
    t2 = -D_actual - w_v
    Target1 = b_org + b_dir.Multiply(t1)
    Target2 = b_org + b_dir.Multiply(t2)
    
    Target = Target1 if Target1.DistanceTo(pt_target_raw) < Target2.DistanceTo(pt_target_raw) else Target2
    
    return {
        "Start": Start, "StubEnd": StubEnd, "Target": Target,
        "VecDummy90": vec_rad # Vector vuông góc dùng để vẽ ống mồi đẻ Tee
    }

# --- 4. MAIN EXECUTION ---
def main():
    pipe_filter = PipeSelectionFilter()

    try:
        ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "Task 2&3: Chọn Main Pipe")
        p_main = doc.GetElement(ref_main)
        pt_pick_raw = ref_main.GlobalPoint 
        
        ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "Task 2&3: Chọn Branch Pipe")
        p_branch = doc.GetElement(ref_branch)

        target_symbol = get_ultimate_fitting_symbol(doc, p_main)
        if not target_symbol:
            TaskDialog.Show("Lỗi Routing", "Không tìm thấy Family Wye trong Routing Preferences của ống chính.")
            return

        geo = calculate_geometry(pt_pick_raw, p_main, p_branch)
        if not geo: return

        t = Transaction(doc, "Task 2&3: Perfect ProMax 6-Parts")
        t.Start()

        if not target_symbol.IsActive: target_symbol.Activate()
        
        b_sys = p_branch.MEPSystem.GetTypeId() if p_branch.MEPSystem else doc.GetElement(p_branch.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()).Id
        b_type = p_branch.GetTypeId()
        b_lev = p_branch.ReferenceLevel.Id
        b_dia = p_branch.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()

        # [TASK 1] - XỬ LÝ ỐNG NHÁNH
        l_c = p_branch.Location.Curve
        p0, p1 = l_c.GetEndPoint(0), l_c.GetEndPoint(1)
        t_pt = geo["Target"]
        new_c = Line.CreateBound(t_pt, p1) if p0.DistanceTo(t_pt) < p1.DistanceTo(t_pt) else Line.CreateBound(p0, t_pt)
        if new_c.Length > 0.01: p_branch.Location.Curve = new_c
        doc.Regenerate()

        # [TASK 3] - TẠO NIPPLE, SPOOL VÀ 2 CO 45 (Bọc từ Nhánh về)
        nipple_pipe = Pipe.Create(doc, b_sys, b_type, b_lev, geo["Start"], geo["StubEnd"])
        nipple_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
        
        spool_pipe = Pipe.Create(doc, b_sys, b_type, b_lev, geo["StubEnd"], geo["Target"])
        spool_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
        doc.Regenerate()
        
        # Bọc Co 1 (Giữa Nipple và Spool)
        c_nip_end, c_spool_start = get_connector_closest(nipple_pipe, geo["StubEnd"]), get_connector_closest(spool_pipe, geo["StubEnd"])
        if c_nip_end and c_spool_start: doc.Create.NewElbowFitting(c_nip_end, c_spool_start)
        
        # Bọc Co 2 (Giữa Spool và Branch)
        c_spool_end, c_branch_start = get_connector_closest(spool_pipe, geo["Target"]), get_connector_closest(p_branch, geo["Target"])
        if c_spool_end and c_branch_start: doc.Create.NewElbowFitting(c_spool_end, c_branch_start)

        # [TASK 2] - WYE HACK TRÊN ỐNG CHÍNH VÀ NỐI VÀO NIPPLE
        pt_ins = geo["Start"]
        new_main_id = PlumbingUtils.BreakCurve(doc, p_main.Id, pt_ins)
        p_main_2 = doc.GetElement(new_main_id)
        doc.Regenerate()

        # Dùng Vector 90 độ để ép đẻ Tee an toàn
        d_pt = pt_ins + geo["VecDummy90"].Multiply(2.0)
        dummy_pipe = Pipe.Create(doc, b_sys, b_type, b_lev, pt_ins, d_pt)
        dummy_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
        doc.Regenerate()

        c_m1, c_m2, c_dum = get_connector_closest(p_main, pt_ins), get_connector_closest(p_main_2, pt_ins), get_connector_closest(dummy_pipe, pt_ins)
        fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
        doc.Regenerate()

        if fitting.Symbol.Id != target_symbol.Id:
            fitting.ChangeTypeId(target_symbol.Id)
            doc.Regenerate()
            
        fitting = doc.GetElement(fitting.Id) 
        doc.Delete(dummy_pipe.Id)
        doc.Regenerate()

        # Ép góc Wye chuẩn 45 độ (math.pi / 4)
        for p in fitting.Parameters:
            p_name = p.Definition.Name.lower()
            if any(k in p_name for k in ["angle", "góc", "bend", "goc"]):
                if not p.IsReadOnly:
                    try: p.Set(math.pi / 4); doc.Regenerate()
                    except: pass

        # MoveElement Nipple khớp vào Wye Branch (Bí quyết chống giật ống chính)
        c_wye_branch = None
        min_dist = float('inf')
        for c in fitting.MEPModel.ConnectorManager.Connectors:
            if c.IsConnected: continue
            d = c.Origin.DistanceTo(geo["StubEnd"])
            if d < min_dist:
                min_dist = d
                c_wye_branch = c
                
        if c_wye_branch:
            c_nipple_start = get_connector_closest(nipple_pipe, pt_ins)
            diff = c_wye_branch.Origin - c_nipple_start.Origin
            if not diff.IsAlmostEqualTo(XYZ.Zero):
                try: 
                    ElementTransformUtils.MoveElement(doc, nipple_pipe.Id, diff)
                    doc.Regenerate()
                except: pass
            
            # Kết nối hoàn thiện
            try: c_wye_branch.ConnectTo(c_nipple_start)
            except: pass

        t.Commit()
        TaskDialog.Show("Thành Công Tuyệt Đối", "Hệ thống 6 Parts đã được tạo hình thành công!\nTam giác vuông cân hoàn hảo và Wye không làm lệch ống chính.")

    except Exception as e:
        import traceback
        TaskDialog.Show("Lỗi Hệ Thống", traceback.format_exc())

if __name__ == "__main__":
    main()