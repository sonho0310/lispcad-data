# -*- coding: utf-8 -*-
"""
TOOL: AUTO 45-UP & CAP (CLEAN & NATIVE API VERSION)
AUTHOR: Superpowers Coding Agent
"""

import math
import clr
import Autodesk

import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI.Selection as Sel
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

# =======================================================
# 0. CLASS FILTER
# =======================================================
class PipeSelectionFilter(Sel.ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, DB.Plumbing.Pipe)
    def AllowReference(self, ref, point):
        return True

# =======================================================
# 1. HÌNH HỌC TẠO ỐNG 45 ĐỘ
# =======================================================
def create_45_up_extension_dynamic(doc, pipe, open_connector):
    vec_out = open_connector.CoordinateSystem.BasisZ
    if abs(vec_out.Z) > 0.9: return None 
    
    vec_z = DB.XYZ.BasisZ
    vec_45 = (vec_out + vec_z).Normalize() 
    p_start = open_connector.Origin

    try:
        dia_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
        b_dia = dia_param.AsDouble()
    except:
        b_dia = 0.1 

    stub_len = max(b_dia * 1.5, 0.25) 
    p_end = p_start + vec_45.Multiply(stub_len)

    try:
        sys_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
        sys_id = sys_param.AsElementId() if sys_param else pipe.MEPSystem.GetTypeId()
        
        new_pipe = DB.Plumbing.Pipe.Create(doc, sys_id, pipe.GetTypeId(), pipe.LevelId, p_start, p_end)
        new_pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
        return new_pipe
    except: return None

def get_connector_closest(element, point):
    if not element: return None
    conns = element.ConnectorManager.Connectors
    min_d = float('inf'); best_c = None
    for c in conns:
        d = c.Origin.DistanceTo(point)
        if d < min_d: min_d = d; best_c = c
    return best_c

# =======================================================
# 2. MAIN LOOP (INTERACTIVE)
# =======================================================
def main():
    while True:
        try:
            ref = uidoc.Selection.PickObject(Sel.ObjectType.Element, PipeSelectionFilter(), "Click đầu ống (ESC thoát)")
            pipe = doc.GetElement(ref)
            click_point = ref.GlobalPoint
            
            t = DB.Transaction(doc, "Auto 45-Up & Cap (Native API)")
            t.Start()

            try:
                target_conn = get_connector_closest(pipe, click_point)
                if not target_conn or target_conn.IsConnected:
                    t.RollBack(); continue

                # Sinh ra đoạn nhánh 45 độ
                new_pipe = create_45_up_extension_dynamic(doc, pipe, target_conn)
                doc.Regenerate()

                if new_pipe:
                    c1 = target_conn
                    c2 = get_connector_closest(new_pipe, target_conn.Origin)
                    
                    # Nối cút 45 độ
                    try: 
                        doc.Create.NewElbowFitting(c1, c2)
                    except Exception: 
                        doc.Delete(new_pipe.Id)
                        t.RollBack(); continue
                    
                    doc.Regenerate()

                    # ĐÂY LÀ "THE MAGIC LINE": Giao việc đặt Cap cho Revit API
                    # Nó sẽ tìm các đầu Connector đang hở của new_pipe và nhét Nút bịt theo đúng Routing
                    try:
                        DB.Plumbing.PlumbingUtils.PlaceCapOnOpenEnds(doc, new_pipe.Id, new_pipe.GetTypeId())
                    except Exception as e:
                        forms.alert(
                            "Không thể đặt nút bịt. Root Cause: Chưa gán Family Nút Bịt (Cap) vào bảng Routing Preferences của loại ống này.\n\n"
                            "Cách fix: Chọn ống -> Edit Type -> Routing Preferences -> Chọn Nút bịt (Cap).", 
                            title="Lỗi Routing Preferences"
                        )
                        t.RollBack()
                        continue
                
                t.Commit()
            
            except Exception:
                t.RollBack()

        except Autodesk.Revit.Exceptions.OperationCanceledException:
            break
        except Exception as e:
            forms.alert("LỖI NGHIÊM TRỌNG: " + str(e))
            break

if __name__ == "__main__":
    main()