# -*- coding: utf-8 -*-
import clr
import math
from pyrevit import forms
from pyrevit import script
from System.Collections.Generic import List

# --- SETUP MÔI TRƯỜNG ---
import Autodesk
import System

clr.AddReference("PresentationCore")
clr.AddReference("PresentationFramework")
clr.AddReference("WindowsBase")

from System.Windows.Media import Brushes
from System.Windows import FontStyles

clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI as UI
import Autodesk.Revit.Exceptions as Extensions
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# ==========================================
# --- PHẦN 1: GIAO DIỆN NGƯỜI DÙNG (GUI) ---
# ==========================================
# FIX VIỀN ĐEN: Dùng AllowsTransparency="True" trên Window và bọc lại bằng thẻ Border
# NÚT CLOSE: Xóa chữ X, làm đậm (ExtraBold)
xaml_string = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="MEP Multi Elbow" 
        Width="350" SizeToContent="Height" 
        WindowStartupLocation="CenterScreen" 
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" ResizeMode="NoResize" 
        MouseLeftButtonDown="window_drag">
    
    <Border BorderBrush="#0078D7" BorderThickness="2" Background="#F9F9F9">
        <Grid Margin="15">
            <StackPanel>
                <Grid Margin="0,0,0,5">
                    <TextBlock Text="SMART MULTI ELBOW" FontSize="18" FontWeight="Bold" Foreground="#0078D7" HorizontalAlignment="Left" VerticalAlignment="Center"/>
                    <Button Name="btn_close" Content="CLOSE" FontSize="14" Foreground="Red" FontWeight="ExtraBold" Background="Transparent" BorderThickness="0" HorizontalAlignment="Right" VerticalAlignment="Center" Cursor="Hand" Click="close_click"/>
                </Grid>
                <TextBlock Text="(Kéo thả tự do - Đồng bộ Workset VIP)" FontSize="11" FontStyle="Italic" Foreground="Gray" HorizontalAlignment="Left" Margin="0,0,0,20"/>
                
                <Grid Margin="0,0,0,15">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="140"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Grid.Column="0" Text="Chiều dài nhánh (mm):" VerticalAlignment="Center" FontWeight="SemiBold"/>
                    <TextBox Grid.Column="1" Name="length_tb" Height="30" 
                             Text="500" Foreground="Gray" FontStyle="Italic"
                             VerticalContentAlignment="Center" Padding="5,0,0,0" BorderBrush="#AAAAAA"/>
                </Grid>

                <TextBlock Text="Chọn góc bẻ nhánh:" FontWeight="SemiBold" Margin="0,0,0,10"/>
                <StackPanel Orientation="Horizontal" Margin="0,0,0,25">
                    <RadioButton Name="rad_angle_90" Content="Góc 90 Độ" IsChecked="True" Width="140" FontSize="14" VerticalContentAlignment="Center"/>
                    <RadioButton Name="rad_angle_45" Content="Góc 45 Độ" FontSize="14" VerticalContentAlignment="Center"/>
                </StackPanel>
                
                <Button Name="btn_ok" Content="CHẠY NGAY" Height="45" 
                        Background="#0078D7" Foreground="White" FontWeight="Bold" FontSize="14" 
                        Click="ok_click" Cursor="Hand" BorderThickness="0" Margin="0,0,0,5"/>
            </StackPanel>
        </Grid>
    </Border>
</Window>
"""

class MultiElbowWindow(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self, xaml_string, literal_string=True)
        self.length_tb.GotFocus += self.tb_focus
        self.length_tb.LostFocus += self.tb_blur

    def window_drag(self, sender, args):
        try:
            self.DragMove()
        except:
            pass

    def close_click(self, sender, args):
        self.DialogResult = False
        self.Close()

    def tb_focus(self, sender, args):
        if sender.Text in ["300", "500"]:
            sender.Text = ""
            sender.Foreground = Brushes.Black
            sender.FontStyle = FontStyles.Normal

    def tb_blur(self, sender, args):
        if not sender.Text.strip():
            sender.Text = "500" if self.rad_angle_90.IsChecked else "300"
            sender.Foreground = Brushes.Gray
            sender.FontStyle = FontStyles.Italic
        
    def ok_click(self, sender, args):
        val = self.length_tb.Text
        if not val.isdigit(): val = "500"
        
        self.length_val = float(val) / 304.8 
        self.angle_mode = "90" if self.rad_angle_90.IsChecked else "45"
            
        self.DialogResult = True
        self.Close()


# ==========================================
# --- PHẦN 2: CÁC HÀM BỔ TRỢ & WORKSET ---
# ==========================================

class MEPElementFilter(ISelectionFilter):
    def AllowElement(self, element):
        cat = element.Category
        if cat and ("Duct" in cat.Name or "Pipe" in cat.Name or "Cable Tray" in cat.Name):
            if isinstance(element, DB.MEPCurve): return True
        return False
    def AllowReference(self, reference, position): return False

class WarningSwallower(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        if failures.Count == 0: return DB.FailureProcessingResult.Continue
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning: 
                failuresAccessor.DeleteWarning(f)
            else: 
                failuresAccessor.ResolveFailure(f)
                return DB.FailureProcessingResult.ProceedWithCommit
        return DB.FailureProcessingResult.Continue

def get_connector_closest(element, point):
    closest = None
    min_dist = float('inf')
    try:
        for c in element.ConnectorManager.Connectors:
            d = c.Origin.DistanceTo(point)
            if d < min_dist:
                min_dist = d
                closest = c
    except: pass
    return closest

def copy_parameters(src, dest):
    # 1. Copy Kích thước và System
    try:
        if isinstance(src, DB.Mechanical.Duct):
            sys_param = src.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
            if sys_param and sys_param.HasValue: 
                dest.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).Set(sys_param.AsElementId())
            dest.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(src.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).AsDouble())
            dest.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(src.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).AsDouble())
            
        elif isinstance(src, DB.Plumbing.Pipe):
            sys_param = src.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
            if sys_param and sys_param.HasValue: 
                dest.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).Set(sys_param.AsElementId())
            dest.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(src.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble())
            
        elif isinstance(src, DB.Electrical.CableTray):
            dest.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(src.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).AsDouble())
            dest.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(src.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).AsDouble())
    except: pass

    # 2. COPY WORKSET CHUẨN VIP TỪ ỐNG GỐC
    try:
        ws_id = src.WorksetId.IntegerValue
        ws_param_dest = dest.get_Parameter(DB.BuiltInParameter.ELEM_PARTITION_PARAM)
        if ws_param_dest and not ws_param_dest.IsReadOnly and ws_id != -1:
            ws_param_dest.Set(ws_id)
    except: pass


# ==========================================
# --- PHẦN 3: LOGIC CHỐNG XOẮN TỪ MEP-AVOID ---
# ==========================================

def fix_rotation_like_avoid(doc, ref_elem, target_elem, pt_intersect):
    if not ref_elem or not target_elem: return
    
    if isinstance(ref_elem, DB.Plumbing.Pipe): return
    if isinstance(ref_elem, DB.Mechanical.Duct):
        dia = ref_elem.get_Parameter(DB.BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
        if dia and dia.HasValue: return
        
    tgt_curve = target_elem.Location.Curve
    p_start = tgt_curve.GetEndPoint(0)
    p_end = tgt_curve.GetEndPoint(1)
    tgt_dir = (p_end - p_start).Normalize()
    
    is_vertical = abs(tgt_dir.Z) > 0.99
    if not is_vertical: return 
        
    c_ref = get_connector_closest(ref_elem, pt_intersect)
    c_tgt = get_connector_closest(target_elem, pt_intersect)
    if not c_ref or not c_tgt: return
    
    v_ref = c_ref.CoordinateSystem.BasisX
    v_ref = DB.XYZ(v_ref.X, v_ref.Y, 0)
    if v_ref.GetLength() < 0.01:
        v_ref = c_ref.CoordinateSystem.BasisY
        v_ref = DB.XYZ(v_ref.X, v_ref.Y, 0)
        
    v_tgt = c_tgt.CoordinateSystem.BasisX
    v_tgt = DB.XYZ(v_tgt.X, v_tgt.Y, 0)
    if v_tgt.GetLength() < 0.01:
        v_tgt = c_tgt.CoordinateSystem.BasisY
        v_tgt = DB.XYZ(v_tgt.X, v_tgt.Y, 0)
        
    if v_ref.GetLength() > 0.01 and v_tgt.GetLength() > 0.01:
        v_ref = v_ref.Normalize()
        v_tgt = v_tgt.Normalize()
        
        angle = v_tgt.AngleTo(v_ref)
        cross = v_tgt.X * v_ref.Y - v_tgt.Y * v_ref.X
        if cross < 0: angle = -angle
        
        if abs(angle) > 0.01:
            axis = DB.Line.CreateBound(p_start, p_end) 
            try: DB.ElementTransformUtils.RotateElement(doc, target_elem.Id, axis, angle)
            except: pass


# ==========================================
# --- PHẦN 4: LOGIC TOÁN HỌC TÌM HƯỚNG ---
# ==========================================

def get_direction_90(connector, click_point):
    vec_click = (click_point - connector.Origin).Normalize()
    vec_flow = connector.CoordinateSystem.BasisZ
    
    directions = [DB.XYZ(1,0,0), DB.XYZ(-1,0,0), DB.XYZ(0,1,0), DB.XYZ(0,-1,0), DB.XYZ(0,0,1), DB.XYZ(0,0,-1)]
    valid_dirs = [d for d in directions if abs(vec_flow.DotProduct(d)) < 0.95] 
    
    return max(valid_dirs, key=lambda d: vec_click.DotProduct(d))

def get_direction_45(connector, click_point):
    vec_click = (click_point - connector.Origin).Normalize()
    
    z_con = connector.CoordinateSystem.BasisZ 
    x_con = connector.CoordinateSystem.BasisX 
    y_con = connector.CoordinateSystem.BasisY 
    
    dir_up = (z_con + y_con).Normalize()
    dir_down = (z_con - y_con).Normalize()
    dir_right = (z_con + x_con).Normalize()
    dir_left = (z_con - x_con).Normalize()
    
    directions = [dir_up, dir_down, dir_right, dir_left]
    
    return max(directions, key=lambda d: vec_click.DotProduct(d))

def process_elbow_smart(element, click_point, angle_mode, length_ft):
    con_base = get_connector_closest(element, click_point)
    if not con_base: return

    p1 = con_base.Origin
    
    if angle_mode == "90": direction = get_direction_90(con_base, click_point)
    else: direction = get_direction_45(con_base, click_point)
    
    p2 = p1 + (direction * length_ft)
    level_id = element.ReferenceLevel.Id

    new_elem = None
    try:
        if isinstance(element, DB.Mechanical.Duct):
            new_elem = DB.Mechanical.Duct.Create(doc, element.MEPSystem.GetTypeId(), element.GetTypeId(), level_id, p1, p2)
        elif isinstance(element, DB.Plumbing.Pipe):
            new_elem = DB.Plumbing.Pipe.Create(doc, element.MEPSystem.GetTypeId(), element.GetTypeId(), level_id, p1, p2)
        elif isinstance(element, DB.Electrical.CableTray):
            new_elem = DB.Electrical.CableTray.Create(doc, element.GetTypeId(), p1, p2, level_id)
    except: return
    
    if new_elem:
        copy_parameters(element, new_elem) 
        doc.Regenerate() 
        
        fix_rotation_like_avoid(doc, element, new_elem, p1)
        doc.Regenerate() 
        
        con_new = get_connector_closest(new_elem, p1)
        if con_base and con_new:
            try: 
                fitting = doc.Create.NewElbowFitting(con_base, con_new)
                
                # COPY WORKSET CHO FITTING SAU KHI SINH RA
                doc.Regenerate()
                try:
                    ws_id = element.WorksetId.IntegerValue
                    if fitting and ws_id != -1:
                        ws_param_fit = fitting.get_Parameter(DB.BuiltInParameter.ELEM_PARTITION_PARAM)
                        if ws_param_fit and not ws_param_fit.IsReadOnly:
                            ws_param_fit.Set(ws_id)
                except: pass
            except: pass


# ==========================================
# --- PHẦN 5: VÒNG LẶP CHẠY LỆNH CHÍNH ---
# ==========================================
try:
    win = MultiElbowWindow()
    win.ShowDialog()

    if win.DialogResult:
        angle_mode = win.angle_mode
        length_ft = win.length_val
        
        tg_name = "Smart Multi Elbow {0}°".format(angle_mode)
        tg = DB.TransactionGroup(doc, tg_name)
        tg.Start()
        
        while True:
            try:
                msg = "Click hướng trên Ống/Máng ({0} Độ) -> Ra nhánh dài {1}mm (Nhấn ESC thoát)".format(angle_mode, int(length_ft * 304.8))
                ref = uidoc.Selection.PickObject(ObjectType.Element, MEPElementFilter(), msg)
                el = doc.GetElement(ref)
                pick_point = ref.GlobalPoint 

                t = DB.Transaction(doc, "Tạo nhánh")
                opt = t.GetFailureHandlingOptions()
                opt.SetFailuresPreprocessor(WarningSwallower())
                opt.SetClearAfterRollback(True)
                t.SetFailureHandlingOptions(opt)
                
                t.Start()
                process_elbow_smart(el, pick_point, angle_mode, length_ft)
                t.Commit()
                
            except Extensions.OperationCanceledException:
                break 
            except Exception as e:
                if 't' in locals() and t.GetStatus() == DB.TransactionStatus.Started: 
                    t.RollBack()
                break

        tg.Assimilate()

except Exception as e:
    pass