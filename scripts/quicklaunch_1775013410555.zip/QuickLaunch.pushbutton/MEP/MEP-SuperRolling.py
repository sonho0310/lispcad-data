# -*- coding: utf-8 -*-
import clr
import math
import traceback

# --- IMPORT ---
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Electrical import CableTray, Conduit
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException

# WPF GUI
clr.AddReference("PresentationCore")
clr.AddReference("PresentationFramework")
clr.AddReference("WindowsBase")
from System.Windows.Media import Brushes
from System.Windows import FontStyles
from pyrevit import forms

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# ==========================================
# --- PHẦN 1: GIAO DIỆN NGƯỜI DÙNG (GUI) ---
# ==========================================
xaml_string = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="MEP Smart Rolling" 
        Width="350" SizeToContent="Height" 
        WindowStartupLocation="CenterScreen" 
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" ResizeMode="NoResize" 
        MouseLeftButtonDown="window_drag">
    
    <Border BorderBrush="#0078D7" BorderThickness="2" Background="#F9F9F9">
        <Grid Margin="15">
            <StackPanel>
                <Grid Margin="0,0,0,5">
                    <TextBlock Text="SMART ROLLING" FontSize="18" FontWeight="Bold" Foreground="#0078D7" HorizontalAlignment="Left" VerticalAlignment="Center"/>
                    <Button Name="btn_close" Content="CLOSE" FontSize="14" Foreground="Red" FontWeight="ExtraBold" Background="Transparent" BorderThickness="0" HorizontalAlignment="Right" VerticalAlignment="Center" Cursor="Hand" Click="close_click"/>
                </Grid>
                <TextBlock Text="(Kéo thả tự do - Fix xoắn &amp; Đồng bộ Workset VIP)" FontSize="11" FontStyle="Italic" Foreground="Gray" HorizontalAlignment="Left" Margin="0,0,0,20"/>
                
                <TextBlock Text="Chọn góc nối ống:" FontWeight="SemiBold" Margin="0,0,0,10"/>
                <StackPanel Orientation="Horizontal" Margin="0,0,0,25">
                    <RadioButton Name="rad_angle_90" Content="Góc 90 Độ" IsChecked="True" Width="140" FontSize="14" VerticalContentAlignment="Center"/>
                    <RadioButton Name="rad_angle_45" Content="Góc 45 Độ" FontSize="14" VerticalContentAlignment="Center"/>
                </StackPanel>
                
                <Button Name="btn_ok" Content="CHẠY NGAY" Height="45" 
                        Background="#0078D7" Foreground="White" FontWeight="Bold" FontSize="14" 
                        Click="ok_click" Cursor="Hand" BorderThickness="0" Margin="0,0,0,5"/>
            </StackPanel>
        </Grid>
    </Border>
</Window>
"""

class RollingWindow(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self, xaml_string, literal_string=True)

    def window_drag(self, sender, args):
        try: self.DragMove()
        except: pass

    def close_click(self, sender, args):
        self.DialogResult = False
        self.Close()
        
    def ok_click(self, sender, args):
        self.angle_mode = "90" if self.rad_angle_90.IsChecked else "45"
        self.DialogResult = True
        self.Close()

# ==========================================
# --- PHẦN 2: CÁC HÀM BỔ TRỢ & WORKSET ---
# ==========================================

class MEPFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category is None: return False
        cat_id = elem.Category.Id.IntegerValue
        if cat_id in [int(BuiltInCategory.OST_PipeCurves), int(BuiltInCategory.OST_DuctCurves), int(BuiltInCategory.OST_CableTray), int(BuiltInCategory.OST_Conduit)]:
            return True
        return False
    def AllowReference(self, reference, position):
        return False

def get_connectors_safe(element):
    if isinstance(element, (Pipe, Duct, CableTray, Conduit)):
        return element.ConnectorManager.Connectors
    return []

def get_connector_closest_to(element, point):
    connectors = get_connectors_safe(element)
    if not connectors: return None
    closest = None
    min_dist = float('inf')
    for con in connectors:
        dist = con.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist = dist
            closest = con
    return closest

def store_connection(element, fixed_point):
    conn = get_connector_closest_to(element, fixed_point)
    if not conn or not conn.IsConnected: return None
    target_ref = None
    for ref in conn.AllRefs:
        if ref.Owner.Id != element.Id and ref.ConnectorType != ConnectorType.Logical:
            target_ref = ref
            break
    if target_ref:
        try: conn.DisconnectFrom(target_ref)
        except: pass
        return target_ref
    return None

def restore_connection(element, fixed_point, target_connector):
    if not target_connector: return False
    new_conn = get_connector_closest_to(element, fixed_point)
    if new_conn and not new_conn.IsConnected:
        try:
            new_conn.ConnectTo(target_connector)
            return True
        except: pass
    return False

def get_closest_points_between_lines(line1_p1, line1_dir, line2_p1, line2_dir):
    w0 = line1_p1 - line2_p1
    a = line1_dir.DotProduct(line1_dir)
    b = line1_dir.DotProduct(line2_dir)
    c = line2_dir.DotProduct(line2_dir)
    d = line1_dir.DotProduct(w0)
    e = line2_dir.DotProduct(w0)
    denom = a * c - b * b
    if abs(denom) < 1e-6: return None, None 
    sc = (b * e - c * d) / denom
    tc = (a * e - b * d) / denom
    return line1_p1 + line1_dir * sc, line2_p1 + line2_dir * tc

def project_point_on_line(point, line_origin, line_dir):
    v = point - line_origin
    dist = v.DotProduct(line_dir)
    return line_origin + line_dir * dist

def get_system_type_id(element):
    if isinstance(element, (CableTray, Conduit)): return None
    pm = element.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
    if pm and pm.HasValue: return pm.AsElementId()
    pm = element.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
    if pm and pm.HasValue: return pm.AsElementId()
    return ElementId.InvalidElementId

def copy_size_and_workset(source_elem, target_elem):
    # Copy Size
    params_to_copy = [
        BuiltInParameter.RBS_PIPE_DIAMETER_PARAM, BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,
        BuiltInParameter.RBS_CURVE_WIDTH_PARAM, BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
        BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM, BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM
    ]
    for pid in params_to_copy:
        src_p = source_elem.get_Parameter(pid)
        tgt_p = target_elem.get_Parameter(pid)
        if src_p and tgt_p and not src_p.IsReadOnly and not tgt_p.IsReadOnly:
            try: tgt_p.Set(src_p.AsDouble())
            except: pass
            
    # Copy Workset VIP (Âm thầm thực thi)
    try:
        ws_id = source_elem.WorksetId.IntegerValue
        ws_param_dest = target_elem.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM)
        if ws_param_dest and not ws_param_dest.IsReadOnly and ws_id != -1:
            ws_param_dest.Set(ws_id)
    except: pass

def get_diameter(elem):
    try:
        if isinstance(elem, Pipe):
            p = elem.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
            if p: return p.AsDouble()
        elif isinstance(elem, Duct):
            p = elem.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
            if p and p.HasValue: return p.AsDouble()
            w = elem.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
            h = elem.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
            if w and h: return max(w.AsDouble(), h.AsDouble())
    except: pass
    return 0.33 

# ==========================================
# --- PHẦN 3: LOGIC CHỐNG XOẮN ỐNG GIÓ/MÁNG CÁP ---
# ==========================================
def fix_rotation(doc, ref_elem, target_elem, pt_ref, pt_tgt):
    """ Nắn lại mặt cắt (trục X,Y) cho ống nối sinh ra đồng phẳng với ống gốc """
    if not ref_elem or not target_elem: return
    
    if isinstance(ref_elem, (Pipe, Conduit)): return
    
    if isinstance(ref_elem, Duct):
        dia = ref_elem.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
        if dia and dia.HasValue: return
        
    tgt_curve = target_elem.Location.Curve
    tgt_dir = (tgt_curve.GetEndPoint(1) - tgt_curve.GetEndPoint(0)).Normalize()
    
    # Bắt mọi ống nối có độ dốc (Z > 0.05). Cả 45 độ và 90 độ đều bị nắn.
    has_slope = abs(tgt_dir.Z) > 0.05
    if not has_slope: return 
        
    c_ref = get_connector_closest_to(ref_elem, pt_ref)
    c_tgt = get_connector_closest_to(target_elem, pt_tgt)
    if not c_ref or not c_tgt: return
    
    # Ép Vector 2 mặt cắt xuống mặt phẳng 2D
    v_ref = c_ref.CoordinateSystem.BasisX
    v_ref = XYZ(v_ref.X, v_ref.Y, 0)
    if v_ref.GetLength() < 0.01:
        v_ref = c_ref.CoordinateSystem.BasisY
        v_ref = XYZ(v_ref.X, v_ref.Y, 0)
        
    v_tgt = c_tgt.CoordinateSystem.BasisX
    v_tgt = XYZ(v_tgt.X, v_tgt.Y, 0)
    if v_tgt.GetLength() < 0.01:
        v_tgt = c_tgt.CoordinateSystem.BasisY
        v_tgt = XYZ(v_tgt.X, v_tgt.Y, 0)
        
    if v_ref.GetLength() > 0.01 and v_tgt.GetLength() > 0.01:
        v_ref = v_ref.Normalize()
        v_tgt = v_tgt.Normalize()
        
        angle = v_tgt.AngleTo(v_ref)
        
        # Tích có hướng 2D xác định chiều vặn âm dương
        cross = v_tgt.X * v_ref.Y - v_tgt.Y * v_ref.X
        if cross < 0: angle = -angle
        
        if abs(angle) > 0.01:
            axis = Line.CreateBound(tgt_curve.GetEndPoint(0), tgt_curve.GetEndPoint(1))
            try: ElementTransformUtils.RotateElement(doc, target_elem.Id, axis, angle)
            except: pass

def apply_workset_to_fitting(fitting, source_elem):
    """ Bơm Workset cho Fitting VIP """
    try:
        ws_id = source_elem.WorksetId.IntegerValue
        if fitting and ws_id != -1:
            ws_param_fit = fitting.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM)
            if ws_param_fit and not ws_param_fit.IsReadOnly:
                ws_param_fit.Set(ws_id)
    except: pass

# ==========================================
# --- PHẦN 4: VÒNG LẶP CHẠY LỆNH CHÍNH ---
# ==========================================
def run():
    try:
        win = RollingWindow()
        win.ShowDialog()
        if not win.DialogResult: return
        angle_mode = win.angle_mode
    except: return

    tg_name = "Smart MEP Rolling {0}°".format(angle_mode)
    tg = TransactionGroup(doc, tg_name)
    tg.Start()
    step = "Khởi tạo"
    
    try:
        mep_filter = MEPFilter()
        while True:
            step = "Pick đối tượng"
            try:
                msg1 = "Chọn ỐNG 1 ({0} Độ) - Nhấn ESC để ngưng lệnh".format(angle_mode)
                ref1 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, msg1)
                ref2 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ỐNG 2 - Nhấn ESC để ngưng lệnh")
            except OperationCanceledException:
                break 

            elem1 = doc.GetElement(ref1)
            elem2 = doc.GetElement(ref2)

            if type(elem1) != type(elem2) or not isinstance(elem1, (Pipe, Duct, CableTray, Conduit)):
                 continue 

            t = Transaction(doc, "Connect Geometry")
            t.Start()
            
            try:
                step = "Lấy dữ liệu Curve"
                c1 = elem1.Location.Curve
                c2 = elem2.Location.Curve
                
                p1_start, p1_end = c1.GetEndPoint(0), c1.GetEndPoint(1)
                v1_dir = (p1_end - p1_start).Normalize()

                p2_start, p2_end = c2.GetEndPoint(0), c2.GetEndPoint(1)
                v2_dir = (p2_end - p2_start).Normalize()

                pt1, pt2 = get_closest_points_between_lines(p1_start, v1_dir, p2_start, v2_dir)
                is_parallel = (pt1 is None or pt2 is None)

                # ==========================================================
                # LOGIC KẾT NỐI THEO CHẾ ĐỘ ĐÃ CHỌN TRÊN UI
                # ==========================================================
                if angle_mode == "90":
                    if is_parallel:
                        click_p1 = ref1.GlobalPoint
                        p1_root = p1_start if p1_start.DistanceTo(click_p1) < p1_end.DistanceTo(click_p1) else p1_end
                        p2_target = project_point_on_line(p1_root, p2_start, v2_dir)
                        p2_fixed = p2_start if p2_start.DistanceTo(p2_target) > p2_end.DistanceTo(p2_target) else p2_end

                        saved_conn_2 = store_connection(elem2, p2_fixed)
                        elem2.Location.Curve = Line.CreateBound(p2_fixed, p2_target)
                        doc.Regenerate()
                        restore_connection(elem2, p2_fixed, saved_conn_2)
                        p1_target = p1_root 
                    else:
                        p_corner = pt1
                        p1_fixed = p1_start if p1_start.DistanceTo(p_corner) > p1_end.DistanceTo(p_corner) else p1_end
                        p2_fixed = p2_start if p2_start.DistanceTo(p_corner) > p2_end.DistanceTo(p_corner) else p2_end

                        saved_conn_1 = store_connection(elem1, p1_fixed)
                        elem1.Location.Curve = Line.CreateBound(p1_fixed, p_corner)
                        doc.Regenerate()
                        restore_connection(elem1, p1_fixed, saved_conn_1)

                        saved_conn_2 = store_connection(elem2, p2_fixed)
                        elem2.Location.Curve = Line.CreateBound(p2_fixed, p_corner)
                        doc.Regenerate()
                        restore_connection(elem2, p2_fixed, saved_conn_2)

                        c1_conn = get_connector_closest_to(elem1, p_corner)
                        c2_conn = get_connector_closest_to(elem2, p_corner)
                        if c1_conn and c2_conn:
                            fit = doc.Create.NewElbowFitting(c1_conn, c2_conn)
                            doc.Regenerate()
                            apply_workset_to_fitting(fit, elem1) # <--- TRUYỀN WORKSET CHO FITTING 90 ĐỘ CẮT NHAU
                        t.Commit()
                        continue # Nếu 90 độ cắt nhau thì không cần sinh ống Bridge, tới đây là xong

                elif angle_mode == "45":
                    if is_parallel:
                        mid_p2 = (p2_start + p2_end) / 2
                        p1_root = p1_start if p1_start.DistanceTo(mid_p2) < p1_end.DistanceTo(mid_p2) else p1_end
                        H = project_point_on_line(p1_root, p2_start, v2_dir)
                        offset_dist = p1_root.DistanceTo(H)

                        candidate1 = H + v2_dir * offset_dist
                        candidate2 = H - v2_dir * offset_dist
                        p2_target = candidate1 if candidate1.DistanceTo(mid_p2) < candidate2.DistanceTo(mid_p2) else candidate2
                        p2_fixed = p2_start if p2_start.DistanceTo(p2_target) > p2_end.DistanceTo(p2_target) else p2_end

                        saved_conn_2 = store_connection(elem2, p2_fixed)
                        elem2.Location.Curve = Line.CreateBound(p2_fixed, p2_target)
                        doc.Regenerate()
                        restore_connection(elem2, p2_fixed, saved_conn_2)
                        p1_target = p1_root 
                    else:
                        p_corner = pt1 
                        p1_fixed = p1_start if p1_start.DistanceTo(p_corner) > p1_end.DistanceTo(p_corner) else p1_end
                        p2_fixed = p2_start if p2_start.DistanceTo(p_corner) > p2_end.DistanceTo(p_corner) else p2_end

                        b_dia = get_diameter(elem1)
                        L = max(b_dia * 2.0, 0.3)
                        setback = L / math.sqrt(2.0)

                        v1_away = (p1_fixed - p_corner).Normalize()
                        v2_away = (p2_fixed - p_corner).Normalize()
                        p1_target = p_corner + v1_away * setback
                        p2_target = p_corner + v2_away * setback

                        saved_conn_1 = store_connection(elem1, p1_fixed)
                        elem1.Location.Curve = Line.CreateBound(p1_fixed, p1_target)
                        doc.Regenerate()
                        restore_connection(elem1, p1_fixed, saved_conn_1)

                        saved_conn_2 = store_connection(elem2, p2_fixed)
                        elem2.Location.Curve = Line.CreateBound(p2_fixed, p2_target)
                        doc.Regenerate()
                        restore_connection(elem2, p2_fixed, saved_conn_2)

                # ==========================================================
                # TẠO ỐNG BRIDGE (DÙNG CHUNG CHO 90 PARALLEL VÀ 45)
                # ==========================================================
                step = "Tạo ống nối ngang/chéo (Bridge)"
                ptype_id = elem1.GetTypeId()
                lvl_param = elem1.get_Parameter(BuiltInParameter.RBS_START_LEVEL_PARAM)
                lvl_id = lvl_param.AsElementId() if lvl_param else doc.ActiveView.GenLevel.Id

                mid_elem = None
                if isinstance(elem1, Pipe):
                    mid_elem = Pipe.Create(doc, get_system_type_id(elem1), ptype_id, lvl_id, p1_target, p2_target)
                elif isinstance(elem1, Duct):
                    mid_elem = Duct.Create(doc, get_system_type_id(elem1), ptype_id, lvl_id, p1_target, p2_target)
                elif isinstance(elem1, CableTray):
                    mid_elem = CableTray.Create(doc, ptype_id, p1_target, p2_target, lvl_id)
                elif isinstance(elem1, Conduit):
                    mid_elem = Conduit.Create(doc, ptype_id, p1_target, p2_target, lvl_id)

                if mid_elem:
                    copy_size_and_workset(elem1, mid_elem) # <--- TRUYỀN WORKSET CHO ỐNG NỐI
                    doc.Regenerate()
                    
                    # [CHỐNG XOẮN ỐNG GIÓ CHỮ NHẬT VÀ MÁNG CÁP VIP]
                    fix_rotation(doc, elem1, mid_elem, p1_target, p1_target)
                    doc.Regenerate() 

                    # Lắp 2 Elbow và truyền Workset
                    c1_conn = get_connector_closest_to(elem1, p1_target)
                    cm1 = get_connector_closest_to(mid_elem, p1_target)
                    if c1_conn and cm1: 
                        fit1 = doc.Create.NewElbowFitting(c1_conn, cm1)
                        doc.Regenerate()
                        apply_workset_to_fitting(fit1, elem1) # <--- TRUYỀN WORKSET CHO CÚT 1

                    c2_conn = get_connector_closest_to(elem2, p2_target)
                    cm2 = get_connector_closest_to(mid_elem, p2_target)
                    if c2_conn and cm2: 
                        fit2 = doc.Create.NewElbowFitting(c2_conn, cm2)
                        doc.Regenerate()
                        apply_workset_to_fitting(fit2, elem1) # <--- TRUYỀN WORKSET CHO CÚT 2

                t.Commit()

            except Exception as e_geo:
                if t.GetStatus() == TransactionStatus.Started: t.RollBack()
                error_trace = traceback.format_exc()
                TaskDialog.Show("Bug Catcher 🐛", "Lỗi tại bước: [{}]\n\n{}".format(step, error_trace))

    except Exception as e:
        pass 
    finally:
        if tg.GetStatus() == TransactionStatus.Started: tg.Assimilate()

if __name__ == '__main__':
    run()