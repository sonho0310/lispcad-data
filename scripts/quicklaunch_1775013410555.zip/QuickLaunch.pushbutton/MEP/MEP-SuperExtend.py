# -*- coding: utf-8 -*-
import clr
import traceback
clr.AddReference('System.Windows.Forms')
clr.AddReference('PresentationFramework')

import wpf
from System.IO import StringReader
from System.Windows import Window

from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe, PipeType, PipingSystemType
from Autodesk.Revit.DB.Mechanical import Duct, DuctType, MechanicalSystemType
from Autodesk.Revit.DB.Electrical import CableTray, CableTrayType, Conduit, ConduitType
from Autodesk.Revit.UI.Selection import ISelectionFilter, ObjectType
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit, forms

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# =========================================================
# NGUYÊN TẮC 1: GIAO DIỆN UI BORDERLESS VIP (ĐÃ ÉP EO GỌN GÀNG)
# =========================================================
xaml_str = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        WindowStyle="None" AllowsTransparency="True" Background="Transparent" 
        ResizeMode="NoResize" MouseLeftButtonDown="window_drag"
        Width="280" Height="200" WindowStartupLocation="CenterScreen" Topmost="True">
    <Border BorderBrush="#0078D7" BorderThickness="2" Background="#F9F9F9">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="35"/>
                <RowDefinition Height="*"/>
                <RowDefinition Height="45"/>
            </Grid.RowDefinitions>
            <Grid Background="#EAEAEA">
                <TextBlock Text="MEP EXTEND VIP" FontWeight="ExtraBold" FontSize="13" VerticalAlignment="Center" Margin="10,0,0,0" Foreground="#333333"/>
                <Button Name="btn_close" Content="CLOSE" FontSize="12" Foreground="Red" FontWeight="ExtraBold" Background="Transparent" BorderThickness="0" HorizontalAlignment="Right" Width="50" Click="close_click" Cursor="Hand"/>
            </Grid>
            <StackPanel Grid.Row="1" Margin="20,15,20,10">
                <TextBlock Text="Khoảng cách (mm):" FontWeight="Bold" FontSize="13" Margin="0,0,0,8" Foreground="#444"/>
                <TextBox Name="txt_length" Text="500" FontSize="18" Padding="3" FontWeight="Bold" Foreground="#0078D7" HorizontalContentAlignment="Center"/>
            </StackPanel>
            <Button Name="btn_run" Grid.Row="2" Content="CHẠY THÔI ĐẠI CA!" Background="#0078D7" Foreground="White" FontWeight="Bold" FontSize="13" Margin="20,0,20,10" Click="run_click" Cursor="Hand"/>
        </Grid>
    </Border>
</Window>
"""

class ExtendUI(Window):
    def __init__(self):
        wpf.LoadComponent(self, StringReader(xaml_str))
        self.extend_length = 500.0
    def window_drag(self, sender, args):
        try: self.DragMove()
        except: pass
    def close_click(self, sender, args):
        self.DialogResult = False
        self.Close()
    def run_click(self, sender, args):
        try:
            self.extend_length = float(self.txt_length.Text)
            self.DialogResult = True
            self.Close()
        except: forms.alert("Nhập số vào đại ca!")

# =========================================================
# NGUYÊN TẮC 2: ĐỒNG BỘ WORKSET
# =========================================================
def sync_workset(src_el, new_el):
    try:
        ws_id = src_el.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM).AsInteger()
        if ws_id != -1:
            doc.Regenerate()
            new_el.get_Parameter(BuiltInParameter.ELEM_PARTITION_PARAM).Set(ws_id)
    except: pass

# =========================================================
# LOGIC LÕI: TÌM SYSTEM VÀ TYPE CHUẨN XÁC
# =========================================================
def get_most_recent_system_in_view(doc, domain):
    target_class = Pipe if domain == Domain.DomainPiping else Duct if domain == Domain.DomainHvac else None
    if not target_class: return None
    collector = FilteredElementCollector(doc, doc.ActiveView.Id).OfClass(target_class).ToElements()
    if not collector: return None
    sorted_elements = sorted(collector, key=lambda x: x.Id.IntegerValue, reverse=True)[:5]
    for elem in sorted_elements:
        p_name = BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if domain == Domain.DomainPiping else BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
        sys_param = elem.get_Parameter(p_name)
        if sys_param and sys_param.HasValue and sys_param.AsElementId() != ElementId.InvalidElementId:
            return sys_param.AsElementId()
    return None

def get_fallback_system_type(doc, domain):
    cls = PipingSystemType if domain == Domain.DomainPiping else MechanicalSystemType if domain == Domain.DomainHvac else None
    if not cls: return ElementId.InvalidElementId
    return FilteredElementCollector(doc).OfClass(cls).FirstElementId()

def get_system_type_smart(doc, element, target_conn):
    domain = target_conn.Domain
    cm = getattr(element, "MEPModel", element).ConnectorManager if hasattr(element, "MEPModel") or hasattr(element, "ConnectorManager") else None
    if cm:
        for c in cm.Connectors:
            if c.Id != target_conn.Id and c.Domain == domain and c.IsConnected:
                for ref in c.AllRefs:
                    if isinstance(ref.Owner, (Pipe, Duct)):
                        p_name = BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if domain == Domain.DomainPiping else BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
                        sys_param = ref.Owner.get_Parameter(p_name)
                        if sys_param and sys_param.AsElementId().IntegerValue != -1: return sys_param.AsElementId()

    p_name_self = BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM if domain == Domain.DomainPiping else BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM
    sys_param_self = element.get_Parameter(p_name_self)
    if sys_param_self and sys_param_self.AsElementId().IntegerValue != -1: return sys_param_self.AsElementId()

    try:
        t_cls = target_conn.GetMEPSystemClassification()
        if str(t_cls) not in ["Fitting", "Global"]:
            cls = PipingSystemType if domain == Domain.DomainPiping else MechanicalSystemType if domain == Domain.DomainHvac else None
            for st in FilteredElementCollector(doc).OfClass(cls).ToElements():
                if st.SystemClassification == t_cls: return st.Id
    except: pass
    recent_id = get_most_recent_system_in_view(doc, domain)
    return recent_id if recent_id else get_fallback_system_type(doc, domain)

def find_curve_type_by_routing(doc, family_symbol, domain):
    if domain == Domain.DomainPiping: all_types = FilteredElementCollector(doc).OfClass(PipeType).ToElements()
    elif domain == Domain.DomainHvac: all_types = FilteredElementCollector(doc).OfClass(DuctType).ToElements()
    else: return ElementId.InvalidElementId
    
    for p_type in all_types:
        rpm = getattr(p_type, "RoutingPreferenceManager", None)
        if not rpm: continue
        groups = [RoutingPreferenceRuleGroupType.Elbows, RoutingPreferenceRuleGroupType.Junctions, RoutingPreferenceRuleGroupType.Transitions]
        for group in groups:
            for i in range(rpm.GetNumberOfRules(group)):
                try:
                    if rpm.GetRule(group, i).MEPPartId == family_symbol.Id: return p_type.Id
                except: pass
    return ElementId.InvalidElementId

def get_best_curve_type(doc, element, conn):
    domain = conn.Domain
    shape = getattr(conn, "Shape", ConnectorProfileType.Round)
    
    if isinstance(element, (Pipe, Duct, CableTray, Conduit)): return element.GetTypeId()
    
    if isinstance(element, FamilyInstance) and domain in [Domain.DomainPiping, Domain.DomainHvac]:
        matched_id = find_curve_type_by_routing(doc, element.Symbol, domain)
        if matched_id != ElementId.InvalidElementId: return matched_id

    cm = getattr(element, "MEPModel", element).ConnectorManager if hasattr(element, "MEPModel") or hasattr(element, "ConnectorManager") else None
    if cm:
        for c in cm.Connectors:
            if c.IsConnected and c.Id != conn.Id and c.Domain == domain:
                for ref in c.AllRefs:
                    if isinstance(ref.Owner, (Pipe, Duct, CableTray, Conduit)): return ref.Owner.GetTypeId()
    
    if domain == Domain.DomainPiping: return FilteredElementCollector(doc).OfClass(PipeType).FirstElementId()
    elif domain == Domain.DomainHvac:
        types = FilteredElementCollector(doc).OfClass(DuctType).ToElements()
        for t in types:
            if shape == ConnectorProfileType.Rectangular and "Rectangular" in t.FamilyName: return t.Id
            if shape == ConnectorProfileType.Round and "Round" in t.FamilyName: return t.Id
        return types[0].Id if types else ElementId.InvalidElementId
    elif domain in [Domain.DomainElectrical, Domain.DomainCableTrayConduit]:
        if shape == ConnectorProfileType.Rectangular: return FilteredElementCollector(doc).OfClass(CableTrayType).FirstElementId()
        return FilteredElementCollector(doc).OfClass(ConduitType).FirstElementId()
    return ElementId.InvalidElementId

# =========================================================
# NGUYÊN TẮC 3: CÂN BẰNG TRỌNG LỰC & AUTO-ALIGN (CHỐNG LẬT)
# =========================================================
def process_element(element, length_mm):
    cm = getattr(element, "MEPModel", element).ConnectorManager if hasattr(element, "MEPModel") or hasattr(element, "ConnectorManager") else None
    if not cm: return 0

    len_ft = length_mm / 304.8
    level_id = element.LevelId if element.LevelId != ElementId.InvalidElementId else (doc.ActiveView.GenLevel.Id if doc.ActiveView.GenLevel else FilteredElementCollector(doc).OfClass(Level).FirstElementId())

    count = 0
    for conn in cm.Connectors:
        if conn.IsConnected or conn.ConnectorType == ConnectorType.Logical: continue
        try:
            type_id = get_best_curve_type(doc, element, conn)
            sys_id = get_system_type_smart(doc, element, conn) if conn.Domain in [Domain.DomainPiping, Domain.DomainHvac] else ElementId.InvalidElementId
            if type_id == ElementId.InvalidElementId: continue
            
            origin, direction = conn.Origin, conn.CoordinateSystem.BasisZ
            end_pt = origin + (direction * len_ft)
            new_el = None

            # 1. TẠO PHẦN TỬ
            if conn.Domain == Domain.DomainPiping:
                new_el = Pipe.Create(doc, sys_id, type_id, level_id, origin, end_pt)
            elif conn.Domain == Domain.DomainHvac:
                new_el = Duct.Create(doc, sys_id, type_id, level_id, origin, end_pt)
            elif conn.Domain in [Domain.DomainElectrical, Domain.DomainCableTrayConduit]:
                t_obj = doc.GetElement(type_id)
                new_el = CableTray.Create(doc, type_id, origin, end_pt, level_id) if isinstance(t_obj, CableTrayType) else Conduit.Create(doc, type_id, origin, end_pt, level_id)

            if new_el:
                sync_workset(element, new_el)
                doc.Regenerate()

                # 2. XÁC ĐỊNH SIZE CHUẨN XÁC BẰNG VECTOR
                if conn.Shape != ConnectorProfileType.Round:
                    w, h = conn.Width, conn.Height
                    vec_x, vec_y = conn.CoordinateSystem.BasisX, conn.CoordinateSystem.BasisY
                    
                    if abs(vec_x.Z) > abs(vec_y.Z) + 0.01:
                        true_w, true_h = h, w
                    else:
                        true_w, true_h = w, h

                    if isinstance(new_el, Duct):
                        new_el.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(true_w)
                        new_el.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(true_h)
                    elif isinstance(new_el, CableTray):
                        new_el.get_Parameter(BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(true_w)
                        new_el.get_Parameter(BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(true_h)
                else:
                    if isinstance(new_el, Duct): new_el.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM).Set(conn.Radius * 2)
                    elif isinstance(new_el, Pipe): new_el.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(conn.Radius * 2)
                    elif isinstance(new_el, Conduit): new_el.get_Parameter(BuiltInParameter.RBS_CONDUIT_DIAMETER_PARAM).Set(conn.Radius * 2)

                doc.Regenerate()

                # 3. KẾT NỐI (AUTO-ALIGN)
                new_conn = next((c for c in new_el.ConnectorManager.Connectors if c.Origin.DistanceTo(origin) < 0.01), None)
                if new_conn: 
                    conn.ConnectTo(new_conn)
                    count += 1
        except: pass
    return count

# =========================================================
# FILTER VIP: BAO PICK TẤT CẢ
# =========================================================
class MEPFilterVIP(ISelectionFilter):
    def AllowElement(self, e):
        if not e.Category: return False
        allowed = [
            BuiltInCategory.OST_PipeFitting, BuiltInCategory.OST_DuctFitting,
            BuiltInCategory.OST_CableTrayFitting, BuiltInCategory.OST_ConduitFitting,
            BuiltInCategory.OST_MechanicalEquipment, BuiltInCategory.OST_ElectricalEquipment,
            BuiltInCategory.OST_PlumbingFixtures, BuiltInCategory.OST_Sprinklers,
            BuiltInCategory.OST_LightingFixtures, BuiltInCategory.OST_DuctAccessory,
            BuiltInCategory.OST_PipeAccessory, BuiltInCategory.OST_DuctTerminal,
            BuiltInCategory.OST_CableTray, BuiltInCategory.OST_Conduit, 
            BuiltInCategory.OST_DuctCurves, BuiltInCategory.OST_PipeCurves
        ]
        return e.Category.Id.IntegerValue in [int(c) for c in allowed]
    def AllowReference(self, r, p): return True

def main():
    ui = ExtendUI()
    if ui.ShowDialog():
        while True:
            try:
                ref = uidoc.Selection.PickObject(ObjectType.Element, MEPFilterVIP(), "Pick ống/máng/phụ kiện (ESC thoát)")
                with revit.Transaction("MEP Extend VIP", doc):
                    process_element(doc.GetElement(ref), ui.extend_length)
            except OperationCanceledException: break
            except: forms.alert(traceback.format_exc()); break

if __name__ == '__main__':
    main()