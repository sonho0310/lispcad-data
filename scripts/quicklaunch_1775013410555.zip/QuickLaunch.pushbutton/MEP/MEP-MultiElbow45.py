# -*- coding: utf-8 -*-

import math
import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI as UI
import Autodesk.Revit.Exceptions as Extensions
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. CLASSES ---
class MEPElementFilter(ISelectionFilter):
    def AllowElement(self, element):
        cat = element.Category
        if cat and ("Duct" in cat.Name or "Pipe" in cat.Name or "Cable Tray" in cat.Name):
            if isinstance(element, DB.MEPCurve): return True
        return False
    def AllowReference(self, reference, position): return False

class WarningSwallower(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        if failures.Count == 0: return DB.FailureProcessingResult.Continue
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning: failuresAccessor.DeleteWarning(f)
            else: failuresAccessor.ResolveFailure(f); return DB.FailureProcessingResult.ProceedWithCommit
        return DB.FailureProcessingResult.Continue

# --- 2. UTILS ---
def get_connector_closest(element, point):
    closest = None
    min_dist = float('inf')
    try:
        for c in element.ConnectorManager.Connectors:
            d = c.Origin.DistanceTo(point)
            if d < min_dist:
                min_dist = d
                closest = c
    except: pass
    return closest

def copy_parameters(src, dest):
    """Copy Size & System chuẩn"""
    try:
        if isinstance(src, DB.Mechanical.Duct):
            sys_param = src.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
            if sys_param and sys_param.HasValue: 
                dest.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).Set(sys_param.AsElementId())
        elif isinstance(src, DB.Plumbing.Pipe):
            sys_param = src.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
            if sys_param and sys_param.HasValue: 
                dest.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).Set(sys_param.AsElementId())
        
        if isinstance(src, DB.Mechanical.Duct):
            w = src.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).AsDouble()
            h = src.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).AsDouble()
            dest.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(w)
            dest.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(h)
        elif isinstance(src, DB.Electrical.CableTray):
            w = src.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).AsDouble()
            h = src.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).AsDouble()
            dest.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(w)
            dest.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(h)
        elif isinstance(src, DB.Plumbing.Pipe):
             d = src.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
             dest.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(d)
    except: pass

# ĐÃ XÓA BỎ HÀM rotate_element_correctly TẠI ĐÂY

# --- 3. CORE LOGIC ---
def get_direction_45(element, connector, click_point):
    vec_click = (click_point - connector.Origin).Normalize()
    
    z_con = connector.CoordinateSystem.BasisZ 
    x_con = connector.CoordinateSystem.BasisX 
    y_con = connector.CoordinateSystem.BasisY 
    
    dir_up = (z_con + y_con).Normalize()
    dir_down = (z_con - y_con).Normalize()
    dir_right = (z_con + x_con).Normalize()
    dir_left = (z_con - x_con).Normalize()
    
    directions = {
        "Up45": dir_up,
        "Down45": dir_down,
        "Right45": dir_right,
        "Left45": dir_left
    }
    
    best_dir = None
    max_dot = -1.0 
    
    for name, d in directions.items():
        val = vec_click.DotProduct(d)
        if val > max_dot:
            max_dot = val
            best_dir = d
            
    if best_dir is None: best_dir = dir_up
    return best_dir

def process_elbow_smart_45(element, click_point):
    con_base = get_connector_closest(element, click_point)
    if not con_base: return

    p1 = con_base.Origin
    
    # 1. Xác định hướng 45 độ
    direction = get_direction_45(element, con_base, click_point)
    
    # 2. Tính chiều dài (FIX CỨNG 500mm đổi sang đơn vị Feet nội bộ của Revit)
    size_ref = 500.0 / 304.8

    p2 = p1 + (direction * size_ref)
    level_id = element.ReferenceLevel.Id

    # 3. Tạo ống mới
    new_elem = None
    if isinstance(element, DB.Mechanical.Duct):
        new_elem = DB.Mechanical.Duct.Create(doc, element.MEPSystem.GetTypeId(), element.GetTypeId(), level_id, p1, p2)
    elif isinstance(element, DB.Plumbing.Pipe):
        new_elem = DB.Plumbing.Pipe.Create(doc, element.MEPSystem.GetTypeId(), element.GetTypeId(), level_id, p1, p2)
    elif isinstance(element, DB.Electrical.CableTray):
        new_elem = DB.Electrical.CableTray.Create(doc, element.GetTypeId(), p1, p2, level_id)
    
    if new_elem:
        # 4. Copy Size chuẩn
        copy_parameters(element, new_elem)
        doc.Regenerate()
        
        # [ĐÃ XÓA LOGIC ÉP XOAY THEO ROOT CAUSE]

        # 5. Nối Fitting
        con_new = get_connector_closest(new_elem, p1)
        if con_base and con_new:
            try: 
                doc.Create.NewElbowFitting(con_base, con_new)
            except: pass

# --- 4. RUN ---
def run_script():
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, MEPElementFilter(), "Click hướng 45 độ (Trên/Dưới/Trái/Phải) -> Ra ống 45 độ (ESC thoát)")
            el = doc.GetElement(ref)
            pick_point = ref.GlobalPoint 

            t = DB.Transaction(doc, "No Transition Elbow 45")
            opt = t.GetFailureHandlingOptions()
            opt.SetFailuresPreprocessor(WarningSwallower())
            opt.SetClearAfterRollback(True)
            t.SetFailureHandlingOptions(opt)
            
            t.Start()
            process_elbow_smart_45(el, pick_point)
            t.Commit()
            
        except Extensions.OperationCanceledException:
            break
        except Exception as e:
            break

if __name__ == "__main__": run_script()