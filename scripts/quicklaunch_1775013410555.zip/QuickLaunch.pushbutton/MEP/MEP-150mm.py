# -*- coding: utf-8 -*-
import clr
import math
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.UI import TaskDialog
from Autodesk.Revit.Exceptions import OperationCanceledException

# Lấy Document hiện tại
uidoc = __revit__.ActiveUIDocument
doc = uidoc.Document

# YAGNI: Gắn cứng con số 150mm
TARGET_DIST_MM = 150.0
TARGET_DIST_FT = TARGET_DIST_MM / 304.8

class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category is not None:
            return elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves)
        return False
        
    def AllowReference(self, ref, pos):
        return False

def show_error(title, message):
    """Hiển thị Pop-up lỗi"""
    dialog = TaskDialog(title)
    dialog.MainInstruction = message
    dialog.MainIcon = TaskDialogIcon.TaskDialogIconWarning
    dialog.Show()

def main():
    # Thêm vòng lặp vô hạn theo yêu cầu "Pick chán thì thôi"
    while True:
        try:
            # Task 1: Tương tác người dùng (Cập nhật text nhắc nhở ESC)
            picked_point = uidoc.Selection.PickPoint("1/2: Click ĐIỂM mốc (Nhấn phím ESC để kết thúc lệnh)")
            
            pipe_ref = uidoc.Selection.PickObject(ObjectType.Element, PipeSelectionFilter(), "2/2: Click chọn ỐNG (Pipe) cần dời")
            pipe = doc.GetElement(pipe_ref)
            
            # Task 2: Lấy dữ liệu hình học
            loc_curve = pipe.Location
            if not isinstance(loc_curve, LocationCurve):
                show_error("Lỗi dữ liệu", "Đối tượng được chọn không có đường dẫn (curve) hợp lệ.")
                continue # Bỏ qua vòng lặp này, cho phép pick lại
                
            pipe_line = loc_curve.Curve
            if not isinstance(pipe_line, Line):
                show_error("Lỗi hình học", "Trục ống không phải là một đường thẳng.")
                continue

            is_vertical = abs(pipe_line.Direction.Z) > 0.9
            move_vector = None

            # Task 3: Core Logic (Toán học xử lý 2 trường hợp)
            if is_vertical:
                # --- XỬ LÝ ỐNG ĐỨNG (Khóa trục trực giao) ---
                p1_x, p1_y = picked_point.X, picked_point.Y
                p2_x, p2_y = pipe_line.Origin.X, pipe_line.Origin.Y
                
                delta_x = abs(p1_x - p2_x)
                delta_y = abs(p1_y - p2_y)
                
                if delta_x < 0.001 and delta_y < 0.001:
                    show_error("Cảnh báo an toàn", "Điểm chọn trùng với tâm ống đứng. Không thể xác định hướng!")
                    continue
                    
                if delta_x > delta_y:
                    current_dist = delta_x
                    move_dist = current_dist - TARGET_DIST_FT
                    if abs(move_dist) < 0.001: continue
                    
                    dir_x = 1.0 if p1_x > p2_x else -1.0
                    move_vector = XYZ(dir_x * move_dist, 0, 0)
                else:
                    current_dist = delta_y
                    move_dist = current_dist - TARGET_DIST_FT
                    if abs(move_dist) < 0.001: continue
                    
                    dir_y = 1.0 if p1_y > p2_y else -1.0
                    move_vector = XYZ(0, dir_y * move_dist, 0)
                    
            else:
                # --- XỬ LÝ ỐNG NGANG ---
                pt_flattened = XYZ(picked_point.X, picked_point.Y, pipe_line.Origin.Z)
                unbounded_line = Line.CreateUnbound(pipe_line.Origin, pipe_line.Direction)
                
                projected_result = unbounded_line.Project(pt_flattened)
                if projected_result is None:
                    show_error("Lỗi toán học", "Không thể chiếu điểm mốc lên trục ống ngang.")
                    continue
                    
                projected_pt = projected_result.XYZPoint
                vec_to_point = pt_flattened - projected_pt
                current_dist = vec_to_point.GetLength()
                
                if current_dist < 0.001:
                    show_error("Cảnh báo an toàn", "Điểm chọn nằm ngay trên trục ống ngang. Không thể xác định hướng!")
                    continue
                    
                dir_normalized = vec_to_point.Normalize()
                move_dist = current_dist - TARGET_DIST_FT
                
                if abs(move_dist) < 0.001: continue
                move_vector = dir_normalized.Multiply(move_dist)

            # Task 4: Thực thi Transaction 
            if move_vector is not None:
                # Tạo transaction riêng cho từng lần pick để Ctrl+Z từng bước một
                t = Transaction(doc, "Superpowers: Dời ống {}mm".format(TARGET_DIST_MM))
                t.Start()
                ElementTransformUtils.MoveElement(doc, pipe.Id, move_vector)
                t.Commit()

        except OperationCanceledException:
            # Task 5: User bấm ESC -> Ngắt vòng lặp, kết thúc tool im lặng
            break 
        except Exception as e:
            show_error("Lỗi hệ thống", str(e))
            break # Lỗi crash thì thoát luôn tool để an toàn

if __name__ == '__main__':
    main()