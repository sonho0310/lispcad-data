# -*- coding: utf-8 -*-
import clr
import math
import traceback

# --- IMPORT ---
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.DB.Plumbing import Pipe
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.DB.Electrical import CableTray
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. CÁC HÀM HỖ TRỢ ---

class MEPFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category is None: return False
        cat_id = elem.Category.Id.IntegerValue
        if cat_id == int(BuiltInCategory.OST_PipeCurves) or \
           cat_id == int(BuiltInCategory.OST_DuctCurves) or \
           cat_id == int(BuiltInCategory.OST_CableTray):
            return True
        return False
    def AllowReference(self, reference, position):
        return False

def get_connectors_safe(element):
    if isinstance(element, (Pipe, Duct, CableTray)):
        return element.ConnectorManager.Connectors
    elif isinstance(element, FamilyInstance):
        if element.MEPModel:
            return element.MEPModel.ConnectorManager.Connectors
    return []

def get_connector_closest_to(element, point):
    connectors = get_connectors_safe(element)
    if not connectors: return None
    closest = None
    min_dist = float('inf')
    for con in connectors:
        dist = con.Origin.DistanceTo(point)
        if dist < min_dist:
            min_dist = dist
            closest = con
    return closest

def store_connection(element, fixed_point):
    conn = get_connector_closest_to(element, fixed_point)
    if not conn or not conn.IsConnected: return None
    
    target_ref = None
    for ref in conn.AllRefs:
        if ref.Owner.Id != element.Id and ref.ConnectorType != ConnectorType.Logical:
            target_ref = ref
            break
            
    # CHỦ ĐỘNG RÚT PHÍCH CẮM
    if target_ref:
        try: conn.DisconnectFrom(target_ref)
        except: pass
        return target_ref
    return None

def restore_connection(element, fixed_point, target_connector):
    if not target_connector: return False
    new_conn = get_connector_closest_to(element, fixed_point)
    if new_conn and not new_conn.IsConnected:
        try:
            new_conn.ConnectTo(target_connector)
            return True
        except: pass
    return False

def get_closest_points_between_lines(line1_p1, line1_dir, line2_p1, line2_dir):
    w0 = line1_p1 - line2_p1
    a = line1_dir.DotProduct(line1_dir)
    b = line1_dir.DotProduct(line2_dir)
    c = line2_dir.DotProduct(line2_dir)
    d = line1_dir.DotProduct(w0)
    e = line2_dir.DotProduct(w0)
    denom = a * c - b * b
    if abs(denom) < 1e-6: return None, None # Song song
    sc = (b * e - c * d) / denom
    tc = (a * e - b * d) / denom
    return line1_p1 + line1_dir * sc, line2_p1 + line2_dir * tc

def project_point_on_line(point, line_origin, line_dir):
    v = point - line_origin
    dist = v.DotProduct(line_dir)
    return line_origin + line_dir * dist

def get_system_type_id(element):
    if isinstance(element, CableTray): return None
    pm = element.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
    if pm and pm.HasValue: return pm.AsElementId()
    pm = element.get_Parameter(BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
    if pm and pm.HasValue: return pm.AsElementId()
    return ElementId.InvalidElementId

def copy_size_parameters(source_elem, target_elem):
    params_to_copy = [
        BuiltInParameter.RBS_PIPE_DIAMETER_PARAM,
        BuiltInParameter.RBS_CURVE_DIAMETER_PARAM,
        BuiltInParameter.RBS_CURVE_WIDTH_PARAM,
        BuiltInParameter.RBS_CURVE_HEIGHT_PARAM,
        BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM, 
        BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM
    ]
    for pid in params_to_copy:
        src_p = source_elem.get_Parameter(pid)
        tgt_p = target_elem.get_Parameter(pid)
        if src_p and tgt_p and not src_p.IsReadOnly and not tgt_p.IsReadOnly:
            try: tgt_p.Set(src_p.AsDouble())
            except: pass

def get_diameter(elem):
    try:
        if isinstance(elem, Pipe):
            p = elem.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
            if p: return p.AsDouble()
        elif isinstance(elem, Duct):
            p = elem.get_Parameter(BuiltInParameter.RBS_CURVE_DIAMETER_PARAM)
            if p and p.HasValue: return p.AsDouble()
            w = elem.get_Parameter(BuiltInParameter.RBS_CURVE_WIDTH_PARAM)
            h = elem.get_Parameter(BuiltInParameter.RBS_CURVE_HEIGHT_PARAM)
            if w and h: return max(w.AsDouble(), h.AsDouble())
    except: pass
    return 0.33 # Mặc định ~100mm nếu lỗi

# --- 2. MAIN ---

def run():
    tg = TransactionGroup(doc, "Smart MEP 45 (Dual Logic)")
    tg.Start()
    step = "Khởi tạo"
    
    try:
        mep_filter = MEPFilter()
        while True:
            step = "Pick đối tượng"
            try:
                ref1 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ỐNG 1 (Nhấn ESC để ngưng lệnh)")
                ref2 = uidoc.Selection.PickObject(ObjectType.Element, mep_filter, "Chọn ỐNG 2 (Nhấn ESC để ngưng lệnh)")
            except OperationCanceledException:
                break 

            elem1 = doc.GetElement(ref1)
            elem2 = doc.GetElement(ref2)

            if type(elem1) != type(elem2) or not isinstance(elem1, (Pipe, Duct, CableTray)):
                 TaskDialog.Show("Lỗi", "Vui lòng chọn 2 đối tượng cùng loại.")
                 continue 

            t = Transaction(doc, "Connect 45 Geometry")
            t.Start()
            
            try:
                step = "Lấy dữ liệu Curve"
                c1 = elem1.Location.Curve
                c2 = elem2.Location.Curve
                
                p1_start = c1.GetEndPoint(0)
                p1_end = c1.GetEndPoint(1)
                v1_dir = (p1_end - p1_start).Normalize()

                p2_start = c2.GetEndPoint(0)
                p2_end = c2.GetEndPoint(1)
                v2_dir = (p2_end - p2_start).Normalize()

                step = "Kiểm tra hình học (Song song hay Cắt nhau)"
                pt1, pt2 = get_closest_points_between_lines(p1_start, v1_dir, p2_start, v2_dir)

                # ==========================================================
                # KỊCH BẢN A: 2 ỐNG SONG SONG (OFFSET) - MASTER/SLAVE
                # ==========================================================
                if not pt1 or not pt2:
                    step = "[Song Song] Tính điểm đích"
                    # Tìm đầu mút của Ống 1 gần Ống 2 nhất
                    mid_p2 = (p2_start + p2_end) / 2
                    if p1_start.DistanceTo(mid_p2) < p1_end.DistanceTo(mid_p2): p1_root = p1_start
                    else: p1_root = p1_end

                    # Tính độ lệch Offset
                    H = project_point_on_line(p1_root, p2_start, v2_dir)
                    offset_dist = p1_root.DistanceTo(H)

                    # Tạo tam giác vuông cân (góc 45 độ)
                    candidate1 = H + v2_dir * offset_dist
                    candidate2 = H - v2_dir * offset_dist
                    p2_target = candidate1 if candidate1.DistanceTo(mid_p2) < candidate2.DistanceTo(mid_p2) else candidate2

                    # Xác định đầu cố định của Ống 2
                    if p2_start.DistanceTo(p2_target) > p2_end.DistanceTo(p2_target): p2_fixed = p2_start
                    else: p2_fixed = p2_end

                    step = "[Song Song] Vuốt Ống 2"
                    saved_conn_2 = store_connection(elem2, p2_fixed)
                    elem2.Location.Curve = Line.CreateBound(p2_fixed, p2_target)
                    doc.Regenerate()
                    restore_connection(elem2, p2_fixed, saved_conn_2)
                    
                    p1_target = p1_root # Ống 1 giữ nguyên

                # ==========================================================
                # KỊCH BẢN B: 2 ỐNG CẮT NHAU (VÁT GÓC) - SYMMETRIC CHAMFER
                # ==========================================================
                else:
                    step = "[Cắt Nhau] Tính Setback"
                    p_corner = pt1 # Giao điểm

                    # Xác định đầu cố định (nằm xa giao điểm nhất)
                    if p1_start.DistanceTo(p_corner) > p1_end.DistanceTo(p_corner): p1_fixed = p1_start
                    else: p1_fixed = p1_end

                    if p2_start.DistanceTo(p_corner) > p2_end.DistanceTo(p_corner): p2_fixed = p2_start
                    else: p2_fixed = p2_end

                    # Tính chiều dài Bridge (L) và Setback
                    b_dia = get_diameter(elem1)
                    L = max(b_dia * 2.0, 0.3)
                    setback = L / math.sqrt(2.0)

                    # Tính tọa độ mới (giật lùi từ Corner về phía mút cố định)
                    v1_away = (p1_fixed - p_corner).Normalize()
                    v2_away = (p2_fixed - p_corner).Normalize()
                    
                    p1_target = p_corner + v1_away * setback
                    p2_target = p_corner + v2_away * setback

                    step = "[Cắt Nhau] Vuốt Ống 1"
                    saved_conn_1 = store_connection(elem1, p1_fixed)
                    elem1.Location.Curve = Line.CreateBound(p1_fixed, p1_target)
                    doc.Regenerate()
                    restore_connection(elem1, p1_fixed, saved_conn_1)

                    step = "[Cắt Nhau] Vuốt Ống 2"
                    saved_conn_2 = store_connection(elem2, p2_fixed)
                    elem2.Location.Curve = Line.CreateBound(p2_fixed, p2_target)
                    doc.Regenerate()
                    restore_connection(elem2, p2_fixed, saved_conn_2)

                # ==========================================================
                # CHUNG: TẠO ỐNG BRIDGE 45 ĐỘ VÀ FITTING
                # ==========================================================
                step = "Tạo ống Bridge ngang"
                ptype_id = elem1.GetTypeId()
                lvl_param = elem1.get_Parameter(BuiltInParameter.RBS_START_LEVEL_PARAM)
                lvl_id = lvl_param.AsElementId() if lvl_param else doc.ActiveView.GenLevel.Id

                if isinstance(elem1, Pipe):
                    sys_id = get_system_type_id(elem1)
                    mid_elem = Pipe.Create(doc, sys_id, ptype_id, lvl_id, p1_target, p2_target)
                elif isinstance(elem1, Duct):
                    sys_id = get_system_type_id(elem1)
                    mid_elem = Duct.Create(doc, sys_id, ptype_id, lvl_id, p1_target, p2_target)
                elif isinstance(elem1, CableTray):
                    mid_elem = CableTray.Create(doc, ptype_id, p1_target, p2_target, lvl_id)

                copy_size_parameters(elem1, mid_elem)
                doc.Regenerate()

                step = "Đặt 2 Cút 45 độ"
                c1_conn = get_connector_closest_to(elem1, p1_target)
                cm1 = get_connector_closest_to(mid_elem, p1_target)
                if c1_conn and cm1: doc.Create.NewElbowFitting(c1_conn, cm1)

                c2_conn = get_connector_closest_to(elem2, p2_target)
                cm2 = get_connector_closest_to(mid_elem, p2_target)
                if c2_conn and cm2: doc.Create.NewElbowFitting(c2_conn, cm2)

                t.Commit()

            except Exception as e_geo:
                if t.GetStatus() == TransactionStatus.Started: t.RollBack()
                error_trace = traceback.format_exc()
                TaskDialog.Show("Bug Catcher 🐛", "Tool chết tại bước: [{}]\n\nChi tiết lỗi:\n{}".format(step, error_trace))

    except Exception as e:
        if "OperationCanceled" not in str(e):
            error_trace = traceback.format_exc()
            TaskDialog.Show("Critical Error", "Lỗi văng hệ thống:\n\n" + error_trace)
    finally:
        if tg.GetStatus() == TransactionStatus.Started:
            tg.Assimilate()

if __name__ == '__main__':
    run()