# -*- coding: utf-8 -*-
import clr

# Import thư viện Revit API
import Autodesk
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

# Khai báo biến
doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# Bộ lọc đối tượng MEP
class MEPCurveFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Location and isinstance(elem.Location, LocationCurve):
            return True
        return False
    def AllowReference(self, reference, position):
        return True

def flatten_2d(pt):
    """Hàm ép phẳng mọi điểm/vector xuống mặt phẳng 2D (Z=0)"""
    return XYZ(pt.X, pt.Y, 0.0)

def final_merged_align_v2():
    while True:
        t = Transaction(doc, "Final Merged Align V2")
        try:
            # ==========================================
            # BƯỚC 1 & 2: Chọn Source và Target
            # ==========================================
            try:
                ref_source = uidoc.Selection.PickObject(
                    ObjectType.Element, 
                    MEPCurveFilter(), 
                    "Chọn ống CHUẨN (Source) - ESC để thoát"
                )
            except Autodesk.Revit.Exceptions.OperationCanceledException:
                break 

            elem_source = doc.GetElement(ref_source)
            c_src = elem_source.Location.Curve

            try:
                ref_target = uidoc.Selection.PickObject(
                    ObjectType.Element, 
                    MEPCurveFilter(), 
                    "Chọn ống CẦN ALIGN (Target)"
                )
            except Autodesk.Revit.Exceptions.OperationCanceledException:
                break 

            elem_target = doc.GetElement(ref_target)
            if elem_target.Id == elem_source.Id:
                continue

            # ==========================================
            # NHẬN DIỆN VÀ PHÂN NHÁNH THUẬT TOÁN
            # ==========================================
            t.Start()
            c_tgt = elem_target.Location.Curve

            # [SUPERPOWERS FIXED] - Nâng cấp Cảm biến nhận diện Ống Đứng
            # Mọi ống dốc > 45 độ đều tính là Ống Đứng để chống sai số nét vẽ.
            dir_src_norm = c_src.Direction.Normalize()
            dir_tgt_norm = c_tgt.Direction.Normalize()

            src_is_vert = abs(dir_src_norm.Z) > 0.5
            tgt_is_vert = abs(dir_tgt_norm.Z) > 0.5

            if not src_is_vert and not tgt_is_vert:
                # --------------------------------------------------
                # NHÁNH 1: NGANG - NGANG (Luật đồng phẳng 3D của User)
                # --------------------------------------------------
                line_src = Line.CreateUnbound(c_src.Origin, c_src.Direction)
                line_tgt = Line.CreateUnbound(c_tgt.Origin, c_tgt.Direction)
                
                pt_clicked = ref_target.GlobalPoint
                pt_center_tgt = line_tgt.Project(pt_clicked).XYZPoint
                
                res_proj = line_src.Project(pt_center_tgt)
                if res_proj:
                    pt_dest = res_proj.XYZPoint
                    raw_move = pt_dest - pt_center_tgt
                    
                    tgt_dir = c_tgt.Direction.Normalize()
                    slide_mag = raw_move.DotProduct(tgt_dir)
                    slide_vec = tgt_dir.Multiply(slide_mag)
                    
                    final_move = raw_move - slide_vec
                else:
                    final_move = XYZ.Zero

            else:
                # --------------------------------------------------
                # NHÁNH 2: CÓ ỐNG ĐỨNG (Luật Ultimate 2D của User)
                # --------------------------------------------------
                v_src_3d = flatten_2d(c_src.Direction)
                v_tgt_3d = flatten_2d(c_tgt.Direction)

                p_src = flatten_2d(c_src.Origin)
                p_tgt = flatten_2d(c_tgt.Origin)

                v_src = XYZ.Zero if src_is_vert else v_src_3d.Normalize()
                v_tgt = XYZ.Zero if tgt_is_vert else v_tgt_3d.Normalize()

                pt_clicked_2d = flatten_2d(ref_target.GlobalPoint)

                # Tâm Target 2D
                if tgt_is_vert:
                    pt_center_tgt = p_tgt
                else:
                    w_click = pt_clicked_2d - p_tgt
                    pt_center_tgt = p_tgt + v_tgt.Multiply(w_click.DotProduct(v_tgt))

                # Đích Source 2D
                if src_is_vert:
                    pt_dest = p_src
                else:
                    w_src = pt_center_tgt - p_src
                    pt_dest = p_src + v_src.Multiply(w_src.DotProduct(v_src))

                raw_move = pt_dest - pt_center_tgt

                # Khử trượt
                if tgt_is_vert:
                    final_move = raw_move
                else:
                    slide_mag = raw_move.DotProduct(v_tgt)
                    slide_vec = v_tgt.Multiply(slide_mag)
                    final_move = raw_move - slide_vec

            # ==========================================
            # THỰC THI DI CHUYỂN
            # ==========================================
            if final_move.GetLength() > 0.001:
                ElementTransformUtils.MoveElement(doc, elem_target.Id, final_move)
            
            t.Commit()

        except Exception as e:
            print("Lỗi: " + str(e))
            if t.GetStatus() == TransactionStatus.Started:
                t.RollBack()
            break

# Chạy script
final_merged_align_v2()