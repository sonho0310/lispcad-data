# -*- coding: utf-8 -*-
"""
TOOL: PROMAX HYBRID DROP (V7.10 - SILENT MODE)
AUTHOR: Revit Geometry ProMax
DESCRIPTION: 
    - Đã tắt console print.
    - Fix namespace conflict (DBPlumbing).
    - Tích hợp Smart Parameter Scanner để đổi góc Y.
"""

# --- 1. IMPORTS ---
import clr
import math
from System.Collections.Generic import List

# Revit API
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import *
from Autodesk.Revit.Exceptions import OperationCanceledException

# [FIX QUANTITY] Import Plumbing của DB với tên riêng biệt
import Autodesk.Revit.DB.Plumbing as DBPlumbing

# pyRevit
from pyrevit import forms

# --- 2. SETTINGS ---
class Settings(object):
    KICK_LENGTH = 0.8            
    PARALLEL_LENGTH = 0.8        
    COS_45 = 0.70710678          

# --- 3. UTILITIES ---
class RevitUtils(object):
    @staticmethod
    def get_closest_connector(element, point):
        if not element: return None
        try:
            conns = element.ConnectorManager.Connectors
            min_dist = float('inf')
            best_conn = None
            for c in conns:
                dist = c.Origin.DistanceTo(point)
                if dist < min_dist:
                    min_dist = dist
                    best_conn = c
            return best_conn
        except: return None

    @staticmethod
    def get_pipe_diameter(pipe):
        param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
        return param.AsDouble() if param else 0.0

    @staticmethod
    def get_pipe_slope(pipe):
        param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_SLOPE)
        return param.AsDouble() if param else 0.0

    @staticmethod
    def set_pipe_param(pipe, diameter, slope=0):
        d_param = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
        if d_param and not d_param.IsReadOnly:
            d_param.Set(diameter)
        if slope > 0:
            ps = pipe.get_Parameter(BuiltInParameter.RBS_PIPE_SLOPE)
            if ps and not ps.IsReadOnly: 
                ps.Set(slope)

    # --- HÀM LẤY FITTING (SILENT MODE) ---
    @staticmethod
    def get_routing_junction_symbol(doc, pipe):
        try:
            pipe_type = doc.GetElement(pipe.GetTypeId())
            routing_manager = pipe_type.RoutingPreferenceManager
            
            # [FIX] Dùng DBPlumbing
            group_type = DBPlumbing.RoutingPreferenceRuleGroupType.Junction
            
            rule_count = routing_manager.GetNumberOfRules(group_type)
            
            if rule_count == 0:
                return None
                
            rule = routing_manager.GetRule(group_type, 0)
            
            symbol_id = rule.MEPPartId
            if symbol_id and symbol_id != ElementId.InvalidElementId:
                symbol = doc.GetElement(symbol_id)
                return symbol
        except:
            pass
        return None

class GeoUtils(object):
    @staticmethod
    def project_point_on_line(pt, line_origin, line_dir):
        vec = pt - line_origin
        dot = vec.DotProduct(line_dir)
        return line_origin + line_dir.Multiply(dot)

    @staticmethod
    def line_intersection_xy(p1, v1, p2, v2):
        det = v1.X * v2.Y - v1.Y * v2.X
        if abs(det) < 0.0001: return None 
        dx = p2.X - p1.X
        dy = p2.Y - p1.Y
        t = (dx * v2.Y - dy * v2.X) / det
        return p1 + v1.Multiply(t)

# --- 4. SELECTION FILTER ---
class PipeSelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        return elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves) if elem else False
    def AllowReference(self, ref, pt): return False

# --- 5. GEOMETRY PROCESSOR ---
class GeometryProcessor(object):
    def __init__(self, pt_pick, main_pipe, branch_pipe):
        self.pt_pick = pt_pick
        self.main_loc = main_pipe.Location.Curve
        self.main_origin = self.main_loc.GetEndPoint(0)
        self.main_dir = self.main_loc.Direction.Normalize()
        self.branch_pipe = branch_pipe
        
        self.dia = RevitUtils.get_pipe_diameter(branch_pipe)
        self.slope = RevitUtils.get_pipe_slope(branch_pipe)
        self.sys_type_id = branch_pipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
        self.type_id = branch_pipe.GetTypeId()
        self.level_id = branch_pipe.LevelId

    def calculate(self):
        # --- A. TÍNH TOÁN KICK & PARALLEL ---
        l_branch = self.branch_pipe.Location.Curve
        b_p1 = l_branch.GetEndPoint(0)
        b_p2 = l_branch.GetEndPoint(1)
        
        proj_1 = GeoUtils.project_point_on_line(b_p1, self.main_origin, self.main_dir)
        proj_2 = GeoUtils.project_point_on_line(b_p2, self.main_origin, self.main_dir)
        
        if b_p1.DistanceTo(proj_1) < b_p2.DistanceTo(proj_2):
            p_near, p_far, active_end_idx = b_p1, b_p2, 0
        else:
            p_near, p_far, active_end_idx = b_p2, b_p1, 1
            
        v_branch = (p_near - p_far).Normalize()
        
        intersection = GeoUtils.line_intersection_xy(p_far, v_branch, self.main_origin, self.main_dir)
        if not intersection: raise Exception("Hai ống song song, không thể tạo Kick!")

        offset_dist = Settings.KICK_LENGTH * Settings.COS_45
        p_start_xy = intersection - v_branch.Multiply(offset_dist)
        
        dist_total = p_near.DistanceTo(p_far)
        z_unit = (p_near.Z - p_far.Z) / dist_total if dist_total > 0.001 else 0
        dist_from_far = p_far.DistanceTo(p_start_xy)
        p_start = XYZ(p_start_xy.X, p_start_xy.Y, p_far.Z + dist_from_far * z_unit)
        
        pt_pick_proj = GeoUtils.project_point_on_line(self.pt_pick, self.main_origin, self.main_dir)
        near_proj = GeoUtils.project_point_on_line(p_near, self.main_origin, self.main_dir)
        is_forward = (pt_pick_proj - near_proj).DotProduct(self.main_dir) > 0
        v_flow_main = self.main_dir if is_forward else self.main_dir.Negate()
        
        p1_xy = intersection + v_flow_main.Multiply(offset_dist)
        p1 = XYZ(p1_xy.X, p1_xy.Y, p_start.Z - (Settings.KICK_LENGTH * self.slope))
        
        p2_xy = p1_xy + v_flow_main.Multiply(Settings.PARALLEL_LENGTH)
        p2 = XYZ(p2_xy.X, p2_xy.Y, p1.Z - (Settings.PARALLEL_LENGTH * self.slope))

        # --- B. TÍNH ĐIỂM ĐẶT Y ---
        pt_proj = GeoUtils.project_point_on_line(p2, self.main_origin, self.main_dir)
        dist_h = p2.DistanceTo(pt_proj)
        
        pt_wye_center = pt_proj + v_flow_main.Multiply(dist_h)
        
        vec_up = (p2 - pt_proj).Normalize() 
        pt_dummy_end = pt_wye_center + vec_up.Multiply(1.0)

        return {
            "ActiveEndIdx": active_end_idx,
            "P_Start": p_start,
            "P1": p1,
            "P2": p2,
            "P_Wye": pt_wye_center,
            "P_Dummy_End": pt_dummy_end,
            "Dia": self.dia,
            "Slope": self.slope,
            "SysTypeId": self.sys_type_id,
            "BranchTypeId": self.type_id,
            "LevelId": self.level_id
        }

# --- 6. MAIN FUNCTION ---
def main():
    doc = __revit__.ActiveUIDocument.Document
    uidoc = __revit__.ActiveUIDocument
    pipe_filter = PipeSelectionFilter()

    while True:
        t = None
        try:
            # --- INPUT ---
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B1: Chọn Main Pipe (ESC thoát)")
                main_pipe = doc.GetElement(ref_main)
            except OperationCanceledException: break

            try:
                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, pipe_filter, "B2: Chọn Branch Pipe")
                branch_pipe = doc.GetElement(ref_branch)
            except OperationCanceledException: break

            # --- PROCESS ---
            processor = GeometryProcessor(ref_main.GlobalPoint, main_pipe, branch_pipe)
            geo = processor.calculate()

            # --- EXECUTION ---
            t = Transaction(doc, "ProMax Routing Fixed")
            t.Start()

            def create_pipe(p_start, p_end, slope_val=0):
                # [FIX] Dùng DBPlumbing.Pipe
                p = DBPlumbing.Pipe.Create(doc, geo["SysTypeId"], geo["BranchTypeId"], geo["LevelId"], p_start, p_end)
                RevitUtils.set_pipe_param(p, geo["Dia"], slope_val)
                return p

            # LẤY FITTING TỪ ROUTING
            target_symbol = RevitUtils.get_routing_junction_symbol(doc, main_pipe)
            if target_symbol and not target_symbol.IsActive: target_symbol.Activate()
            
            # 1. Chỉnh ống gốc
            l_curve = branch_pipe.Location
            try:
                l_curve.Curve.MakeBound(0, 1)
                curr_p0 = l_curve.Curve.GetEndPoint(0)
                curr_p1 = l_curve.Curve.GetEndPoint(1)
                if geo["ActiveEndIdx"] == 0: new_line = Line.CreateBound(geo["P_Start"], curr_p1)
                else: new_line = Line.CreateBound(curr_p0, geo["P_Start"])
                l_curve.Curve = new_line
            except: pass
            doc.Regenerate()

            # 2. Vẽ Kick & Parallel
            p_kick = create_pipe(geo["P_Start"], geo["P1"], geo["Slope"])
            p_para = create_pipe(geo["P1"], geo["P2"], geo["Slope"])
            doc.Regenerate()

            # 3. Nối Elbows (Trên cao)
            try:
                doc.Create.NewElbowFitting(RevitUtils.get_closest_connector(branch_pipe, geo["P_Start"]), RevitUtils.get_closest_connector(p_kick, geo["P_Start"]))
                doc.Create.NewElbowFitting(RevitUtils.get_closest_connector(p_kick, geo["P1"]), RevitUtils.get_closest_connector(p_para, geo["P1"]))
            except: pass

            # 4. Tạo Wye trên Main
            try:
                # [FIX] Dùng DBPlumbing.PlumbingUtils
                new_main_id = DBPlumbing.PlumbingUtils.BreakCurve(doc, main_pipe.Id, geo["P_Wye"])
                main_pipe_2 = doc.GetElement(new_main_id)
            except:
                t.RollBack()
                forms.alert("Lỗi: Không thể cắt ống Main (quá gần đầu mút).")
                continue
            doc.Regenerate()

            # 5. Tạo Dummy Pipe & Tee
            dummy_pipe = create_pipe(geo["P_Wye"], geo["P_Dummy_End"])
            doc.Regenerate()

            c_m1 = RevitUtils.get_closest_connector(main_pipe, geo["P_Wye"])
            c_m2 = RevitUtils.get_closest_connector(main_pipe_2, geo["P_Wye"])
            c_dum = RevitUtils.get_closest_connector(dummy_pipe, geo["P_Wye"])
            
            fitting = doc.Create.NewTeeFitting(c_m1, c_m2, c_dum)
            doc.Regenerate()

            # SWAP SANG ROUTING SYMBOL
            if fitting and target_symbol:
                if fitting.Symbol.Id != target_symbol.Id:
                    fitting.ChangeTypeId(target_symbol.Id)
                    doc.Regenerate()
            
            fitting = doc.GetElement(fitting.Id) 
            doc.Delete(dummy_pipe.Id)
            doc.Regenerate()

            # ==========================================================
            # XOAY 45 ĐỘ (Đã áp dụng bộ quét thông minh)
            # ==========================================================
            for p in fitting.Parameters:
                p_name = p.Definition.Name.lower()
                if any(k in p_name for k in ["angle", "góc", "bend"]):
                    if not p.IsReadOnly:
                        try:
                            p.Set(math.pi / 4)
                            doc.Regenerate()
                        except:
                            pass

            # ==========================================================
            # 6. Kết nối cuối cùng
            # ==========================================================
            c_wye_branch = None
            min_dist = float('inf')
            for c in fitting.MEPModel.ConnectorManager.Connectors:
                # [FIX] Phải bỏ qua các đầu đã nối với ống Main để tránh bắt nhầm
                if c.IsConnected: 
                    continue 
                d = c.Origin.DistanceTo(geo["P2"])
                if d < min_dist:
                    min_dist = d
                    c_wye_branch = c
            
            if c_wye_branch:
                p_drop = create_pipe(geo["P2"], c_wye_branch.Origin, 0)
                doc.Regenerate()
                
                c_drop_bot = RevitUtils.get_closest_connector(p_drop, c_wye_branch.Origin)
                c_wye_branch.ConnectTo(c_drop_bot)
                
                c_drop_top = RevitUtils.get_closest_connector(p_drop, geo["P2"])
                c_para_end = RevitUtils.get_closest_connector(p_para, geo["P2"])
                try:
                    doc.Create.NewElbowFitting(c_para_end, c_drop_top)
                except: pass
            else:
                 forms.alert("Không tìm thấy connector nhánh của phụ kiện Y!")

            t.Commit()

        except Exception as e:
            if t and t.GetStatus() == TransactionStatus.Started: t.RollBack()
            # Vẫn hiện Alert khi lỗi nặng (Crash)
            forms.alert("Lỗi Runtime: {}".format(str(e)))

if __name__ == "__main__":
    main()