# -*- coding: utf-8 -*-
import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

from pyrevit import revit

doc = revit.doc
uidoc = revit.uidoc
from System.Collections.Generic import List

# --- BỘ LỌC CỨNG (Category ID) ---
class CategorySelectionFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves):
            return True
        return False

    def AllowReference(self, ref, point):
        return True

# --- HÀM HELPER ---
def is_pipe(elem):
    if elem is None: return False
    if elem.Category and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves):
        return True
    return False

def is_elbow_fitting(elem):
    if elem is None: return False
    if elem.Category and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeFitting):
        if isinstance(elem, FamilyInstance):
            if elem.MEPModel and elem.MEPModel.PartType == PartType.Elbow:
                return True
    return False

# --- LOGIC CHÍNH ---
def convert_safe_mode():
    while True:
        try:
            # 1. Chọn đối tượng
            ref = uidoc.Selection.PickObject(
                ObjectType.Element, 
                CategorySelectionFilter(), 
                "Click vào ống nối để gộp (ESC để thoát)..."
            )
            mid_pipe = doc.GetElement(ref.ElementId)
            
            # 2. Bắt đầu Transaction
            t = Transaction(doc, "Convert 2x45 to 90")
            t.Start()
            
            try:
                # --- KIỂM TRA LOGIC ---
                mid_conns = [c for c in mid_pipe.ConnectorManager.Connectors]
                
                # Nếu không đủ 2 đầu -> Bỏ qua
                if len(mid_conns) != 2:
                    raise Exception("Ống không hợp lệ")

                elbows = []
                outer_connectors = [] 
                valid_assembly = True

                for mid_c in mid_conns:
                    found_elbow = False
                    for r in mid_c.AllRefs:
                        connected_elem = r.Owner
                        if connected_elem.Id == mid_pipe.Id: continue
                        
                        if is_elbow_fitting(connected_elem):
                            elbows.append(connected_elem)
                            found_elbow = True
                            
                            elbow_mgr = connected_elem.MEPModel.ConnectorManager
                            for elbow_c in elbow_mgr.Connectors:
                                if elbow_c.Id != r.Id:
                                    for outer_ref in elbow_c.AllRefs:
                                        if is_pipe(outer_ref.Owner):
                                            outer_connectors.append(outer_ref)
                    
                    if not found_elbow:
                        valid_assembly = False
                        break
                
                # Check đủ bộ phận
                if not valid_assembly or len(elbows) != 2 or len(outer_connectors) != 2:
                    raise Exception("Không tìm thấy đủ cụm Fitting")

                # --- HÀNH ĐỘNG ---
                # 1. Xóa đồ cũ
                delete_ids = List[ElementId]()
                delete_ids.Add(mid_pipe.Id)
                delete_ids.Add(elbows[0].Id)
                delete_ids.Add(elbows[1].Id)
                
                doc.Delete(delete_ids)
                
                # Quan trọng: Regenerate để Revit hiểu không gian đã trống
                doc.Regenerate()
                
                # 2. Tạo đồ mới
                new_fitting = doc.Create.NewElbowFitting(outer_connectors[0], outer_connectors[1])
                
                # 3. KIỂM TRA KẾT QUẢ (Safety Check)
                if new_fitting is None:
                    # Nếu hàm trả về None -> Thất bại -> Rollback
                    raise Exception("Revit từ chối tạo Fitting (Do hình học hoặc Routing)")
                
                if new_fitting.Id == ElementId.InvalidElementId:
                     raise Exception("Fitting tạo ra bị lỗi")

                # Nếu sống sót qua tất cả bước trên -> Commit
                t.Commit()
                
            except Exception as e:
                # Bất kỳ lỗi gì xảy ra -> Undo toàn bộ thao tác vừa rồi
                if t.GetStatus() == TransactionStatus.Started:
                    t.RollBack()
                # print("Lỗi xử lý: " + str(e)) # Uncomment nếu muốn debug

        except OperationCanceledException:
            break
        except Exception:
            break

if __name__ == '__main__':
    convert_safe_mode()