# -*- coding: utf-8 -*-
"""
TOOL: AUTO 45-UP & CAP (V15.2 - SMART LENGTH)
AUTHOR: Revit Geometry ProMax
CHANGE: Dynamic Stub Length based on Diameter
"""

import math
import clr
import Autodesk # Fix lỗi name global

import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI.Selection as Sel
from Autodesk.Revit.DB import *
from pyrevit import revit, forms

doc = revit.doc
uidoc = revit.uidoc

# =======================================================
# 0. CLASS FILTER
# =======================================================
class PipeSelectionFilter(Sel.ISelectionFilter):
    def AllowElement(self, elem):
        return isinstance(elem, DB.Plumbing.Pipe)
    def AllowReference(self, ref, point):
        return True

# =======================================================
# 1. LOGIC TÍNH TOÁN & HÌNH HỌC
# =======================================================
def safe_inject_size(cap_inst, pipe_dia_feet):
    try:
        bip = DB.BuiltInParameter.RBS_PIPE_NOMINAL_DIAMETER_PARAM
        p = cap_inst.get_Parameter(bip)
        if p and not p.IsReadOnly: p.Set(pipe_dia_feet)
    except: pass

    val_mm = int(round(pipe_dia_feet * 304.8))
    other_names = ["DN", "Size", "Diameter", "Kích thước", "Nominal Diameter"]
    for name in other_names:
        try:
            p = cap_inst.LookupParameter(name)
            if p and not p.IsReadOnly:
                if p.StorageType == DB.StorageType.Double: p.Set(pipe_dia_feet)
                elif p.StorageType == DB.StorageType.String: p.Set(str(val_mm))
                elif p.StorageType == DB.StorageType.Integer: p.Set(val_mm)
        except: pass

def get_best_cap_symbol(doc, pipe):
    try:
        pipe_type = doc.GetElement(pipe.GetTypeId())
        rpm = pipe_type.RoutingPreferenceManager
        if rpm.GetNumberOfRules(DB.RoutingPreferenceRuleGroupType.Caps) > 0:
            rule = rpm.GetRule(DB.RoutingPreferenceRuleGroupType.Caps, 0)
            sym_id = rule.MEPPartId
            if sym_id != ElementId.InvalidElementId: return doc.GetElement(sym_id)
    except: pass

    collector = DB.FilteredElementCollector(doc).OfCategory(DB.BuiltInCategory.OST_PipeFitting).WhereElementIsElementType()
    for sym in collector:
        name = Element.Name.GetValue(sym)
        if "PVC Thông tắc" in name or "PF_PVC_Thongtac" in sym.FamilyName: return sym
    return None

# =======================================================
# [UPDATE] HÀM TẠO ỐNG 45 VỚI ĐỘ DÀI ĐỘNG
# =======================================================
def create_45_up_extension_dynamic(doc, pipe, open_connector):
    """
    Tạo đoạn ống 45 độ hướng lên.
    Độ dài = Max(Diameter * 3.2, 0.4 feet)
    """
    # 1. Check hướng
    vec_out = open_connector.CoordinateSystem.BasisZ
    if abs(vec_out.Z) > 0.9: return None # Đang đứng thì thôi
    
    vec_z = XYZ.BasisZ
    vec_45 = (vec_out + vec_z).Normalize() 
    p_start = open_connector.Origin

    # 2. [MỚI] LẤY SIZE ĐỂ TÍNH ĐỘ DÀI
    try:
        # Lấy đường kính (Feet)
        dia_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
        b_dia = dia_param.AsDouble()
    except:
        b_dia = 0.1 # Fallback nếu lỗi (ít khi xảy ra)

    # 3. [MỚI] CÔNG THỨC CỦA BẠN
    # 0.4 ở đây là Feet (~122mm). Nếu muốn 400mm thì sửa thành 1.31
    stub_len = max(b_dia * 2.2, 0.4) 

    p_end = p_start + vec_45.Multiply(stub_len)

    try:
        new_pipe = DB.Plumbing.Pipe.Create(doc, pipe.MEPSystem.GetTypeId(), pipe.GetTypeId(), pipe.LevelId, p_start, p_end)
        new_pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(b_dia)
        return new_pipe
    except: return None

# ... (Hàm place_cap giữ nguyên logic robot) ...
def place_cap_v14_robot(doc, pipe_end_connector, cap_symbol, pipe_dia_feet):
    insert_point = pipe_end_connector.Origin
    cap_inst = doc.Create.NewFamilyInstance(insert_point, cap_symbol, DB.Structure.StructuralType.NonStructural)
    safe_inject_size(cap_inst, pipe_dia_feet)
    doc.Regenerate()

    cap_conn = None
    try:
        for c in cap_inst.MEPModel.ConnectorManager.Connectors: cap_conn = c; break
    except: return False 
    if not cap_conn: return False

    pipe_vec = pipe_end_connector.CoordinateSystem.BasisZ
    target_vec = pipe_vec.Negate()
    cap_vec = cap_conn.CoordinateSystem.BasisZ
    
    angle = cap_vec.AngleTo(target_vec)
    if angle > 0.01:
        axis = cap_vec.CrossProduct(target_vec)
        if axis.IsZeroLength():
             if abs(cap_vec.Z) < 0.99: axis = cap_vec.CrossProduct(XYZ.BasisZ)
             else: axis = cap_vec.CrossProduct(XYZ.BasisX)
        line_axis = Line.CreateBound(insert_point, insert_point + axis)
        DB.ElementTransformUtils.RotateElement(doc, cap_inst.Id, line_axis, angle)
        doc.Regenerate()

    cap_conn_new = None
    for c in cap_inst.MEPModel.ConnectorManager.Connectors: cap_conn_new = c; break
    
    translation = pipe_end_connector.Origin - cap_conn_new.Origin
    if not translation.IsZeroLength():
        DB.ElementTransformUtils.MoveElement(doc, cap_inst.Id, translation)

    try:
        cap_conn_new.ConnectTo(pipe_end_connector)
        return True
    except: return False

def get_connector_closest(element, point):
    if not element: return None
    conns = element.ConnectorManager.Connectors
    min_d = float('inf'); best_c = None
    for c in conns:
        d = c.Origin.DistanceTo(point)
        if d < min_d: min_d = d; best_c = c
    return best_c

# =======================================================
# 2. MAIN LOOP (INTERACTIVE)
# =======================================================
def main():
    while True:
        try:
            ref = uidoc.Selection.PickObject(Sel.ObjectType.Element, PipeSelectionFilter(), "Click đầu ống (ESC thoát)")
            pipe = doc.GetElement(ref)
            click_point = ref.GlobalPoint
            
            t = DB.Transaction(doc, "Auto Cap Smart Len")
            t.Start()

            try:
                target_conn = get_connector_closest(pipe, click_point)
                if not target_conn or target_conn.IsConnected:
                    print("Đầu này ko hợp lệ.")
                    t.RollBack(); continue

                dia_param = pipe.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM)
                pipe_dia = dia_param.AsDouble()
                
                cap_symbol = get_best_cap_symbol(doc, pipe)
                if not cap_symbol:
                    print("Thiếu Family Cap."); t.RollBack(); continue
                
                if not cap_symbol.IsActive: cap_symbol.Activate(); doc.Regenerate()

                # --- GỌI HÀM MỚI (DYNAMIC LENGTH) ---
                new_pipe = create_45_up_extension_dynamic(doc, pipe, target_conn)
                doc.Regenerate()

                if new_pipe:
                    c1 = target_conn
                    c2 = get_connector_closest(new_pipe, target_conn.Origin)
                    try: doc.Create.NewElbowFitting(c1, c2)
                    except: 
                        doc.Delete(new_pipe.Id)
                        print("Lỗi tạo Elbow.")
                        t.RollBack(); continue
                    
                    doc.Regenerate()

                    # Tìm đầu hở của ống mới để gắn Cap
                    conns_new = new_pipe.ConnectorManager.Connectors
                    c_pipe_end = None
                    for c in conns_new:
                        if not c.IsConnected: c_pipe_end = c; break
                    
                    if c_pipe_end:
                        if not place_cap_v14_robot(doc, c_pipe_end, cap_symbol, pipe_dia):
                            print("Lỗi gắn Cap.")
                else:
                    print("Lỗi tạo ống 45.")

                t.Commit()
            
            except Exception as inner_e:
                print("Lỗi: " + str(inner_e))
                t.RollBack()

        except Autodesk.Revit.Exceptions.OperationCanceledException:
            break
        except Exception as e:
            forms.alert("System Error: " + str(e))
            break

if __name__ == "__main__":
    main()