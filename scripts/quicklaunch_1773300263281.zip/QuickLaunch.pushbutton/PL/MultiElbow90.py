# -*- coding: utf-8 -*-

import math
import Autodesk.Revit.DB as DB
import Autodesk.Revit.UI as UI
import Autodesk.Revit.Exceptions as Extensions
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

# --- 1. CLASSES ---
class MEPElementFilter(ISelectionFilter):
    def AllowElement(self, element):
        cat = element.Category
        if cat and ("Duct" in cat.Name or "Pipe" in cat.Name or "Cable Tray" in cat.Name):
            if isinstance(element, DB.MEPCurve): return True
        return False
    def AllowReference(self, reference, position): return False

class WarningSwallower(DB.IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        failures = failuresAccessor.GetFailureMessages()
        if failures.Count == 0: return DB.FailureProcessingResult.Continue
        for f in failures:
            if f.GetSeverity() == DB.FailureSeverity.Warning: failuresAccessor.DeleteWarning(f)
            else: failuresAccessor.ResolveFailure(f); return DB.FailureProcessingResult.ProceedWithCommit
        return DB.FailureProcessingResult.Continue

# --- 2. UTILS ---
def get_connector_closest(element, point):
    closest = None
    min_dist = float('inf')
    try:
        for c in element.ConnectorManager.Connectors:
            d = c.Origin.DistanceTo(point)
            if d < min_dist:
                min_dist = d
                closest = c
    except: pass
    return closest

def copy_parameters(src, dest):
    """Copy Size & System chuẩn"""
    try:
        # 1. System Type
        if isinstance(src, DB.Mechanical.Duct):
            sys_param = src.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM)
            if sys_param and sys_param.HasValue: 
                dest.get_Parameter(DB.BuiltInParameter.RBS_DUCT_SYSTEM_TYPE_PARAM).Set(sys_param.AsElementId())
        elif isinstance(src, DB.Plumbing.Pipe):
            sys_param = src.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM)
            if sys_param and sys_param.HasValue: 
                dest.get_Parameter(DB.BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).Set(sys_param.AsElementId())
        
        # 2. Size (Copy y chang Width -> Width, Height -> Height)
        # Việc xoay đúng hay sai sẽ do hàm rotate quyết định
        if isinstance(src, DB.Mechanical.Duct):
            w = src.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).AsDouble()
            h = src.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).AsDouble()
            dest.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).Set(w)
            dest.get_Parameter(DB.BuiltInParameter.RBS_CURVE_HEIGHT_PARAM).Set(h)
        elif isinstance(src, DB.Electrical.CableTray):
            w = src.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).AsDouble()
            h = src.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).AsDouble()
            dest.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).Set(w)
            dest.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_HEIGHT_PARAM).Set(h)
        elif isinstance(src, DB.Plumbing.Pipe):
             d = src.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
             dest.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(d)
    except: pass

def rotate_element_correctly(new_vertical_elem, ref_connector):
    """
    [FIX QUAN TRỌNG] Xoay ống đứng để khớp bề mặt với ống ngang.
    Thay vì tính góc theo hướng đi, ta tính góc theo trục X (Width) của Connector.
    """
    if isinstance(new_vertical_elem, DB.Plumbing.Pipe): return # Ống tròn ko cần xoay
    
    try:
        # 1. Lấy trục X (Hướng Width) của connector ống gốc
        # CoordinateSystem của Connector cho biết hướng chính xác của mặt cắt
        basis_x = ref_connector.CoordinateSystem.BasisX 
        
        # 2. Tính góc xoay cần thiết so với trục X toàn cầu (1,0,0)
        # Ống đứng mới tạo ra mặc định BasisX trùng với trục X toàn cầu
        target_angle = math.atan2(basis_x.Y, basis_x.X)
        
        # 3. Xoay ống đứng
        curve_ver = new_vertical_elem.Location.Curve
        p1 = curve_ver.GetEndPoint(0)
        p2 = curve_ver.GetEndPoint(1)
        axis = DB.Line.CreateBound(p1, p2) # Trục xoay là tâm ống đứng
        
        DB.ElementTransformUtils.RotateElement(doc, new_vertical_elem.Id, axis, target_angle)
    except: pass

# --- 3. CORE LOGIC ---
def get_direction_90(element, connector, click_point):
    vec_click = click_point - connector.Origin
    vec_flow = connector.CoordinateSystem.BasisZ
    
    directions = {
        "X+": DB.XYZ(1,0,0), "X-": DB.XYZ(-1,0,0),
        "Y+": DB.XYZ(0,1,0), "Y-": DB.XYZ(0,-1,0),
        "Z+": DB.XYZ(0,0,1), "Z-": DB.XYZ(0,0,-1)
    }
    
    best_dir = None
    max_dot = -1.0 
    
    for name, d in directions.items():
        if abs(vec_flow.DotProduct(d)) > 0.95: continue 
        val = vec_click.Normalize().DotProduct(d)
        if val > max_dot:
            max_dot = val
            best_dir = d
            
    if best_dir is None: best_dir = DB.XYZ(0,0,1)
    return best_dir

def process_elbow_smart(element, click_point):
    con_base = get_connector_closest(element, click_point)
    if not con_base: return

    p1 = con_base.Origin
    
    # 1. Xác định hướng
    direction = get_direction_90(element, con_base, click_point)
    
    # 2. Tính chiều dài
    size_ref = 1.0
    try:
        if isinstance(element, DB.Mechanical.Duct):
            w = element.get_Parameter(DB.BuiltInParameter.RBS_CURVE_WIDTH_PARAM).AsDouble()
            size_ref = w * 2.0
        elif isinstance(element, DB.Electrical.CableTray):
             w = element.get_Parameter(DB.BuiltInParameter.RBS_CABLETRAY_WIDTH_PARAM).AsDouble()
             size_ref = w * 2.5
        elif isinstance(element, DB.Plumbing.Pipe):
            size_ref = element.get_Parameter(DB.BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble() * 3.0
    except: pass
    if size_ref < 1.0: size_ref = 1.0

    p2 = p1 + (direction * size_ref)
    level_id = element.ReferenceLevel.Id

    # 3. Tạo ống mới
    new_elem = None
    if isinstance(element, DB.Mechanical.Duct):
        new_elem = DB.Mechanical.Duct.Create(doc, element.MEPSystem.GetTypeId(), element.GetTypeId(), level_id, p1, p2)
    elif isinstance(element, DB.Plumbing.Pipe):
        new_elem = DB.Plumbing.Pipe.Create(doc, element.MEPSystem.GetTypeId(), element.GetTypeId(), level_id, p1, p2)
    elif isinstance(element, DB.Electrical.CableTray):
        new_elem = DB.Electrical.CableTray.Create(doc, element.GetTypeId(), p1, p2, level_id)
    
    if new_elem:
        # 4. Copy Size
        copy_parameters(element, new_elem)
        doc.Regenerate()
        
        # 5. [FIX] Xoay ống cho khớp mặt cắt TRƯỚC KHI nối
        # Nếu ống mới là ống đứng (Z), cần xoay theo connector của ống ngang
        if abs(direction.Z) > 0.9: 
            rotate_element_correctly(new_elem, con_base)
            doc.Regenerate() # Cập nhật lại hình học sau khi xoay

        # 6. Nối Fitting
        con_new = get_connector_closest(new_elem, p1)
        if con_base and con_new:
            try: 
                doc.Create.NewElbowFitting(con_base, con_new)
            except: pass

# --- 4. RUN ---
def run_script():
    while True:
        try:
            ref = uidoc.Selection.PickObject(ObjectType.Element, MEPElementFilter(), "Click hướng nào -> Ra ống hướng đó (ESC thoát)")
            el = doc.GetElement(ref)
            pick_point = ref.GlobalPoint 

            t = DB.Transaction(doc, "No Transition Elbow")
            opt = t.GetFailureHandlingOptions()
            opt.SetFailuresPreprocessor(WarningSwallower())
            opt.SetClearAfterRollback(True)
            t.SetFailureHandlingOptions(opt)
            
            t.Start()
            process_elbow_smart(el, pick_point)
            t.Commit()
            
        except Extensions.OperationCanceledException:
            break
        except Exception as e:
            # print(e)
            break

if __name__ == "__main__": run_script()