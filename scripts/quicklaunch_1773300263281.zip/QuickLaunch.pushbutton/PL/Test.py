# -*- coding: utf-8 -*-
from pyrevit import forms; forms.alert("Chạy ngon rồi!")