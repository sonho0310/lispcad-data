# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType
from pyrevit import revit, DB, UI
import math

# --- CẤU HÌNH ---
OFFSET_FACTOR = 1.5
MIN_PIPE_LEN = 0.05 

doc = revit.doc
uidoc = revit.uidoc

# ==========================================================
# 1. BỘ XỬ LÝ LỖI
# ==========================================================
class WarningSwallower(IFailuresPreprocessor):
    def PreprocessFailures(self, failuresAccessor):
        fail_list = failuresAccessor.GetFailureMessages()
        for failure in fail_list:
            if failure.GetSeverity() == FailureSeverity.Warning:
                failuresAccessor.DeleteWarning(failure)
            elif failure.GetSeverity() == FailureSeverity.Error:
                if failuresAccessor.IsFailureResolutionPermitted(failure):
                    failuresAccessor.ResolveFailure(failure)
                    return FailureProcessingResult.ProceedWithCommit
        return FailureProcessingResult.Continue

# ==========================================================
# 2. CÁC HÀM HỖ TRỢ
# ==========================================================
def get_connectors(element):
    if hasattr(element, "MEPModel") and element.MEPModel:
        return element.MEPModel.ConnectorManager.Connectors
    elif hasattr(element, "ConnectorManager"):
        return element.ConnectorManager.Connectors
    return []

def get_connector_closest_to(element, point):
    connectors = get_connectors(element)
    min_dist = float('inf')
    target_conn = None
    if connectors:
        for conn in connectors:
            dist = conn.Origin.DistanceTo(point)
            if dist < min_dist:
                min_dist = dist
                target_conn = conn
    return target_conn

def get_connected_pipe_info(fitting_connector):
    for ref in fitting_connector.AllRefs:
        if ref.Owner.Category.Id.IntegerValue == int(BuiltInCategory.OST_PipeCurves) and ref.ConnectorType == ConnectorType.End:
            return ref.Owner, ref
    return None, None

def is_elbow_90(element):
    try:
        if element.Category.Id.IntegerValue != int(BuiltInCategory.OST_PipeFitting): return False
        if element.MEPModel.PartType != PartType.Elbow: return False
        connectors = [c for c in get_connectors(element)]
        if len(connectors) != 2: return False
        angle = connectors[0].CoordinateSystem.BasisZ.AngleTo(connectors[1].CoordinateSystem.BasisZ)
        if abs(angle - math.pi/2) < 0.1: return True
        return False
    except: return False

# ==========================================================
# 3. LOGIC "TÁI SINH" (REBUILD)
# ==========================================================

def get_neighbor_info(pipe, near_pt):
    """
    Lấy thông tin 'Hàng xóm' ở đầu xa của ống.
    Trả về: (Toạ độ Connector Hàng Xóm, Connector Object Hàng Xóm)
    """
    connectors = get_connectors(pipe)
    far_conn = None
    max_dist = -1
    
    # Tìm đầu xa
    for c in connectors:
        if c.Origin.DistanceTo(near_pt) > max_dist:
            max_dist = c.Origin.DistanceTo(near_pt)
            far_conn = c
    
    # Mặc định lấy toạ độ hình học của đầu xa
    far_pt_geo = far_conn.Origin
    neighbor_connector = None

    if far_conn and far_conn.IsConnected:
        for ref in far_conn.AllRefs:
            if ref.Owner.Id != pipe.Id and ref.ConnectorType != ConnectorType.Logical:
                # Tìm thấy hàng xóm!
                neighbor_elem = ref.Owner
                # Cố gắng lấy Connector object thật của hàng xóm
                try:
                    nb_conns = get_connectors(neighbor_elem)
                    for nbc in nb_conns:
                        # So sánh toạ độ để tìm đúng connector khớp nhau
                        if nbc.Origin.DistanceTo(far_pt_geo) < 0.01: # Sai số 1mm
                            return nbc.Origin, nbc
                except: pass
                
                # Nếu không lấy được object thật, trả về Ref (dự phòng)
                return far_pt_geo, ref
                
    return far_pt_geo, None

def replace_pipe_segment(old_pipe, start_pt, end_pt, neighbor_connect_to):
    """
    Xóa ống cũ, tạo ống mới và nối ngay lập tức.
    """
    # 1. Hút dữ liệu từ ống cũ trước khi xóa
    sys_id = old_pipe.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
    type_id = old_pipe.PipeType.Id
    lev_id = old_pipe.LevelId
    dia = old_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
    
    # 2. Xóa ống cũ
    old_id = old_pipe.Id
    doc.Delete(old_id)
    doc.Regenerate() # Bắt buộc
    
    # 3. Tạo ống mới
    new_pipe = DB.Plumbing.Pipe.Create(doc, sys_id, type_id, lev_id, start_pt, end_pt)
    new_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia)
    
    # 4. Nối lại với hàng xóm (QUAN TRỌNG NHẤT)
    if neighbor_connect_to:
        # Tìm đầu ống vừa tạo trùng với vị trí hàng xóm
        conn_to_connect = None
        min_d = float('inf')
        
        # Xác định vị trí của connector hàng xóm
        if isinstance(neighbor_connect_to, Connector):
            nb_pt = neighbor_connect_to.Origin
        else: # Trường hợp là ConnectorRef
            nb_pt = start_pt # Giả định start_pt là điểm nối
            
        # Lấy connector của ống mới gần hàng xóm nhất
        for c in get_connectors(new_pipe):
            if c.Origin.DistanceTo(nb_pt) < 0.1:
                conn_to_connect = c
                break
        
        if conn_to_connect:
            try:
                # Nếu là Connector thật
                if isinstance(neighbor_connect_to, Connector):
                    conn_to_connect.ConnectTo(neighbor_connect_to)
                # Nếu là Ref (ít xảy ra hơn với logic mới)
                else: 
                     # Ref không connect trực tiếp được dễ dàng, 
                     # nhưng logic get_neighbor_info ưu tiên trả về Connector thật rồi
                     pass
            except Exception as e:
                print("Không nối được: " + str(e))
                
    return new_pipe

def process_single_elbow(elbow):
    try:
        if not elbow.IsValidObject: return False
        
        elbow_loc = elbow.Location.Point
        connectors = [c for c in get_connectors(elbow)]
        
        # Lấy 2 ống cũ
        pipe1, conn_ref1 = get_connected_pipe_info(connectors[0])
        pipe2, conn_ref2 = get_connected_pipe_info(connectors[1])

        if not pipe1 or not pipe2: return False

        # --- BƯỚC 1: LẤY DỮ LIỆU ĐỂ TÁI TẠO ---
        # Tìm hàng xóm để lát nối lại
        p1_anchor, neighbor_1 = get_neighbor_info(pipe1, elbow_loc)
        p2_anchor, neighbor_2 = get_neighbor_info(pipe2, elbow_loc)
        
        # Đường kính để tính offset
        dia = pipe1.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).AsDouble()
        offset_dist = dia * OFFSET_FACTOR
        
        # --- BƯỚC 2: TÍNH ĐIỂM CẮT MỚI ---
        # Vector từ Anchor -> Elbow
        vec1 = (elbow_loc - p1_anchor).Normalize()
        vec2 = (elbow_loc - p2_anchor).Normalize()
        
        dist_1 = p1_anchor.DistanceTo(elbow_loc)
        dist_2 = p2_anchor.DistanceTo(elbow_loc)
        
        if dist_1 < offset_dist + MIN_PIPE_LEN or dist_2 < offset_dist + MIN_PIPE_LEN:
             print("ID {}: Khoảng cách không đủ.".format(elbow.Id))
             return False

        new_p1 = p1_anchor + vec1 * (dist_1 - offset_dist)
        new_p2 = p2_anchor + vec2 * (dist_2 - offset_dist)

        # --- BƯỚC 3: XÓA SỔ FITTING CŨ ---
        # Ngắt kết nối trước khi xóa
        for c in connectors:
            if c.IsConnected:
                for ref in c.AllRefs:
                    if ref.ConnectorType != ConnectorType.Logical:
                        c.DisconnectFrom(ref)
        doc.Delete(elbow.Id)
        doc.Regenerate()

        # --- BƯỚC 4: THAY THẾ ỐNG CŨ BẰNG ỐNG MỚI (REBUILD) ---
        # Thay vì resize, ta xóa ống cũ và tạo ống mới nối vào Anchor
        new_pipe_1 = replace_pipe_segment(pipe1, p1_anchor, new_p1, neighbor_1)
        new_pipe_2 = replace_pipe_segment(pipe2, p2_anchor, new_p2, neighbor_2)
        
        doc.Regenerate()

        # --- BƯỚC 5: TẠO 2x45 ---
        # Lấy thông tin từ ống mới vừa tạo để tạo ống giữa
        sys_id = new_pipe_1.get_Parameter(BuiltInParameter.RBS_PIPING_SYSTEM_TYPE_PARAM).AsElementId()
        type_id = new_pipe_1.PipeType.Id
        lev_id = new_pipe_1.LevelId
        
        middle_pipe = DB.Plumbing.Pipe.Create(doc, sys_id, type_id, lev_id, new_p1, new_p2)
        middle_pipe.get_Parameter(BuiltInParameter.RBS_PIPE_DIAMETER_PARAM).Set(dia)
        
        # Nối Elbow 1
        c1 = get_connector_closest_to(new_pipe_1, new_p1)
        cm1 = get_connector_closest_to(middle_pipe, new_p1)
        doc.Create.NewElbowFitting(c1, cm1)
        doc.Regenerate()

        # Nối Elbow 2
        c2 = get_connector_closest_to(new_pipe_2, new_p2)
        cm2 = get_connector_closest_to(middle_pipe, new_p2)
        doc.Create.NewElbowFitting(c2, cm2)

        return True

    except Exception as e:
        print("Error ID {}: {}".format(elbow.Id, str(e)))
        return False

# ==========================================================
# MAIN RUN
# ==========================================================
try:
    elements_to_process = []
    selection_ids = uidoc.Selection.GetElementIds()
    
    if selection_ids and selection_ids.Count > 0:
        for eid in selection_ids:
            elements_to_process.append(doc.GetElement(eid))
    else:
        try:
            picked_refs = uidoc.Selection.PickObjects(ObjectType.Element, "Quét chọn Co 90 (Finish để chạy)")
            for ref in picked_refs:
                elements_to_process.append(doc.GetElement(ref))
        except: pass

    if elements_to_process:
        tg = TransactionGroup(doc, "Rebuild 2x45 System")
        tg.Start()
        
        t = Transaction(doc, "Process")
        
        fail_options = t.GetFailureHandlingOptions()
        fail_processor = WarningSwallower()
        fail_options.SetFailuresPreprocessor(fail_processor)
        fail_options.SetClearAfterRollback(True)
        t.SetFailureHandlingOptions(fail_options)
        
        t.Start()
        
        count = 0
        for el in elements_to_process:
            if is_elbow_90(el):
                if process_single_elbow(el):
                    count += 1
        
        t.Commit()
        tg.Assimilate()
        
except Exception as e:
    UI.TaskDialog.Show("Error", str(e))