# -*- coding: utf-8 -*-
from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.DB.Mechanical import Duct
from Autodesk.Revit.Exceptions import OperationCanceledException
from pyrevit import revit, forms
import math

doc = __revit__.ActiveUIDocument.Document
uidoc = __revit__.ActiveUIDocument

class DuctFilter(ISelectionFilter):
    def AllowElement(self, element):
        return isinstance(element, Duct)
    def AllowReference(self, reference, point):
        return False

def get_connector_closest_to_curve(element, target_curve):
    closest_connector = None
    min_dist = float('inf')
    for conn in element.ConnectorManager.Connectors:
        dist = target_curve.Project(conn.Origin).Distance
        if dist < min_dist:
            min_dist = dist
            closest_connector = conn
    return closest_connector

def main():
    duct_filter = DuctFilter()
    
    while True:
        try:
            try:
                ref_main = uidoc.Selection.PickObject(ObjectType.Element, duct_filter, "B1: Chọn hướng trên ống chính (Nhấn ESC để dừng)")
                main_duct = doc.GetElement(ref_main)
                click_point = ref_main.GlobalPoint 

                ref_branch = uidoc.Selection.PickObject(ObjectType.Element, duct_filter, "B2: Chọn ống nhánh")
                branch_duct = doc.GetElement(ref_branch)
            except OperationCanceledException:
                break 

            t = Transaction(doc, "AutoTap")
            t.Start()
            
            try:
                main_curve = main_duct.Location.Curve
                # Vector chuẩn của ống chính
                main_p0 = main_curve.GetEndPoint(0)
                main_p1 = main_curve.GetEndPoint(1)
                main_vec = (main_p1 - main_p0).Normalize()
                
                closest_conn = get_connector_closest_to_curve(branch_duct, main_curve)
                
                if closest_conn:
                    # 1. Tạo Tap
                    new_fitting = doc.Create.NewTakeoffFitting(closest_conn, main_duct)
                    doc.Regenerate()
                    
                    if new_fitting:
                        fit_origin = new_fitting.Location.Point
                        
                        # --- LOGIC XỬ LÝ TRÁI/PHẢI (CRITICAL FIX) ---
                        # Xác định phía của ống nhánh so với ống chính
                        branch_vec = (closest_conn.Origin - fit_origin).Normalize()
                        side_check = main_vec.CrossProduct(branch_vec).Z
                        
                        # Hướng người dùng muốn (Click)
                        vec_to_click = (click_point - fit_origin).Normalize()
                        dot_click = main_vec.DotProduct(vec_to_click)
                        
                        # Hướng hiện tại của Fitting
                        fit_facing = new_fitting.HandOrientation
                        dot_fit = main_vec.DotProduct(fit_facing)
                        
                        # Quyết định xoay: 
                        # Nếu cùng 1 phía thì logic bình thường, nếu khác phía thì phải đảo logic
                        should_rotate = (dot_click * dot_fit < 0)
                        
                        # Nếu side_check âm (phía bên kia ống), Revit thường tự đảo HandOrientation
                        # nên ta cần bù trừ lại để hướng click luôn thắng.
                        if side_check < 0:
                            should_rotate = not should_rotate

                        if should_rotate:
                            axis_p1 = fit_origin
                            axis_p2 = axis_p1 + closest_conn.CoordinateSystem.BasisZ 
                            rotation_axis = Line.CreateBound(axis_p1, axis_p2)
                            ElementTransformUtils.RotateElement(doc, new_fitting.Id, rotation_axis, math.pi)
                    
                    t.Commit()
            except Exception as e_inner:
                t.RollBack()
                print("Lỗi: {}".format(e_inner))

        except Exception as e_outer:
            break

if __name__ == "__main__":
    main()