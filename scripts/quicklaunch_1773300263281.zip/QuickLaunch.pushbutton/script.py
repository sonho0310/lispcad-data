# -*- coding: utf-8 -*-
__title__ = 'Quick\nLaunch'
__doc__ = 'Gọi nhanh các file Python như gõ lệnh Lisp CAD'

import clr
import os
import codecs
import traceback
from pyrevit import forms

clr.AddReference('PresentationFramework')
clr.AddReference('PresentationCore')

from System.Windows import Visibility
from System.Windows.Markup import XamlReader
from System.Windows.Input import Key

def scan_commands():
    cmd_db = {}
    # Lấy thư mục gốc chứa chính file script.py này (thư mục QuickLaunch.pushbutton)
    current_dir = os.path.dirname(__file__)

    # Quét TẤT CẢ các thư mục con bên trong
    for root, dirs, files in os.walk(current_dir):
        # Bỏ qua các thư mục ẩn hoặc hệ thống
        dirs[:] = [d for d in dirs if not d.startswith('.') and not d.startswith('__')]
        
        for file in files:
            # Chỉ lấy file .py và BẮT BUỘC bỏ qua file script.py của chính cái UI này
            if file.lower().endswith('.py') and file.lower() != 'script.py':
                raw_cmd_name = os.path.splitext(file)[0].upper()
                file_path = os.path.join(root, file)
                
                # Lấy tên thư mục cha chứa file này
                parent_folder = os.path.basename(root).upper()
                
                desc = ""
                try:
                    with codecs.open(file_path, 'r', 'utf-8') as f:
                        for i in range(10): 
                            line = f.readline()
                            if '__doc__' in line:
                                desc = line.split('=')[-1].strip(" \"'\n\r")
                                break
                except: pass
                
                # XỬ LÝ TRÙNG TÊN LỆNH: Nếu lệnh đã tồn tại, gắn thêm tên thư mục vào đuôi
                if raw_cmd_name in cmd_db:
                    cmd_name = "{} [{}]".format(raw_cmd_name, parent_folder)
                else:
                    cmd_name = raw_cmd_name
                
                cmd_db[cmd_name] = {"path": file_path, "desc": desc}
                
    return cmd_db

# ==========================================
# GIAO DIỆN XAML (PHIÊN BẢN FLAT UI TỐI GIẢN)
# ==========================================
xaml_str = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Width="400" SizeToContent="Height" WindowStartupLocation="CenterScreen" 
        WindowStyle="None" AllowsTransparency="True" Background="Transparent"
        Topmost="True" ShowInTaskbar="False">
    
    <Window.Resources>
        <Style TargetType="Button" x:Key="FlatCloseBtn">
            <Setter Property="Background" Value="Transparent"/>
            <Setter Property="Foreground" Value="#999"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="4">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center" Margin="8,4"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
            <Style.Triggers>
                <Trigger Property="IsMouseOver" Value="True">
                    <Setter Property="Foreground" Value="#D32F2F"/>
                    <Setter Property="Background" Value="#FCE8E6"/>
                </Trigger>
            </Style.Triggers>
        </Style>
    </Window.Resources>

    <StackPanel Margin="8">
        <Border Background="White" CornerRadius="6" BorderBrush="#E0E0E0" BorderThickness="1" Height="45">
            <Border.Effect>
                <DropShadowEffect BlurRadius="10" ShadowDepth="2" Color="Black" Opacity="0.1"/>
            </Border.Effect>
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/> 
                </Grid.ColumnDefinitions>
                
                <TextBox Name="CmdInput" Grid.Column="0" FontSize="16" FontWeight="SemiBold" 
                         Background="Transparent" BorderThickness="0" Foreground="#2A2A2A" 
                         VerticalAlignment="Stretch" VerticalContentAlignment="Center" Cursor="IBeam"
                         Margin="15,0,5,0"
                         ToolTip="Gõ lệnh, từ khóa, hoặc gõ '/' để xem toàn bộ lệnh"/>
                         
                <Button Name="BtnClose" Grid.Column="1" Content="CLOSE" FontSize="11" FontWeight="Bold"
                        Style="{StaticResource FlatCloseBtn}" Margin="0,0,6,0" Cursor="Hand"/>
            </Grid>
        </Border>
        
        <Border Name="SuggestBorder" Background="White" CornerRadius="6" Margin="0,6,0,0" 
                Visibility="Collapsed" MaxHeight="250" BorderBrush="#E0E0E0" BorderThickness="1">
            <Border.Effect>
                <DropShadowEffect BlurRadius="8" ShadowDepth="2" Color="Black" Opacity="0.08"/>
            </Border.Effect>
            
            <ListBox Name="SuggestList" Background="Transparent" BorderThickness="0" FontSize="13" 
                     Padding="4" Foreground="#444" SelectionMode="Single" ScrollViewer.VerticalScrollBarVisibility="Auto">
                <ListBox.ItemContainerStyle>
                    <Style TargetType="ListBoxItem">
                        <Setter Property="Padding" Value="10,8"/>
                        <Setter Property="Cursor" Value="Hand"/>
                        <Setter Property="Template">
                            <Setter.Value>
                                <ControlTemplate TargetType="ListBoxItem">
                                    <Border Name="Border" Padding="{TemplateBinding Padding}" CornerRadius="4">
                                        <ContentPresenter />
                                    </Border>
                                    <ControlTemplate.Triggers>
                                        <Trigger Property="IsMouseOver" Value="True">
                                            <Setter TargetName="Border" Property="Background" Value="#F5F5F5"/>
                                        </Trigger>
                                        <Trigger Property="IsSelected" Value="True">
                                            <Setter TargetName="Border" Property="Background" Value="#E8F0FE"/>
                                            <Setter Property="Foreground" Value="#1A73E8"/>
                                            <Setter Property="FontWeight" Value="SemiBold"/>
                                        </Trigger>
                                    </ControlTemplate.Triggers>
                                </ControlTemplate>
                            </Setter.Value>
                        </Setter>
                    </Style>
                </ListBox.ItemContainerStyle>
            </ListBox>
        </Border>
    </StackPanel>
</Window>
"""

class QuickLaunchApp(object):
    def __init__(self, cmd_db):
        self.cmd_db = cmd_db
        self.window = XamlReader.Parse(xaml_str)
        
        self.cmd_input = self.window.FindName("CmdInput")
        self.btn_close = self.window.FindName("BtnClose")
        self.suggest_border = self.window.FindName("SuggestBorder")
        self.suggest_list = self.window.FindName("SuggestList")
        
        self.file_to_run = None
        self.is_closed = False
        
        if not self.cmd_db:
            self.cmd_input.Text = "⚠️ Chưa có file code nào trong các thư mục con..."
            self.cmd_input.IsReadOnly = True

        self.window.Loaded += self.on_loaded
        self.window.Deactivated += self.on_deactivated 
        self.btn_close.Click += self.on_close_click
        
        self.cmd_input.TextChanged += self.on_text_changed
        self.window.PreviewKeyDown += self.on_preview_key_down
        self.suggest_list.MouseDoubleClick += self.on_list_double_click
        
        self.window.ShowDialog()

    def safe_close(self):
        if not self.is_closed:
            self.is_closed = True
            self.window.DialogResult = True

    def on_loaded(self, sender, args):
        if self.cmd_db:
            self.cmd_input.Focus()

    def on_deactivated(self, sender, args):
        self.safe_close() 

    def on_close_click(self, sender, args):
        self.safe_close()

    def on_text_changed(self, sender, args):
        txt = self.cmd_input.Text.strip().lower()
        self.suggest_list.Items.Clear()
        
        if txt == "/" or txt == "": 
            if txt == "/":
                matches = sorted(list(self.cmd_db.keys()))
            else:
                self.suggest_border.Visibility = Visibility.Collapsed
                return
        else:
            matches = []
            for cmd, info in self.cmd_db.items():
                if txt in cmd.lower() or txt in info['desc'].lower():
                    matches.append(cmd)
            matches.sort()
            
        if matches:
            for m in matches:
                desc = self.cmd_db[m]['desc']
                display_text = "{}  -  {}".format(m, desc) if desc else m
                self.suggest_list.Items.Add(display_text)
            self.suggest_border.Visibility = Visibility.Visible
            self.suggest_list.SelectedIndex = -1 
        else:
            self.suggest_border.Visibility = Visibility.Collapsed

    def commit_command(self, item_text):
        cmd_name = item_text.split("  -  ")[0].strip()
        if cmd_name in self.cmd_db:
            self.file_to_run = self.cmd_db[cmd_name]['path']
            self.safe_close()
        else:
            self.cmd_input.Text = ""

    def on_preview_key_down(self, sender, args):
        if args.Key == Key.Escape:
            self.safe_close()
            args.Handled = True
            
        elif args.Key == Key.Down:
            if self.suggest_border.Visibility == Visibility.Visible:
                self.suggest_list.Focus()
                if self.suggest_list.SelectedIndex == -1 and self.suggest_list.Items.Count > 0:
                    self.suggest_list.SelectedIndex = 0
                args.Handled = True
                
        elif args.Key == Key.Enter:
            if self.suggest_border.Visibility == Visibility.Visible and self.suggest_list.SelectedItem:
                cmd_text = str(self.suggest_list.SelectedItem)
                self.commit_command(cmd_text)
            else:
                raw_cmd = self.cmd_input.Text.strip().upper()
                if raw_cmd in self.cmd_db:
                    self.file_to_run = self.cmd_db[raw_cmd]['path']
                    self.safe_close()
                else:
                    self.cmd_input.Text = ""
            args.Handled = True

    def on_list_double_click(self, sender, args):
        if self.suggest_list.SelectedItem:
            cmd_text = str(self.suggest_list.SelectedItem)
            self.commit_command(cmd_text)

def main():
    cmd_db = scan_commands()
    app = QuickLaunchApp(cmd_db)
    
    if app.file_to_run:
        try:
            with codecs.open(app.file_to_run, 'r', 'utf-8') as f:
                code_content = f.read()
            clean_code = code_content.replace('\r', '')
            
            script_globals = globals().copy()
            script_globals['__file__'] = app.file_to_run
            script_globals['__name__'] = '__main__'
            
            exec(clean_code, script_globals)
        except Exception as e:
            forms.alert("Lỗi khi chạy file [{}]:\n\n{}".format(os.path.basename(app.file_to_run), traceback.format_exc()), title="Bug Lệnh")

if __name__ == '__main__':
    main()