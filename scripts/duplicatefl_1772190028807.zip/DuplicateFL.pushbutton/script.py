# -*- coding: utf-8 -*-
"""
Smart Clone V13: Individual Template Selection per View (Fixed Scope Box)
"""
__title__ = "Smart Clone V13"

# --- IMPORTS ---
from Autodesk.Revit.DB import (
    Transaction, ViewPlan, FilteredElementCollector, View,
    ElementTransformUtils, ElementId, DatumEnds, Grid, IndependentTag, BuiltInParameter
)
from pyrevit import revit, script, forms
import clr

# --- WPF / UI IMPORTS ---
clr.AddReference("PresentationFramework")
from System.Windows import Markup, Window
from System.Collections.Generic import List
from System.Collections.ObjectModel import ObservableCollection

# ==============================================================================
# HÀM PHỤ TRỢ: COPY AN TOÀN
# ==============================================================================
def smart_copy_elements(doc, src_view, dest_view, element_ids_list):
    if not element_ids_list or element_ids_list.Count == 0:
        return True
    try:
        ElementTransformUtils.CopyElements(src_view, element_ids_list, dest_view, None, None)
        return True
    except:
        safe_ids = List[ElementId]()
        risky_ids = List[ElementId]()
        for eid in element_ids_list:
            el = doc.GetElement(eid)
            if isinstance(el, IndependentTag):
                risky_ids.Add(eid)
            else:
                safe_ids.Add(eid)
        if safe_ids.Count > 0:
            try: ElementTransformUtils.CopyElements(src_view, safe_ids, dest_view, None, None)
            except: pass
        for tag_id in risky_ids:
            try:
                single_list = List[ElementId]([tag_id])
                ElementTransformUtils.CopyElements(src_view, single_list, dest_view, None, None)
            except: pass
        return False

# ==============================================================================
# 1. GIAO DIỆN NHẬP LIỆU (UI MỚI: LISTVIEW VỚI COMBOBOX)
# ==============================================================================
INPUT_XAML = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Smart Clone V13 (Multi-Template)" Width="450" SizeToContent="Height"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize" Background="#F8F9FA">
    
    <Window.Resources>
        <Style TargetType="GroupBox">
            <Setter Property="Margin" Value="0,0,0,10"/>
            <Setter Property="Padding" Value="5"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
        </Style>
    </Window.Resources>

    <Grid Margin="15">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/> <RowDefinition Height="150"/>  <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="150"/>  <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> </Grid.RowDefinitions>

        <TextBlock Text="1. CẤU HÌNH VIEW NGUỒN &amp; TEMPLATE:" Grid.Row="0" FontWeight="Bold" Foreground="#007ACC" Margin="0,0,0,5"/>
        
        <Border Grid.Row="1" BorderBrush="#DDD" BorderThickness="1" Background="White" CornerRadius="3" Margin="0,0,0,15">
            <ScrollViewer VerticalScrollBarVisibility="Auto">
                <ItemsControl x:Name="source_list" Margin="5">
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <Grid Margin="0,2,0,2">
                                <Grid.ColumnDefinitions>
                                    <ColumnDefinition Width="*"/>
                                    <ColumnDefinition Width="160"/>
                                </Grid.ColumnDefinitions>
                                
                                <TextBlock Text="{Binding ViewName}" VerticalAlignment="Center" FontWeight="Normal" ToolTip="{Binding ViewName}"/>
                                
                                <ComboBox Grid.Column="1" 
                                          ItemsSource="{Binding TemplateOptions}" 
                                          SelectedItem="{Binding SelectedTemplate}"
                                          DisplayMemberPath="Name"
                                          Height="22" FontSize="11"/>
                            </Grid>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
            </ScrollViewer>
        </Border>

        <Grid Grid.Row="2" Margin="0,0,0,10">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="80"/>
                <ColumnDefinition Width="*"/>
            </Grid.ColumnDefinitions>
            <TextBlock Text="Mode:" VerticalAlignment="Center"/>
            <ComboBox x:Name="cb_mode" Grid.Column="1" SelectedIndex="1">
                <ComboBoxItem Content="Duplicate (Model Only)"/>
                <ComboBoxItem Content="Duplicate with Detailing"/>
            </ComboBox>
        </Grid>

        <GroupBox Header="Naming: [Prefix] + [Original Name] + [Suffix]" Grid.Row="3">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <Grid.RowDefinitions>
                    <RowDefinition Height="Auto"/>
                    <RowDefinition Height="Auto"/>
                </Grid.RowDefinitions>

                <TextBlock Text="Prefix:" Grid.Row="0" Grid.Column="0" VerticalAlignment="Center" Margin="0,0,5,5"/>
                <TextBox x:Name="txt_prefix" Grid.Row="0" Grid.Column="1" Margin="0,0,0,5"/>

                <TextBlock Text="Suffix:" Grid.Row="1" Grid.Column="0" VerticalAlignment="Center" Margin="0,0,5,5"/>
                <TextBox x:Name="txt_suffix" Grid.Row="1" Grid.Column="1" Margin="0,0,0,5"/>
            </Grid>
        </GroupBox>

        <DockPanel Grid.Row="4" LastChildFill="True" Margin="0,5,0,0">
            <CheckBox x:Name="chk_all" Content="Select Target Levels" DockPanel.Dock="Top" Margin="2,0,0,5" FontWeight="Bold" Foreground="#007ACC"/>
        </DockPanel>

        <Border Grid.Row="5" BorderBrush="#DDD" BorderThickness="1" Background="White" CornerRadius="3">
            <ScrollViewer VerticalScrollBarVisibility="Auto">
                <ItemsControl x:Name="levels_list" Margin="5">
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <CheckBox Content="{Binding Name}" IsChecked="{Binding IsChecked}" Margin="0,2,0,2"/>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
            </ScrollViewer>
        </Border>

        <TextBlock Text="⚠️ Lưu ý: Không thể duplicate mặt bằng có Keynote vui lòng check trước khi duplicate." 
                   Grid.Row="6" Foreground="#DC3545" FontStyle="Italic" FontSize="11" 
                   TextWrapping="Wrap" Margin="0,10,0,5" HorizontalAlignment="Center"/>

        <Button x:Name="btn_run" Content="DUPLICATE NOW" Grid.Row="7" Margin="0,5,0,0" Height="40" 
                Background="#FF8C00" Foreground="White" FontWeight="Bold" BorderThickness="0" Cursor="Hand"/>
    </Grid>
</Window>
"""

RESULT_XAML = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Result" Width="400" SizeToContent="Height"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize" Background="#F8F9FA">
    <Grid Margin="15">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>
        <TextBlock Text="PROCESSING COMPLETE" FontWeight="Bold" Foreground="#28A745" HorizontalAlignment="Center" Margin="0,0,0,10"/>
        <Border Grid.Row="1" BorderBrush="#DDD" BorderThickness="1" Background="White" CornerRadius="3" MaxHeight="300">
            <ScrollViewer VerticalScrollBarVisibility="Auto">
                <ItemsControl x:Name="result_list" Margin="10">
                    <ItemsControl.ItemTemplate>
                        <DataTemplate>
                            <StackPanel Orientation="Horizontal" Margin="0,3,0,3">
                                <TextBlock Text="{Binding Status}" Foreground="{Binding Color}" FontWeight="Bold" Margin="0,0,8,0"/>
                                <TextBlock Text="{Binding Message}" TextTrimming="CharacterEllipsis"/>
                            </StackPanel>
                        </DataTemplate>
                    </ItemsControl.ItemTemplate>
                </ItemsControl>
            </ScrollViewer>
        </Border>
        <Button x:Name="btn_close" Content="CLOSE" Grid.Row="2" Margin="0,15,0,0" Height="35" Background="#6C757D" Foreground="White" FontWeight="Bold" BorderThickness="0" Cursor="Hand"/>
    </Grid>
</Window>
"""

# --- DATA MODELS ---
class LevelItem:
    def __init__(self, level_elem):
        self.Name = level_elem.Name
        self.Element = level_elem
        self.IsChecked = False 

class TemplateOption:
    def __init__(self, name, id):
        self.Name = name
        self.Id = id

# Class đại diện cho một Dòng View Nguồn (View Name + Template Box)
class SourceViewRow:
    def __init__(self, view_elem, available_templates):
        self.ViewName = view_elem.Name
        self.ViewElement = view_elem
        self.TemplateOptions = available_templates # List các template để fill vào combobox
        self.SelectedTemplate = available_templates[0] # Mặc định chọn cái đầu tiên (Giữ nguyên)

class ResultItem:
    def __init__(self, status, message, is_success=True):
        self.Status = status
        self.Message = message
        self.Color = "#28A745" if is_success else "#DC3545"
        if status == "⚠": self.Color = "#FFC107"

# --- LOGIC CLASS CHO INPUT FORM ---
class SmartDupForm(object):
    def __init__(self, levels, source_views, template_options):
        self.window = Markup.XamlReader.Parse(INPUT_XAML)
        
        # 1. Setup Levels
        self.level_items = [LevelItem(l) for l in levels]
        self.levels_list = self.window.FindName("levels_list")
        self.levels_list.ItemsSource = self.level_items
        
        # 2. Setup Source View Rows (Với ComboBox Template riêng cho từng dòng)
        self.source_rows = []
        for view in source_views:
            row = SourceViewRow(view, template_options)
            self.source_rows.append(row)
            
        self.source_list = self.window.FindName("source_list")
        self.source_list.ItemsSource = self.source_rows
        
        # 3. Setup Naming
        self.txt_prefix = self.window.FindName("txt_prefix")
        self.txt_prefix.Text = "" 
        self.txt_suffix = self.window.FindName("txt_suffix")
        self.txt_suffix.Text = " Copy" 
        
        # Events
        self.window.FindName("chk_all").Checked += self.CheckAll_Click
        self.window.FindName("chk_all").Unchecked += self.UncheckAll_Click
        self.window.FindName("btn_run").Click += self.Run_Click
        
        self.cb_mode = self.window.FindName("cb_mode")
        self.values = {}

    def CheckAll_Click(self, sender, args):
        for item in self.level_items: item.IsChecked = True
        self.levels_list.Items.Refresh()

    def UncheckAll_Click(self, sender, args):
        for item in self.level_items: item.IsChecked = False
        self.levels_list.Items.Refresh()

    def Run_Click(self, sender, args):
        selected_levels = [x.Element for x in self.level_items if x.IsChecked]
        if not selected_levels:
            forms.alert("Chọn ít nhất 1 Level đi fen!")
            return
        
        # Thu thập cấu hình View + Template từ List
        view_configs = []
        for row in self.source_rows:
            view_configs.append({
                "view": row.ViewElement,
                "template_id": row.SelectedTemplate.Id
            })

        self.values = {
            "levels": selected_levels,
            "mode": self.cb_mode.SelectedIndex,
            "prefix": self.txt_prefix.Text,
            "suffix": self.txt_suffix.Text,
            "view_configs": view_configs # Trả về list config thay vì 1 template chung
        }
        self.window.DialogResult = True
        self.window.Close()

    def show(self):
        return self.window.ShowDialog()

class ResultWindow(object):
    def __init__(self, results):
        self.window = Markup.XamlReader.Parse(RESULT_XAML)
        self.window.FindName("result_list").ItemsSource = results
        self.window.FindName("btn_close").Click += lambda s, e: self.window.Close()
    def show(self):
        self.window.ShowDialog()

# ==============================================================================
# MAIN SCRIPT
# ==============================================================================
doc = revit.doc
uidoc = revit.uidoc

# 1. THU THẬP VIEW NGUỒN
source_views = []
selection_ids = uidoc.Selection.GetElementIds()

if selection_ids:
    for eid in selection_ids:
        el = doc.GetElement(eid)
        if hasattr(el, "ViewType") and str(el.ViewType).endswith("Plan") and not el.IsTemplate:
            source_views.append(el)
if not source_views:
    if str(doc.ActiveView.ViewType).endswith("Plan"):
        source_views.append(doc.ActiveView)
if not source_views:
    forms.alert("Fen phải chọn View Plan trong Project Browser hoặc mở View lên nhé!", exitscript=True)

# 2. CHUẨN BỊ TEMPLATE OPTIONS (CHUNG CHO TẤT CẢ COMBOBOX)
all_views = FilteredElementCollector(doc).OfClass(View).ToElements()
template_options = []
template_options.append(TemplateOption("Giữ nguyên (Gốc)", ElementId(-1)))
template_options.append(TemplateOption("<None> (Bỏ Template)", ElementId.InvalidElementId))

# Lấy các Template thực tế (cùng loại với view đầu tiên để lọc bớt)
raw_templates = []
for v in all_views:
    if v.IsTemplate and v.ViewType == source_views[0].ViewType: 
        raw_templates.append(v)
raw_templates.sort(key=lambda x: x.Name)
for t in raw_templates:
    template_options.append(TemplateOption(t.Name, t.Id))

# 3. CHUẨN BỊ LEVEL
all_levels = FilteredElementCollector(doc).OfClass(revit.DB.Level).ToElements()
all_levels = sorted(all_levels, key=lambda x: x.Elevation)

# 4. HIỆN FORM
form = SmartDupForm(all_levels, source_views, template_options)
if form.show() != True:
    script.exit()

inputs = form.values
selected_levels = inputs["levels"]
is_detailing = (inputs["mode"] == 1)
view_configs = inputs["view_configs"] # List chứa cặp {view, template_id}

# 5. THỰC THI
t = Transaction(doc, "Smart Clone V13")
t.Start()

results_log = []

# Duyệt qua từng cấu hình (Mỗi view nguồn kèm template đã chọn)
for config in view_configs:
    src_view = config["view"]
    selected_template_id = config["template_id"]
    
    src_type_id = src_view.GetTypeId()
    
    # Xác định ID Template cuối cùng
    final_template_id = ElementId.InvalidElementId
    if selected_template_id == ElementId(-1): 
        final_template_id = src_view.ViewTemplateId
    else:
        final_template_id = selected_template_id

    # Gom đối tượng 2D
    net_ids_to_copy = None
    if is_detailing:
        collector = FilteredElementCollector(doc, src_view.Id)
        elements_in_view = collector.WhereElementIsNotElementType().ToElements()
        ids_to_copy = []
        for el in elements_in_view:
            if el.ViewSpecific and el.Category and el.Category.Name != "Views" and el.Id != src_view.Id:
                 ids_to_copy.append(el.Id)
        if ids_to_copy:
            net_ids_to_copy = List[ElementId](ids_to_copy)

    # Grid Data
    src_grids = FilteredElementCollector(doc, src_view.Id).OfClass(Grid).ToElements()

    for target_lvl in selected_levels:
        if src_view.GenLevel and src_view.GenLevel.Id == target_lvl.Id:
            continue

        try:
            # A. Tạo View
            new_view = ViewPlan.Create(doc, src_type_id, target_lvl.Id)
            
            # B. Đặt Tên
            base_name = "{}{}{}".format(inputs["prefix"], src_view.Name, inputs["suffix"])
            try: new_view.Name = base_name
            except:
                safe_name = "{} - {}".format(base_name, target_lvl.Name)
                try: new_view.Name = safe_name
                except: new_view.Name = safe_name + " (Copy)"

            # [FIX] C. GÁN SCOPE BOX (Trước khi ốp Template)
            try:
                sb_param_src = src_view.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP)
                if sb_param_src and sb_param_src.HasValue:
                    sb_id = sb_param_src.AsElementId()
                    sb_param_new = new_view.get_Parameter(BuiltInParameter.VIEWER_VOLUME_OF_INTEREST_CROP)
                    if sb_param_new:
                        sb_param_new.Set(sb_id)
            except: pass

            # D. Ốp Template (Theo lựa chọn riêng của view này)
            if final_template_id != ElementId.InvalidElementId:
                new_view.ViewTemplateId = final_template_id

            # E. Crop Box
            if src_view.CropBoxActive:
                new_view.CropBoxActive = True
                new_view.CropBoxVisible = src_view.CropBoxVisible
                try:
                    src_crop = src_view.GetCropRegionShapeManager()
                    loop = src_crop.GetCropShape()[0]
                    new_view.GetCropRegionShapeManager().SetCropShape(loop)
                except: pass 

            # F. Paste Detailing (Safe Mode)
            status_symbol = "✔"
            if is_detailing and net_ids_to_copy:
                is_perfect = smart_copy_elements(doc, src_view, new_view, net_ids_to_copy)
                if not is_perfect: status_symbol = "⚠" 

            # Fix Grid
            for g in src_grids:
                try:
                    is_start_visible = g.IsBubbleVisibleInView(DatumEnds.End0, src_view)
                    is_end_visible = g.IsBubbleVisibleInView(DatumEnds.End1, src_view)
                    g.ShowBubbleInView(DatumEnds.End0, new_view, is_start_visible)
                    g.ShowBubbleInView(DatumEnds.End1, new_view, is_end_visible)
                except: pass

            # Fix Scale
            try: new_view.Scale = src_view.Scale
            except: pass 

            results_log.append(ResultItem(status_symbol, new_view.Name, True))

        except Exception as e:
            results_log.append(ResultItem("✘", "Lỗi {}: {}".format(target_lvl.Name, str(e)), False))

t.Commit()
res_window = ResultWindow(results_log)
res_window.show()