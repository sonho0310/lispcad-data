# -*- coding: utf-8 -*-
"""
Master Layout V25: Force Delete Old Views (Regenerate Fix)
"""
__title__ = "Master Layout"

# --- IMPORTS ---
from Autodesk.Revit.DB import (
    Transaction, ViewSheet, Viewport, FilteredElementCollector, 
    View, ElementId, ViewType
)
from pyrevit import revit, script, forms
import clr
from System.Collections.Generic import List # Import List C# để xóa batch

# --- WPF / UI IMPORTS ---
clr.AddReference("PresentationFramework")
clr.AddReference("WindowsBase")
clr.AddReference("PresentationCore")
clr.AddReference("System")

from System.Windows import Markup, Window
from System.Collections.ObjectModel import ObservableCollection

# ==============================================================================
# UI XAML
# ==============================================================================
XAML_STRING = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Master Layout" Height="720" Width="950"
        WindowStartupLocation="CenterScreen" ResizeMode="NoResize" 
        WindowStyle="None" AllowsTransparency="True" Background="Transparent">
    
    <Window.Resources>
        <Style x:Key="RoundedButton" TargetType="Button">
            <Setter Property="Background" Value="#FFA500"/>
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontWeight" Value="Bold"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}" CornerRadius="20" BorderThickness="0">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Background" Value="#FF8C00"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="CloseButton" TargetType="Button">
            <Setter Property="Background" Value="Transparent"/>
            <Setter Property="Foreground" Value="#999"/>
            <Setter Property="FontSize" Value="18"/>
            <Setter Property="FontWeight" Value="Bold"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border Background="{TemplateBinding Background}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter Property="Foreground" Value="#DC3545"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="RoundedTextBox" TargetType="TextBox">
            <Setter Property="Padding" Value="10,5"/>
            <Setter Property="VerticalContentAlignment" Value="Center"/>
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="TextBox">
                        <Border Background="White" BorderBrush="#FFD580" BorderThickness="1" CornerRadius="15">
                            <ScrollViewer x:Name="PART_ContentHost"/>
                        </Border>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>
    </Window.Resources>

    <Border Background="White" CornerRadius="15" BorderBrush="#DDD" BorderThickness="1" Padding="20">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="Auto"/> <RowDefinition Height="*"/>    <RowDefinition Height="Auto"/> </Grid.RowDefinitions>

            <Grid Grid.Row="0" Margin="0,0,0,5" Background="Transparent" x:Name="drag_area">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                
                <StackPanel Orientation="Horizontal">
                    <TextBlock Text="🏗️" FontSize="20" Margin="0,0,10,0"/>
                    <TextBlock Text="MASTER LAYOUT" FontWeight="Bold" FontSize="18" Foreground="#FFA500" VerticalAlignment="Center"/>
                    <TextBlock Text="(VIEW SWAPPER)" FontWeight="Normal" FontSize="14" Foreground="Gray" VerticalAlignment="Center" Margin="10,2,0,0"/>
                </StackPanel>

                <Button x:Name="btn_close" Grid.Column="1" Content="✕" Style="{StaticResource CloseButton}" Width="30" Height="30"/>
            </Grid>
            
            <TextBlock Grid.Row="1" Text="⚠️ Lưu ý: Chỉ thay thế được những view chưa có trong sheet. View cũ sau khi thay thế sẽ bị XÓA (trừ Legend)." 
                       FontSize="11" Foreground="#DC3545" FontStyle="Italic" Margin="35,0,0,15"/>

            <Grid Grid.Row="2" Margin="0,0,0,15">
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="*"/>
                </Grid.ColumnDefinitions>
                <TextBlock Text="🔍 LỌC NHANH:" VerticalAlignment="Center" FontWeight="Bold" Foreground="#FFA500" Margin="0,0,10,0"/>
                <TextBox x:Name="txt_search" Grid.Column="1" Style="{StaticResource RoundedTextBox}" 
                         Height="35" ToolTip="Nhập tên view mới muốn tìm (VD: T5)"/>
            </Grid>

            <Border Grid.Row="3" Background="#FFF8E1" CornerRadius="5" Margin="0,0,0,5" Padding="0,8">
                <Grid>
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="50"/>
                        <ColumnDefinition Width="300"/>
                        <ColumnDefinition Width="40"/>
                        <ColumnDefinition Width="*"/>
                    </Grid.ColumnDefinitions>
                    <TextBlock Text="NO." FontWeight="Bold" Foreground="#FFA500" HorizontalAlignment="Center"/>
                    <TextBlock Text="VIEW HIỆN TẠI (OLD)" FontWeight="Bold" Foreground="#555" Grid.Column="1" Margin="10,0,0,0"/>
                    <TextBlock Text="➔" FontWeight="Bold" Foreground="#FFA500" HorizontalAlignment="Center" Grid.Column="2"/>
                    <TextBlock Text="CHỌN VIEW MỚI (TARGET)" FontWeight="Bold" Foreground="#555" Grid.Column="3" Margin="10,0,0,0"/>
                </Grid>
            </Border>

            <Border Grid.Row="4" BorderBrush="#EEE" BorderThickness="1" Background="White" CornerRadius="5">
                <ScrollViewer VerticalScrollBarVisibility="Auto">
                    <ItemsControl x:Name="view_list">
                        <ItemsControl.ItemTemplate>
                            <DataTemplate>
                                <Border BorderBrush="#F5F5F5" BorderThickness="0,0,0,1" Padding="0,5">
                                    <Grid Background="White">
                                        <Grid.ColumnDefinitions>
                                            <ColumnDefinition Width="50"/>
                                            <ColumnDefinition Width="300"/>
                                            <ColumnDefinition Width="40"/>
                                            <ColumnDefinition Width="*"/>
                                        </Grid.ColumnDefinitions>
                                        
                                        <TextBlock Text="{Binding Index}" VerticalAlignment="Center" HorizontalAlignment="Center" Foreground="#999" FontWeight="SemiBold"/>
                                        
                                        <StackPanel Grid.Column="1" VerticalAlignment="Center" Margin="10,0,0,0">
                                            <TextBlock Text="{Binding OldName}" FontWeight="SemiBold" Foreground="#333" TextTrimming="CharacterEllipsis" ToolTip="{Binding OldName}"/>
                                            <TextBlock Text="{Binding ViewType}" FontSize="10" Foreground="#AAA"/>
                                        </StackPanel>

                                        <TextBlock Text="➔" Grid.Column="2" HorizontalAlignment="Center" VerticalAlignment="Center" Foreground="#DDD"/>

                                        <ComboBox Grid.Column="3" 
                                                  ItemsSource="{Binding DisplayedOptions}" 
                                                  SelectedItem="{Binding SelectedOption}"
                                                  DisplayMemberPath="Name"
                                                  Height="35" 
                                                  Margin="10,0,10,0"
                                                  VerticalContentAlignment="Center"
                                                  IsEditable="False" Background="White"/>
                                    </Grid>
                                </Border>
                            </DataTemplate>
                        </ItemsControl.ItemTemplate>
                    </ItemsControl>
                </ScrollViewer>
            </Border>

            <Grid Grid.Row="5" Margin="0,20,0,0">
                <Button x:Name="btn_run" Content="THỰC HIỆN (APPLY)" Height="45" Style="{StaticResource RoundedButton}"/>
            </Grid>
        </Grid>
    </Border>
</Window>
"""

# --- DATA MODELS ---
class ViewOption(object):
    def __init__(self, view):
        self.Name = view.Name
        self.Element = view
        self.Id = view.Id

class SwapRow(object):
    def __init__(self, index, viewport, doc, all_views):
        self.Index = index
        self.Viewport = viewport
        
        view = doc.GetElement(viewport.ViewId)
        self.OldView = view
        self.OldName = view.Name
        self.ViewType = str(view.ViewType)
        
        self.FullOptions = []
        self.KeepOption = ViewOption(view)
        self.KeepOption.Name = "(Giữ nguyên) " + view.Name
        
        compatible_views = [v for v in all_views if v.ViewType == view.ViewType and v.Id != view.Id]
        compatible_views.sort(key=lambda x: x.Name)
        
        for v in compatible_views:
            self.FullOptions.append(ViewOption(v))
            
        self.DisplayedOptions = ObservableCollection[object]()
        self.ResetOptions()
        self.SelectedOption = self.KeepOption

    def ResetOptions(self):
        self.DisplayedOptions.Clear()
        self.DisplayedOptions.Add(self.KeepOption)
        for opt in self.FullOptions:
            self.DisplayedOptions.Add(opt)

    def ApplyFilter(self, text):
        self.DisplayedOptions.Clear()
        self.DisplayedOptions.Add(self.KeepOption) 
        
        if not text:
            for opt in self.FullOptions:
                self.DisplayedOptions.Add(opt)
        else:
            keyword = text.lower()
            for opt in self.FullOptions:
                if keyword in opt.Name.lower():
                    self.DisplayedOptions.Add(opt)
        
        if self.SelectedOption not in self.DisplayedOptions:
            self.SelectedOption = self.KeepOption

# --- LOGIC FORM ---
class MasterLayoutForm(object):
    def __init__(self, doc, sheet):
        self.doc = doc
        self.window = Markup.XamlReader.Parse(XAML_STRING)
        
        self.all_views_cache = []
        collector = FilteredElementCollector(doc).OfClass(View)
        for v in collector:
            if not v.IsTemplate and v.ViewType not in [ViewType.DrawingSheet, ViewType.Internal]:
                self.all_views_cache.append(v)
        
        vp_ids = sheet.GetAllViewports()
        self.rows = []
        for i, vp_id in enumerate(vp_ids):
            vp = doc.GetElement(vp_id)
            if vp:
                self.rows.append(SwapRow(i+1, vp, doc, self.all_views_cache))

        self.view_list = self.window.FindName("view_list")
        self.view_list.ItemsSource = self.rows
        
        # --- EVENT HANDLERS ---
        self.window.FindName("btn_run").Click += self.Run_Click
        self.window.FindName("btn_close").Click += self.Close_Click
        self.window.MouseLeftButtonDown += self.Drag_Window
        
        self.txt_search = self.window.FindName("txt_search")
        self.txt_search.TextChanged += self.Search_Changed

    def Search_Changed(self, sender, args):
        text = self.txt_search.Text
        for row in self.rows:
            row.ApplyFilter(text)

    def Drag_Window(self, sender, args):
        try: self.window.DragMove()
        except: pass

    def Close_Click(self, sender, args):
        self.window.Close()

    def Run_Click(self, sender, args):
        self.window.DialogResult = True
        self.window.Close()

    def show(self):
        return self.window.ShowDialog()

# ==============================================================================
# MAIN SCRIPT
# ==============================================================================
doc = revit.doc
uidoc = revit.uidoc

active_view = doc.ActiveView
if active_view.ViewType != ViewType.DrawingSheet:
    forms.alert("Fen phải mở Sheet cần chỉnh sửa lên trước đã!", exitscript=True)

form = MasterLayoutForm(doc, active_view)
if form.show() != True:
    script.exit()

t = Transaction(doc, "Master Layout Swap")
t.Start()

# Danh sách chứa ID các view cũ cần xóa
views_to_delete = List[ElementId]()

try:
    for row in form.rows:
        selected_view = row.SelectedOption.Element
        
        # Nếu có sự thay đổi view
        if selected_view.Id != row.OldView.Id:
            old_vp = row.Viewport
            old_view_element = row.OldView 
            
            center_pt = old_vp.GetBoxCenter()
            type_id = old_vp.GetTypeId()

            try:
                # 1. Xóa Viewport cũ
                doc.Delete(old_vp.Id)
                
                # 2. Tạo Viewport mới
                new_vp = Viewport.Create(doc, active_view.Id, selected_view.Id, center_pt)
                try: new_vp.ChangeTypeId(type_id)
                except: pass
                
                # 3. GOM ID VIEW CŨ ĐỂ XÓA SAU
                # Chỉ xóa nếu KHÔNG PHẢI là Legend và không phải là Template (an toàn)
                if old_view_element.ViewType != ViewType.Legend:
                    views_to_delete.Add(old_view_element.Id)
                
            except:
                pass 

    # --- BƯỚC QUAN TRỌNG: CẬP NHẬT & XÓA ---
    # Bắt buộc Regenerate để Revit cập nhật rằng các View kia đã không còn nằm trên Sheet nữa
    doc.Regenerate()
    
    # Tiến hành xóa một thể
    if views_to_delete.Count > 0:
        try:
            doc.Delete(views_to_delete)
        except:
            pass # Nếu vẫn lỗi thì thôi, an toàn là trên hết

except:
    pass

t.Commit()