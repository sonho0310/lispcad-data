# -*- coding: utf-8 -*-
# COMBINED BATCH EXPORT MULTI-SETS (PDF & CAD) - GIAO DIỆN CHUẨN UI/UX & CUSTOM PROGRESS BAR
import clr
import os
import re
import json
import uuid 
import time
import io

# KHAI BÁO CÁC THƯ VIỆN NHÂN CỦA WINDOWS WPF ĐỂ KHÔNG BỊ LỖI IMPORT
clr.AddReference('System.Drawing')
clr.AddReference('PresentationCore')
clr.AddReference('PresentationFramework')
clr.AddReference('WindowsBase')

import System
from System import Action
from System.Windows import Visibility
from System.Windows.Threading import Dispatcher, DispatcherPriority

from System.Drawing.Printing import PrinterSettings
from pyrevit import revit, DB, UI, forms

# --- CONFIG ---
appdata_path = System.Environment.GetFolderPath(System.Environment.SpecialFolder.ApplicationData)
desktop_path = System.Environment.GetFolderPath(System.Environment.SpecialFolder.DesktopDirectory)
CONFIG_FILE = os.path.join(appdata_path, 'pyRevit_ExportAllPro_Config.json')

VIRTUAL_SET_NAME = "< TẤT CẢ BẢN VẼ >"

# --- DATA CLASS ---
class SheetItem(object):
    def __init__(self, sheet, set_name, is_checked=True):
        self.Sheet = sheet
        self.SheetNumber = sheet.SheetNumber
        self.SheetName = sheet.Name
        self.SetName = set_name
        self.IsChecked = is_checked

class VirtualSheetSet(object):
    def __init__(self, name, views):
        self.Name = name
        self.Views = views
        self.Id = DB.ElementId.InvalidElementId

# --- MAIN WINDOW ---
class ExportAllWindow(forms.WPFWindow):
    def __init__(self):
        forms.WPFWindow.__init__(self, "script.xaml")
        self.doc = revit.doc
        self.current_sheets = []
        self.dgSheets.ItemsSource = []

        self.cleanup_temp_data()

        # LOAD REPOSITORY
        db_sets = sorted(DB.FilteredElementCollector(self.doc)
                               .OfClass(DB.ViewSheetSet)
                               .ToElements(), key=lambda x: x.Name)
        
        all_sheets = DB.FilteredElementCollector(self.doc).OfClass(DB.ViewSheet).ToElements()
        all_sheets = sorted(all_sheets, key=lambda s: s.SheetNumber)
        virtual_set = VirtualSheetSet(VIRTUAL_SET_NAME, all_sheets)
        
        self.all_sets = [virtual_set] + db_sets
        self.lbSets.ItemsSource = self.all_sets

        # LOAD PDF SETTINGS
        available_printers = ["Revit Native PDF Export"]
        try:
            for p in PrinterSettings.InstalledPrinters: available_printers.append(p)
        except: pass
        self.cbPrinter.ItemsSource = available_printers
        
        self.all_print_settings = sorted(DB.FilteredElementCollector(self.doc)
                                         .OfClass(DB.PrintSetting)
                                         .ToElements(), key=lambda x: x.Name)
        self.cbPrintSetting.ItemsSource = self.all_print_settings

        # LOAD CAD SETTINGS
        dwg_setups = sorted(DB.FilteredElementCollector(self.doc)
                                         .OfClass(DB.ExportDWGSettings)
                                         .ToElements(), key=lambda x: x.Name)
        self.cmbCadSetup.ItemsSource = [s.Name for s in dwg_setups]
        if dwg_setups: self.cmbCadSetup.SelectedIndex = 0
        
        self.cmbCadVersion.ItemsSource = ["AutoCAD 2018", "AutoCAD 2013", "AutoCAD 2010"]
        self.cmbCadVersion.SelectedIndex = 0

        self.load_config()

    # --- ÉP CẬP NHẬT GIAO DIỆN ---
    def refresh_ui(self):
        """Hàm này giúp ép giao diện WPF render ngay lập tức để thanh Progress Bar chạy mượt"""
        Dispatcher.CurrentDispatcher.Invoke(DispatcherPriority.Background, Action(lambda: None))

    # --- SỰ KIỆN WPF CƠ BẢN ---
    def Window_MouseLeftButtonDown(self, sender, args):
        self.DragMove()

    def BtnClose_Click(self, sender, args):
        self.Close()

    def cleanup_temp_data(self):
        t = DB.Transaction(self.doc, "Cleanup Temporary Sets")
        try:
            t.Start()
            sets = DB.FilteredElementCollector(self.doc).OfClass(DB.ViewSheetSet).ToElements()
            for s in sets:
                if "PR_TMP_" in s.Name: self.doc.Delete(s.Id)
            t.Commit()
        except: 
            if t.GetStatus() == DB.TransactionStatus.Started: 
                t.RollBack()

    def load_config(self):
        self.txtFolder.Text = os.path.join(desktop_path, "Export_All")
        self.cbPrinter.SelectedIndex = 0
        if self.cbPrintSetting.ItemsSource: self.cbPrintSetting.SelectedIndex = 0
        self.cbPrintType.SelectedIndex = 0
        
        if not os.path.exists(CONFIG_FILE): return
            
        try:
            with io.open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content.strip(): return 
                data = json.loads(content)
                
            if 'output_folder' in data and data['output_folder']:                self.txtFolder.Text = data['output_folder']
            if 'printer' in data:
                saved_p = data['printer'].strip().lower()
                for i, p in enumerate(self.cbPrinter.ItemsSource):
                    if str(p).strip().lower() == saved_p: self.cbPrinter.SelectedIndex = i; break
            if 'print_setting' in data:
                saved_s = data['print_setting'].strip().lower()
                for i, s in enumerate(self.cbPrintSetting.ItemsSource):
                    if str(s.Name).strip().lower() == saved_s: self.cbPrintSetting.SelectedIndex = i; break
            if 'is_pdf_checked' in data: self.chkPdf.IsChecked = data['is_pdf_checked']
            if 'is_cad_checked' in data: self.chkCad.IsChecked = data['is_cad_checked']
            if 'is_combine' in data: self.cbPrintType.SelectedIndex = 0 if data['is_combine'] else 1
            if 'cad_setup' in data:
                saved_cad = data['cad_setup'].lower()
                for i, s in enumerate(self.cmbCadSetup.ItemsSource):
                    if str(s).lower() == saved_cad: self.cmbCadSetup.SelectedIndex = i; break
        except Exception:
            try: os.remove(CONFIG_FILE)
            except: pass

    def save_config(self):
        data = {
            'output_folder': self.txtFolder.Text,
            'is_combine': (self.cbPrintType.SelectedIndex == 0),
            'is_pdf_checked': bool(self.chkPdf.IsChecked),
            'is_cad_checked': bool(self.chkCad.IsChecked)
        }
        if self.cbPrinter.SelectedItem: data['printer'] = str(self.cbPrinter.SelectedItem).strip()
        if self.cbPrintSetting.SelectedItem: data['print_setting'] = str(self.cbPrintSetting.SelectedItem.Name).strip()
        if self.cmbCadSetup.SelectedItem: data['cad_setup'] = str(self.cmbCadSetup.SelectedItem)
             
        try:
            with io.open(CONFIG_FILE, 'w', encoding='utf-8') as f: 
                json.dump(data, f, ensure_ascii=False, indent=4)
        except: pass

    def sheet_set_changed(self, sender, args):
        selected_sets = self.lbSets.SelectedItems
        if not selected_sets:
            self.dgSheets.ItemsSource = []
            self.lblCount.Text = "SL: 0"
            return
            
        self.current_sheets = []
        for s_set in selected_sets:
            should_check = (s_set.Name != VIRTUAL_SET_NAME)
            for v in s_set.Views:
                if v.ViewType == DB.ViewType.DrawingSheet:
                    self.current_sheets.append(SheetItem(v, s_set.Name, is_checked=should_check))
        self.current_sheets.sort(key=lambda x: (x.SetName, x.SheetNumber))
        self.refresh_grid()

    def refresh_grid(self):
        search = self.txtSearch.Text.lower()
        hide = self.chkHideUnchecked.IsChecked
        lst = []
        for item in self.current_sheets:
            match_txt = (search in item.SheetNumber.lower()) or (search in item.SheetName.lower()) or (search in item.SetName.lower())
            match_chk = True
            if hide and not item.IsChecked: match_chk = False
            if match_txt and match_chk: lst.append(item)
        self.dgSheets.ItemsSource = lst
        self.lblCount.Text = "SL: {}".format(len(lst))

    def filter_sheets(self, sender, args): self.refresh_grid()
    def select_all_click(self, sender, args):
        for i in self.dgSheets.ItemsSource: i.IsChecked = True
        self.dgSheets.Items.Refresh()
    def deselect_all_click(self, sender, args):
        for i in self.dgSheets.ItemsSource: i.IsChecked = False
        self.dgSheets.Items.Refresh()
    def pick_folder_click(self, sender, args):
        f = forms.pick_folder()
        if f: self.txtFolder.Text = f

    def export_click(self, sender, args):
        items = self.dgSheets.ItemsSource
        if items is None or len(items) == 0:
            return forms.alert("Chưa có danh sách bản vẽ. Vui lòng chọn Sheet Set.")
            
        checked_ids = {i.Sheet.Id.IntegerValue: True for i in items if i.IsChecked}
        if not checked_ids: 
            return forms.alert("Chưa chọn bản vẽ nào để in.")
            
        do_pdf = self.chkPdf.IsChecked
        do_cad = self.chkCad.IsChecked
        
        if not do_pdf and not do_cad:
            return forms.alert("Vui lòng tích chọn ít nhất 1 định dạng (XUẤT PDF hoặc XUẤT CAD)!")

        self.save_config()
        self.cleanup_temp_data()
        
        selected_sets = self.lbSets.SelectedItems
        target_folder = self.txtFolder.Text
        
        if not os.path.exists(target_folder):
            os.makedirs(target_folder)
            
        # UI UX: Chuyển đổi giao diện sang chế độ chạy Progress Bar
        self.btnExport.IsEnabled = False
        self.btnExport.Content = "ĐANG XỬ LÝ..."
        self.btnClose.IsEnabled = False # Khóa nút đóng cửa sổ
        self.ProgressPanel.Visibility = Visibility.Visible # Hiện thanh progress bar
        self.refresh_ui()
        
        processed_count = 0
        pdf_success = 0
        cad_success_count = 0
        total_tasks = len(selected_sets)

        # Thiết lập giá trị Max cho Progress Bar
        self.pbExport.Maximum = total_tasks
        self.pbExport.Value = 0

        for idx, s_set in enumerate(selected_sets):
            # Cập nhật Text và Thanh chạy trên giao diện
            self.lblProgressText.Text = "Đang xuất: {}".format(s_set.Name)
            self.lblProgressPercent.Text = "{} / {}".format(idx + 1, total_tasks)
            self.pbExport.Value = idx + 1
            self.refresh_ui()
            
            # Lọc view
            sheets_in_set = []
            for v in s_set.Views:
                 if v.ViewType == DB.ViewType.DrawingSheet and v.Id.IntegerValue in checked_ids:
                     sheets_in_set.append(v)
            
            if not sheets_in_set: continue
            
            set_folder_name = sanitize_filename(s_set.Name)
            if s_set.Name == VIRTUAL_SET_NAME: set_folder_name = "ALL_SHEETS"
            
            # 1. EXPORT PDF
            if do_pdf:
                pdf_folder = target_folder
                printer = self.cbPrinter.SelectedItem
                selected_setting = self.cbPrintSetting.SelectedItem
                is_combine = (self.cbPrintType.SelectedIndex == 0)
                
                if "Revit Native PDF" in printer:
                    self.run_native_export(sheets_in_set, pdf_folder, s_set.Name, is_combine, selected_setting)
                    pdf_success += 1
                else:
                    if self.run_classic_print(sheets_in_set, pdf_folder, printer, is_combine, selected_setting, s_set.Name):
                        pdf_success += 1
            
            # 2. EXPORT CAD
            if do_cad:
                cad_folder = target_folder
                if len(selected_sets) > 1 or s_set.Name == VIRTUAL_SET_NAME:
                    cad_folder = os.path.join(target_folder, set_folder_name)
                if not os.path.exists(cad_folder): os.makedirs(cad_folder)
                
                cad_setup_name = self.cmbCadSetup.SelectedItem
                cad_version_txt = self.cmbCadVersion.SelectedItem
                merge_views = self.chkMergeViews.IsChecked
                
                self.run_cad_export(sheets_in_set, cad_folder, cad_setup_name, cad_version_txt, merge_views)
                cad_success_count += len(sheets_in_set)
            
            processed_count += 1
        
        # Hoàn tất vòng lặp xuất file
        self.lblProgressText.Text = "Hoàn thành!"
        self.refresh_ui()

        # Thông báo và mở thư mục, SAU ĐÓ TỰ ĐÓNG cửa sổ
        msg = "HOÀN THÀNH:\n"
        if do_pdf: msg += "- PDF: Thành công {}/{} Bộ bản vẽ.\n".format(pdf_success, processed_count)
        if do_cad: msg += "- CAD: Đã xuất thành công bản vẽ vào thư mục.\n"
        msg += "Thư mục: {}".format(target_folder)
        
        forms.alert(msg)
        try: os.startfile(target_folder)
        except: pass
        
        # Đóng tool sau khi xong hết nhiệm vụ
        self.Close()

    # === CAD EXPORT ===
    def run_cad_export(self, sheets, folder, cad_setup_name, cad_version_txt, merge_views):
        try:
            dwg_setup = next((s for s in DB.FilteredElementCollector(self.doc).OfClass(DB.ExportDWGSettings) if s.Name == cad_setup_name), None)
            options = None
            if dwg_setup: options = dwg_setup.GetDWGExportOptions()
            else: options = DB.DWGExportOptions()
            
            options.MergedViews = bool(merge_views)
            
            if "2018" in cad_version_txt: options.FileVersion = DB.ACADVersion.Default
            elif "2013" in cad_version_txt: options.FileVersion = DB.ACADVersion.R2013
            elif "2010" in cad_version_txt: options.FileVersion = DB.ACADVersion.R2010
            elif "2007" in cad_version_txt: options.FileVersion = DB.ACADVersion.R2007
            
            for s in sheets:
                name = sanitize_filename("{}-{}".format(s.SheetNumber, s.Name))
                ids = System.Collections.Generic.List[DB.ElementId]()
                ids.Add(s.Id)
                self.doc.Export(folder, name, ids, options)
        except Exception as e:
            print("Lỗi khi xuất CAD: " + str(e))

    # === NATIVE PDF EXPORT ===
    def run_native_export(self, sheets, folder, set_name, is_combine, print_setting):
        try:
            opts = DB.PDFExportOptions()
            opts.HideScopeBoxes = True
            opts.HideUnreferencedViewTags = True
            if print_setting:
                setups = DB.FilteredElementCollector(self.doc).OfClass(DB.PDFExportSetup).ToElements()
                matched = next((s for s in setups if s.Name == print_setting.Name), None)
                if matched: opts.ExportSetupId = matched.Id
                else: opts.ColorDepth = DB.ColorDepthType.Color
            
            def get_unique_native_path(base_folder, file_name):
                clean_name = sanitize_filename(file_name)
                full_check = os.path.join(base_folder, clean_name + ".pdf")
                if os.path.exists(full_check):
                    try: 
                        os.remove(full_check)
                        return clean_name
                    except: 
                        return sanitize_filename(file_name + "_" + str(uuid.uuid4())[:4])
                return clean_name

            if is_combine:
                final_name = get_unique_native_path(folder, set_name)
                opts.FileName = final_name
                opts.Combine = True
                ids = System.Collections.Generic.List[DB.ElementId]([s.Id for s in sheets])
                self.doc.Export(folder, ids, opts)
            else:
                for s in sheets:
                    final_name = get_unique_native_path(folder, "{} - {}".format(s.SheetNumber, s.Name))
                    opts.FileName = final_name
                    opts.Combine = True
                    self.doc.Export(folder, System.Collections.Generic.List[DB.ElementId]([s.Id]), opts)
        except: pass

    # === CLASSIC PRINT PDF ===
    def run_classic_print(self, sheets, folder, printer_name, is_combine, print_setting, set_name):
        try:
            print_mgr = self.doc.PrintManager
            print_jobs = []
            if is_combine:
                job_name = sanitize_filename(set_name)
                print_jobs.append((sheets, job_name))
            else:
                for s in sheets:
                    job_name = sanitize_filename("{} - {}".format(s.SheetNumber, s.Name))
                    print_jobs.append(([s], job_name))

            t_config = DB.Transaction(self.doc, "Config Printer")
            try:
                t_config.Start()
                print_mgr.SelectNewPrintDriver(printer_name)
                if print_setting:
                    try: print_mgr.PrintSetup.CurrentPrintSetting = print_setting
                    except: pass
                print_mgr.Apply()
                t_config.Commit()
            except: 
                if t_config.GetStatus() == DB.TransactionStatus.Started: t_config.RollBack()
                return False

            for job_sheets, job_filename in print_jobs:
                final_path = os.path.join(folder, job_filename + ".pdf")
                if os.path.exists(final_path):
                    try: 
                        time.sleep(0.1)
                        os.remove(final_path)
                    except: 
                        final_path = os.path.join(folder, job_filename + "_" + str(uuid.uuid4())[:4] + ".pdf")

                t_prep = DB.Transaction(self.doc, "Prepare Set")
                try:
                    t_prep.Start()
                    print_mgr.PrintRange = DB.PrintRange.Select
                    print_mgr.Apply()
                    print_mgr.PrintToFileName = final_path
                    print_mgr.PrintToFile = True
                    print_mgr.CombinedFile = True 
                    print_mgr.Apply()

                    view_set = DB.ViewSet()
                    for s in job_sheets: view_set.Insert(s)
                    
                    setting = print_mgr.ViewSheetSetting
                    setting.CurrentViewSheetSet = setting.InSession
                    setting.CurrentViewSheetSet.Views = view_set
                    
                    unique_name = "PR_TMP_" + str(uuid.uuid4())[:8]
                    setting.SaveAs(unique_name)
                    print_mgr.Apply()
                    
                    for s in DB.FilteredElementCollector(self.doc).OfClass(DB.ViewSheetSet).ToElements():
                        if s.Name == unique_name:
                            setting.CurrentViewSheetSet = s
                            print_mgr.Apply()
                            break

                    t_prep.Commit()
                except:
                    if t_prep.GetStatus() == DB.TransactionStatus.Started: t_prep.RollBack()
                    continue 

                try:
                    print_mgr.SubmitPrint()
                    time.sleep(0.5) 
                except: pass
            
            return True
        except:
            return False

def sanitize_filename(name):
    return re.sub(r'[\\/*?:"<>|]', '_', name)

if __name__ == '__main__':
    ExportAllWindow().ShowDialog()