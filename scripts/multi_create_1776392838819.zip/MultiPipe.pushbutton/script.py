# -*- coding: utf-8 -*-
from pyrevit import revit, DB, forms, script
from Autodesk.Revit.UI.Selection import ObjectType
from System.Collections.Generic import List
import math

doc = revit.doc
uidoc = revit.uidoc

# =======================================================
# HÀM HỖ TRỢ TOÁN HỌC
# =======================================================
def get_world_transform(link_instance, element):
    """Lấy Transform thực tế của element trong Link"""
    try:
        total_tf = link_instance.GetTotalTransform()
        elem_tf = element.GetTransform() # Trả về Transform của Instance
        # Nhân ma trận: Total * Local = World
        world_tf = total_tf.Multiply(elem_tf)
        return world_tf
    except:
        return None

def get_rotation_via_atan2(vec_source, vec_target):
    """Tính góc xoay chuẩn xác bằng Atan2"""
    # Atan2 trả về góc so với trục X (từ -Pi đến Pi)
    ang_src = math.atan2(vec_source.Y, vec_source.X)
    ang_tgt = math.atan2(vec_target.Y, vec_target.X)
    
    # Góc cần xoay = Góc Đích - Góc Nguồn
    angle = ang_tgt - ang_src
    return angle

# =======================================================
# BƯỚC 1: CHỌN THIẾT BỊ MẪU (SOURCE)
# =======================================================
try:
    with forms.WarningBar(title="B1: Chọn thiết bị MẪU trong Link"):
        ref_source = uidoc.Selection.PickObject(ObjectType.LinkedElement)
except:
    script.exit()

source_link_inst = doc.GetElement(ref_source.ElementId)
source_link_doc = source_link_inst.GetLinkDocument()
source_element = source_link_doc.GetElement(ref_source.LinkedElementId)

# Lấy thông tin định vị Source
src_tf = get_world_transform(source_link_inst, source_element)
if not src_tf:
    forms.alert("Lỗi: Không lấy được toạ độ thiết bị mẫu.", exitscript=True)

src_origin = src_tf.Origin
src_facing = src_tf.BasisY # Hướng mặt của thiết bị

# =======================================================
# BƯỚC 2: CHỌN CỤM ỐNG MẪU
# =======================================================
try:
    with forms.WarningBar(title="B2: Quét chọn cụm ống/phụ kiện cần Copy"):
        sel_refs = uidoc.Selection.PickObjects(ObjectType.Element)
        sample_ids = [r.ElementId for r in sel_refs]
except:
    script.exit()

if not sample_ids: script.exit()

# =======================================================
# BƯỚC 3: TÌM & COPY (ĐÃ FIX LỖI TRANSFORM)
# =======================================================
target_cat = source_element.Category.BuiltInCategory
target_fam_name = source_element.Symbol.FamilyName
target_type_name = source_element.Name

# Lọc các đối tượng tương tự trong Link
collector = DB.FilteredElementCollector(source_link_doc).OfCategory(target_cat).WhereElementIsNotElementType().ToElements()
targets = [e for e in collector if e.Symbol.FamilyName == target_fam_name and e.Name == target_type_name]
targets = [t for t in targets if t.UniqueId != source_element.UniqueId] # Bỏ qua chính nó

# Bắt đầu Transaction
t = DB.Transaction(doc, "Smart Copy V3 Fixed")
t.Start()

success_count = 0
fail_count = 0
final_selection = List[DB.ElementId]()

for target in targets:
    try:
        # 1. Lấy Transform của Target
        tgt_tf = get_world_transform(source_link_inst, target)
        if not tgt_tf: 
            fail_count += 1
            continue

        tgt_origin = tgt_tf.Origin
        tgt_facing = tgt_tf.BasisY

        # 2. Tính toán
        rotation_angle = get_rotation_via_atan2(src_facing, tgt_facing)
        translation_vec = tgt_origin - src_origin

        # 3. COPY TẠI CHỖ (FIXED)
        # Sử dụng Transform.Identity (Ma trận đơn vị) thay vì XYZ.Zero
        copied_ids = DB.ElementTransformUtils.CopyElements(
            doc, 
            List[DB.ElementId](sample_ids), 
            doc, 
            DB.Transform.Identity, # <--- ĐÃ SỬA LỖI TẠI ĐÂY (Ma trận giữ nguyên vị trí)
            None
        )
        
        final_selection.AddRange(copied_ids)

        # 4. XOAY TẠI TÂM NGUỒN (Nếu cần)
        if abs(rotation_angle) > 0.0001:
            axis_line = DB.Line.CreateBound(src_origin, src_origin + DB.XYZ.BasisZ)
            DB.ElementTransformUtils.RotateElements(doc, copied_ids, axis_line, rotation_angle)

        # 5. DI CHUYỂN ĐẾN ĐÍCH
        DB.ElementTransformUtils.MoveElements(doc, copied_ids, translation_vec)

        success_count += 1

    except Exception as e:
        fail_count += 1
        print("Lỗi tại Target {}: {}".format(target.Id, e))

t.Commit()

# =======================================================
# KẾT QUẢ
# =======================================================
if final_selection.Count > 0:
    uidoc.Selection.SetElementIds(final_selection)
    forms.alert("Xong! Đã copy cho {} thiết bị.\n(Bỏ qua/Lỗi: {})".format(success_count, fail_count))
else:
    forms.alert("Không copy được đối tượng nào.")