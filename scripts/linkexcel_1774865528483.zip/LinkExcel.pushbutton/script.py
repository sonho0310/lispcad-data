# -*- coding: utf-8 -*-
"""
LINK EXCEL (The Ultimate Edition - Clean UI & White Text)
Features: Flat UI, Loop, Schedule Sync Fix, Smart White Text, BG Color, Duplicate Header Fix
Author: Senior Developer (Win) & Fen (Co-op)
"""
import clr
clr.AddReference('System.Data')
clr.AddReference('PresentationFramework')
clr.AddReference('System.Core')

import System
import os
import time
from System.IO import File
from System.Collections.Generic import List
from System.Runtime.InteropServices import Marshal
import traceback

from pyrevit import revit, DB, forms, script

# --- 1. BASIC SETUP (CẤU HÌNH CƠ BẢN) ---
doc = revit.doc
app = doc.Application
uidoc = revit.uidoc
active_view = doc.ActiveView

# ID Nhận diện Chip của Tool
SCHEMA_GUID = System.Guid("F1E2D3C4-B5A6-9788-7766-554433221100") 
DUMMY_CATEGORY = DB.BuiltInCategory.OST_GenericModel
PT_TO_FEET = 1.0 / 864.0

# --- 2. MEMORY CHIP SYSTEM (HỆ THỐNG GHI NHỚ) ---
def get_or_create_schema():
    """Khởi tạo cấu trúc Chip để lưu thông tin đường dẫn Excel vào Revit"""
    schema = DB.ExtensibleStorage.Schema.Lookup(SCHEMA_GUID)
    if not schema:
        builder = DB.ExtensibleStorage.SchemaBuilder(SCHEMA_GUID)
        builder.SetReadAccessLevel(DB.ExtensibleStorage.AccessLevel.Public)
        builder.SetWriteAccessLevel(DB.ExtensibleStorage.AccessLevel.Public)
        builder.SetSchemaName("ArcExcelGodModeV3") 
        builder.AddSimpleField("WorkbookPath", System.String)
        builder.AddSimpleField("SourceName", System.String)
        builder.AddSimpleField("IsNamedRange", System.Boolean)
        builder.AddSimpleField("ExportType", System.String)
        builder.AddSimpleField("TableID", System.String)
        builder.AddSimpleField("TextTypeId", DB.ElementId)
        builder.AddSimpleField("LastSyncTime", System.String) 
        schema = builder.Finish()
    return schema

def safe_com_str(prop):
    """Bẫy lỗi ép kiểu text từ Excel Interop để tránh crash tool"""
    try:
        if callable(prop) or "DispCallable" in str(type(prop)): return str(prop())
        return str(prop)
    except Exception: return str(prop)

def attach_chip(element, wb_path, source_name, is_named_range, export_type, table_id="", text_type_id=DB.ElementId.InvalidElementId):
    """Cấy chip lưu trữ dữ liệu vào đối tượng (Group 2D hoặc Schedule)"""
    schema = get_or_create_schema()
    entity = DB.ExtensibleStorage.Entity(schema)
    entity.Set[System.String]("WorkbookPath", safe_com_str(wb_path))
    entity.Set[System.String]("SourceName", safe_com_str(source_name))
    entity.Set[System.Boolean]("IsNamedRange", is_named_range)
    entity.Set[System.String]("ExportType", safe_com_str(export_type))
    entity.Set[System.String]("TableID", safe_com_str(table_id))
    entity.Set[DB.ElementId]("TextTypeId", text_type_id)
    mod_time = File.GetLastWriteTime(wb_path).ToString() if os.path.exists(wb_path) else str(time.time())
    entity.Set[System.String]("LastSyncTime", mod_time)
    element.SetEntity(entity)

def read_chip(element):
    """Đọc dữ liệu chip từ đối tượng đã cấy"""
    schema = get_or_create_schema()
    entity = element.GetEntity(schema)
    if entity.IsValid():
        return {
            'wb_path': entity.Get[System.String]("WorkbookPath"),
            'source_name': entity.Get[System.String]("SourceName"),
            'is_named_range': entity.Get[System.Boolean]("IsNamedRange"),
            'export_type': entity.Get[System.String]("ExportType"),
            'table_id': entity.Get[System.String]("TableID"),
            'text_type_id': entity.Get[DB.ElementId]("TextTypeId"),
            'last_sync_time': entity.Get[System.String]("LastSyncTime")
        }
    return None

def get_excel_app():
    """Bắt session file Excel đang mở (COM Object)"""
    try: return Marshal.GetActiveObject("Excel.Application")
    except:
        t = System.Type.GetTypeFromProgID("Excel.Application")
        xl_app = System.Activator.CreateInstance(t)
        xl_app.Visible = True 
        return xl_app

# --- 3. BORDERLESS ULTRA FLAT UI (GIAO DIỆN PHẲNG TRÀN VIỀN - TEXT TRẮNG) ---
xaml_source = """
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" 
        Title="LINK EXCEL" Height="750" Width="1150" 
        WindowStartupLocation="CenterScreen" Background="#F4F7F9" FontFamily="Segoe UI"
        WindowStyle="None" AllowsTransparency="False" ResizeMode="NoResize" BorderBrush="#99CCFF" BorderThickness="2">
    <Grid>
        <Grid.RowDefinitions>
            <RowDefinition Height="45"/>
            <RowDefinition Height="*"/>
        </Grid.RowDefinitions>

        <!-- Thanh Tiêu đề Kéo Thả (Custom Header) - Đã đổi tên và chữ trắng -->
        <Grid Grid.Row="0" Background="#99CCFF" MouseLeftButtonDown="DragWindow">
            <TextBlock Text="LINK EXCEL" FontWeight="Bold" Foreground="White" VerticalAlignment="Center" Margin="15,0,0,0" FontSize="16"/>
            <Button Name="btnClose" Content="✕" Width="50" Background="#99CCFF" Foreground="White" FontWeight="Bold" FontSize="18" BorderThickness="0" HorizontalAlignment="Right" Click="btnClose_Click"/>
        </Grid>

        <Grid Grid.Row="1">
            <Grid.ColumnDefinitions>
                <ColumnDefinition Width="380"/>
                <ColumnDefinition Width="*"/>
            </Grid.ColumnDefinitions>

            <!-- Bảng điều khiển bên trái -->
            <Border Grid.Column="0" Background="White" BorderBrush="#E0E0E0" BorderThickness="0,0,1,0" Padding="20">
                <StackPanel>
                    <TextBlock Text="DATA CONTROLS" FontWeight="Bold" FontSize="18" Foreground="#003366" Margin="0,0,0,15"/>
                    
                    <TextBlock Text="1. Source Excel File:" FontWeight="SemiBold" Foreground="#555" Margin="0,0,0,5"/>
                    <ComboBox Name="cmbWorkbooks" Height="32" SelectionChanged="cmbWorkbooks_SelectionChanged" BorderThickness="1"/>
                    <Button Name="btnBrowse" Content="📂 Browse File..." Height="30" Margin="0,5,0,20" Background="#F0F0F0" BorderThickness="0" Click="btnBrowse_Click"/>
                    
                    <TextBlock Text="2. Select Table / Sheet:" FontWeight="SemiBold" Foreground="#555" Margin="0,0,0,5"/>
                    <ListBox Name="lstSource" Height="200" Margin="0,0,0,20" SelectionChanged="lstSource_SelectionChanged" BorderBrush="#99CCFF" BorderThickness="1" Background="#FAFAFA" ScrollViewer.VerticalScrollBarVisibility="Auto"/>
                    
                    <TextBlock Text="3. Export Category:" FontWeight="SemiBold" Foreground="#555" Margin="0,0,0,5"/>
                    <ComboBox Name="cmbExportType" Height="32" Margin="0,0,0,15" BorderThickness="1">
                        <ComboBoxItem Content="Schedule (BIM)" IsSelected="True"/>
                        <ComboBoxItem Content="2D Table (Drafting View)"/>
                        <ComboBoxItem Content="2D Table (Legend View)"/>
                    </ComboBox>
                    
                    <TextBlock Text="4. Text Type (For 2D Lines):" FontWeight="SemiBold" Foreground="#555" Margin="0,0,0,5"/>
                    <ComboBox Name="cmbTextType" Height="32" Margin="0,0,0,30" BorderThickness="1"/>
                    
                    <!-- Nút bấm chữ trắng -->
                    <Button Name="btnCreate" Content="✨ TRANSFER ITEMS" Height="55" Background="#99CCFF" Foreground="White" FontWeight="Bold" FontSize="15" BorderThickness="0" Click="btnCreate_Click" Margin="0,0,0,15"/>
                    <Button Name="btnGlobalSync" Content="🔄 GLOBAL SYNC" Height="50" Background="#99CCFF" Foreground="White" FontWeight="Bold" FontSize="14" BorderThickness="0" Click="btnGlobalSync_Click"/>
                    
                    <TextBlock Text="* Automatically scans and updates all Excel tables." FontSize="11" FontStyle="Italic" Foreground="Gray" TextAlignment="Center" Margin="0,8,0,0"/>
                </StackPanel>
            </Border>

            <!-- Khu vực Xem trước bên phải -->
            <Border Grid.Column="1" Padding="20">
                <Grid>
                    <Grid.RowDefinitions>
                        <RowDefinition Height="Auto"/>
                        <RowDefinition Height="*"/>
                    </Grid.RowDefinitions>
                    
                    <!-- Tiêu đề Preview chữ trắng -->
                    <Border Background="#99CCFF" Padding="12" BorderThickness="0">
                        <TextBlock Name="lblPreviewStatus" Text="PREVIEW PANEL (Please select a table on the left)" FontWeight="Bold" FontSize="14" Foreground="White"/>
                    </Border>
                    
                    <DataGrid Name="dgPreview" Grid.Row="1" AutoGenerateColumns="True" IsReadOnly="True" Background="White" BorderBrush="#99CCFF" BorderThickness="1,0,1,1" HeadersVisibility="Column" RowBackground="#FAFAFA" AlternatingRowBackground="#FFFFFF"/>
                </Grid>
            </Border>
        </Grid>
    </Grid>
</Window>
"""

class LinkExcelWindow(forms.WPFWindow):
    def __init__(self, xaml_file, xl_app, text_type_dict):
        forms.WPFWindow.__init__(self, xaml_file, literal_string=True)
        self.xl_app = xl_app
        self.type_dict = text_type_dict
        self.action = None 
        
        self.final_wb_path = ""; self.final_source_name = ""; self.final_is_named_range = False
        self.final_range = None; self.final_export_type = ""; self.final_text_type = None
        
        self.cmbTextType.ItemsSource = sorted(text_type_dict.keys())
        if self.cmbTextType.ItemsSource: self.cmbTextType.SelectedIndex = 0
        self.load_open_workbooks()

    def DragWindow(self, sender, e):
        """Cho phép kéo thả cửa sổ tự do"""
        try: self.DragMove()
        except: pass

    def btnClose_Click(self, sender, e):
        """Nút X đóng hoàn toàn tool và ngắt vòng lặp"""
        self.action = None
        self.Close()

    def load_open_workbooks(self):
        try:
            wbs = [self.xl_app.Workbooks[i].FullName for i in range(1, self.xl_app.Workbooks.Count + 1)]
            self.cmbWorkbooks.ItemsSource = wbs
            if wbs: self.cmbWorkbooks.SelectedIndex = 0
        except: pass

    def cmbWorkbooks_SelectionChanged(self, sender, e):
        try:
            wb_path = self.cmbWorkbooks.SelectedItem
            if not wb_path: return
            wb = self.xl_app.Workbooks.Item(os.path.basename(wb_path))
            sources = []
            for name_obj in wb.Names:
                try: 
                    if name_obj.RefersToRange: sources.append("🏷️ [Name] " + name_obj.Name)
                except: pass
            for i in range(1, wb.Sheets.Count + 1): sources.append("📄 [Sheet] " + wb.Sheets[i].Name)
            self.lstSource.ItemsSource = sources
        except: pass

    def btnBrowse_Click(self, sender, e):
        from Microsoft.Win32 import OpenFileDialog
        dialog = OpenFileDialog(); dialog.Filter = "Excel Files|*.xls;*.xlsx;*.xlsm"
        if dialog.ShowDialog():
            try:
                self.xl_app.Workbooks.Open(dialog.FileName)
                self.load_open_workbooks()
                self.cmbWorkbooks.SelectedItem = dialog.FileName
            except Exception as ex: forms.alert("Error opening file: " + str(ex))

    def lstSource_SelectionChanged(self, sender, e):
        try:
            wb_path = self.cmbWorkbooks.SelectedItem; source_raw = self.lstSource.SelectedItem
            if not wb_path or not source_raw: return
            wb = self.xl_app.Workbooks.Item(os.path.basename(wb_path))
            
            if source_raw.startswith("🏷️ [Name] "):
                name_str = source_raw.replace("🏷️ [Name] ", "")
                xl_range = wb.Names.Item(name_str).RefersToRange
                self.final_is_named_range = True; self.final_source_name = name_str
            else:
                sheet_name = source_raw.replace("📄 [Sheet] ", "")
                xl_range = wb.Sheets[sheet_name].UsedRange
                self.final_is_named_range = False; self.final_source_name = sheet_name
                
            self.final_range = xl_range; self.final_wb_path = wb.FullName
            
            rows = xl_range.Rows.Count; cols = xl_range.Columns.Count
            self.lblPreviewStatus.Text = "PREVIEW ({} Rows x {} Cols) - {}".format(rows, cols, self.final_source_name)
            
            view_rows = min(rows, 100); view_cols = min(cols, 20)
            dt = System.Data.DataTable()
            for c in range(view_cols): dt.Columns.Add("Col {}".format(c+1))
            for r in range(view_rows):
                dt_row = dt.NewRow()
                for c in range(view_cols): dt_row[c] = safe_com_str(xl_range.Cells[r+1, c+1].Text)
                dt.Rows.Add(dt_row)
            self.dgPreview.ItemsSource = dt.DefaultView
        except: pass

    def btnCreate_Click(self, sender, e):
        if not self.final_range: return forms.alert("Please select a table first!")
        idx = self.cmbExportType.SelectedIndex
        if idx == 0: self.final_export_type = 'SCHEDULE'
        elif idx == 1: self.final_export_type = 'DRAFTING'
        else: self.final_export_type = 'LEGEND'
        if idx > 0:
            if not self.cmbTextType.SelectedItem: return forms.alert("Please select a Text Type!")
            self.final_text_type = self.type_dict[self.cmbTextType.SelectedItem]
        self.action = 'CREATE'
        self.Close()

    def btnGlobalSync_Click(self, sender, e):
        self.action = 'GLOBAL_SYNC'
        self.Close()


# --- 4. CORE FUNCTIONS (HÀM XỬ LÝ LÕI) ---
def get_range_from_source(wb, source_name, is_named_range):
    if is_named_range: return wb.Names.Item(source_name).RefersToRange
    else: return wb.Sheets[source_name].UsedRange

def get_guid_for_param(name):
    import hashlib; m = hashlib.md5(); m.update(name.encode('utf-8'))
    return System.Guid(m.hexdigest())

def sync_schedule(xl_range, wb_path, source_name, is_named_range, table_id, target_schedule):
    """CẬP NHẬT SCHEDULE (XỬ LÝ TRÙNG LẶP TIÊU ĐỀ)"""
    rows = xl_range.Rows.Count; cols = xl_range.Columns.Count
    
    # --- 1. THUẬT TOÁN KIỂM TRA VÀ ĐÁNH SỐ NGẦM TIÊU ĐỀ TRÙNG LẶP ---
    header_data = []
    seen = {}
    for c in range(1, cols + 1):
        raw_val = safe_com_str(xl_range.Cells[1, c].Text).strip()
        if not raw_val: raw_val = "Col_{}".format(c) 
        
        if raw_val in seen:
            seen[raw_val] += 1
            unique_val = "{}_{}".format(raw_val, seen[raw_val])
        else:
            seen[raw_val] = 0
            unique_val = raw_val
            
        header_data.append({
            'raw': raw_val,                  
            'unique': "ARC_" + unique_val    
        })
    
    unique_headers = [h['unique'] for h in header_data]
    
    # --- 2. TẠO SHARED PARAMETERS NGẦM ĐỘC LẬP ---
    orig_file = app.SharedParametersFilename
    temp_file = os.path.join(os.getenv('TEMP'), "ARC_Temp_SP_{}.txt".format(int(time.time())))
    with open(temp_file, 'w') as f: f.write("")
    app.SharedParametersFilename = temp_file
    try:
        def_file = app.OpenSharedParameterFile()
        group = def_file.Groups.Create("ARC_Data")
        cat_set = app.Create.NewCategorySet()
        cat_set.Insert(doc.Settings.Categories.get_Item(DUMMY_CATEGORY))
        binding = app.Create.NewInstanceBinding(cat_set)
        
        for p_name in ["ARC_Table_ID"] + unique_headers:
            existing = DB.SharedParameterElement.Lookup(doc, get_guid_for_param(p_name))
            if not existing:
                try: opt = DB.ExternalDefinitionCreationOptions(p_name, DB.SpecTypeId.String.Text)
                except AttributeError: opt = DB.ExternalDefinitionCreationOptions(p_name, DB.ParameterType.Text)
                opt.GUID = get_guid_for_param(p_name); opt.UserModifiable = True
                ext_def = group.Definitions.Create(opt)
                doc.ParameterBindings.Insert(ext_def, binding, DB.BuiltInParameterGroup.PG_DATA)
    finally:
        app.SharedParametersFilename = orig_file
        if os.path.exists(temp_file): os.remove(temp_file)

    # --- 3. ĐỔ DỮ LIỆU CHÍNH XÁC VÀO TỪNG CỘT ---
    collector = DB.FilteredElementCollector(doc).OfClass(DB.DirectShape).OfCategory(DUMMY_CATEGORY)
    ids_del = List[DB.ElementId]()
    for ds in collector:
        p = ds.LookupParameter("ARC_Table_ID")
        if p and p.AsString() == table_id: ids_del.Add(ds.Id)
    if ids_del.Count > 0: doc.Delete(ids_del)

    for r in range(2, rows + 1): 
        ds = DB.DirectShape.CreateElement(doc, DB.ElementId(DUMMY_CATEGORY))
        ds.SetShape([DB.Line.CreateBound(DB.XYZ(0,0,-1000), DB.XYZ(0,0,-999))])
        ds.LookupParameter("ARC_Table_ID").Set(table_id)
        for c in range(1, cols + 1):
            p = ds.LookupParameter(header_data[c-1]['unique'])
            if p and not p.IsReadOnly: p.Set(safe_com_str(xl_range.Cells[r, c].Text))

    # --- 4. SETUP GIAO DIỆN SCHEDULE (GIẤU TÊN NGẦM, TRẢ LẠI TÊN GỐC) ---
    definition = target_schedule.Definition
    definition.ClearFields()
    try: definition.ClearFilters()
    except: pass

    s_fields = definition.GetSchedulableFields()
    id_field = next((f for f in s_fields if f.GetName(doc) == "ARC_Table_ID"), None)
    if id_field:
        added_id = definition.AddField(id_field)
        added_id.IsHidden = True
        definition.AddFilter(DB.ScheduleFilter(added_id.FieldId, DB.ScheduleFilterType.Equal, table_id))

    added_param_names = set() 
    
    for h_info in header_data:
        u_name = h_info['unique']
        d_name = h_info['raw']
        
        if u_name in added_param_names: continue
        
        field = next((f for f in s_fields if f.GetName(doc) == u_name), None)
        if field:
            try:
                added = definition.AddField(field)
                added.ColumnHeading = d_name 
                added_param_names.add(u_name)
            except Exception as e:
                pass 

    attach_chip(target_schedule, wb_path, source_name, is_named_range, "SCHEDULE", table_id=table_id)


def sync_2d_group(xl_range, wb_path, source_name, is_named_range, text_type, export_type, target_group):
    """CẬP NHẬT 2D (ĐỔ MÀU NỀN + MÀU CHỮ THÔNG MINH)"""
    target_view_id = target_group.OwnerViewId
    target_view = doc.GetElement(target_view_id)
    if not target_view: return
    
    rows = xl_range.Rows.Count; cols = xl_range.Columns.Count
    scale_mult = PT_TO_FEET * target_view.Scale 
    
    bbox = target_group.get_BoundingBox(target_view)
    start_pt = DB.XYZ(bbox.Min.X, bbox.Max.Y, 0) if bbox else DB.XYZ.Zero

    fr_types = DB.FilteredElementCollector(doc).OfClass(DB.FilledRegionType).ToElements()
    base_fr_type_id = fr_types[0].Id if fr_types else DB.ElementId.InvalidElementId
    
    solid_pattern_id = DB.ElementId.InvalidElementId
    patterns = DB.FilteredElementCollector(doc).OfClass(DB.FillPatternElement).ToElements()
    for p in patterns:
        try:
            fill_pattern = p.GetFillPattern()
            if hasattr(fill_pattern, 'IsSolid'):
                if fill_pattern.IsSolid:
                    solid_pattern_id = p.Id; break
            else:
                if fill_pattern.GridCount == 0:
                    solid_pattern_id = p.Id; break
        except: pass

    current_y = start_pt.Y; lines_draw = set(); created_ids = List[DB.ElementId]()
    opt = DB.TextNoteOptions(); opt.TypeId = text_type.Id
    opt.HorizontalAlignment = DB.HorizontalTextAlignment.Center
    opt.VerticalAlignment = DB.VerticalTextAlignment.Middle

    for r in range(1, rows + 1):
        current_x = start_pt.X; row_h = xl_range.Rows[r].Height * scale_mult
        for c in range(1, cols + 1):
            cell = xl_range.Cells[r, c]
            col_w = xl_range.Columns[c].Width * scale_mult
            
            if cell.MergeCells and safe_com_str(cell.Address) != safe_com_str(cell.MergeArea.Cells[1,1].Address):
                current_x += col_w; continue
                
            act_w = cell.MergeArea.Width * scale_mult if cell.MergeCells else col_w
            act_h = cell.MergeArea.Height * scale_mult if cell.MergeCells else row_h
            
            pTL = DB.XYZ(current_x, current_y, 0); pTR = DB.XYZ(current_x + act_w, current_y, 0)
            pBL = DB.XYZ(current_x, current_y - act_h, 0); pBR = DB.XYZ(current_x + act_w, current_y - act_h, 0)
            
            has_background = False 
            try:
                if cell.Interior.ColorIndex != -4142 and base_fr_type_id != DB.ElementId.InvalidElementId and solid_pattern_id != DB.ElementId.InvalidElementId:
                    bg_color_val = int(cell.Interior.Color)
                    r_bg = bg_color_val & 255
                    g_bg = (bg_color_val >> 8) & 255
                    b_bg = (bg_color_val >> 16) & 255
                    
                    if not (r_bg == 255 and g_bg == 255 and b_bg == 255):
                        has_background = True 
                        rvt_bg_color = DB.Color(r_bg, g_bg, b_bg)
                        
                        loop = DB.CurveLoop()
                        loop.Append(DB.Line.CreateBound(pTL, pTR))
                        loop.Append(DB.Line.CreateBound(pTR, pBR))
                        loop.Append(DB.Line.CreateBound(pBR, pBL))
                        loop.Append(DB.Line.CreateBound(pBL, pTL))
                        
                        fr = DB.FilledRegion.Create(doc, base_fr_type_id, target_view.Id, List[DB.CurveLoop]([loop]))
                        created_ids.Add(fr.Id)
                        
                        ogs_bg = DB.OverrideGraphicSettings()
                        ogs_bg.SetSurfaceForegroundPatternId(solid_pattern_id)
                        ogs_bg.SetSurfaceForegroundPatternColor(rvt_bg_color)
                        target_view.SetElementOverrides(fr.Id, ogs_bg)
            except: pass

            for p1, p2 in [(pTL,pTR), (pBL,pBR), (pTL,pBL), (pTR,pBR)]:
                k1, k2 = "{:.4f},{:.4f}".format(p1.X, p1.Y), "{:.4f},{:.4f}".format(p2.X, p2.Y)
                lines_draw.add((p1, p2, tuple(sorted([k1, k2]))))

            val = safe_com_str(cell.Text)
            if val.strip():
                try:
                    color_val = int(cell.Font.Color)
                    r_fg = color_val & 255
                    g_fg = (color_val >> 8) & 255
                    b_fg = (color_val >> 16) & 255
                    
                    if r_fg == 255 and g_fg == 255 and b_fg == 255:
                        if has_background:
                            r_fg = g_fg = b_fg = 254 
                        else:
                            r_fg = g_fg = b_fg = 0 
                            
                    rvt_fg_color = DB.Color(r_fg, g_fg, b_fg)
                except:
                    rvt_fg_color = DB.Color(0, 0, 0) 
                
                note = DB.TextNote.Create(doc, target_view.Id, DB.XYZ(current_x + act_w/2, current_y - act_h/2, 0), val, opt)
                created_ids.Add(note.Id)
                
                ogs_fg = DB.OverrideGraphicSettings()
                ogs_fg.SetProjectionLineColor(rvt_fg_color)
                target_view.SetElementOverrides(note.Id, ogs_fg)
                
            current_x += col_w
        current_y -= row_h

    drawn_keys = set()
    for p1, p2, key in lines_draw:
        if key not in drawn_keys and p1.DistanceTo(p2) > 0.001:
            line_elem = doc.Create.NewDetailCurve(target_view, DB.Line.CreateBound(p1, p2))
            created_ids.Add(line_elem.Id)
            drawn_keys.add(key)

    if created_ids.Count > 0:
        new_group = doc.Create.NewGroup(created_ids)
        try: new_group.GroupType.Name = "LINK_EXCEL_2D_{}_{}".format(source_name, int(time.time())%1000)
        except: pass
        attach_chip(new_group, wb_path, source_name, is_named_range, export_type, text_type_id=text_type.Id)
        doc.Delete(target_group.Id) 

def execute_create_mode(xl_range, wb_path, source_name, is_named_range, text_type, export_type):
    if export_type == 'SCHEDULE':
        table_id = "ARC_TBL_" + str(int(time.time()))
        
        with revit.Transaction("Link Excel: Create Schedule View"):
            schedule_view = DB.ViewSchedule.CreateSchedule(doc, DB.ElementId(DUMMY_CATEGORY))
            schedule_view.Name = "BIM Table - " + source_name + " " + str(int(time.time())%1000)
            
        with revit.Transaction("Link Excel: Sync Schedule Data"):
            sync_schedule(xl_range, wb_path, source_name, is_named_range, table_id, schedule_view)
        
        uidoc.ActiveView = schedule_view

    else:
        with revit.Transaction("Link Excel: Create 2D View"):
            if export_type == 'DRAFTING':
                vf_col = DB.FilteredElementCollector(doc).OfClass(DB.ViewFamilyType)
                vft_id = next((v.Id for v in vf_col if v.ViewFamily == DB.ViewFamily.Drafting), None)
                target_view = DB.ViewDrafting.Create(doc, vft_id)
                target_view.Name = "Drafting_" + source_name + "_" + str(int(time.time())%1000)
            else:
                legends = DB.FilteredElementCollector(doc).OfClass(DB.View).ToElements()
                legend_base = next((v for v in legends if v.ViewType == DB.ViewType.Legend), None)
                if not legend_base: return forms.alert("No Legend View found in project to duplicate! Create an empty one first.")
                new_view_id = legend_base.Duplicate(DB.ViewDuplicateOption.Duplicate)
                target_view = doc.GetElement(new_view_id)
                target_view.Name = "Legend_" + source_name + "_" + str(int(time.time())%1000)
                trash_col = DB.FilteredElementCollector(doc, target_view.Id)
                ids_del = List[DB.ElementId]()
                for elem in trash_col:
                    if isinstance(elem, (DB.DetailCurve, DB.TextNote, DB.Group, DB.FilledRegion)): ids_del.Add(elem.Id)
                if ids_del.Count > 0: doc.Delete(ids_del)
        uidoc.ActiveView = target_view
        
        with revit.Transaction("Link Excel: Draw 2D Table With Colors"):
            dummy_line = doc.Create.NewDetailCurve(target_view, DB.Line.CreateBound(DB.XYZ(0,0,0), DB.XYZ(1,0,0)))
            dummy_group = doc.Create.NewGroup(List[DB.ElementId]([dummy_line.Id]))
            sync_2d_group(xl_range, wb_path, source_name, is_named_range, text_type, export_type, dummy_group)

# --- 5. MAIN LOGIC (VÒNG LẶP SỰ KIỆN) ---
def main():
    try:
        col = DB.FilteredElementCollector(doc).OfClass(DB.TextNoteType)
        type_dict = {"{} : {}".format(t.FamilyName, t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM).AsString()): t for t in col if t.get_Parameter(DB.BuiltInParameter.SYMBOL_NAME_PARAM)}
        xl_app = get_excel_app()
        
        while True:
            window = LinkExcelWindow(xaml_source, xl_app, type_dict)
            window.ShowDialog()
            
            if not window.action:
                break
                
            if window.action == 'CREATE':
                execute_create_mode(window.final_range, window.final_wb_path, window.final_source_name, window.final_is_named_range, window.final_text_type, window.final_export_type)

            elif window.action == 'GLOBAL_SYNC':
                chipped_items = []
                for v in DB.FilteredElementCollector(doc).OfClass(DB.ViewSchedule):
                    chip = read_chip(v)
                    if chip: chipped_items.append((v, chip))
                for g in DB.FilteredElementCollector(doc).OfClass(DB.Group):
                    chip = read_chip(g)
                    if chip: chipped_items.append((g, chip))
                    
                if not chipped_items:
                    forms.alert("No linked Excel tables found in this project!", title="LINK EXCEL")
                    continue

                count_success = 0
                with revit.TransactionGroup("Link Excel: Global Sync"):
                    t_group = DB.TransactionGroup(doc, "Global Sync")
                    t_group.Start()
                    for elem, chip in chipped_items:
                        try:
                            wb = xl_app.Workbooks.Open(chip['wb_path'])
                            xl_range = get_range_from_source(wb, chip['source_name'], chip['is_named_range'])
                            with revit.Transaction("Sync Table"):
                                if chip['export_type'] == 'SCHEDULE':
                                    sync_schedule(xl_range, chip['wb_path'], chip['source_name'], chip['is_named_range'], chip['table_id'], elem)
                                else:
                                    text_type = doc.GetElement(chip['text_type_id']) or list(type_dict.values())[0]
                                    sync_2d_group(xl_range, chip['wb_path'], chip['source_name'], chip['is_named_range'], text_type, chip['export_type'], elem)
                            count_success += 1
                        except Exception as e:
                            print("Error syncing table {}: {}".format(chip['source_name'], str(e)))
                            pass 
                    t_group.Assimilate()
                forms.alert("Successfully synced {}/{} tables across the project!".format(count_success, len(chipped_items)), title="LINK EXCEL - SYNC COMPLETE")

    except Exception as e: 
        forms.alert("ERROR:\n{}\n\n{}".format(str(e), traceback.format_exc()), title="LINK EXCEL")

if __name__ == '__main__': 
    main()