# -*- coding: utf-8 -*-
__title__ = 'Dem So\nDetail Item'

import clr
clr.AddReference('RevitAPI')
clr.AddReference('RevitAPIUI')

from Autodesk.Revit.DB import *
from Autodesk.Revit.UI import *
from Autodesk.Revit.UI.Selection import ObjectType, ISelectionFilter
from Autodesk.Revit.Exceptions import OperationCanceledException

from pyrevit import revit, forms, script

doc = revit.doc
uidoc = revit.uidoc

class DetailItemFilter(ISelectionFilter):
    def AllowElement(self, elem):
        if elem.Category and elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_DetailComponents):
            return True
        return False
    def AllowReference(self, ref, pos):
        return False

class DemSoWindow(forms.WPFWindow):
    def __init__(self, xaml_file_name, param_names, default_param):
        forms.WPFWindow.__init__(self, xaml_file_name)
        
        self.config = script.get_config()
        self.param_names = param_names
        
        # Đổ dữ liệu vào ComboBox
        self.cbParamName.ItemsSource = self.param_names
        
        # Khôi phục cài đặt lúc trước hoặc dùng mặc định
        saved_param_name = self.config.get_option('param_name', default_param)
        if saved_param_name in self.param_names:
            self.cbParamName.SelectedItem = saved_param_name
        else:
            self.cbParamName.SelectedItem = default_param
            
        self.txtPrefix.Text = self.config.get_option('prefix', 'A.4:7-')
        self.txtStartNum.Text = self.config.get_option('start_num', '1')
        self.txtStep.Text = self.config.get_option('step', '1')
        self.txtSuffix.Text = self.config.get_option('suffix', '')

        self.ret_values = {}

    def DragWindow(self, sender, e):
        # Cho phép kéo thả form
        self.DragMove()

    def Close_Click(self, sender, e):
        self.Close()

    def Start_Click(self, sender, e):
        # Validate số đầu vào
        try:
            int(self.txtStartNum.Text.strip())
            int(self.txtStep.Text.strip())
        except ValueError:
            forms.alert("Số bắt đầu và Bước nhảy phải là số nguyên!")
            return

        # Lưu thiết lập
        param_name = self.cbParamName.SelectedItem
        if not param_name:
            param_name = str(self.cbParamName.Text)
       
        self.config.param_name = str(param_name)
        self.config.prefix = str(self.txtPrefix.Text)
        self.config.start_num = str(self.txtStartNum.Text)
        self.config.step = str(self.txtStep.Text)
        self.config.suffix = str(self.txtSuffix.Text)
        script.save_config()
        
        self.ret_values = {
            'param_name': self.config.param_name,
            'prefix': self.config.prefix,
            'start_num': self.config.start_num,
            'step': self.config.step,
            'suffix': self.config.suffix
        }
        self.Close()

def main():
    sel_filter = DetailItemFilter()
    
    # 1. Lấy phần tử mẫu từ vùng chọn hiện tại, nếu không có thì yêu cầu user pick 1 cái
    selection = uidoc.Selection.GetElementIds()
    sample_elem = None
    
    if selection:
        first_elem = doc.GetElement(selection[0])
        if first_elem.Category and first_elem.Category.Id.IntegerValue == int(BuiltInCategory.OST_DetailComponents):
            sample_elem = first_elem
            
    if not sample_elem:
        try:
            sample_ref = uidoc.Selection.PickObject(ObjectType.Element, sel_filter, "Bước 1: Click chọn 1 Detail Item làm mẫu để lấy danh sách tham số (Nhấn ESC để huỷ)")
            sample_elem = doc.GetElement(sample_ref)
        except OperationCanceledException:
            # Người dùng huỷ lệnh
            return
        except Exception as e:
            print("Lỗi: {}".format(str(e)))
            return
    
    # 2. Lấy tất cả các tham số có thể ghi được (chữ hoặc số) từ đối tượng mẫu
    param_names = []
    for param in sample_elem.Parameters:
        if not param.IsReadOnly:
            if param.StorageType == StorageType.String or param.StorageType == StorageType.Integer:
                name = param.Definition.Name
                if name not in param_names:
                    param_names.append(name)
                    
    param_names.sort()
    
    if not param_names:
        forms.alert('Không tìm thấy tham số dạng Text/Integer nào có thể chỉnh sửa trong Family được chọn!', exitscript=True)
        return
        
    # Thử đẩy tham số "Mã Căn Hộ" hoặc "Mark" lên đầu cho tiện nếu có
    default_param = param_names[0]
    for p in ["Mã Căn Hộ", "Mark", "Comments"]:
        if p in param_names:
            default_param = p
            break

    # 3. Tạo giao diện từ XAML
    window = DemSoWindow('window.xaml', param_names, default_param)
    window.ShowDialog()
    
    if not window.ret_values:
        return
        
    param_name = window.ret_values.get('param_name')
    prefix = window.ret_values.get('prefix', '')
    suffix = window.ret_values.get('suffix', '')
    
    # 4. Xử lý giá trị đầu vào
    try:
        start_num_str = window.ret_values.get('start_num', '1').strip()
        current_num = int(start_num_str)
        step = int(window.ret_values.get('step', '1').strip())
        
        # Độ dài ban đầu của chuỗi (để format 01, 02, 03 nếu user nhập có số 0 ở trước)
        pad_length = len(start_num_str)
    except Exception as e:
        forms.alert('Lỗi khởi tạo thông số: {}'.format(str(e)), exitscript=True)
        return
        
    # 5. Vòng lặp đếm số
    # Note: Nếu vừa pick mẫu, ta vẫn yêu cầu người dùng pick lại chính đối tượng đó nếu muốn đánh số,
    # Điều này để thống nhất trải nghiệm "Pick là gán mã".
    while True:
        try:
            # Tạo Text số dựa trên định dạng 0 (zfill)
            num_str = str(current_num).zfill(pad_length)
            next_val = "{0}{1}{2}".format(prefix, num_str, suffix)
            
            # Gợi ý Text sẽ chạy dưới góc trái màn hình (Prompt)
            prompt_msg = "Bước 3: Click Detail Item để gán = {} (Nhấn ESC để thoát)".format(next_val)
            
            # Chức năng chọn đối tượng
            ref = uidoc.Selection.PickObject(ObjectType.Element, sel_filter, prompt_msg)
            elem = doc.GetElement(ref)
            
            # Lấy tham số Instance
            param = elem.LookupParameter(param_name)
            
            if param:
                if not param.IsReadOnly:
                    with revit.Transaction("Đánh số: {}".format(next_val)):
                        if param.StorageType == StorageType.Integer:
                            # Cố gắng gán số nguyên
                            try:
                                param.Set(int(next_val))
                                current_num += step
                            except ValueError:
                                print("Cảnh báo: Không thể gán giá trị '{}' cho tham số kiểu số nguyên (Integer).".format(next_val))
                        else:
                            # Gán text
                            param.Set(next_val)
                            current_num += step
                else:
                    print("Cảnh báo: Tham số '{}' chỉ đọc (read-only).".format(param_name))
            else:
                print("Cảnh báo: Không tìm thấy tham số '{}' trong Family được chọn lần này.".format(param_name))
                
        except OperationCanceledException:
            # Bắt lỗi khi người dùng ấn phím ESC để thoát vòng lặp PickObject
            break
        except Exception as e:
            print("Lỗi: {}".format(str(e)))
            break

if __name__ == '__main__':
    main()
